"""
CARMol: a constraint-aware language agent for molecular optimization with adaptive control and structure-indexed replay
"""
