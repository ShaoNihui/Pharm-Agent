__all__ = ["CARMolOptimizer"]


def __getattr__(name):
    """Import the optimizer lazily to keep low-level journal imports acyclic."""
    if name == "CARMolOptimizer":
        from carmol.evaluation.pmo_evaluator import CARMolOptimizer

        return CARMolOptimizer
    raise AttributeError(name)
