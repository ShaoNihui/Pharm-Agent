#!/usr/bin/env python3
"""Run PharmAgent E1/E2 with user-owned credentials and the fixed protocol."""

from __future__ import annotations

import argparse
from contextlib import contextmanager
import fcntl
import getpass
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import warnings

ROOT = Path(__file__).resolve().parent
API_ENV = "MINIMAX_API_KEY"
PHASES = {"E1": ["standard"], "E2": ["admet"], "both": ["standard", "admet"]}


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--experiment", choices=PHASES, default="both")
    result.add_argument("--workers", type=int, choices=range(1, 11), default=2)
    result.add_argument("--output-dir", type=Path, default=ROOT / "results" / "pharmagent")
    mode = result.add_mutually_exclusive_group()
    mode.add_argument("--run", action="store_true", help="Authorize a paid run after confirmation")
    mode.add_argument("--dry-run", action="store_true", help="Validate and print a zero-API plan (default)")
    result.add_argument("--yes", action="store_true", help="Confirm the printed cost envelope non-interactively; requires --run")
    return result


def command(args: argparse.Namespace, *, paid: bool) -> list[str]:
    phases = PHASES[args.experiment]
    argv = [
        sys.executable, str(ROOT / "scripts" / "run_distributed_pharmagent.py"),
        "--execute-phases", *phases,
        "--standard-config", str(ROOT / "configs" / "pmo_standard.yaml"),
        "--admet-config", str(ROOT / "configs" / "pmo_admet.yaml"),
        "--output-root", str(args.output_dir.expanduser().resolve()),
        "--max-concurrency", str(args.workers), "--resume",
    ]
    if paid:
        argv += ["--allow-paid-api", "--confirm-formal-jobs", str(5 * len(phases)),
                 "--confirm-http-attempt-cap", str(60100 * 25 * len(phases))]
    else:
        argv += ["--dry-run"]
    return argv


def read_credential() -> str:
    value = os.environ.get(API_ENV, "").strip()
    if not value:
        if not sys.stdin.isatty():
            raise ValueError(f"Set {API_ENV} in the job environment, or run in an interactive terminal.")
        # Refuse getpass's echoing fallback: never expose a pasted credential.
        with warnings.catch_warnings():
            warnings.simplefilter("error", getpass.GetPassWarning)
            value = getpass.getpass("MiniMax API key (hidden; used for this process only): ").strip()
    if not value or value == "EMPTY" or any(char.isspace() for char in value):
        raise ValueError("The credential must be one non-empty token without whitespace.")
    return value


@contextmanager
def output_lock(output_dir: Path):
    """Keep two public launchers from scheduling into the same output root."""
    output_dir.mkdir(parents=True, exist_ok=True)
    descriptor = os.open(output_dir / ".execution.lock", os.O_CREAT | os.O_RDWR, 0o600)
    try:
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise ValueError("Another launcher owns this output directory. Do not start duplicate workers.") from None
        yield descriptor
    finally:
        # The child inherits the descriptor and holds the lock if this parent
        # exits unexpectedly. Do not explicitly unlock the shared descriptor.
        os.close(descriptor)


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    if args.yes and not args.run:
        parser().error("--yes requires --run")
    if not args.run:
        plan = subprocess.run(command(args, paid=False), cwd=ROOT,
                              stdout=subprocess.PIPE, text=True, check=False)
        if plan.returncode:
            return plan.returncode
        data = json.loads(plan.stdout)
        jobs = data["execution_jobs"]
        print(json.dumps({
            "status": data["status"], "api_requests": 0,
            "credentials_accessed": data["credentials_accessed"],
            "experiment": args.experiment, "concurrent_workers": args.workers,
            "seed_workers": len(jobs), "task_runs": len(jobs) * 5,
            "oracle_budget": len(jobs) * 5000,
            "http_attempt_safety_ceiling": 60100 * len(jobs) * 5,
            "identity_sha256": jobs[0]["formal_reproduction_identity"]["identity_sha256"],
            "ordered_tasks": jobs[0]["tasks"],
            "workers": [job["job_id"] for job in jobs],
            "output_dir": str(args.output_dir.expanduser().resolve()),
        }, indent=2))
        return 0
    try:
        # Validate source, assets and dependencies before asking for a key.
        preflight = subprocess.run(command(args, paid=False), cwd=ROOT,
                                   stdout=subprocess.DEVNULL, check=False)
        if preflight.returncode:
            return preflight.returncode
        phase_count = len(PHASES[args.experiment])
        print(f"{args.experiment}: {5 * phase_count} seed workers, {25 * phase_count} tasks, "
              f"up to {25000 * phase_count:,} unique oracle evaluations.", flush=True)
        print(f"HTTP-attempt safety ceiling: {60100 * 25 * phase_count:,}. "
              "This is not a token or monetary budget; retries may incur charges.", flush=True)
        if not args.yes:
            if not sys.stdin.isatty():
                raise ValueError("Use --run --yes only after reviewing the dry-run and provider costs.")
            if input("Use your paid API account for this run? Type RUN to continue: ") != "RUN":
                print("Cancelled. No API calls made.")
                return 0
        with output_lock(args.output_dir.expanduser().resolve()) as descriptor:
            key = read_credential()
            environment = os.environ.copy()
            environment[API_ENV] = key
            process = subprocess.Popen(command(args, paid=True), cwd=ROOT, env=environment,
                                       start_new_session=True, pass_fds=(descriptor,))
            del environment, key
            try:
                return process.wait()
            except KeyboardInterrupt:
                print("Stopping the worker group; preserving checkpoints. Please wait.", flush=True)
                os.killpg(process.pid, signal.SIGINT)
                try:
                    process.wait(timeout=60)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGTERM)
                    process.wait()
                return 130
    except (ValueError, OSError, getpass.GetPassWarning, EOFError) as error:
        # Exceptions from credential capture never contain the supplied value.
        print(f"Cannot launch: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
