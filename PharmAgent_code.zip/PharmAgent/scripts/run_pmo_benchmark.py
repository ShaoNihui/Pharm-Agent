#!/usr/bin/env python
"""
Run PharmAgent on the standard PMO benchmark (23 tasks).

Usage:
    # Full benchmark
    python scripts/run_pmo_benchmark.py --config configs/pmo_standard.yaml

    # Single task, quick test
    python scripts/run_pmo_benchmark.py --tasks gsk3b --seeds 1 --oracle_budget 100

    # PMO-1K setting
    python scripts/run_pmo_benchmark.py --oracle_budget 1000
"""

import argparse
import hashlib
import json
import logging
import os
from pathlib import Path
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pharmagent.evaluation.pmo_evaluator import (
    PMO_TASKS,
    PharmAgentOptimizer,
    build_failed_pmo_checkpoint,
)
from pharmagent.evaluation.oracle_utils import (
    create_oracle,
    is_complete_diagnostic_smoke_result,
    is_complete_pmo_result,
    upsert_seed_result,
)
from pharmagent.evaluation.diagnostic_smoke import (
    DIAGNOSTIC_SMOKE_STATUS,
    label_result as label_diagnostic_smoke_result,
    validate_run_budget_mode,
)
from pharmagent.evaluation.metrics import (
    build_evaluation_history,
    compute_pmo_run_metrics,
)
from pharmagent.evaluation.formal_identity import (
    FormalIdentityError,
    parse_formal_reproduction_identity_json,
    validate_formal_arm_config,
    validate_formal_identity_against_current_workspace,
)
from pharmagent.evaluation.native_run import (
    NativeRunJournal,
    configure_native_run_journal,
    native_journal_path,
    reject_unjournaled_partial_resume,
)
from pharmagent.config import load_config
from pharmagent.llm.attempt_ledger import (
    configure_formal_attempt_ledger,
    formal_ledger_path,
)
from pharmagent.optimization.cer_runtime import (
    clear_incomplete_task,
    configure_seed_cer,
    mark_task_complete,
    persistent_seed_paths,
    require_task_complete,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)
logger = logging.getLogger(__name__)
CODE_DIR = Path(__file__).resolve().parents[1]


def _resolve_seed_indices(
    total_seeds: int, requested: list[int] | None
) -> tuple[int, ...]:
    """Return the deterministic subset of a fixed total seed population."""
    if (
        isinstance(total_seeds, bool)
        or not isinstance(total_seeds, int)
        or total_seeds <= 0
    ):
        raise RuntimeError("--seeds must be a positive integer")
    if requested is None:
        return tuple(range(total_seeds))
    if not requested:
        raise RuntimeError("--seed-indices requires at least one seed")
    if any(
        isinstance(seed, bool)
        or not isinstance(seed, int)
        or seed < 0
        or seed >= total_seeds
        for seed in requested
    ):
        raise RuntimeError(
            "--seed-indices must be within the fixed --seeds range"
        )
    if len(requested) != len(set(requested)):
        raise RuntimeError("--seed-indices must not contain duplicates")
    return tuple(sorted(requested))


def main():
    parser = argparse.ArgumentParser(description="Run PharmAgent PMO benchmark")
    parser.add_argument("--config", type=str, default="configs/pmo_standard.yaml")
    parser.add_argument("--tasks", nargs="+", default=None,
                        help="Specific tasks to run (default: all 23)")
    parser.add_argument("--seeds", type=int, default=5,
                        help="Number of random seeds per task")
    parser.add_argument(
        "--seed-indices",
        nargs="+",
        type=int,
        default=None,
        help=(
            "Run only these zero-based seed indices while --seeds retains "
            "the total seed population (for isolated seed workers)"
        ),
    )
    parser.add_argument("--oracle_budget", type=int, default=None,
                        help="Override oracle budget from config")
    parser.add_argument("--output_dir", type=str, default="results/pmo_standard")
    parser.add_argument(
        "--cer-root",
        type=Path,
        default=None,
        help=(
            "Persist Chemical-CER in one SQLite database per seed; tasks must "
            "run together in their declared order to enable cross-task transfer"
        ),
    )
    parser.add_argument(
        "--resume", action=argparse.BooleanOptionalAction, default=True,
        help=(
            "Skip completed task/seed runs and continue compatible incomplete "
            "runs from their identity-bound native journal. Indeterminate "
            "in-flight HTTP/oracle events fail closed instead of being repeated."
        ),
    )
    parser.add_argument(
        "--llm-ledger-root",
        type=Path,
        default=None,
        help=(
            "Root for isolated formal paid-attempt ledgers (default: "
            "OUTPUT_DIR/llm_attempt_ledgers when require_full_budget=true)"
        ),
    )
    parser.add_argument(
        "--native-journal-root",
        type=Path,
        default=None,
        help=(
            "Root for exact task/seed oracle, LLM, and optimizer journals "
            "(default: OUTPUT_DIR/native_run_journals for formal runs)"
        ),
    )
    parser.add_argument(
        "--formal-reproduction-identity",
        default=None,
        help=(
            "Canonical identity JSON supplied by the formal distributed driver; "
            "required for full-budget runs"
        ),
    )
    parser.add_argument(
        "--diagnostic-smoke",
        action="store_true",
        help=(
            "Run a reduced-budget paid smoke under a paid_smoke_* identity. "
            "Outputs use diagnostic_complete and are never submission eligible."
        ),
    )
    args = parser.parse_args()
    seed_indices = _resolve_seed_indices(args.seeds, args.seed_indices)

    # Load config
    config = load_config(args.config)
    configured_formal_budget = config.get("optimization", {}).get(
        "oracle_budget", 10000
    )
    require_full_budget = config.get("optimization", {}).get(
        "require_full_budget", False
    )
    tasks = args.tasks or PMO_TASKS
    formal_identity = None
    if require_full_budget:
        expected_seeds = config.get("evaluation", {}).get("seeds")
        if (
            not args.diagnostic_smoke
            and args.seeds != expected_seeds
        ):
            raise RuntimeError(
                "formal full-budget runs require --seeds to retain the "
                f"configured total seed population ({expected_seeds})"
            )
        try:
            # Validate the canonical on-disk PMO-1K protocol before a
            # diagnostic CLI override changes only the runtime budget.
            validate_formal_arm_config(config, "standard")
        except FormalIdentityError as error:
            raise RuntimeError(
                f"invalid standard formal protocol: {error}"
            ) from error
        if not args.formal_reproduction_identity:
            raise RuntimeError(
                "full-budget formal runs require "
                "--formal-reproduction-identity from the distributed driver"
            )
        try:
            formal_identity = parse_formal_reproduction_identity_json(
                args.formal_reproduction_identity
            )
        except FormalIdentityError as error:
            raise RuntimeError(f"invalid formal reproduction identity: {error}") from error
        try:
            formal_identity = validate_formal_identity_against_current_workspace(
                formal_identity,
                code_dir=CODE_DIR,
                matrix_scope=formal_identity["matrix_scope"],
                task_chain=tasks,
            )
        except FormalIdentityError as error:
            raise RuntimeError(
                "formal reproduction identity is not current: "
                f"{error}"
            ) from error
        config_sha = hashlib.sha256(Path(args.config).resolve().read_bytes()).hexdigest()
        if formal_identity["formal_config_sha256"]["standard"] != config_sha:
            raise RuntimeError(
                "formal reproduction identity does not match the standard config"
            )
        # CER identity is derived from the scientific config before runtime
        # paths are injected.  Bind it to the same source/assets/dependencies
        # identity so cross-task experience can never survive a protocol change.
        config["formal_reproduction_identity"] = formal_identity

    if args.oracle_budget is not None:
        config.setdefault("optimization", {})["oracle_budget"] = args.oracle_budget
    oracle_budget = config.get("optimization", {}).get("oracle_budget", 10000)

    validate_run_budget_mode(
        diagnostic_smoke=args.diagnostic_smoke,
        require_full_budget=require_full_budget,
        configured_formal_budget=configured_formal_budget,
        oracle_budget=oracle_budget,
        formal_identity=formal_identity,
    )
    if (
        require_full_budget
        and config.get("cer", {}).get("enabled", False)
        and args.cer_root is None
    ):
        raise RuntimeError(
            "formal full-budget Chemical-CER requires --cer-root for exact "
            "crash-resume visibility"
        )

    llm_ledger_root = None
    native_journal_root = None
    if require_full_budget:
        llm_ledger_root = (
            args.llm_ledger_root
            if args.llm_ledger_root is not None
            else Path(args.output_dir) / "llm_attempt_ledgers"
        ).expanduser().resolve()
        native_journal_root = (
            args.native_journal_root
            if args.native_journal_root is not None
            else Path(args.output_dir) / "native_run_journals"
        ).expanduser().resolve()
    os.makedirs(args.output_dir, exist_ok=True)
    if not args.resume:
        cer_paths_by_seed = dict(enumerate(persistent_seed_paths(
            config, cer_root=args.cer_root, seeds=args.seeds
        )))
        existing_cer = [
            cer_paths_by_seed[seed]
            for seed in seed_indices
            if seed in cer_paths_by_seed
            and cer_paths_by_seed[seed].exists()
        ]
        if existing_cer:
            raise RuntimeError(
                "--no-resume refuses existing CER databases; choose a new "
                f"--cer-root (first existing path: {existing_cer[0]})"
            )
        if llm_ledger_root is not None:
            existing_ledgers = [
                path
                for task in tasks
                for seed in seed_indices
                if (
                    path := formal_ledger_path(
                        llm_ledger_root,
                        phase="standard",
                        task=task,
                        seed=seed,
                    )
                ).exists()
            ]
            if existing_ledgers:
                raise RuntimeError(
                    "--no-resume refuses an existing paid-attempt ledger; "
                    "choose a new --llm-ledger-root "
                    f"(first existing path: {existing_ledgers[0]})"
                )
        if native_journal_root is not None:
            existing_journals = [
                path
                for task in tasks
                for seed in seed_indices
                if (
                    path := native_journal_path(
                        native_journal_root,
                        phase="standard",
                        task=task,
                        seed=seed,
                    )
                ).exists()
            ]
            if existing_journals:
                raise RuntimeError(
                    "--no-resume refuses an existing native run journal; "
                    "choose a new --native-journal-root "
                    f"(first existing path: {existing_journals[0]})"
                )

    logger.info("=" * 60)
    logger.info("PharmAgent PMO Benchmark")
    logger.info(
        "Tasks: %d, Total seeds: %d, Selected seeds: %s, Oracle budget: %d",
        len(tasks), args.seeds, list(seed_indices), oracle_budget,
    )
    logger.info("=" * 60)

    all_results = _load_results(args.output_dir) if args.resume else {}
    total_start = time.time()

    for task_idx, task in enumerate(tasks):
        logger.info("\n%s", "=" * 60)
        logger.info("[%d/%d] Task: %s", task_idx + 1, len(tasks), task)
        logger.info("=" * 60)

        task_results = all_results.setdefault(task, [])
        for seed in seed_indices:
            seed_config = configure_seed_cer(
                config,
                cer_root=args.cer_root,
                seed=seed,
                phase="standard",
                tasks=tasks,
            )
            completed_result = _completed_seed_result(
                task_results,
                task,
                seed,
                oracle_budget,
                formal_identity_sha256=(
                    formal_identity["identity_sha256"]
                    if formal_identity is not None else None
                ),
                diagnostic_smoke=args.diagnostic_smoke,
            )
            if completed_result is not None:
                require_task_complete(
                    seed_config,
                    task=task,
                    task_index=task_idx,
                    result=completed_result,
                )
                logger.info("  Seed %d/%d already complete; skipping", seed + 1, args.seeds)
                continue
            if llm_ledger_root is not None:
                seed_config = configure_formal_attempt_ledger(
                    seed_config,
                    ledger_root=llm_ledger_root,
                    phase="standard",
                    task=task,
                    seed=seed,
                    formal_reproduction_identity=formal_identity,
                )
            native_journal = None
            if native_journal_root is not None:
                journal_path = native_journal_path(
                    native_journal_root,
                    phase="standard",
                    task=task,
                    seed=seed,
                )
                reject_unjournaled_partial_resume(
                    seed_config,
                    journal_path=journal_path,
                    task=task,
                    seed=seed,
                    checkpoint_rows=task_results,
                )
                seed_config = configure_native_run_journal(
                    seed_config,
                    journal_root=native_journal_root,
                    phase="standard",
                    task=task,
                    seed=seed,
                    oracle_budget=oracle_budget,
                    formal_reproduction_identity=formal_identity,
                )
                native_spec = seed_config["native_run_journal"]
                native_journal = NativeRunJournal(
                    native_spec["path"], identity=native_spec["identity"]
                )
            logger.info("  Seed %d/%d", seed + 1, args.seeds)
            np.random.seed(seed)

            removed = (
                0
                if native_journal is not None
                else clear_incomplete_task(seed_config, task)
            )
            if removed:
                logger.info(
                    "    Removed %d partial CER rows before clean resume", removed
                )
            for prior_index, prior_task in enumerate(tasks[:task_idx]):
                prior_result = _completed_seed_result(
                    all_results.get(prior_task, []),
                    prior_task,
                    seed,
                    oracle_budget,
                    formal_identity_sha256=(
                        formal_identity["identity_sha256"]
                        if formal_identity is not None else None
                    ),
                    diagnostic_smoke=args.diagnostic_smoke,
                )
                if prior_result is None:
                    raise RuntimeError(
                        "CER task order is incomplete: cannot start "
                        f"{task}/seed_{seed} before {prior_task}/seed_{seed}"
                    )
                require_task_complete(
                    seed_config,
                    task=prior_task,
                    task_index=prior_index,
                    result=prior_result,
                    require_experience_presence=prior_index == task_idx - 1,
                )

            oracle = create_oracle(
                task,
                oracle_budget,
                native_journal=native_journal,
            )
            optimizer = PharmAgentOptimizer(seed_config)

            seed_start = time.time()
            try:
                result = optimizer.optimize(oracle, seed_config, seed=seed)
            except Exception as error:
                failed = build_failed_pmo_checkpoint(
                    error,
                    optimizer=optimizer,
                    oracle=oracle,
                    task=task,
                    seed=seed,
                    oracle_budget=oracle_budget,
                    elapsed_time=time.time() - seed_start,
                    evaluation_history=(
                        native_journal.evaluation_history()
                        if native_journal is not None
                        else build_evaluation_history(oracle.mol_buffer)
                    ),
                )
                if formal_identity is not None:
                    failed["formal_reproduction_identity"] = formal_identity
                upsert_seed_result(task_results, failed)
                _save_results(all_results, args.output_dir)
                raise RuntimeError(
                    f"Formal run failed for {task}/seed_{seed}: "
                    f"optimizer_exception:{type(error).__name__}"
                ) from None
            elapsed = time.time() - seed_start

            evaluation_history = (
                native_journal.evaluation_history()
                if native_journal is not None
                else build_evaluation_history(oracle.mol_buffer)
            )
            result["evaluation_history"] = evaluation_history
            result["metrics"] = compute_pmo_run_metrics(
                evaluation_history, oracle_budget=oracle_budget
            )

            result["elapsed_time"] = elapsed
            result["task"] = task
            result["seed"] = seed
            result["oracle_budget"] = oracle_budget
            if formal_identity is not None:
                result["formal_reproduction_identity"] = formal_identity
            if args.diagnostic_smoke and result.get("status") == "complete":
                result = label_diagnostic_smoke_result(
                    result,
                    phase="standard",
                    configured_formal_budget=configured_formal_budget,
                )
            valid_result = (
                is_complete_diagnostic_smoke_result(
                    result,
                    task=task,
                    seed=seed,
                    oracle_budget=oracle_budget,
                    expected_formal_identity_sha256=formal_identity[
                        "identity_sha256"
                    ],
                    require_novelty_recovery_protocol=True,
                    require_near_feasible_repair_protocol=True,
                    require_native_run_journal=True,
                )
                if args.diagnostic_smoke
                else is_complete_pmo_result(
                    result,
                    task=task,
                    seed=seed,
                    oracle_budget=oracle_budget,
                    expected_formal_identity_sha256=(
                        formal_identity["identity_sha256"]
                        if formal_identity is not None else None
                    ),
                    require_novelty_recovery_protocol=True,
                    require_near_feasible_repair_protocol=True,
                    require_native_run_journal=(formal_identity is not None),
                )
            )
            expected_status = (
                DIAGNOSTIC_SMOKE_STATUS
                if args.diagnostic_smoke
                else "complete"
            )
            if not valid_result and result.get("status") == expected_status:
                result["status"] = "failed"
                result["termination_reason"] = "postrun_validation_failed"
            upsert_seed_result(task_results, result)
            if result.get("status") == expected_status:
                mark_task_complete(
                    seed_config,
                    task=task,
                    task_index=task_idx,
                    result=result,
                )

            # Per-seed checkpoint: a long API sweep can be resumed without
            # losing already completed seeds.
            _save_results(all_results, args.output_dir)

            if result.get("status") != expected_status:
                raise RuntimeError(
                    f"Run failed for {task}/seed_{seed}: "
                    f"{result.get('termination_reason', 'unknown')}"
                )

            logger.info(
                "    Result: best_score=%.4f, AUC Top-10=%.4f, combined=%.4f, "
                "oracle_calls=%d, time=%.1fs",
                result["metrics"].get("top_1", 0),
                result["metrics"].get("auc_top_10", 0),
                result.get("best_combined_score", 0),
                result.get("total_oracle_calls", 0),
                elapsed,
            )

    # Final save with timestamped archival copy
    _save_results(all_results, args.output_dir, final=True)

    total_elapsed = time.time() - total_start
    logger.info("\n%s", "=" * 60)
    logger.info("Benchmark complete! Total time: %.1fs", total_elapsed)
    logger.info("Results saved to %s", args.output_dir)

    # Print summary
    _print_summary(all_results)


def _save_results(results: dict, output_dir: str, final: bool = False):
    """Save results to JSON.

    Incremental saves overwrite results_latest.json as a recovery checkpoint.
    When *final* is True, also writes a timestamped copy for archival.
    """
    out_path = os.path.join(output_dir, "results_latest.json")

    # Convert to serializable format
    serializable = {}
    for task, seed_results in results.items():
        serializable[task] = []
        for r in seed_results:
            # This is the recovery checkpoint, not the normalized
            # publication artifact.  Preserve the bounded optimizer memory so
            # resume and native-journal validation can prove exact state
            # continuity after the checkpoint is reloaded.
            sr = dict(r)
            sr["trajectory"] = r.get("trajectory", [])
            serializable[task].append(sr)

    _write_json_atomic(out_path, serializable)

    if final:
        from datetime import datetime
        ts_path = os.path.join(
            output_dir,
            f"results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
        )
        _write_json_atomic(ts_path, serializable)


def _write_json_atomic(path: str, value: dict) -> None:
    """Write a JSON checkpoint atomically so interruption cannot corrupt it."""
    temporary = f"{path}.tmp"
    with open(temporary, "w") as file:
        json.dump(value, file, indent=2, default=str)
    os.replace(temporary, path)


def _load_results(output_dir: str) -> dict:
    path = os.path.join(output_dir, "results_latest.json")
    if not os.path.exists(path):
        return {}
    try:
        with open(path) as file:
            value = json.load(file)
    except (OSError, json.JSONDecodeError) as error:
        raise RuntimeError(f"Cannot resume invalid checkpoint {path}: {error}") from error
    if not isinstance(value, dict):
        raise RuntimeError(f"Cannot resume checkpoint with non-object root: {path}")
    logger.info("Resuming from %s", path)
    return value


def _has_completed_seed(
    seed_results: list,
    task: str,
    seed: int,
    oracle_budget: int,
    formal_identity_sha256: str | None = None,
    diagnostic_smoke: bool = False,
) -> bool:
    return _completed_seed_result(
        seed_results,
        task,
        seed,
        oracle_budget,
        formal_identity_sha256=formal_identity_sha256,
        diagnostic_smoke=diagnostic_smoke,
    ) is not None


def _completed_seed_result(
    seed_results: list,
    task: str,
    seed: int,
    oracle_budget: int,
    formal_identity_sha256: str | None = None,
    diagnostic_smoke: bool = False,
) -> dict | None:
    return next((
        result
        for result in seed_results
        if
        (
            is_complete_diagnostic_smoke_result(
                result,
                task=task,
                seed=seed,
                oracle_budget=oracle_budget,
                expected_formal_identity_sha256=formal_identity_sha256,
                require_novelty_recovery_protocol=True,
                require_near_feasible_repair_protocol=True,
                require_native_run_journal=True,
            )
            if diagnostic_smoke and formal_identity_sha256 is not None
            else is_complete_pmo_result(
                result,
                task=task,
                seed=seed,
                oracle_budget=oracle_budget,
                expected_formal_identity_sha256=formal_identity_sha256,
                require_novelty_recovery_protocol=True,
                require_near_feasible_repair_protocol=True,
                require_native_run_journal=(
                    formal_identity_sha256 is not None
                ),
            )
        )
    ), None)


def _print_summary(results: dict):
    """Print summary table of results."""
    logger.info("\nSummary:")
    logger.info(
        "%-30s %10s %10s %10s %10s",
        "Task", "Avg Top-1", "Avg AUC10", "Avg Combined", "Avg Calls",
    )
    logger.info("-" * 74)

    sum_scores = []
    for task, seed_results in results.items():
        scores = [r.get("metrics", {}).get("top_1", 0) for r in seed_results]
        aucs = [r.get("metrics", {}).get("auc_top_10", 0) for r in seed_results]
        combined = [r.get("best_combined_score", 0) for r in seed_results]
        calls = [r.get("total_oracle_calls", 0) for r in seed_results]
        avg_s = np.mean(scores)
        avg_auc = np.mean(aucs)
        avg_c = np.mean(combined)
        avg_calls = np.mean(calls)
        sum_scores.append(avg_auc)
        logger.info(
            "%-30s %10.4f %10.4f %10.4f %10.0f",
            task, avg_s, avg_auc, avg_c, avg_calls,
        )

    logger.info("-" * 74)
    logger.info("%-30s %10s %10.4f", "Task Sum", "", sum(sum_scores))


if __name__ == "__main__":
    main()
