#!/usr/bin/env python3
"""Run the formal matrix as phase-and-seed-isolated local workers.

Each worker owns one global seed and contains every task in canonical order.
Different seeds and phases may run concurrently, while Chemical-CER still
transfers experience across tasks within the same phase/seed lineage.  Task-level
shards remain forbidden because they would silently turn CER into per-task memory.
The parent process limits concurrency, keeps the MiniMax credential in memory,
redacts child output before writing logs, and atomically checkpoints scheduler
state.  A failed task does not cancel unrelated work.

The default invocation is deliberately a zero-API plan::

    python scripts/run_distributed_pharmagent.py --dry-run

Paid execution requires explicit acknowledgement plus both exact
numeric confirmations printed by the dry-run::

    python scripts/run_distributed_pharmagent.py \
        --allow-paid-api --confirm-formal-jobs 10 \
        --confirm-http-attempt-cap 3005000
"""

from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
from typing import Any, Callable, Mapping, Sequence

from openai import OpenAI
import yaml


CODE_DIR = Path(__file__).resolve().parents[1]
if str(CODE_DIR) not in sys.path:
    sys.path.insert(0, str(CODE_DIR))

from pharmagent.evaluation.oracle_utils import is_complete_pmo_result  # noqa: E402
from pharmagent.evaluation.formal_identity import (  # noqa: E402
    FormalIdentityError,
    build_formal_reproduction_identity,
    validate_formal_reproduction_identity,
)
from pharmagent.evaluation.pmo_evaluator import (  # noqa: E402
    DEFAULT_SEEDS,
    PMO_TASKS,
)
from pharmagent.optimization.novelty_recovery import (  # noqa: E402
    CANONICAL_NOVELTY_RECOVERY_PROTOCOL,
)
from pharmagent.llm.api_client import (  # noqa: E402
    MINIMAX_API_KEY_ENV,
    MINIMAX_BACKEND,
    MINIMAX_BASE_URL,
    MINIMAX_MAX_TOKEN_PARAMETER,
    MINIMAX_MODEL,
    MINIMAX_PROVIDER_TRANSPORT,
    MINIMAX_REGION,
    MINIMAX_REASONING_SPLIT,
    MINIMAX_SERVICE_TIER,
    MINIMAX_THINKING_TYPE,
)
from pharmagent.llm.attempt_ledger import (  # noqa: E402
    FORMAL_HTTP_ATTEMPT_CAP_PER_RUN,
    FORMAL_MAX_LOGICAL_REQUESTS_PER_ROUND,
    FORMAL_NOMINAL_LOGICAL_REQUESTS_PER_ROUND,
)


FIVE_TASKS = (
    "gsk3b",
    "jnk3",
    "drd2",
    "sitagliptin_mpo",
    "albuterol_similarity",
)
FORMAL_PHASES = ("standard", "admet")
MATRIX_TASK_CHAINS = {
    "five_task_main": FIVE_TASKS,
    "pmo_23_task_appendix": tuple(PMO_TASKS),
}
FORMAL_SEEDS = 5
FORMAL_ORACLE_BUDGET = 1000
FORMAL_VALIDITY_ONLY_VERIFIER = {
    "check_lipinski": False,
    "check_veber": False,
    "check_pains": False,
    "check_brenk": False,
    "check_sa": False,
    "check_qed": False,
    "max_sa_score": 6.0,
    "min_qed": 0.3,
}
FORMAL_CURRICULUM_TRANSITION_POLICY = "round_boundary_only"
DEFAULT_MAX_CONCURRENCY = 10
MANIFEST_SCHEMA_VERSION = 6
DEFAULT_OUTPUT_ROOT = Path("results/pharmagent")


class DistributedRunError(RuntimeError):
    """Raised before execution when a formal scheduling invariant is broken."""


@dataclass(frozen=True)
class JobSpec:
    job_id: str
    phase: str
    task: str
    config_path: Path
    runner_path: Path
    output_dir: Path
    log_path: Path
    argv: tuple[str, ...]
    tasks: tuple[str, ...] = ()
    seed_indices: tuple[int, ...] = ()
    formal_reproduction_identity: Mapping[str, Any] | None = None

    @property
    def selected_tasks(self) -> tuple[str, ...]:
        """Tasks owned by this job, including single-task specifications."""
        return self.tasks or (self.task,)

    def selected_seeds(self, total_seeds: int) -> tuple[int, ...]:
        """Global seed indices owned by this worker."""
        return self.seed_indices or tuple(range(total_seeds))

    def public_record(self) -> dict[str, Any]:
        """Return the non-secret, stable job description stored in state."""
        record = {
            "job_id": self.job_id,
            "phase": self.phase,
            "task": self.task,
            "tasks": list(self.selected_tasks),
            "seed_indices": list(self.seed_indices),
            "config": str(self.config_path),
            "config_sha256": _sha256_file(self.config_path),
            "runner": str(self.runner_path),
            "runner_sha256": _sha256_file(self.runner_path),
            "output_dir": str(self.output_dir),
            "log_path": str(self.log_path),
            "command": list(self.argv),
        }
        if self.formal_reproduction_identity is not None:
            record["formal_reproduction_identity"] = (
                validate_formal_reproduction_identity(
                    self.formal_reproduction_identity
                )
            )
        return record


@dataclass(frozen=True)
class JobOutcome:
    returncode: int
    error_type: str | None = None


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _json_sha256(value: Mapping[str, Any]) -> str:
    payload = json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _atomic_write_json(
    path: Path, value: Mapping[str, Any], *, forbidden_secret: str | None = None
) -> None:
    """Atomically persist JSON with owner-only permissions and optional guard."""
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False)
    if forbidden_secret and forbidden_secret in payload:
        raise DistributedRunError(
            "refusing to persist scheduler state containing the API credential"
        )
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    descriptor = os.open(
        temporary,
        os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
        0o600,
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            handle.write(payload)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        try:
            directory_fd = os.open(path.parent, os.O_RDONLY)
        except OSError:
            return
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    finally:
        if temporary.exists():
            temporary.unlink()


def _load_json_object(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise DistributedRunError(
            f"cannot read scheduler state {path}: {type(error).__name__}"
        ) from None
    if not isinstance(value, dict):
        raise DistributedRunError(f"scheduler state root is not an object: {path}")
    return value


def _load_yaml(path: Path) -> dict[str, Any]:
    try:
        value = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, yaml.YAMLError) as error:
        raise DistributedRunError(
            f"cannot read formal config {path}: {type(error).__name__}"
        ) from None
    if not isinstance(value, dict):
        raise DistributedRunError(f"formal config root is not a mapping: {path}")
    return value


def _validate_formal_config(path: Path, phase: str) -> None:
    value = _load_yaml(path)
    llm = value.get("llm")
    expected_llm = {
        "backend": MINIMAX_BACKEND,
        "model": MINIMAX_MODEL,
        "api_key_env": MINIMAX_API_KEY_ENV,
        "base_url": MINIMAX_BASE_URL,
        "region": MINIMAX_REGION,
        "thinking_type": MINIMAX_THINKING_TYPE,
        "reasoning_split": MINIMAX_REASONING_SPLIT,
        "service_tier": MINIMAX_SERVICE_TIER,
        "provider_transport": MINIMAX_PROVIDER_TRANSPORT,
        "max_token_parameter": MINIMAX_MAX_TOKEN_PARAMETER,
        "temperature": 0.7,
        "max_tokens": 2048,
        "max_retries": 10,
        "retry_delay": 2,
        "max_retry_delay": 30,
        "max_retry_elapsed": 180,
        "max_transport_recovery_batches": 3,
    }
    observed_llm = {
        field: llm.get(field) if isinstance(llm, Mapping) else None
        for field in expected_llm
    }
    if observed_llm != expected_llm:
        raise DistributedRunError(
            f"{phase} config must pin canonical MiniMax-M3 China-region "
            "chat semantics"
        )

    optimization = value.get("optimization")
    admet = value.get("admet")
    reviewer = value.get("reviewer")
    generator = value.get("generator")
    verifier = value.get("verifier")
    novelty_recovery = value.get("novelty_recovery")
    if (
        not isinstance(optimization, Mapping)
        or not isinstance(admet, Mapping)
        or not isinstance(reviewer, Mapping)
        or not isinstance(generator, Mapping)
        or not isinstance(verifier, Mapping)
    ):
        raise DistributedRunError(f"{phase} config is missing protocol mappings")
    full_budget_valid = (
        optimization.get("require_full_budget") is True
        and reviewer.get("allow_early_termination") is False
        and isinstance(optimization.get("max_rounds"), int)
        and not isinstance(optimization.get("max_rounds"), bool)
        and optimization["max_rounds"] >= FORMAL_ORACLE_BUDGET
        and FORMAL_HTTP_ATTEMPT_CAP_PER_RUN
        >= FORMAL_MAX_LOGICAL_REQUESTS_PER_ROUND
        * optimization["max_rounds"]
        and generator.get("n_candidates")
        == CANONICAL_NOVELTY_RECOVERY_PROTOCOL[
            "candidate_cap_per_generator_call"
        ]
        and novelty_recovery
        == CANONICAL_NOVELTY_RECOVERY_PROTOCOL
        and dict(verifier) == FORMAL_VALIDITY_ONLY_VERIFIER
    )
    if phase == "standard":
        valid = (
            optimization.get("objective") == "target_only"
            and admet.get("admet_constraints") == {}
        )
    else:
        lagrangian = value.get("lagrangian")
        curriculum = value.get("curriculum")
        valid = (
            optimization.get("objective") == "admet_constrained"
            and admet.get("backend") == "admet_ai"
            and admet.get("fallback_to_rdkit") is False
            and admet.get("missing_prediction_policy") == "fail"
            and admet.get("allow_approximate_endpoint_fallback") is False
            and isinstance(lagrangian, Mapping)
            and lagrangian.get("enabled") is True
            and lagrangian.get("reset_rho_on_phase_transition") is True
            and lagrangian.get("rho_growth_rule")
            == "accepted_violation_only"
            and lagrangian.get("rho_init") == 1.0
            and lagrangian.get("rho_growth") == 1.5
            and lagrangian.get("rho_max") == 100.0
            and isinstance(curriculum, Mapping)
            and curriculum.get("enabled") is True
            and curriculum.get("transition_policy")
            == FORMAL_CURRICULUM_TRANSITION_POLICY
            and curriculum.get("phase1_rounds") == 20
            and curriculum.get("phase2_rounds") == 60
            and curriculum.get("easy_constraints")
            == ["lipinski_mw", "lipinski_logp", "qed", "sa_score"]
            and curriculum.get("stagnation_trigger") == 5
            and reviewer.get("max_stagnation_rounds") == 5
        )
    if not valid or not full_budget_valid:
        raise DistributedRunError(f"{phase} config does not match the formal arm")

    rag = value.get("rag")
    if not isinstance(rag, Mapping):
        raise DistributedRunError(f"{phase} config is missing RAG paths")
    for field in ("faiss_index_path", "mmp_data_path"):
        raw_path = rag.get(field)
        if not isinstance(raw_path, str) or not raw_path.strip():
            raise DistributedRunError(f"{phase} config has invalid rag.{field}")
        asset = Path(raw_path).expanduser()
        if not asset.is_absolute():
            asset = CODE_DIR / asset
        if not asset.is_file() or not os.access(asset, os.R_OK):
            raise DistributedRunError(f"{phase} RAG asset is unavailable: {asset}")


def _resolve_python(value: str) -> str:
    candidate = Path(value).expanduser()
    if candidate.is_absolute() or candidate.parent != Path("."):
        if not candidate.is_file() or not os.access(candidate, os.X_OK):
            raise DistributedRunError(f"Python executable is unavailable: {candidate}")
        return str(candidate.resolve())
    resolved = shutil.which(value)
    if resolved is None:
        raise DistributedRunError(f"Python executable is unavailable: {value}")
    return str(Path(resolved).resolve())


def build_jobs(
    *,
    phases: Sequence[str],
    tasks: Sequence[str],
    seeds: int,
    oracle_budget: int,
    output_root: Path,
    python_executable: str,
    standard_config: Path,
    admet_config: Path,
    resume: bool,
    formal_reproduction_identity: Mapping[str, Any],
) -> list[JobSpec]:
    """Build one deterministic, credential-free command per phase and seed.

    One global seed's complete ordered task chain is the smallest safe formal
    shard.  This permits seed-level concurrency without breaking Chemical-CER
    transfer across tasks or sharing mutable state between seeds.
    """
    config_by_phase = {
        "standard": standard_config.resolve(),
        "admet": admet_config.resolve(),
    }
    runner_by_phase = {
        "standard": CODE_DIR / "scripts" / "run_pmo_benchmark.py",
        "admet": CODE_DIR / "scripts" / "run_admet_pmo.py",
    }
    jobs: list[JobSpec] = []
    ordered_tasks = tuple(tasks)
    formal_identity = validate_formal_reproduction_identity(
        formal_reproduction_identity
    )
    if tuple(formal_identity["task_chain"]) != ordered_tasks:
        raise DistributedRunError(
            "formal reproduction identity task_chain does not match the "
            "distributed phase bundle"
        )
    formal_identity_json = json.dumps(
        formal_identity,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    )
    for phase in phases:
        cer_root = (output_root / "cer" / phase).resolve()
        llm_ledger_root = (output_root / "llm_attempt_ledgers").resolve()
        native_journal_root = (output_root / "native_run_journals").resolve()
        runner = runner_by_phase[phase].resolve()
        for seed in range(seeds):
            output_dir = (
                output_root / "seed_shards" / phase / f"seed_{seed}"
            ).resolve()
            log_path = (
                output_root / "logs" / f"{phase}_seed_{seed}.log"
            ).resolve()
            argv = (
                python_executable,
                str(runner),
                "--config",
                str(config_by_phase[phase]),
                "--tasks",
                *ordered_tasks,
                "--seeds",
                str(seeds),
                "--seed-indices",
                str(seed),
                "--oracle_budget",
                str(oracle_budget),
                "--output_dir",
                str(output_dir),
                "--cer-root",
                str(cer_root),
                "--llm-ledger-root",
                str(llm_ledger_root),
                "--native-journal-root",
                str(native_journal_root),
                "--formal-reproduction-identity",
                formal_identity_json,
                "--resume" if resume else "--no-resume",
            )
            jobs.append(
                JobSpec(
                    job_id=f"{phase}_seed_{seed}",
                    phase=phase,
                    task=ordered_tasks[0],
                    tasks=ordered_tasks,
                    seed_indices=(seed,),
                    config_path=config_by_phase[phase],
                    runner_path=runner,
                    output_dir=output_dir,
                    log_path=log_path,
                    argv=argv,
                    formal_reproduction_identity=formal_identity,
                )
            )
    return jobs


def _driver_identity(
    jobs: Sequence[JobSpec], *, seeds: int, oracle_budget: int
) -> dict[str, Any]:
    seed_universe = list(range(seeds))
    shard_partition = {
        phase: [
            list(job.seed_indices)
            for job in jobs
            if job.phase == phase
        ]
        for phase in sorted({job.phase for job in jobs})
    }
    return {
        "schema_version": MANIFEST_SCHEMA_VERSION,
        "seeds": seeds,
        "seed_universe": seed_universe,
        "seed_shard_partition": shard_partition,
        "seed_merge_contract": {
            "schema_version": 1,
            "key": ["task", "seed"],
            "duplicate_missing_or_extra_seed_policy": "fail_closed",
            "publication": "exact_complete_seed_universe_only",
            "ordering": "ascending_global_seed",
        },
        "oracle_budget": oracle_budget,
        "nominal_logical_requests_per_round": (
            FORMAL_NOMINAL_LOGICAL_REQUESTS_PER_ROUND
        ),
        "max_logical_requests_per_round": (
            FORMAL_MAX_LOGICAL_REQUESTS_PER_ROUND
        ),
        "hard_http_attempt_cap_per_task_seed": FORMAL_HTTP_ATTEMPT_CAP_PER_RUN,
        "jobs": [job.public_record() for job in jobs],
    }


def _request_exposure_plan(
    *,
    phases: Sequence[str],
    tasks: Sequence[str],
    seeds: int,
    configs: Mapping[str, Path],
) -> dict[str, Any]:
    """Return a credential-free request estimate and hard paid envelope.

    ``nominal_min`` assumes all five requested candidates are valid, unique,
    and consume the remaining oracle budget each round.  The round-cap ceiling
    includes the conditional novelty repair (at most 2 Generator + 1 Reviewer
    logical calls). Network retries also consume the ledger.  The per-run
    HTTP cap therefore covers that maximum logical path plus the fixed retry
    margin, rather than making full-budget completion depend on how often the
    preregistered novelty recovery is exercised.
    """
    per_phase: dict[str, dict[str, int]] = {}
    candidates_by_phase: dict[str, int] = {}
    nominal_min_total = 0
    nominal_round_cap_total = 0
    theoretical_round_cap_total = 0
    hard_total = 0
    runs_per_phase = len(tasks) * seeds
    for phase in phases:
        value = _load_yaml(configs[phase])
        max_rounds = int(value["optimization"]["max_rounds"])
        n_candidates = int(value.get("generator", {}).get("n_candidates", 5))
        candidates_by_phase[phase] = n_candidates
        seed_pool_calls = min(len(DEFAULT_SEEDS), FORMAL_ORACLE_BUDGET)
        remaining_calls = max(0, FORMAL_ORACLE_BUDGET - seed_pool_calls)
        nominal_rounds = math.ceil(remaining_calls / max(1, n_candidates))
        nominal_min = (
            FORMAL_NOMINAL_LOGICAL_REQUESTS_PER_ROUND
            * nominal_rounds
            * runs_per_phase
        )
        nominal_round_cap = (
            FORMAL_NOMINAL_LOGICAL_REQUESTS_PER_ROUND
            * max_rounds
            * runs_per_phase
        )
        theoretical_round_cap = (
            FORMAL_MAX_LOGICAL_REQUESTS_PER_ROUND
            * max_rounds
            * runs_per_phase
        )
        hard_cap = FORMAL_HTTP_ATTEMPT_CAP_PER_RUN * runs_per_phase
        per_phase[phase] = {
            "task_seed_runs": runs_per_phase,
            "seed_shards": seeds,
            "hard_http_attempt_cap_per_seed_shard": (
                FORMAL_HTTP_ATTEMPT_CAP_PER_RUN * len(tasks)
            ),
            "max_rounds_per_run": max_rounds,
            "nominal_rounds_per_run": nominal_rounds,
            "nominal_min_logical_requests": nominal_min,
            "nominal_round_cap_logical_requests": nominal_round_cap,
            "theoretical_max_logical_requests_before_round_cap": (
                theoretical_round_cap
            ),
            "hard_http_attempt_cap": hard_cap,
        }
        nominal_min_total += nominal_min
        nominal_round_cap_total += nominal_round_cap
        theoretical_round_cap_total += theoretical_round_cap
        hard_total += hard_cap
    return {
        # Keep the user-facing "expected" name, but bind it to an explicit
        # ideal-fill estimate rather than mislabelling the round-cap ceiling.
        "expected_logical_requests": nominal_min_total,
        "nominal_min_logical_requests": nominal_min_total,
        "nominal_round_cap_logical_requests": nominal_round_cap_total,
        "theoretical_max_logical_requests_before_round_cap": (
            theoretical_round_cap_total
        ),
        "hard_http_attempt_cap": hard_total,
        "hard_http_attempt_cap_per_task_seed": (
            FORMAL_HTTP_ATTEMPT_CAP_PER_RUN
        ),
        "per_phase": per_phase,
        "estimate_assumptions": {
            "fixed_seed_pool_calls_per_run": min(
                len(DEFAULT_SEEDS), FORMAL_ORACLE_BUDGET
            ),
            "requested_candidates_per_round_by_phase": candidates_by_phase,
            "nominal_logical_requests_per_round": (
                FORMAL_NOMINAL_LOGICAL_REQUESTS_PER_ROUND
            ),
            "max_logical_requests_per_round_with_novelty_repair": (
                FORMAL_MAX_LOGICAL_REQUESTS_PER_ROUND
            ),
            "hard_cap_is_cost_fuse": True,
        },
    }


def _checkpoint_path(job: JobSpec) -> Path:
    filename = (
        "results_latest.json"
        if job.phase == "standard"
        else "admet_results_latest.json"
    )
    return job.output_dir / filename


def _read_valid_job_results(
    job: JobSpec, *, seeds: int, oracle_budget: int
) -> dict[str, list[dict[str, Any]]] | None:
    if job.formal_reproduction_identity is None:
        return None
    try:
        formal_identity = validate_formal_reproduction_identity(
            job.formal_reproduction_identity
        )
    except ValueError:
        return None
    checkpoint = _checkpoint_path(job)
    try:
        value = json.loads(checkpoint.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return None
    if not isinstance(value, dict) or set(value) != set(job.selected_tasks):
        return None
    expected_seeds = set(job.selected_seeds(seeds))
    for task in job.selected_tasks:
        results = value.get(task)
        if not isinstance(results, list) or len(results) != len(expected_seeds):
            return None
        results_by_seed: dict[int, Mapping[str, Any]] = {}
        for result in results:
            if not isinstance(result, Mapping):
                return None
            seed = result.get("seed")
            if (
                isinstance(seed, bool)
                or not isinstance(seed, int)
                or seed not in expected_seeds
                or seed in results_by_seed
            ):
                return None
            results_by_seed[seed] = result
        if set(results_by_seed) != expected_seeds:
            return None
        for seed, result in results_by_seed.items():
            if not is_complete_pmo_result(
                result,
                task=task,
                seed=seed,
                oracle_budget=oracle_budget,
                require_admet=job.phase == "admet",
                require_lagrangian_phase_protocol=job.phase == "admet",
                expected_formal_identity_sha256=formal_identity[
                    "identity_sha256"
                ],
                require_novelty_recovery_protocol=True,
                require_near_feasible_repair_protocol=True,
                require_native_run_journal=True,
            ):
                return None
    return value


def _new_manifest(
    jobs: Sequence[JobSpec],
    *,
    seeds: int,
    oracle_budget: int,
    max_concurrency: int,
) -> dict[str, Any]:
    identity = _driver_identity(jobs, seeds=seeds, oracle_budget=oracle_budget)
    now = _utc_now()
    return {
        "schema_version": MANIFEST_SCHEMA_VERSION,
        "identity": identity,
        "identity_sha256": _json_sha256(identity),
        "created_at": now,
        "updated_at": now,
        "max_concurrency": max_concurrency,
        "credential_persisted": False,
        "jobs": {
            job.job_id: {
                **job.public_record(),
                "status": "pending",
                "attempts": 0,
                "started_at": None,
                "finished_at": None,
                "returncode": None,
                "error_type": None,
                "completion_source": None,
                "checkpoint_adopted_at": None,
            }
            for job in jobs
        },
        "aggregates": {},
    }


def prepare_manifest(
    manifest_path: Path,
    jobs: Sequence[JobSpec],
    *,
    seeds: int,
    oracle_budget: int,
    max_concurrency: int,
    resume: bool,
) -> tuple[dict[str, Any], list[JobSpec]]:
    """Load/reconcile state and return only jobs that still need execution."""
    identity = _driver_identity(jobs, seeds=seeds, oracle_budget=oracle_budget)
    identity_sha = _json_sha256(identity)
    if manifest_path.exists():
        if not resume:
            raise DistributedRunError(
                "--no-resume refuses an existing manifest; choose a new output root"
            )
        manifest = _load_json_object(manifest_path)
        if (
            manifest.get("identity_sha256") != identity_sha
            or manifest.get("identity") != identity
        ):
            raise DistributedRunError(
                "existing manifest belongs to a different scientific protocol"
            )
    else:
        manifest = _new_manifest(
            jobs,
            seeds=seeds,
            oracle_budget=oracle_budget,
            max_concurrency=max_concurrency,
        )

    pending: list[JobSpec] = []
    records = manifest.get("jobs")
    if not isinstance(records, dict):
        raise DistributedRunError("manifest jobs field is not an object")
    for job in jobs:
        record = records.get(job.job_id)
        if not isinstance(record, dict):
            raise DistributedRunError(f"manifest is missing job {job.job_id}")
        complete = _read_valid_job_results(
            job, seeds=seeds, oracle_budget=oracle_budget
        ) is not None
        if complete:
            # A task may have been completed by an already-running shard before
            # this driver created (or resumed) its manifest.  Adopt only after
            # strict trace validation.  Do not invent a scheduler attempt or
            # fake process timestamps: ``attempts == 0`` plus the explicit
            # adoption timestamp remains auditable for a new manifest.
            if record.get("status") != "succeeded":
                record["status"] = "succeeded"
                record["completion_source"] = "preexisting_checkpoint"
                record["checkpoint_adopted_at"] = _utc_now()
            else:
                record.setdefault("completion_source", "driver_execution")
                record.setdefault("checkpoint_adopted_at", None)
            continue
        record.update(
            {
                "status": "pending",
                "started_at": None,
                "finished_at": None,
                "returncode": None,
                "error_type": None,
                "completion_source": None,
                "checkpoint_adopted_at": None,
            }
        )
        pending.append(job)
    manifest["max_concurrency"] = max_concurrency
    manifest["updated_at"] = _utc_now()
    return manifest, pending


def _require_execution_phase_barrier(
    manifest: Mapping[str, Any],
    jobs: Sequence[JobSpec],
    *,
    execute_phases: Sequence[str],
) -> None:
    """E1 and E2 own independent phase/seed state and need no phase barrier.

    Task order within a seed is unchanged. Selecting E2 alone does not import
    E1 results or experience into that seed's CER lineage.
    """
    return


def _redact(text: str, secret: str) -> str:
    return text.replace(secret, "[REDACTED]") if secret else text


def _open_private_append(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
    return os.fdopen(descriptor, "a", encoding="utf-8")


def run_subprocess_job(
    job: JobSpec, *, api_key: str, api_key_env: str
) -> JobOutcome:
    """Execute one child and redact the credential from its combined log."""
    environment = os.environ.copy()
    environment[api_key_env] = api_key
    try:
        with _open_private_append(job.log_path) as log:
            log.write(f"[{_utc_now()}] command: {shlex.join(job.argv)}\n")
            log.flush()
            try:
                process = subprocess.Popen(
                    job.argv,
                    cwd=CODE_DIR,
                    env=environment,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    errors="replace",
                    bufsize=1,
                )
            except Exception as error:
                log.write(
                    f"[{_utc_now()}] launch failed: {type(error).__name__}\n"
                )
                return JobOutcome(returncode=127, error_type=type(error).__name__)
            assert process.stdout is not None
            with process.stdout:
                for line in process.stdout:
                    log.write(_redact(line, api_key))
                    log.flush()
            returncode = process.wait()
            log.write(f"[{_utc_now()}] returncode: {returncode}\n")
            log.flush()
            return JobOutcome(
                returncode=returncode,
                error_type=None if returncode == 0 else "ChildProcessError",
            )
    except Exception as error:
        return JobOutcome(returncode=126, error_type=type(error).__name__)


def _update_aggregates(
    manifest: dict[str, Any],
    jobs: Sequence[JobSpec],
    *,
    output_root: Path,
    seeds: int,
    oracle_budget: int,
    forbidden_secret: str,
) -> None:
    aggregates: dict[str, Any] = {}
    for phase in FORMAL_PHASES:
        by_task_and_seed: dict[str, dict[int, Mapping[str, Any]]] = {}
        for job in jobs:
            if job.phase != phase:
                continue
            results = _read_valid_job_results(
                job, seeds=seeds, oracle_budget=oracle_budget
            )
            if results is not None:
                for task, rows in results.items():
                    task_rows = by_task_and_seed.setdefault(task, {})
                    for row in rows:
                        seed = int(row["seed"])
                        if seed in task_rows:
                            raise DistributedRunError(
                                f"duplicate {phase}/{task}/seed_{seed} result"
                            )
                        task_rows[seed] = row
        combined = {
            task: [rows[seed] for seed in sorted(rows)]
            for task, rows in sorted(by_task_and_seed.items())
        }
        complete_tasks = sorted(
            task
            for task, rows in by_task_and_seed.items()
            if set(rows) == set(range(seeds))
        )
        filename = (
            "standard_results_latest.json"
            if phase == "standard"
            else "admet_results_latest.json"
        )
        destination = (
            output_root / "combined" / phase / filename
        ).resolve()
        # Always replace the aggregate, including with an empty mapping, so a
        # stale file from an earlier interrupted/invalidated run cannot be
        # mistaken for the current scheduler state.
        expected_tasks = {
            task
            for job in jobs
            if job.phase == phase
            for task in job.selected_tasks
        }
        formal_complete = set(complete_tasks) == expected_tasks
        _atomic_write_json(
            destination,
            combined if formal_complete else {},
            forbidden_secret=forbidden_secret,
        )
        aggregates[phase] = {
            "path": str(destination),
            "complete_tasks": complete_tasks,
            "formal_aggregate_published": formal_complete,
            "seed_counts_by_task": {
                task: len(rows)
                for task, rows in sorted(by_task_and_seed.items())
            },
        }
    manifest["aggregates"] = aggregates


def execute_jobs(
    manifest_path: Path,
    manifest: dict[str, Any],
    pending: Sequence[JobSpec],
    all_jobs: Sequence[JobSpec],
    *,
    output_root: Path,
    seeds: int,
    oracle_budget: int,
    max_concurrency: int,
    api_key: str,
    api_key_env: str,
    runner: Callable[..., JobOutcome] = run_subprocess_job,
    execution_jobs: Sequence[JobSpec] | None = None,
) -> int:
    """Run the selected pending jobs; failures never cancel peer shards."""
    records = manifest["jobs"]
    selected_jobs = tuple(all_jobs if execution_jobs is None else execution_jobs)
    selected_ids = [job.job_id for job in selected_jobs]
    all_job_ids = {job.job_id for job in all_jobs}
    if (
        not selected_jobs
        or len(selected_ids) != len(set(selected_ids))
        or any(job_id not in all_job_ids for job_id in selected_ids)
    ):
        raise DistributedRunError(
            "execution job selection must be a non-empty unique subset of the "
            "scientific manifest jobs"
        )
    selected_id_set = set(selected_ids)
    if any(job.job_id not in selected_id_set for job in pending):
        raise DistributedRunError(
            "pending execution jobs must belong to the selected execution subset"
        )
    _atomic_write_json(manifest_path, manifest, forbidden_secret=api_key)
    if not pending:
        _update_aggregates(
            manifest,
            all_jobs,
            output_root=output_root,
            seeds=seeds,
            oracle_budget=oracle_budget,
            forbidden_secret=api_key,
        )
        manifest["updated_at"] = _utc_now()
        _atomic_write_json(manifest_path, manifest, forbidden_secret=api_key)
        return 0 if all(
            records[job.job_id]["status"] == "succeeded"
            for job in selected_jobs
        ) else 1

    with ThreadPoolExecutor(max_workers=max_concurrency) as executor:
        future_to_job = {}
        for job in pending:
            record = records[job.job_id]
            record["status"] = "running"
            record["attempts"] = int(record.get("attempts", 0)) + 1
            record["started_at"] = _utc_now()
            future = executor.submit(
                runner, job, api_key=api_key, api_key_env=api_key_env
            )
            future_to_job[future] = job
        manifest["updated_at"] = _utc_now()
        _atomic_write_json(manifest_path, manifest, forbidden_secret=api_key)

        for future in as_completed(future_to_job):
            job = future_to_job[future]
            try:
                outcome = future.result()
            except Exception as error:  # Defensive isolation around test/custom runners.
                outcome = JobOutcome(
                    returncode=125, error_type=type(error).__name__
                )
            complete = (
                outcome.returncode == 0
                and _read_valid_job_results(
                    job, seeds=seeds, oracle_budget=oracle_budget
                )
                is not None
            )
            record = records[job.job_id]
            record["status"] = "succeeded" if complete else "failed"
            record["finished_at"] = _utc_now()
            record["returncode"] = outcome.returncode
            record["error_type"] = (
                None
                if complete
                else outcome.error_type or "OutputValidationError"
            )
            record["completion_source"] = (
                "driver_execution" if complete else None
            )
            record["checkpoint_adopted_at"] = None
            _update_aggregates(
                manifest,
                all_jobs,
                output_root=output_root,
                seeds=seeds,
                oracle_budget=oracle_budget,
                forbidden_secret=api_key,
            )
            manifest["updated_at"] = _utc_now()
            _atomic_write_json(manifest_path, manifest, forbidden_secret=api_key)

    return 0 if all(
        records[job.job_id]["status"] == "succeeded"
        for job in selected_jobs
    ) else 1


def resolve_api_key(api_key_env: str) -> str:
    """Use only a credential explicitly supplied by the person running this job."""
    value = os.environ.get(api_key_env, "").strip()
    if not value or value == "EMPTY":
        raise DistributedRunError(f"set {api_key_env} or use the hidden prompt in run.py")
    return value


def verify_minimax_model(api_key: str) -> None:
    """Perform one non-generative models.list check without logging the key."""
    try:
        client = OpenAI(
            api_key=api_key,
            base_url=MINIMAX_BASE_URL,
            max_retries=0,
            timeout=15.0,
        )
        response = client.models.list()
        available = {
            model_id
            for item in (getattr(response, "data", None) or [])
            if isinstance((model_id := getattr(item, "id", None)), str)
        }
    except Exception as error:
        status = getattr(error, "status_code", None)
        if status is None:
            status = getattr(getattr(error, "response", None), "status_code", None)
        label = type(error).__name__
        detail = f"HTTP {status} {label}" if status is not None else label
        raise DistributedRunError(
            f"MiniMax models.list preflight failed ({detail})"
        ) from None
    if MINIMAX_MODEL not in available:
        raise DistributedRunError(
            f"MiniMax models.list did not expose {MINIMAX_MODEL}"
        )


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phases", nargs="+", choices=FORMAL_PHASES,
                        default=list(FORMAL_PHASES))
    parser.add_argument(
        "--execute-phases",
        nargs="+",
        choices=FORMAL_PHASES,
        default=list(FORMAL_PHASES),
        help=(
            "Operational subset to execute in this invocation. The scientific "
            "manifest always contains both --phases standard admet, permitting "
            "the two arms to run sequentially under one identity."
        ),
    )
    parser.add_argument(
        "--matrix-scope",
        choices=tuple(MATRIX_TASK_CHAINS),
        default="five_task_main",
        help="Content-addressed task-chain identity for this formal matrix",
    )
    parser.add_argument("--tasks", nargs="+", default=list(FIVE_TASKS))
    parser.add_argument("--seeds", type=int, default=FORMAL_SEEDS)
    parser.add_argument(
        "--oracle-budget", "--oracle_budget", dest="oracle_budget",
        type=int, default=FORMAL_ORACLE_BUDGET,
    )
    parser.add_argument(
        "--max-concurrency", type=int, default=DEFAULT_MAX_CONCURRENCY
    )
    parser.add_argument(
        "--output-root", type=Path,
        default=DEFAULT_OUTPUT_ROOT,
    )
    parser.add_argument(
        "--standard-config", type=Path, default=Path("configs/pmo_standard.yaml")
    )
    parser.add_argument(
        "--admet-config", type=Path, default=Path("configs/pmo_admet.yaml")
    )
    parser.add_argument("--python-executable", default=sys.executable)
    parser.add_argument(
        "--resume", action=argparse.BooleanOptionalAction, default=True
    )
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--allow-paid-api", action="store_true")
    parser.add_argument("--confirm-formal-jobs", type=int)
    parser.add_argument(
        "--confirm-http-attempt-cap",
        type=int,
        help=(
            "Must exactly equal the selected execution subset's hard "
            "HTTP-attempt cap printed by --dry-run before any credential is "
            "accessed"
        ),
    )
    parser.add_argument("--api-key-env", default=MINIMAX_API_KEY_ENV)
    return parser


def _validate_args(args: argparse.Namespace) -> None:
    tasks = tuple(args.tasks)
    expected_tasks = MATRIX_TASK_CHAINS[args.matrix_scope]
    if tasks != expected_tasks:
        raise DistributedRunError(
            f"--matrix-scope {args.matrix_scope} requires the exact ordered "
            f"{len(expected_tasks)}-task chain"
        )
    if tuple(args.phases) != FORMAL_PHASES:
        raise DistributedRunError(
            "formal scientific manifest requires exact ordered "
            "--phases standard admet"
        )
    execute_phases = tuple(args.execute_phases)
    if not execute_phases:
        raise DistributedRunError("--execute-phases must not be empty")
    if len(execute_phases) != len(set(execute_phases)):
        raise DistributedRunError("--execute-phases must not contain duplicates")
    if any(phase not in FORMAL_PHASES for phase in execute_phases):
        raise DistributedRunError(
            "--execute-phases must be a subset of the scientific phases"
        )
    if args.seeds != FORMAL_SEEDS or args.oracle_budget != FORMAL_ORACLE_BUDGET:
        raise DistributedRunError(
            "formal driver requires seeds=5 and oracle_budget=1000"
        )
    if args.max_concurrency <= 0:
        raise DistributedRunError("--max-concurrency must be positive")
    if args.api_key_env != MINIMAX_API_KEY_ENV:
        raise DistributedRunError(
            f"formal MiniMax driver requires --api-key-env {MINIMAX_API_KEY_ENV}"
        )


def _dry_run_payload(
    jobs: Sequence[JobSpec],
    *,
    execution_jobs: Sequence[JobSpec],
    execute_phases: Sequence[str],
    max_concurrency: int,
    output_root: Path,
    request_exposure: Mapping[str, Any],
) -> dict[str, Any]:
    return {
        "status": "dry_run",
        "generation_requests_made": 0,
        "credentials_accessed": False,
        "formal_matrix_job_count": len(jobs),
        "formal_job_count": len(execution_jobs),
        "execution_job_count": len(execution_jobs),
        "execute_phases": list(execute_phases),
        "required_confirmation": (
            f"--confirm-formal-jobs {len(execution_jobs)}"
        ),
        "expected_logical_requests": request_exposure[
            "expected_logical_requests"
        ],
        "nominal_min_logical_requests": request_exposure[
            "nominal_min_logical_requests"
        ],
        "nominal_round_cap_logical_requests": request_exposure[
            "nominal_round_cap_logical_requests"
        ],
        "theoretical_max_logical_requests_before_round_cap": (
            request_exposure[
                "theoretical_max_logical_requests_before_round_cap"
            ]
        ),
        "hard_http_attempt_cap": request_exposure[
            "hard_http_attempt_cap"
        ],
        "hard_http_attempt_cap_per_task_seed": request_exposure[
            "hard_http_attempt_cap_per_task_seed"
        ],
        "required_http_confirmation": (
            "--confirm-http-attempt-cap "
            f"{request_exposure['hard_http_attempt_cap']}"
        ),
        "request_exposure_by_phase": request_exposure["per_phase"],
        "request_estimate_assumptions": request_exposure[
            "estimate_assumptions"
        ],
        "max_concurrency": max_concurrency,
        "manifest": str((output_root / "run_manifest.json").resolve()),
        "jobs": [job.public_record() for job in jobs],
        "execution_jobs": [job.public_record() for job in execution_jobs],
    }


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        _validate_args(args)
        phases = tuple(args.phases)
        execute_phases = tuple(args.execute_phases)
        output_root = args.output_root.expanduser().resolve()
        standard_config = args.standard_config.expanduser().resolve()
        admet_config = args.admet_config.expanduser().resolve()
        configs = {"standard": standard_config, "admet": admet_config}
        for phase in phases:
            _validate_formal_config(configs[phase], phase)
        python_executable = _resolve_python(args.python_executable)
        # One caller-owned cache means the shared FAISS index and MMP
        # JSON are each content-hashed only once during this invocation.
        formal_identity = build_formal_reproduction_identity(
            code_dir=CODE_DIR,
            standard_config=standard_config,
            admet_config=admet_config,
            matrix_scope=args.matrix_scope,
            task_chain=tuple(args.tasks),
            file_hash_cache={},
        )
        jobs = build_jobs(
            phases=phases,
            tasks=tuple(args.tasks),
            seeds=args.seeds,
            oracle_budget=args.oracle_budget,
            output_root=output_root,
            python_executable=python_executable,
            standard_config=standard_config,
            admet_config=admet_config,
            resume=args.resume,
            formal_reproduction_identity=formal_identity,
        )
        execution_jobs = [
            job for job in jobs if job.phase in set(execute_phases)
        ]
        request_exposure = _request_exposure_plan(
            phases=execute_phases,
            tasks=tuple(args.tasks),
            seeds=args.seeds,
            configs=configs,
        )

        if args.dry_run:
            print(json.dumps(
                _dry_run_payload(
                    jobs,
                    execution_jobs=execution_jobs,
                    execute_phases=execute_phases,
                    max_concurrency=args.max_concurrency,
                    output_root=output_root,
                    request_exposure=request_exposure,
                ),
                indent=2,
                sort_keys=True,
            ))
            return 0

        if not args.allow_paid_api:
            raise DistributedRunError(
                "paid execution requires explicit --allow-paid-api"
            )
        if args.confirm_formal_jobs != len(execution_jobs):
            raise DistributedRunError(
                "paid execution requires exact numeric confirmation "
                f"--confirm-formal-jobs {len(execution_jobs)}"
            )
        hard_http_cap = request_exposure["hard_http_attempt_cap"]
        if args.confirm_http_attempt_cap != hard_http_cap:
            raise DistributedRunError(
                "paid execution requires exact numeric confirmation "
                f"--confirm-http-attempt-cap {hard_http_cap}"
            )

        print(
            "Formal paid envelope authorized: "
            f"nominal_min_logical_requests="
            f"{request_exposure['nominal_min_logical_requests']}, "
            f"theoretical_round_cap_logical_requests="
            f"{request_exposure['theoretical_max_logical_requests_before_round_cap']}, "
            f"hard_http_attempt_cap={hard_http_cap}"
        )

        manifest_path = output_root / "run_manifest.json"
        manifest, pending = prepare_manifest(
            manifest_path,
            jobs,
            seeds=args.seeds,
            oracle_budget=args.oracle_budget,
            max_concurrency=args.max_concurrency,
            resume=args.resume,
        )
        _require_execution_phase_barrier(
            manifest,
            jobs,
            execute_phases=execute_phases,
        )
        execution_job_ids = {job.job_id for job in execution_jobs}
        execution_pending = [
            job for job in pending if job.job_id in execution_job_ids
        ]
        # Reconcile source/assets/protocol identity and every resumable
        # checkpoint before touching the credential or making models.list.
        api_key = resolve_api_key(args.api_key_env)
        verify_minimax_model(api_key)
        status = execute_jobs(
            manifest_path,
            manifest,
            execution_pending,
            jobs,
            output_root=output_root,
            seeds=args.seeds,
            oracle_budget=args.oracle_budget,
            max_concurrency=args.max_concurrency,
            api_key=api_key,
            api_key_env=args.api_key_env,
            execution_jobs=execution_jobs,
        )
        succeeded = sum(
            record.get("status") == "succeeded"
            for record in manifest["jobs"].values()
        )
        failed = sum(
            record.get("status") == "failed"
            for record in manifest["jobs"].values()
        )
        print(
            f"distributed PharmAgent jobs: succeeded={succeeded}, "
            f"failed={failed}, manifest={manifest_path}"
        )
        return status
    except (DistributedRunError, FormalIdentityError) as error:
        print(f"blocked: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
