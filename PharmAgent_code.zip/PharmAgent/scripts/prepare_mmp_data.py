#!/usr/bin/env python
"""
Prepare Matched Molecular Pair (MMP) data from ChEMBL.

Usage:
    python scripts/prepare_mmp_data.py --action download
    python scripts/prepare_mmp_data.py --action generate
    python scripts/prepare_mmp_data.py --action all
    python scripts/prepare_mmp_data.py --action download --backend interface
"""

import argparse
import logging
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pharmagent.rag.mmp_indexer import (
    download_chembl_activities,
    generate_mmps_mmpdb,
    DEFAULT_TARGETS,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)
logger = logging.getLogger(__name__)


def main():
    parser = argparse.ArgumentParser(description="Prepare ChEMBL MMP data for RAG")
    parser.add_argument(
        "--action",
        choices=["download", "generate", "all"],
        default="all",
        help="Action to perform",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default="data/matched_pairs",
        help="Output directory for MMP data",
    )
    parser.add_argument(
        "--targets",
        nargs="+",
        default=None,
        help=(
            "ChEMBL target IDs in formal task order (default: GSK3B, JNK3, "
            "DRD2, DPP4 for sitagliptin, ADRB2 for albuterol)"
        ),
    )
    parser.add_argument(
        "--max_per_target",
        type=int,
        default=5000,
        help="Maximum activities to download per target",
    )
    parser.add_argument(
        "--backend",
        choices=["auto", "rest", "interface"],
        default="auto",
        help=(
            "Official ChEMBL data endpoint. 'auto' tries the documented REST API "
            "then the official web-interface API."
        ),
    )
    parser.add_argument(
        "--page_size",
        type=int,
        default=500,
        help="ChEMBL page size (capped at 1000)",
    )
    parser.add_argument(
        "--attempts",
        type=int,
        default=3,
        help="Attempts per transient ChEMBL request",
    )
    parser.add_argument(
        "--mmpdb_executable",
        default=os.environ.get("PHARMAGENT_MMPDB_EXECUTABLE", "mmpdb"),
        help=(
            "Pinned mmpdb 3.1.4 executable from an isolated builder environment"
        ),
    )
    parser.add_argument(
        "--minimum_delta",
        type=float,
        default=0.5,
        help="Minimum absolute same-assay median delta pActivity",
    )
    parser.add_argument(
        "--num_jobs",
        type=int,
        default=4,
        help="Parallel mmpdb fragmentation workers",
    )
    args = parser.parse_args()

    target_ids = args.targets or list(DEFAULT_TARGETS.values())

    if args.action in ("download", "all"):
        logger.info("Step 1: Downloading ChEMBL activities...")
        activities = download_chembl_activities(
            target_chembl_ids=target_ids,
            output_dir=args.output_dir,
            max_per_target=args.max_per_target,
            backend=args.backend,
            page_size=args.page_size,
            attempts=args.attempts,
        )
        logger.info("Downloaded %d total activities", len(activities))
    else:
        # Load existing activities
        import json
        act_path = os.path.join(args.output_dir, "chembl_activities.json")
        if os.path.exists(act_path):
            with open(act_path) as f:
                activities = json.load(f)
            logger.info("Loaded %d activities from %s", len(activities), act_path)
        else:
            logger.error("No activities file found. Run with --action download first.")
            return

    if args.action in ("generate", "all"):
        logger.info("Step 2: Generating strict fragmentation MMPs...")
        activities_path = os.path.join(args.output_dir, "chembl_activities.json")
        activities_manifest_path = os.path.join(
            args.output_dir, "chembl_activities_manifest.json"
        )
        mmp_pairs = generate_mmps_mmpdb(
            activities_path,
            output_dir=args.output_dir,
            mmpdb_executable=args.mmpdb_executable,
            activities_manifest_path=activities_manifest_path,
            minimum_delta=args.minimum_delta,
            num_jobs=args.num_jobs,
        )
        logger.info("Generated %d MMP pairs", len(mmp_pairs))
        logger.info(
            "Next step: run 'python scripts/build_faiss_index.py' "
            "to build the FAISS index."
        )


if __name__ == "__main__":
    main()
