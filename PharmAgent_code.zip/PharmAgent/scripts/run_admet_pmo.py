#!/usr/bin/env python
"""
Run PharmAgent on the ADMET-Constrained PMO benchmark.
This wraps each PMO oracle with ADMET penalty scoring.

Usage:
    python scripts/run_admet_pmo.py --config configs/pmo_admet.yaml
    python scripts/run_admet_pmo.py --tasks gsk3b jnk3 --seeds 1 --oracle_budget 100
"""

import argparse
from copy import deepcopy
import hashlib
import json
import logging
import math
import os
from pathlib import Path
import sys
import time
from datetime import datetime

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pharmagent.evaluation.pmo_evaluator import (
    PMO_TASKS,
    PharmAgentOptimizer,
    build_failed_pmo_checkpoint,
)
from pharmagent.evaluation.oracle_utils import (
    canonicalize_oracle_smiles,
    create_oracle,
    is_complete_diagnostic_smoke_result,
    is_complete_pmo_result,
    upsert_seed_result,
)
from pharmagent.evaluation.diagnostic_smoke import (
    DIAGNOSTIC_SMOKE_STATUS,
    label_result as label_diagnostic_smoke_result,
    validate_run_budget_mode,
)
from pharmagent.evaluation.metrics import compute_pmo_run_metrics
from pharmagent.evaluation.formal_identity import (
    FormalIdentityError,
    parse_formal_reproduction_identity_json,
    validate_formal_arm_config,
    validate_formal_identity_against_current_workspace,
)
from pharmagent.evaluation.native_run import (
    IndeterminateOracleCallError,
    NativeRunJournal,
    configure_native_run_journal,
    native_journal_path,
    reject_unjournaled_partial_resume,
)
from pharmagent.tools.admet_predictor import ADMETPredictor
from pharmagent.optimization.scoring import compute_admet_constrained_score
from pharmagent.config import load_config
from pharmagent.llm.attempt_ledger import (
    configure_formal_attempt_ledger,
    formal_ledger_path,
)
from pharmagent.optimization.cer_runtime import (
    clear_incomplete_task,
    configure_seed_cer,
    mark_task_complete,
    persistent_seed_paths,
    require_task_complete,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)
logger = logging.getLogger(__name__)
CODE_DIR = Path(__file__).resolve().parents[1]


def _resolve_seed_indices(
    total_seeds: int, requested: list[int] | None
) -> tuple[int, ...]:
    """Return the deterministic subset of a fixed total seed population."""
    if (
        isinstance(total_seeds, bool)
        or not isinstance(total_seeds, int)
        or total_seeds <= 0
    ):
        raise RuntimeError("--seeds must be a positive integer")
    if requested is None:
        return tuple(range(total_seeds))
    if not requested:
        raise RuntimeError("--seed-indices requires at least one seed")
    if any(
        isinstance(seed, bool)
        or not isinstance(seed, int)
        or seed < 0
        or seed >= total_seeds
        for seed in requested
    ):
        raise RuntimeError(
            "--seed-indices must be within the fixed --seeds range"
        )
    if len(requested) != len(set(requested)):
        raise RuntimeError("--seed-indices must not contain duplicates")
    return tuple(sorted(requested))


class ADMETConstrainedOracle:
    """Record raw target and ADMET values for the constrained optimizer.

    The wrapped oracle returns the raw PMO target.  PharmAgent's Lagrangian
    applies the ADMET penalty during candidate selection, exactly once.  A
    diagnostic fixed-alpha constrained score is retained in the trace but is
    never fed back as the target objective.
    """

    def __init__(
        self,
        base_oracle,
        admet_predictor: ADMETPredictor,
        constraints: dict,
        max_calls: int,
        *,
        admet_config: dict | None = None,
        native_journal: NativeRunJournal | None = None,
    ):
        self.base_oracle = base_oracle
        self.admet = admet_predictor
        self.constraints = constraints
        self.total_constraints = len(constraints)
        self.name = getattr(base_oracle, "name", "unknown")
        self.oracle_backend = getattr(base_oracle, "oracle_backend", "unknown")
        self.used_dummy_oracle = bool(
            getattr(base_oracle, "used_dummy_oracle", False)
        )
        self.max_calls = max_calls
        self.native_journal = native_journal
        self._native_call_context: dict = {}
        self.call_count = 0
        self.mol_buffer = {}
        self.evaluation_history: list[dict] = []
        self.finish = False

        # Pre-create analyst agent (reused across all calls)
        from pharmagent.agents.admet_analyst import ADMETAnalystAgent
        analyst_config = dict(admet_config or {})
        analyst_config.update({
            "backend": admet_predictor.backend,
            "admet_constraints": constraints,
        })
        self._analyst = ADMETAnalystAgent(analyst_config)
        self._analyst.admet = admet_predictor
        if self.native_journal is not None:
            self._hydrate_native_calls()

    def _hydrate_native_calls(self) -> None:
        """Restore every durably scored PMO call without repeating PyTDC."""
        assert self.native_journal is not None
        calls = self.native_journal.oracle_calls()
        if any(call["stage"] == "pending" for call in calls):
            raise IndeterminateOracleCallError(
                "ADMET PMO oracle call was interrupted before its target "
                "score was durably recorded; refusing automatic replay"
            )
        for call in calls:
            if call["stage"] != "complete":
                continue
            record = dict(call["record"])
            self.evaluation_history.append(record)
            self.mol_buffer[call["smiles"]] = float(
                call["raw_target_score"]
            )
        self.call_count = self.native_journal.oracle_scored_count
        self.finish = self.call_count >= self.max_calls

    def set_native_call_context(self, context: dict | None) -> None:
        self._native_call_context = dict(context or {})

    def __call__(self, smiles):
        if isinstance(smiles, list):
            return [self(s) for s in smiles]

        canonical = canonicalize_oracle_smiles(smiles)
        if canonical is None:
            logger.warning(
                "Invalid SMILES was not counted by ADMET-constrained oracle: %r",
                smiles,
            )
            return 0.0

        native_call = None
        if self.native_journal is not None:
            native_call = self.native_journal.oracle_call_for_smiles(canonical)
            if native_call is not None:
                if native_call["stage"] == "pending":
                    raise IndeterminateOracleCallError(
                        "ADMET PMO oracle call is indeterminate; refusing "
                        "automatic replay"
                    )
                if native_call["stage"] == "complete":
                    return float(native_call["raw_target_score"])
                # ``raw_scored`` means PyTDC succeeded and only deterministic
                # local ADMET completion remains.  Never call PyTDC again.
                return self._complete_admet_call(
                    canonical,
                    float(native_call["raw_target_score"]),
                    native_call,
                )

        if canonical in self.mol_buffer:
            return self.mol_buffer[canonical]
        if self.finish:
            return 0.0

        if self.native_journal is not None:
            native_call = self.native_journal.reserve_oracle_call(
                canonical, context=self._native_call_context
            )
            if not native_call["newly_reserved"]:
                raise IndeterminateOracleCallError(
                    "unexpected existing ADMET PMO oracle reservation"
                )

        # Get base oracle score
        base_count_before = getattr(self.base_oracle, "call_count", None)
        base_buffer_before = getattr(self.base_oracle, "mol_buffer", {})
        already_scored_by_base = (
            isinstance(base_buffer_before, dict) and canonical in base_buffer_before
        )
        base_score = self.base_oracle(canonical)
        if isinstance(base_score, (list, tuple)):
            base_score = base_score[0] if base_score else 0.0
        base_score = float(base_score)
        if not math.isfinite(base_score):
            raise RuntimeError(
                "Base PMO oracle returned a non-finite score; refusing to count "
                "a failed score toward the formal budget"
            )
        base_count_after = getattr(self.base_oracle, "call_count", None)
        base_buffer_after = getattr(self.base_oracle, "mol_buffer", {})
        if (
            isinstance(base_count_before, int)
            and isinstance(base_count_after, int)
            and base_count_after == base_count_before
            and not already_scored_by_base
            and not (
                isinstance(base_buffer_after, dict)
                and canonical in base_buffer_after
            )
        ):
            raise RuntimeError(
                "Base PMO oracle did not record this molecule; refusing to "
                "count a failed score toward the formal budget"
            )

        if self.native_journal is not None:
            self.native_journal.record_raw_oracle_score(canonical, base_score)

        self.call_count += 1
        if self.call_count >= self.max_calls:
            self.finish = True

        return self._complete_admet_call(canonical, base_score, native_call)

    def _complete_admet_call(
        self,
        canonical: str,
        base_score: float,
        native_call: dict | None,
    ) -> float:
        """Finish deterministic ADMET fields for a durably raw-scored call."""

        # Evaluate all seven paper constraints (including SA score) and retain
        # the per-molecule fields required by PR@10, AA-AUC, and PHV.
        admet_result = self._analyst.run({"smiles_list": [canonical]})[
            "admet_results"
        ][0]
        admet_pred = admet_result.get("admet_predictions", {})
        violations = admet_result.get("violations", [])
        n_violations = len(violations)

        # Apply penalty
        constrained_score = compute_admet_constrained_score(
            base_score, n_violations, self.total_constraints
        )

        call_index = (
            int(native_call["call_index"])
            if native_call is not None
            else self.call_count
        )
        history_row = {
            "call_index": call_index,
            "smiles": canonical,
            "raw_target_score": base_score,
            "constrained_target_score": constrained_score,
            "admet_score": float(admet_result.get("admet_score", 0.0)),
            "pass_all": bool(admet_result.get("pass_all", False)),
            "n_violations": n_violations,
            "violation_names": [v.get("name", "unknown") for v in violations],
            "constraint_assessments": deepcopy(
                admet_result.get("constraint_assessments", [])
            ),
            "oracle_context": deepcopy(
                native_call.get("context", self._native_call_context)
                if native_call is not None
                else self._native_call_context
            ),
        }
        if admet_pred.get("prediction_backend"):
            history_row["admet_backend"] = admet_pred["prediction_backend"]
        if admet_pred.get("admet_ai_version"):
            history_row["admet_ai_version"] = admet_pred["admet_ai_version"]
        if self.native_journal is not None:
            self.native_journal.complete_oracle_call(canonical, history_row)
        self.evaluation_history.append(history_row)
        self.evaluation_history.sort(key=lambda row: row["call_index"])

        self.mol_buffer[canonical] = base_score

        return base_score

    def _count_violations(self, pred: dict) -> int:
        """Count the number of ADMET constraint violations."""
        violations = self._analyst._check_constraints(pred)
        return len(violations)


def _save_results(results: dict, output_dir: str, final: bool = False) -> str:
    """Write a recovery checkpoint and, at completion, an archival copy."""
    serializable = {
        # These are recovery checkpoints.  The optimizer memory is
        # bounded and must remain available for exact native-state validation
        # after a reload; the publication normalizer deliberately omits it.
        task: [dict(result) for result in seed_results]
        for task, seed_results in results.items()
    }

    latest_path = os.path.join(output_dir, "admet_results_latest.json")
    _write_json_atomic(latest_path, serializable)

    if final:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        archival_path = os.path.join(
            output_dir, f"admet_results_{timestamp}.json"
        )
        _write_json_atomic(archival_path, serializable)
        return archival_path

    return latest_path


def _write_json_atomic(path: str, value: dict) -> None:
    temporary = f"{path}.tmp"
    with open(temporary, "w") as file:
        json.dump(value, file, indent=2, default=str)
    os.replace(temporary, path)


def _load_results(output_dir: str) -> dict:
    path = os.path.join(output_dir, "admet_results_latest.json")
    if not os.path.exists(path):
        return {}
    try:
        with open(path) as file:
            value = json.load(file)
    except (OSError, json.JSONDecodeError) as error:
        raise RuntimeError(f"Cannot resume invalid checkpoint {path}: {error}") from error
    if not isinstance(value, dict):
        raise RuntimeError(f"Cannot resume checkpoint with non-object root: {path}")
    logger.info("Resuming from %s", path)
    return value


def _has_completed_seed(
    seed_results: list,
    task: str,
    seed: int,
    oracle_budget: int,
    formal_identity_sha256: str | None = None,
    diagnostic_smoke: bool = False,
) -> bool:
    return _completed_seed_result(
        seed_results,
        task,
        seed,
        oracle_budget,
        formal_identity_sha256=formal_identity_sha256,
        diagnostic_smoke=diagnostic_smoke,
    ) is not None


def _completed_seed_result(
    seed_results: list,
    task: str,
    seed: int,
    oracle_budget: int,
    formal_identity_sha256: str | None = None,
    diagnostic_smoke: bool = False,
) -> dict | None:
    return next((
        result
        for result in seed_results
        if
        (
            is_complete_diagnostic_smoke_result(
                result,
                task=task,
                seed=seed,
                oracle_budget=oracle_budget,
                require_admet=True,
                require_lagrangian_phase_protocol_prefix=True,
                expected_formal_identity_sha256=formal_identity_sha256,
                require_novelty_recovery_protocol=True,
                require_near_feasible_repair_protocol=True,
                require_native_run_journal=True,
            )
            if diagnostic_smoke and formal_identity_sha256 is not None
            else is_complete_pmo_result(
                result,
                task=task,
                seed=seed,
                oracle_budget=oracle_budget,
                require_admet=True,
                require_lagrangian_phase_protocol=True,
                expected_formal_identity_sha256=formal_identity_sha256,
                require_novelty_recovery_protocol=True,
                require_near_feasible_repair_protocol=True,
                require_native_run_journal=(
                    formal_identity_sha256 is not None
                ),
            )
        )
    ), None)


def main():
    parser = argparse.ArgumentParser(description="Run ADMET-Constrained PMO benchmark")
    parser.add_argument("--config", type=str, default="configs/pmo_admet.yaml")
    parser.add_argument("--tasks", nargs="+", default=None)
    parser.add_argument("--seeds", type=int, default=5)
    parser.add_argument(
        "--seed-indices",
        nargs="+",
        type=int,
        default=None,
        help=(
            "Run only these zero-based seed indices while --seeds retains "
            "the total seed population (for isolated seed workers)"
        ),
    )
    parser.add_argument("--oracle_budget", type=int, default=None)
    parser.add_argument("--output_dir", type=str, default="results/pmo_admet")
    parser.add_argument(
        "--cer-root",
        type=Path,
        default=None,
        help=(
            "Persist Chemical-CER in one SQLite database per seed; tasks must "
            "run together in their declared order to enable cross-task transfer"
        ),
    )
    parser.add_argument(
        "--resume", action=argparse.BooleanOptionalAction, default=True,
        help=(
            "Skip completed task/seed runs and continue compatible incomplete "
            "runs from their identity-bound native journal. Indeterminate "
            "in-flight HTTP/oracle events fail closed instead of being repeated."
        ),
    )
    parser.add_argument(
        "--llm-ledger-root",
        type=Path,
        default=None,
        help=(
            "Root for isolated formal paid-attempt ledgers (default: "
            "OUTPUT_DIR/llm_attempt_ledgers when require_full_budget=true)"
        ),
    )
    parser.add_argument(
        "--native-journal-root",
        type=Path,
        default=None,
        help=(
            "Root for exact task/seed oracle, LLM, and optimizer journals "
            "(default: OUTPUT_DIR/native_run_journals for formal runs)"
        ),
    )
    parser.add_argument(
        "--formal-reproduction-identity",
        default=None,
        help=(
            "Canonical identity JSON supplied by the formal distributed driver; "
            "required for full-budget runs"
        ),
    )
    parser.add_argument(
        "--diagnostic-smoke",
        action="store_true",
        help=(
            "Run a reduced-budget paid smoke under a paid_smoke_* identity. "
            "Incomplete active-set coverage is diagnostic-only; outputs use "
            "diagnostic_complete and are never submission eligible."
        ),
    )
    args = parser.parse_args()
    seed_indices = _resolve_seed_indices(args.seeds, args.seed_indices)

    config = load_config(args.config)
    configured_formal_budget = config.get("optimization", {}).get(
        "oracle_budget", 10000
    )
    require_full_budget = config.get("optimization", {}).get(
        "require_full_budget", False
    )
    admet_config = config.get("admet", {})
    constraints = admet_config.get("admet_constraints", {})
    tasks = args.tasks or PMO_TASKS
    formal_identity = None
    if require_full_budget:
        expected_seeds = config.get("evaluation", {}).get("seeds")
        if (
            not args.diagnostic_smoke
            and args.seeds != expected_seeds
        ):
            raise RuntimeError(
                "formal full-budget runs require --seeds to retain the "
                f"configured total seed population ({expected_seeds})"
            )
        try:
            # Validate the canonical on-disk PMO-1K protocol before a
            # diagnostic CLI override changes only the runtime budget.
            validate_formal_arm_config(config, "admet")
        except FormalIdentityError as error:
            raise RuntimeError(
                f"invalid ADMET formal protocol: {error}"
            ) from error
        if not args.formal_reproduction_identity:
            raise RuntimeError(
                "full-budget formal runs require "
                "--formal-reproduction-identity from the distributed driver"
            )
        try:
            formal_identity = parse_formal_reproduction_identity_json(
                args.formal_reproduction_identity
            )
        except FormalIdentityError as error:
            raise RuntimeError(f"invalid formal reproduction identity: {error}") from error
        try:
            formal_identity = validate_formal_identity_against_current_workspace(
                formal_identity,
                code_dir=CODE_DIR,
                matrix_scope=formal_identity["matrix_scope"],
                task_chain=tasks,
            )
        except FormalIdentityError as error:
            raise RuntimeError(
                "formal reproduction identity is not current: "
                f"{error}"
            ) from error
        config_sha = hashlib.sha256(Path(args.config).resolve().read_bytes()).hexdigest()
        if formal_identity["formal_config_sha256"]["admet"] != config_sha:
            raise RuntimeError(
                "formal reproduction identity does not match the ADMET config"
            )
        config["formal_reproduction_identity"] = formal_identity

    if args.oracle_budget is not None:
        config.setdefault("optimization", {})["oracle_budget"] = args.oracle_budget
    oracle_budget = config.get("optimization", {}).get("oracle_budget", 10000)

    validate_run_budget_mode(
        diagnostic_smoke=args.diagnostic_smoke,
        require_full_budget=require_full_budget,
        configured_formal_budget=configured_formal_budget,
        oracle_budget=oracle_budget,
        formal_identity=formal_identity,
    )
    if (
        require_full_budget
        and config.get("cer", {}).get("enabled", False)
        and args.cer_root is None
    ):
        raise RuntimeError(
            "formal full-budget Chemical-CER requires --cer-root for exact "
            "crash-resume visibility"
        )

    llm_ledger_root = None
    native_journal_root = None
    if require_full_budget:
        llm_ledger_root = (
            args.llm_ledger_root
            if args.llm_ledger_root is not None
            else Path(args.output_dir) / "llm_attempt_ledgers"
        ).expanduser().resolve()
        native_journal_root = (
            args.native_journal_root
            if args.native_journal_root is not None
            else Path(args.output_dir) / "native_run_journals"
        ).expanduser().resolve()

    # Create ADMET predictor
    admet_predictor = ADMETPredictor(
        backend=admet_config.get("backend", "rdkit_only"),
        config=admet_config,
    )

    os.makedirs(args.output_dir, exist_ok=True)
    if not args.resume:
        cer_paths_by_seed = dict(enumerate(persistent_seed_paths(
            config, cer_root=args.cer_root, seeds=args.seeds
        )))
        existing_cer = [
            cer_paths_by_seed[seed]
            for seed in seed_indices
            if seed in cer_paths_by_seed
            and cer_paths_by_seed[seed].exists()
        ]
        if existing_cer:
            raise RuntimeError(
                "--no-resume refuses existing CER databases; choose a new "
                f"--cer-root (first existing path: {existing_cer[0]})"
            )
        if llm_ledger_root is not None:
            existing_ledgers = [
                path
                for task in tasks
                for seed in seed_indices
                if (
                    path := formal_ledger_path(
                        llm_ledger_root,
                        phase="admet",
                        task=task,
                        seed=seed,
                    )
                ).exists()
            ]
            if existing_ledgers:
                raise RuntimeError(
                    "--no-resume refuses an existing paid-attempt ledger; "
                    "choose a new --llm-ledger-root "
                    f"(first existing path: {existing_ledgers[0]})"
                )
        if native_journal_root is not None:
            existing_journals = [
                path
                for task in tasks
                for seed in seed_indices
                if (
                    path := native_journal_path(
                        native_journal_root,
                        phase="admet",
                        task=task,
                        seed=seed,
                    )
                ).exists()
            ]
            if existing_journals:
                raise RuntimeError(
                    "--no-resume refuses an existing native run journal; "
                    "choose a new --native-journal-root "
                    f"(first existing path: {existing_journals[0]})"
                )

    logger.info("=" * 60)
    logger.info("PharmAgent ADMET-Constrained PMO Benchmark")
    logger.info(
        "Tasks: %d, Total seeds: %d, Selected seeds: %s, Budget: %d, "
        "Constraints: %d",
        len(tasks), args.seeds, list(seed_indices), oracle_budget,
        len(constraints),
    )
    logger.info("=" * 60)

    all_results = _load_results(args.output_dir) if args.resume else {}

    for task_idx, task in enumerate(tasks):
        logger.info("\n[%d/%d] Task: %s", task_idx + 1, len(tasks), task)

        task_results = all_results.setdefault(task, [])
        for seed in seed_indices:
            seed_config = configure_seed_cer(
                config,
                cer_root=args.cer_root,
                seed=seed,
                phase="admet",
                tasks=tasks,
            )
            completed_result = _completed_seed_result(
                task_results,
                task,
                seed,
                oracle_budget,
                formal_identity_sha256=(
                    formal_identity["identity_sha256"]
                    if formal_identity is not None else None
                ),
                diagnostic_smoke=args.diagnostic_smoke,
            )
            if completed_result is not None:
                require_task_complete(
                    seed_config,
                    task=task,
                    task_index=task_idx,
                    result=completed_result,
                )
                logger.info("  Seed %d/%d already complete; skipping", seed + 1, args.seeds)
                continue
            if llm_ledger_root is not None:
                seed_config = configure_formal_attempt_ledger(
                    seed_config,
                    ledger_root=llm_ledger_root,
                    phase="admet",
                    task=task,
                    seed=seed,
                    formal_reproduction_identity=formal_identity,
                )
            native_journal = None
            if native_journal_root is not None:
                journal_path = native_journal_path(
                    native_journal_root,
                    phase="admet",
                    task=task,
                    seed=seed,
                )
                reject_unjournaled_partial_resume(
                    seed_config,
                    journal_path=journal_path,
                    task=task,
                    seed=seed,
                    checkpoint_rows=task_results,
                )
                seed_config = configure_native_run_journal(
                    seed_config,
                    journal_root=native_journal_root,
                    phase="admet",
                    task=task,
                    seed=seed,
                    oracle_budget=oracle_budget,
                    formal_reproduction_identity=formal_identity,
                )
                native_spec = seed_config["native_run_journal"]
                native_journal = NativeRunJournal(
                    native_spec["path"], identity=native_spec["identity"]
                )
            logger.info("  Seed %d/%d", seed + 1, args.seeds)
            np.random.seed(seed)

            removed = (
                0
                if native_journal is not None
                else clear_incomplete_task(seed_config, task)
            )
            if removed:
                logger.info(
                    "    Removed %d partial CER rows before clean resume", removed
                )
            for prior_index, prior_task in enumerate(tasks[:task_idx]):
                prior_result = _completed_seed_result(
                    all_results.get(prior_task, []),
                    prior_task,
                    seed,
                    oracle_budget,
                    formal_identity_sha256=(
                        formal_identity["identity_sha256"]
                        if formal_identity is not None else None
                    ),
                    diagnostic_smoke=args.diagnostic_smoke,
                )
                if prior_result is None:
                    raise RuntimeError(
                        "CER task order is incomplete: cannot start "
                        f"{task}/seed_{seed} before {prior_task}/seed_{seed}"
                    )
                require_task_complete(
                    seed_config,
                    task=prior_task,
                    task_index=prior_index,
                    result=prior_result,
                    require_experience_presence=prior_index == task_idx - 1,
                )

            base_oracle = create_oracle(task, oracle_budget)
            constrained_oracle = ADMETConstrainedOracle(
                base_oracle,
                admet_predictor,
                constraints,
                oracle_budget,
                admet_config=admet_config,
                native_journal=native_journal,
            )

            optimizer = PharmAgentOptimizer(
                seed_config, admet_predictor=admet_predictor
            )
            start = time.time()
            try:
                result = optimizer.optimize(
                    constrained_oracle, seed_config, seed=seed
                )
            except Exception as error:
                failed = build_failed_pmo_checkpoint(
                    error,
                    optimizer=optimizer,
                    oracle=constrained_oracle,
                    task=task,
                    seed=seed,
                    oracle_budget=oracle_budget,
                    elapsed_time=time.time() - start,
                    evaluation_history=(
                        native_journal.evaluation_history()
                        if native_journal is not None
                        else list(constrained_oracle.evaluation_history)
                    ),
                )
                if formal_identity is not None:
                    failed["formal_reproduction_identity"] = formal_identity
                upsert_seed_result(task_results, failed)
                _save_results(all_results, args.output_dir)
                raise RuntimeError(
                    f"Formal ADMET run failed for {task}/seed_{seed}: "
                    f"optimizer_exception:{type(error).__name__}"
                ) from None
            result["evaluation_history"] = (
                native_journal.evaluation_history()
                if native_journal is not None
                else list(constrained_oracle.evaluation_history)
            )
            result["metrics"] = compute_pmo_run_metrics(
                result["evaluation_history"], oracle_budget=oracle_budget
            )
            result["elapsed_time"] = time.time() - start
            result["task"] = task
            result["seed"] = seed
            result["oracle_budget"] = oracle_budget
            if formal_identity is not None:
                result["formal_reproduction_identity"] = formal_identity
            if args.diagnostic_smoke and result.get("status") == "complete":
                result = label_diagnostic_smoke_result(
                    result,
                    phase="admet",
                    configured_formal_budget=configured_formal_budget,
                )
            valid_result = (
                is_complete_diagnostic_smoke_result(
                    result,
                    task=task,
                    seed=seed,
                    oracle_budget=oracle_budget,
                    require_admet=True,
                    require_lagrangian_phase_protocol_prefix=True,
                    expected_formal_identity_sha256=formal_identity[
                        "identity_sha256"
                    ],
                    require_novelty_recovery_protocol=True,
                    require_near_feasible_repair_protocol=True,
                    require_native_run_journal=True,
                )
                if args.diagnostic_smoke
                else is_complete_pmo_result(
                    result,
                    task=task,
                    seed=seed,
                    oracle_budget=oracle_budget,
                    require_admet=True,
                    require_lagrangian_phase_protocol=True,
                    expected_formal_identity_sha256=(
                        formal_identity["identity_sha256"]
                        if formal_identity is not None else None
                    ),
                    require_novelty_recovery_protocol=True,
                    require_near_feasible_repair_protocol=True,
                    require_native_run_journal=(formal_identity is not None),
                )
            )
            expected_status = (
                DIAGNOSTIC_SMOKE_STATUS
                if args.diagnostic_smoke
                else "complete"
            )
            if not valid_result and result.get("status") == expected_status:
                result["status"] = "failed"
                result["termination_reason"] = "postrun_validation_failed"
            upsert_seed_result(task_results, result)
            if result.get("status") == expected_status:
                mark_task_complete(
                    seed_config,
                    task=task,
                    task_index=task_idx,
                    result=result,
                )
            _save_results(all_results, args.output_dir)

            if result.get("status") != expected_status:
                raise RuntimeError(
                    f"Run failed for {task}/seed_{seed}: "
                    f"{result.get('termination_reason', 'unknown')}"
                )

            logger.info(
                "    Raw Top-1=%.4f, AUC Top-10=%.4f, PR@10=%.1f%%, "
                "Combined=%.4f, Calls=%d, Time=%.1fs",
                result["metrics"].get("top_1", 0),
                result["metrics"].get("auc_top_10", 0),
                100 * result["metrics"].get("pr_at_10", 0),
                result.get("best_combined_score", 0),
                result.get("total_oracle_calls", 0),
                result["elapsed_time"],
            )

    out_path = _save_results(all_results, args.output_dir, final=True)
    logger.info("Results saved to %s", out_path)


if __name__ == "__main__":
    main()
