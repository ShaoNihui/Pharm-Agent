#!/usr/bin/env python
"""
Build FAISS index from MMP data for the MedChem-RAG module.

Usage:
    python scripts/build_faiss_index.py
    python scripts/build_faiss_index.py --mmp_data data/chembl_mmp/mmp_pairs.json
"""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import logging
import os
from pathlib import Path
import sys
import tempfile

import numpy as np
from tqdm import tqdm

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pharmagent.tools.rdkit_tools import compute_morgan_fp
from rdkit import rdBase

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)
logger = logging.getLogger(__name__)


def _sha256_file(path: str | os.PathLike[str]) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _atomic_json(path: str | os.PathLike[str], value: object) -> None:
    destination = Path(path)
    fd, temporary = tempfile.mkstemp(
        prefix=".pharmagent-", suffix=".json", dir=destination.parent
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, indent=2, sort_keys=True)
            handle.write("\n")
        os.replace(temporary, destination)
    except Exception:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def _validate_strict_rows(rows: list[dict]) -> dict[str, int]:
    target_counts: dict[str, int] = {}
    seen: set[tuple[str, str, str]] = set()
    for offset, row in enumerate(rows):
        if not isinstance(row, dict):
            raise ValueError(f"MMP row {offset} is not an object")
        if row.get("strict_fragmentation_mmp") is not True:
            raise ValueError(f"MMP row {offset} is not a strict fragmentation MMP")
        transformation = row.get("transformation")
        if (
            not isinstance(transformation, str)
            or transformation.count(">>") != 1
            or transformation.startswith("Similarity=")
        ):
            raise ValueError(f"MMP row {offset} has no fragmentation transform")
        target_id = row.get("target_chembl_id")
        source = row.get("source_smiles")
        target = row.get("target_smiles")
        if not all(isinstance(item, str) and item for item in (target_id, source, target)):
            raise ValueError(f"MMP row {offset} has incomplete identity fields")
        key = (target_id, source, target)
        if key in seen:
            raise ValueError(f"duplicate directed MMP row: {key}")
        seen.add(key)
        target_counts[target_id] = target_counts.get(target_id, 0) + 1
    return dict(sorted(target_counts.items()))


def build_index(mmp_data_path: str, output_dir: str = "data/retrieval_index",
                batch_size: int = 8192, *,
                mmp_manifest_path: str | None = None,
                require_strict_mmp: bool = False):
    """Build FAISS index from MMP JSON data."""
    try:
        import faiss
    except ImportError as exc:
        raise RuntimeError("faiss not installed. Run: pip install faiss-cpu") from exc

    os.makedirs(output_dir, exist_ok=True)

    # Load MMP data
    logger.info("Loading MMP data from %s...", mmp_data_path)
    with open(mmp_data_path) as f:
        mmp_data = json.load(f)
    if not isinstance(mmp_data, list) or not mmp_data:
        raise ValueError("MMP data must be a non-empty JSON list")
    logger.info("Loaded %d MMP entries", len(mmp_data))

    source_sha = _sha256_file(mmp_data_path)
    strict_target_counts: dict[str, int] | None = None
    upstream_manifest: dict | None = None
    upstream_manifest_sha: str | None = None
    if mmp_manifest_path is None:
        candidate = Path(mmp_data_path).with_name("mmp_pairs_manifest.json")
        if candidate.is_file():
            mmp_manifest_path = str(candidate)
    if mmp_manifest_path is not None:
        upstream_path = Path(mmp_manifest_path).expanduser().resolve()
        upstream_manifest = json.loads(upstream_path.read_text(encoding="utf-8"))
        if not isinstance(upstream_manifest, dict):
            raise ValueError("MMP manifest must be a JSON object")
        upstream_manifest_sha = _sha256_file(upstream_path)
        if upstream_manifest.get("pairs_sha256") != source_sha:
            raise ValueError("MMP manifest pairs SHA does not match input data")
    if require_strict_mmp:
        if upstream_manifest is None:
            raise ValueError("formal strict MMP indexing requires an upstream manifest")
        if (
            upstream_manifest.get("schema_version") != 2
            or upstream_manifest.get("strict_fragmentation_mmp") is not True
        ):
            raise ValueError("upstream manifest is not strict fragmentation MMP")
        strict_target_counts = _validate_strict_rows(mmp_data)
        if upstream_manifest.get("total_pairs") != len(mmp_data):
            raise ValueError("upstream MMP manifest count does not match pair rows")

    if batch_size <= 0:
        raise ValueError("batch_size must be positive")

    # Build in batches.  A dense 500K x 2048 float32 matrix is ~4 GiB, and
    # keeping both the list of vectors and the stacked matrix can double that.
    # Batched adds keep the formal 5,000-activity data build memory-bounded.
    valid_data = []
    pending = []
    test_fp = None
    dim = 2048
    use_flat = len(mmp_data) < 500000
    if use_flat:
        logger.info("Using IndexFlatL2 (dataset < 500K)")
        index = faiss.IndexFlatL2(dim)
    else:
        index = None
    training_fingerprints = []
    training_cap = min(100000, len(mmp_data))

    for mmp in tqdm(mmp_data, desc="Computing fingerprints"):
        if not isinstance(mmp, dict) or not isinstance(mmp.get("source_smiles"), str):
            continue
        fp = compute_morgan_fp(mmp["source_smiles"])
        if fp is not None:
            if test_fp is None:
                test_fp = fp.reshape(1, -1)
            valid_data.append(mmp)
            if use_flat:
                pending.append(fp)
                if len(pending) >= batch_size:
                    index.add(np.stack(pending))
                    pending.clear()
            elif len(training_fingerprints) < training_cap:
                training_fingerprints.append(fp)

    if not valid_data:
        raise ValueError("No valid fingerprints computed. Check MMP data.")
    if use_flat:
        if pending:
            index.add(np.stack(pending))
    else:
        logger.info("Using IndexIVFFlat (dataset >= 500K)")
        import math
        n = len(valid_data)
        nlist = max(1, min(1024, int(math.sqrt(n))))
        if nlist >= n:
            nlist = max(1, n // 2)
        quantizer = faiss.IndexFlatL2(dim)
        index = faiss.IndexIVFFlat(quantizer, dim, nlist)
        index.train(np.stack(training_fingerprints))
        for start in tqdm(
            range(0, len(valid_data), batch_size), desc="Adding FAISS batches"
        ):
            batch = [
                compute_morgan_fp(row["source_smiles"])
                for row in valid_data[start:start + batch_size]
            ]
            index.add(np.stack(batch))

    # Save index
    index_path = os.path.join(output_dir, "mmp_index.faiss")
    fd, temporary_index_path = tempfile.mkstemp(
        prefix=".pharmagent-", suffix=".faiss", dir=output_dir
    )
    os.close(fd)
    try:
        faiss.write_index(index, temporary_index_path)
        verified = faiss.read_index(temporary_index_path)
        if int(verified.ntotal) != len(valid_data):
            raise RuntimeError(
                "FAISS verification failed: "
                f"ntotal={verified.ntotal}, JSON entries={len(valid_data)}"
            )
        os.replace(temporary_index_path, index_path)
    except Exception:
        try:
            os.unlink(temporary_index_path)
        except FileNotFoundError:
            pass
        raise
    logger.info("FAISS index saved to %s (%d vectors)", index_path, index.ntotal)

    # Save valid data subset
    data_path = os.path.join(output_dir, "mmp_data_indexed.json")
    fd, temporary_data_path = tempfile.mkstemp(
        prefix=".pharmagent-", suffix=".json", dir=output_dir
    )
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(valid_data, f, indent=2)
            f.write("\n")
        os.replace(temporary_data_path, data_path)
    except Exception:
        try:
            os.unlink(temporary_data_path)
        except FileNotFoundError:
            pass
        raise
    logger.info("Indexed MMP data saved to %s (%d entries)", data_path, len(valid_data))

    data_sha = _sha256_file(data_path)
    index_sha = _sha256_file(index_path)
    asset_manifest_path = os.path.join(output_dir, "rag_asset_manifest.json")
    asset_manifest = {
        "schema_version": 1,
        "artifact_type": "pharmagent_strict_mmp_faiss_bundle",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "strict_fragmentation_mmp": bool(require_strict_mmp),
        "upstream": {
            "mmp_pairs_file": Path(mmp_data_path).name,
            "mmp_pairs_sha256": source_sha,
            "mmp_pairs_manifest_file": (
                Path(mmp_manifest_path).name if mmp_manifest_path else None
            ),
            "mmp_pairs_manifest_sha256": upstream_manifest_sha,
            "chembl_activity_source_sha256": (
                (upstream_manifest or {}).get("source", {}).get("activities_sha256")
            ),
            "chembl_activity_manifest_sha256": (
                (upstream_manifest or {}).get("source", {}).get(
                    "activities_manifest_sha256"
                )
            ),
            "chembl_assay_source_sha256": (
                (upstream_manifest or {}).get("source", {}).get("assays_sha256")
            ),
        },
        "fingerprint": {
            "algorithm": "Morgan bit vector",
            "radius": 2,
            "n_bits": 2048,
            "storage_dtype": "float32",
        },
        "faiss": {
            "index_type": type(index).__name__,
            "distance": "squared L2 on binary Morgan bits",
            "version": getattr(faiss, "__version__", "unknown"),
            "index_file": Path(index_path).name,
            "index_sha256": index_sha,
            "ntotal": int(index.ntotal),
        },
        "indexed_data": {
            "file": Path(data_path).name,
            "sha256": data_sha,
            "count": len(valid_data),
        },
        "software": {"rdkit": rdBase.rdkitVersion},
        "counts_by_target": strict_target_counts,
    }
    _atomic_json(asset_manifest_path, asset_manifest)

    # Quick verification
    logger.info("Verifying index...")
    distances, indices = index.search(test_fp, 5)
    logger.info("Test search — top 5 distances: %s", distances[0])
    logger.info("Index build complete!")
    return {
        "index_path": index_path,
        "data_path": data_path,
        "ntotal": int(index.ntotal),
        "entries": len(valid_data),
        "asset_manifest_path": asset_manifest_path,
    }


def main():
    parser = argparse.ArgumentParser(description="Build FAISS index for MedChem-RAG")
    parser.add_argument(
        "--mmp_data",
        type=str,
        default="data/matched_pairs/mmp_pairs.json",
        help="Path to MMP pairs JSON file",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default="data/retrieval_index",
        help="Output directory for FAISS index",
    )
    parser.add_argument(
        "--batch_size",
        type=int,
        default=8192,
        help="Number of fingerprints added to FAISS per batch",
    )
    parser.add_argument(
        "--mmp_manifest",
        default="data/matched_pairs/mmp_pairs_manifest.json",
        help="Strict MMP lineage manifest",
    )
    parser.add_argument(
        "--allow_non_strict",
        action="store_true",
        help="Non-strict lineage mode; excluded from formal assets",
    )
    args = parser.parse_args()

    if not os.path.exists(args.mmp_data):
        parser.error(
            f"MMP data file not found: {args.mmp_data}\n"
            "Run 'python scripts/prepare_mmp_data.py --action all' first.",
        )

    build_index(
        args.mmp_data,
        args.output_dir,
        batch_size=args.batch_size,
        mmp_manifest_path=args.mmp_manifest,
        require_strict_mmp=not args.allow_non_strict,
    )


if __name__ == "__main__":
    main()
