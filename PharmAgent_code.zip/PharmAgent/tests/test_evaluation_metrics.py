"""Regression tests for paper-table metric computation."""

from copy import deepcopy
import unittest
from unittest import mock

from pharmagent.agents.admet_analyst import ADMETAnalystAgent
from pharmagent.evaluation.metrics import (
    annotate_history_with_admet,
    build_evaluation_history,
    compute_admet_adjusted_auc_from_history,
    compute_pmo_run_metrics,
    compute_top_auc,
)
from pharmagent.tools.admet_predictor import ADMETPredictor


class _BatchContextSensitiveADMETModel:
    def __init__(self):
        self.calls: list[tuple[str, ...]] = []

    def predict(self, smiles):
        self.calls.append(tuple(smiles))
        return [
            {
                "hERG": 0.2 + sum(ord(char) for char in smi) / 10_000
                + (len(smiles) - 1) * 1e-5
                + index * 1e-6,
                "Caco2_Wang": -4.8,
            }
            for index, smi in enumerate(smiles)
        ]


def _formal_analyst():
    config = {
        "backend": "admet_ai",
        "fallback_to_rdkit": False,
        "allow_approximate_endpoint_fallback": False,
        "missing_prediction_policy": "fail",
        "inference_mode": "canonical_singleton",
        "admet_constraints": {
            "herg": {"type": "max", "threshold": 0.5},
            "caco2": {"type": "min", "threshold": -5.15},
        },
    }
    analyst = ADMETAnalystAgent(config)
    predictor = ADMETPredictor(backend="admet_ai", config=config)
    model = _BatchContextSensitiveADMETModel()
    predictor._admet_ai_model = model
    predictor._admet_ai_load_attempted = True
    predictor._admet_ai_version = "1.4.0-test"
    analyst.admet = predictor
    return analyst, model


class EvaluationMetricTests(unittest.TestCase):
    def test_formal_annotation_is_exact_across_batch_order_and_restart(self):
        history = [
            {"call_index": 1, "smiles": "CCO", "raw_target_score": 0.3},
            {"call_index": 2, "smiles": "CCN", "raw_target_score": 0.7},
            {"call_index": 3, "smiles": "CCC", "raw_target_score": 0.5},
        ]
        forward_analyst, forward_model = _formal_analyst()
        singleton_analyst, singleton_model = _formal_analyst()
        restarted_analyst, restarted_model = _formal_analyst()

        with mock.patch(
            "pharmagent.agents.admet_analyst.compute_sa_score",
            return_value=2.5,
        ):
            forward = annotate_history_with_admet(
                history, forward_analyst, batch_size=3
            )
            singleton = annotate_history_with_admet(
                history, singleton_analyst, batch_size=1
            )
            restarted_reverse = annotate_history_with_admet(
                list(reversed(deepcopy(history))),
                restarted_analyst,
                batch_size=2,
            )

        self.assertEqual(forward, singleton)
        self.assertEqual(
            {row["smiles"]: row for row in forward},
            {row["smiles"]: row for row in restarted_reverse},
        )
        self.assertEqual(
            forward_model.calls, [("CCO",), ("CCN",), ("CCC",)]
        )
        self.assertTrue(all(len(call) == 1 for call in singleton_model.calls))
        self.assertTrue(all(len(call) == 1 for call in restarted_model.calls))

    def test_formal_annotation_fails_closed_on_cardinality_or_provenance(self):
        history = [
            {"call_index": 1, "smiles": "CCO", "raw_target_score": 0.3}
        ]

        class EmptyAnalyst:
            @staticmethod
            def run(_inputs):
                return {"admet_results": []}

        class HeuristicAnalyst:
            @staticmethod
            def run(_inputs):
                return {
                    "admet_results": [{
                        "admet_predictions": {
                            "prediction_backend": "rdkit_only",
                        },
                        "violations": [],
                        "admet_score": 1.0,
                        "pass_all": True,
                    }]
                }

        with self.assertRaisesRegex(RuntimeError, "count differs"):
            annotate_history_with_admet(history, EmptyAnalyst())
        with self.assertRaisesRegex(RuntimeError, "strict ADMET-AI provenance"):
            annotate_history_with_admet(history, HeuristicAnalyst())

    def test_build_history_accepts_tracked_oracle_buffer(self):
        history = build_evaluation_history({"CCO": 0.2, "CCN": 0.7})

        self.assertEqual([row["call_index"] for row in history], [1, 2])
        self.assertEqual([row["smiles"] for row in history], ["CCO", "CCN"])
        self.assertEqual(history[1]["raw_target_score"], 0.7)

    def test_build_history_accepts_reference_pmo_buffer(self):
        history = build_evaluation_history({"CCN": [0.7, 2], "CCO": [0.2, 1]})

        self.assertEqual([row["smiles"] for row in history], ["CCO", "CCN"])

    def test_top_auc_matches_reference_trapezoidal_rule(self):
        history = [
            {"call_index": index, "raw_target_score": 1.0}
            for index in range(1, 101)
        ]

        # The reference PMO implementation initializes the curve at zero,
        # making a constant-one, 100-call curve integrate to 0.95 at freq=10.
        auc = compute_top_auc(
            history, top_n=10, oracle_budget=100, freq_log=10, finish=True
        )
        self.assertAlmostEqual(auc, 0.95)

    def test_aa_auc_uses_passing_raw_scores_at_each_call(self):
        history = [
            {"call_index": 1, "raw_target_score": 0.9, "pass_all": False},
            {"call_index": 2, "raw_target_score": 0.5, "pass_all": True},
            {"call_index": 3, "raw_target_score": 0.4, "pass_all": True},
        ]

        # Curve over four budgeted calls: [0.0, 0.5, 0.5, 0.5].
        self.assertAlmostEqual(
            compute_admet_adjusted_auc_from_history(history, oracle_budget=4),
            0.375,
        )

    def test_run_metrics_report_pr_and_hypervolume(self):
        history = [
            {
                "call_index": 1,
                "raw_target_score": 0.8,
                "admet_score": 0.4,
                "pass_all": False,
            },
            {
                "call_index": 2,
                "raw_target_score": 0.6,
                "admet_score": 0.9,
                "pass_all": True,
                "admet_backend": "admet_ai",
                "admet_ai_version": "1.4.0",
            },
        ]

        metrics = compute_pmo_run_metrics(history, oracle_budget=2, freq_log=1)

        self.assertEqual(metrics["top_1"], 0.8)
        self.assertEqual(metrics["pr_at_10"], 0.5)
        self.assertAlmostEqual(metrics["pareto_hypervolume"], 0.62)
        self.assertEqual(metrics["admet_ai_version"], "1.4.0")


if __name__ == "__main__":
    unittest.main()
