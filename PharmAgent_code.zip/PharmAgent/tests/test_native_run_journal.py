"""Offline contracts for crash-safe native PharmAgent journals."""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest import mock

from pharmagent.evaluation.native_run import (
    IndeterminateLLMRequestError,
    IndeterminateOracleCallError,
    NativeRunIdentityError,
    NativeRunJournal,
    NativeRunJournalError,
    reject_unjournaled_partial_resume,
)
from pharmagent.evaluation.oracle_utils import TrackedOracle
from pharmagent.llm.api_client import (
    LLMClient,
    LLMTransportRecoveryExhaustedError,
)
from pharmagent.optimization.experience_replay import ExperienceDB


def _identity(seed: int = 0) -> dict:
    return {
        "kind": "pharmagent-native-run",
        "identity_version": 1,
        "formal_identity_sha256": "a" * 64,
        "phase": "admet",
        "task": "gsk3b",
        "seed": seed,
        "oracle_budget": 1000,
    }


class NativeRunJournalTests(unittest.TestCase):
    def test_cer_without_journal_is_rejected_as_complete_resume_state(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            cer_config = {
                "enabled": True,
                "path": str(root / "cer.sqlite3"),
                "seed": 0,
                "identity": {"kind": "offline-cer"},
                "max_size": 10,
                "top_k": 1,
                "fp_radius": 2,
                "fp_nbits": 64,
            }
            with ExperienceDB(cer_config) as database:
                database.add_experience({
                    "source_smiles": "CCO",
                    "target_smiles": "CCN",
                    "modifications": [],
                    "delta_target": 0.1,
                    "delta_admet": 0.0,
                    "delta_combined": 0.1,
                    "task_name": "gsk3b",
                    "round": 2,
                })
            with self.assertRaisesRegex(
                NativeRunJournalError, "CER rows do not contain full optimizer state"
            ):
                reject_unjournaled_partial_resume(
                    {"cer": cer_config},
                    journal_path=root / "missing-native.sqlite3",
                    task="gsk3b",
                    seed=0,
                )

    def test_llm_client_replays_response_usage_without_second_http(self):
        with tempfile.TemporaryDirectory() as directory, mock.patch(
            "pharmagent.llm.api_client.OpenAI"
        ) as openai_class:
            root = Path(directory)
            journal_path = root / "run.sqlite3"
            ledger_path = root / "attempts.sqlite3"
            identity = _identity()
            config = {
                "backend": "deepseek",
                "api_key": "offline-test",
                "thinking_type": "disabled",
                "max_retries": 1,
                "attempt_ledger": {
                    "path": str(ledger_path),
                    "cap": 10,
                    "identity": {"kind": "offline-ledger"},
                },
                "native_run_journal": {
                    "path": str(journal_path),
                    "identity": identity,
                },
            }
            sdk = openai_class.return_value
            sdk.chat.completions.create.return_value = SimpleNamespace(
                choices=[SimpleNamespace(
                    message=SimpleNamespace(content='{"ok": true}')
                )],
                usage=SimpleNamespace(
                    prompt_tokens=4,
                    prompt_cache_hit_tokens=1,
                    prompt_cache_miss_tokens=3,
                    completion_tokens=2,
                    total_tokens=6,
                ),
            )
            first = LLMClient(config, client_role="generator")
            self.assertEqual(
                first.generate("offline", request_id="round:0:generator"),
                '{"ok": true}',
            )
            reopened = LLMClient(config, client_role="generator")
            self.assertEqual(
                reopened.generate(
                    "offline", request_id="round:0:generator"
                ),
                '{"ok": true}',
            )
            self.assertEqual(sdk.chat.completions.create.call_count, 1)
            usage = reopened.usage_snapshot()
            self.assertEqual(usage["successful_http_calls"], 1)
            self.assertEqual(usage["total_tokens"], 6)
            self.assertTrue(
                usage["usage_availability"][
                    "covers_durable_attempt_history"
                ]
            )

    def test_known_transient_failure_reopens_same_logical_request(self):
        """A live outage must not become a later optimization round error."""
        with tempfile.TemporaryDirectory() as directory, mock.patch(
            "pharmagent.llm.api_client.OpenAI"
        ) as openai_class:
            root = Path(directory)
            config = {
                "backend": "deepseek",
                "api_key": "offline-test",
                "thinking_type": "disabled",
                "max_retries": 2,
                "retry_delay": 0,
                "max_retry_elapsed": 0,
                "max_transport_recovery_batches": 1,
                "attempt_ledger": {
                    "path": str(root / "attempts.sqlite3"),
                    "cap": 10,
                    "identity": {"kind": "offline-ledger"},
                },
                "native_run_journal": {
                    "path": str(root / "run.sqlite3"),
                    "identity": _identity(),
                },
            }
            sdk = openai_class.return_value
            sdk.chat.completions.create.side_effect = [
                ConnectionError("offline"),
                ConnectionError("offline"),
                SimpleNamespace(
                    choices=[SimpleNamespace(
                        message=SimpleNamespace(content='{"ok": true}')
                    )],
                    usage=SimpleNamespace(
                        prompt_tokens=4,
                        prompt_cache_hit_tokens=1,
                        prompt_cache_miss_tokens=3,
                        completion_tokens=2,
                        total_tokens=6,
                    ),
                ),
            ]

            client = LLMClient(config, client_role="generator")
            self.assertEqual(
                client.generate("offline", request_id="round:0:generator"),
                '{"ok": true}',
            )
            journal = NativeRunJournal(
                root / "run.sqlite3", identity=_identity()
            )
            self.assertEqual(sdk.chat.completions.create.call_count, 3)
            self.assertEqual(client.attempt_ledger.attempts_used, 3)
            self.assertEqual(journal.llm_request_counts(), {"complete": 1})
            self.assertEqual(journal.llm_request_audit(), [{
                "request_id": "round:0:generator",
                "client_role": "generator",
                "status": "complete",
                "known_failed_attempts": 2,
                "last_accounted_attempt": 3,
            }])

    def test_transient_recovery_fuse_stops_without_round_fallback(self):
        with tempfile.TemporaryDirectory() as directory, mock.patch(
            "pharmagent.llm.api_client.OpenAI"
        ) as openai_class:
            root = Path(directory)
            config = {
                "backend": "deepseek",
                "api_key": "offline-test",
                "thinking_type": "disabled",
                "max_retries": 2,
                "retry_delay": 0,
                "max_retry_elapsed": 0,
                "max_transport_recovery_batches": 1,
                "attempt_ledger": {
                    "path": str(root / "attempts.sqlite3"),
                    "cap": 10,
                    "identity": {"kind": "offline-ledger"},
                },
                "native_run_journal": {
                    "path": str(root / "run.sqlite3"),
                    "identity": _identity(),
                },
            }
            openai_class.return_value.chat.completions.create.side_effect = (
                ConnectionError("offline")
            )
            client = LLMClient(config, client_role="generator")

            with self.assertRaises(LLMTransportRecoveryExhaustedError):
                client.generate("offline", request_id="round:0:generator")
            journal = NativeRunJournal(
                root / "run.sqlite3", identity=_identity()
            )
            self.assertEqual(client.attempt_ledger.attempts_used, 4)
            self.assertEqual(journal.llm_request_counts(), {"failed_known": 1})
            self.assertEqual(
                journal.llm_request_audit()[0]["known_failed_attempts"], 4
            )

    def test_tracked_oracle_reopens_without_repeating_base_score(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "run.sqlite3"
            journal = NativeRunJournal(path, identity=_identity())
            calls = []

            def base(smiles):
                calls.append(smiles)
                return 0.42

            first = TrackedOracle(
                base, "gsk3b", 10, native_journal=journal
            )
            first.set_native_call_context({"scope": "seed_pool"})
            self.assertEqual(first("CCO"), 0.42)
            self.assertEqual(calls, ["CCO"])

            reopened = TrackedOracle(
                lambda _smiles: self.fail("base oracle was repeated"),
                "gsk3b",
                10,
                native_journal=NativeRunJournal(path, identity=_identity()),
            )
            self.assertEqual(reopened("OCC"), 0.42)
            self.assertEqual(reopened.call_count, 1)
            self.assertEqual(len(reopened.mol_buffer), 1)

    def test_pending_oracle_call_is_never_automatically_reissued(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "run.sqlite3"
            journal = NativeRunJournal(path, identity=_identity())
            journal.reserve_oracle_call("CCN")
            with self.assertRaises(IndeterminateOracleCallError):
                TrackedOracle(
                    lambda _smiles: 0.1,
                    "gsk3b",
                    10,
                    native_journal=NativeRunJournal(
                        path, identity=_identity()
                    ),
                )

    def test_oracle_raw_and_complete_stages_survive_reopen(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "run.sqlite3"
            journal = NativeRunJournal(path, identity=_identity())
            pending = journal.reserve_oracle_call(
                "CCO", context={"origin": "seed_pool"}
            )
            self.assertEqual(pending["call_index"], 1)
            self.assertEqual(pending["stage"], "pending")

            raw = journal.record_raw_oracle_score("CCO", 0.25)
            self.assertEqual(raw["stage"], "raw_scored")
            self.assertEqual(raw["raw_target_score"], 0.25)

            reopened = NativeRunJournal(path, identity=_identity())
            recovered = reopened.reserve_oracle_call(
                "CCO", context={"origin": "different_replay_context"}
            )
            self.assertEqual(recovered["stage"], "raw_scored")
            self.assertEqual(recovered["context"], {"origin": "seed_pool"})
            reopened.complete_oracle_call(
                "CCO",
                {
                    "call_index": 1,
                    "smiles": "CCO",
                    "raw_target_score": 0.25,
                },
            )
            self.assertEqual(
                reopened.evaluation_history(),
                [{"call_index": 1, "smiles": "CCO", "raw_target_score": 0.25}],
            )

    def test_oracle_replay_is_idempotent_and_disagreement_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            journal = NativeRunJournal(
                Path(directory) / "run.sqlite3", identity=_identity()
            )
            journal.reserve_oracle_call("CCN")
            journal.record_raw_oracle_score("CCN", 0.5)
            record = {
                "call_index": 1,
                "smiles": "CCN",
                "raw_target_score": 0.5,
            }
            journal.complete_oracle_call("CCN", record)
            journal.complete_oracle_call("CCN", record)
            with self.assertRaisesRegex(
                NativeRunJournalError, "disagrees"
            ):
                journal.complete_oracle_call(
                    "CCN", {**record, "extra": "changed"}
                )

    def test_identity_mismatch_fails_closed(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "run.sqlite3"
            NativeRunJournal(path, identity=_identity())
            with self.assertRaises(NativeRunIdentityError):
                NativeRunJournal(path, identity=_identity(seed=1))

    def test_completed_llm_response_and_usage_are_replayable(self):
        with tempfile.TemporaryDirectory() as directory:
            journal = NativeRunJournal(
                Path(directory) / "run.sqlite3", identity=_identity()
            )
            request = {
                "messages": [{"role": "user", "content": "return JSON"}],
                "temperature": 0.7,
            }
            state = journal.prepare_llm_request(
                request_id="round-0-generator-0",
                client_role="generator",
                request=request,
                durable_attempts_used=0,
            )
            self.assertEqual(state["status"], "prepared")
            journal.mark_llm_http_started("round-0-generator-0", 1)
            journal.complete_llm_request(
                "round-0-generator-0",
                response_text='{"molecules": []}',
                usage={
                    "prompt_tokens": 10,
                    "prompt_cache_hit_tokens": 2,
                    "prompt_cache_miss_tokens": 8,
                    "completion_tokens": 3,
                    "total_tokens": 13,
                    "response_with_usage": True,
                    "field_observations": {
                        "prompt_tokens": 1,
                        "prompt_cache_hit_tokens": 1,
                        "prompt_cache_miss_tokens": 1,
                        "completion_tokens": 1,
                        "total_tokens": 1,
                    },
                },
            )
            replay = journal.prepare_llm_request(
                request_id="round-0-generator-0",
                client_role="generator",
                request=request,
                durable_attempts_used=1,
            )
            self.assertEqual(replay["status"], "complete")
            self.assertEqual(replay["response_text"], '{"molecules": []}')
            usage = journal.llm_usage_for_role("generator")
            self.assertEqual(usage["successful_http_calls"], 1)
            self.assertEqual(usage["prompt_tokens"], 10)
            self.assertEqual(usage["total_tokens"], 13)

    def test_inflight_llm_request_never_auto_retries(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "run.sqlite3"
            journal = NativeRunJournal(path, identity=_identity())
            request = {"messages": [{"role": "user", "content": "x"}]}
            journal.prepare_llm_request(
                request_id="r0-generator-0",
                client_role="generator",
                request=request,
                durable_attempts_used=0,
            )
            journal.mark_llm_http_started("r0-generator-0", 1)
            reopened = NativeRunJournal(path, identity=_identity())
            with self.assertRaisesRegex(
                IndeterminateLLMRequestError, "duplicate payment"
            ):
                reopened.prepare_llm_request(
                    request_id="r0-generator-0",
                    client_role="generator",
                    request=request,
                    durable_attempts_used=1,
                )

    def test_unlinked_ledger_advance_is_indeterminate(self):
        with tempfile.TemporaryDirectory() as directory:
            journal = NativeRunJournal(
                Path(directory) / "run.sqlite3", identity=_identity()
            )
            request = {"messages": [{"role": "user", "content": "x"}]}
            journal.prepare_llm_request(
                request_id="r0-reviewer-0",
                client_role="reviewer",
                request=request,
                durable_attempts_used=3,
            )
            with self.assertRaisesRegex(
                IndeterminateLLMRequestError, "ledger advanced"
            ):
                journal.prepare_llm_request(
                    request_id="r0-reviewer-0",
                    client_role="reviewer",
                    request=request,
                    durable_attempts_used=4,
                )

    def test_optimizer_state_is_hashed_and_versioned(self):
        with tempfile.TemporaryDirectory() as directory:
            journal = NativeRunJournal(
                Path(directory) / "run.sqlite3", identity=_identity()
            )
            first = journal.save_optimizer_state(
                {"phase": "round_ready", "next_round": 0}
            )
            second = journal.save_optimizer_state(
                {"phase": "round_ready", "next_round": 1}
            )
            self.assertEqual(first["revision"], 1)
            self.assertEqual(second["revision"], 2)
            loaded = journal.load_optimizer_state()
            self.assertEqual(loaded["revision"], 2)
            self.assertEqual(loaded["state"]["next_round"], 1)
            snapshot = journal.snapshot()
            self.assertEqual(snapshot["optimizer_state_revision"], 2)
            self.assertEqual(snapshot["oracle_complete_count"], 0)


if __name__ == "__main__":
    unittest.main()
