"""Offline tests for the public launcher and fixed scientific protocol."""

import io
import json
import os
from contextlib import redirect_stdout
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import yaml
import check_installation
import run
import summarize
from pharmagent.evaluation.formal_identity import FormalIdentityError, validate_formal_arm_config
from pharmagent.llm.api_client import LLMClient
from pharmagent.optimization.curriculum import ConstraintScheduler
from pharmagent.optimization.lagrangian import LagrangianOptimizer
from scripts import run_distributed_pharmagent as driver

ROOT = Path(__file__).resolve().parents[1]


class PackageTests(unittest.TestCase):
    def test_package_integrity(self):
        check_installation.check_reference()

    def test_command_defaults_to_zero_api(self):
        args = run.parser().parse_args([])
        command = run.command(args, paid=False)
        self.assertIn("--dry-run", command)
        self.assertNotIn("--allow-paid-api", command)

    def test_each_selection_has_exact_paid_envelope(self):
        for experiment, workers, cap in (("E1", 5, 1502500), ("E2", 5, 1502500), ("both", 10, 3005000)):
            with self.subTest(experiment=experiment):
                args = run.parser().parse_args(["--experiment", experiment])
                command = run.command(args, paid=True)
                self.assertEqual(command[command.index("--confirm-formal-jobs") + 1], str(workers))
                self.assertEqual(command[command.index("--confirm-http-attempt-cap") + 1], str(cap))
                self.assertIn("--resume", command)

    def test_e2_needs_no_e1_completion(self):
        driver._require_execution_phase_barrier({}, [], execute_phases=["admet"])

    def test_credential_is_environment_only_in_driver(self):
        with patch.dict(os.environ, {run.API_ENV: "offline-test-placeholder"}, clear=True):
            self.assertEqual(driver.resolve_api_key(run.API_ENV), "offline-test-placeholder")
        with patch.dict(os.environ, {}, clear=True):
            with self.assertRaises(driver.DistributedRunError):
                driver.resolve_api_key(run.API_ENV)

    def test_multiline_credential_is_rejected(self):
        with patch.dict(os.environ, {run.API_ENV: "invalid\nplaceholder"}, clear=True):
            with self.assertRaises(ValueError):
                run.read_credential()

    def test_noninteractive_missing_key_is_rejected(self):
        with patch.dict(os.environ, {}, clear=True), patch("run.sys.stdin.isatty", return_value=False):
            with self.assertRaises(ValueError):
                run.read_credential()

    def test_redaction(self):
        self.assertEqual(driver._redact("before placeholder after", "placeholder"), "before [REDACTED] after")

    def test_lock_rejects_duplicate_and_can_reopen(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with run.output_lock(root):
                with self.assertRaises(ValueError):
                    with run.output_lock(root):
                        pass
            with run.output_lock(root):
                pass

    def test_formal_configuration_rejects_changed_budget(self):
        cfg = yaml.safe_load((ROOT / "configs" / "pmo_admet.yaml").read_text())
        validate_formal_arm_config(cfg, "admet")
        cfg["optimization"]["oracle_budget"] = 10
        with self.assertRaises(FormalIdentityError):
            validate_formal_arm_config(cfg, "admet")

    def test_curriculum_exact_boundaries_despite_stagnation(self):
        cfg = yaml.safe_load((ROOT / "configs" / "pmo_admet.yaml").read_text())
        scheduler = ConstraintScheduler(cfg["admet"]["admet_constraints"], cfg["curriculum"])
        counts = [len(scheduler.get_active_constraints(i, stagnation_count=1000)) for i in range(61)]
        self.assertEqual(counts[:20], [0] * 20)
        self.assertEqual(counts[20:60], [4] * 40)
        self.assertEqual(counts[60], 7)

    def test_penalty_activation_retains_duals_and_resets_rho(self):
        cfg = yaml.safe_load((ROOT / "configs" / "pmo_admet.yaml").read_text())
        optimizer = LagrangianOptimizer(cfg["admet"]["admet_constraints"], cfg["lagrangian"])
        optimizer.prepare_active_constraints(["qed"], round_idx=20)
        optimizer.update_duals({"qed": 1.0}, ["qed"])
        previous_dual = optimizer.lambdas["qed"]
        optimizer.prepare_active_constraints(["qed", "herg"], round_idx=60)
        self.assertEqual(optimizer.lambdas["qed"], previous_dual)
        self.assertEqual(optimizer.rho, optimizer.rho_init)

    def test_minimax_wire_protocol_with_mocked_sdk(self):
        cfg = yaml.safe_load((ROOT / "configs" / "pmo_standard.yaml").read_text())["llm"]
        with patch.dict(os.environ, {run.API_ENV: "offline-test-placeholder"}, clear=True), \
             patch("pharmagent.llm.api_client.OpenAI") as sdk_class:
            response = SimpleNamespace(
                base_resp=SimpleNamespace(status_code=0),
                choices=[SimpleNamespace(message=SimpleNamespace(content='{"candidates": []}'))],
                usage=SimpleNamespace(prompt_tokens=4, completion_tokens=2, total_tokens=6),
            )
            sdk_class.return_value.chat.completions.create.return_value = response
            client = LLMClient(cfg, client_role="generator")
            self.assertEqual(client.generate("offline test"), '{"candidates": []}')
            kwargs = sdk_class.return_value.chat.completions.create.call_args.kwargs
            self.assertEqual(kwargs["model"], "MiniMax-M3")
            self.assertEqual(kwargs["max_completion_tokens"], 2048)
            self.assertEqual(kwargs["service_tier"], "standard")
            self.assertEqual(kwargs["extra_body"], {"thinking": {"type": "disabled"}, "reasoning_split": True})
            self.assertNotIn("response_format", kwargs)
            self.assertNotIn("api_key", kwargs)

    def test_all_real_driver_plans_make_no_api_requests(self):
        identities = set()
        with patch.object(driver, "resolve_api_key", side_effect=AssertionError("credential access")), \
             patch.object(driver, "verify_minimax_model", side_effect=AssertionError("API access")):
            for phases, expected in ((["standard"], 5), (["admet"], 5), (["standard", "admet"], 10)):
                buffer = io.StringIO()
                with redirect_stdout(buffer):
                    status = driver.main([
                        "--dry-run", "--execute-phases", *phases,
                        "--standard-config", str(ROOT / "configs" / "pmo_standard.yaml"),
                        "--admet-config", str(ROOT / "configs" / "pmo_admet.yaml"),
                    ])
                self.assertEqual(status, 0)
                plan = json.loads(buffer.getvalue())
                self.assertFalse(plan["credentials_accessed"])
                self.assertEqual(len(plan["execution_jobs"]), expected)
                for job in plan["execution_jobs"]:
                    self.assertEqual(tuple(job["tasks"]), driver.FIVE_TASKS)
                    self.assertEqual(len(job["seed_indices"]), 1)
                    identities.add(job["formal_reproduction_identity"]["identity_sha256"])
        self.assertEqual(len(identities), 1)

    def test_summary_refuses_incomplete_and_duplicate_seeds(self):
        with self.assertRaises(ValueError):
            summarize.summarize_rows({}, experiment="E1", identity_sha256="a" * 64)
        rows = {task: [{"seed": 0}] * 5 for task in summarize.TASKS}
        with self.assertRaises(ValueError):
            summarize.summarize_rows(rows, experiment="E1", identity_sha256="a" * 64)

    def test_summary_mean_uses_all_five_seeds(self):
        rows = {task: [{"seed": seed, "metrics": {name: seed / 10 for name in summarize.BASE_METRICS}}
                       for seed in range(5)] for task in summarize.TASKS}
        with patch("pharmagent.evaluation.oracle_utils.is_complete_pmo_result", return_value=True) as validator:
            report = summarize.summarize_rows(rows, experiment="E1", identity_sha256="a" * 64)
        self.assertEqual(validator.call_count, 25)
        for item in report.values():
            self.assertEqual(item["mean"]["auc_top_10"], 0.2)
            self.assertEqual(item["n_seeds"], 5)


if __name__ == "__main__":
    unittest.main()
