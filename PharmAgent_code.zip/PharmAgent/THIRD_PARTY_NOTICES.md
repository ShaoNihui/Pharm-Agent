# Third-party resources

## ChEMBL retrieval snapshot

The files under `data/` are derived from the public **ChEMBL 37** database
maintained by EMBL-EBI. ChEMBL data are distributed under
[Creative Commons Attribution-ShareAlike 3.0 Unported](https://creativecommons.org/licenses/by-sa/3.0/).
That license also applies to the ChEMBL-derived data and index in this package.
See the [official ChEMBL licensing statement](https://chembl.gitbook.io/chembl-interface-documentation/about).

Processing consists of the documented activity filters, same-assay single-cut
matched-pair extraction, Morgan fingerprints, and FAISS indexing. The JSON
manifests record source attribution, filtering, release indices, transformation
metadata, record counts, and file hashes. These are public database records and
retrieval assets, not PharmAgent-generated experiment trajectories. No
endorsement by ChEMBL or EMBL-EBI is implied.

## PMO oracle models

The three files in `oracle/` are the public PyTDC PMO predictors. Their upstream
Harvard Dataverse file IDs, as mapped by PyTDC, are:

| File | Dataverse file ID |
| --- | --- |
| `drd2_current.pkl` | 6413411 |
| `gsk3b_current.pkl` | 6413412 |
| `jnk3_current.pkl` | 6413420 |

Upstream downloads use `https://dataverse.harvard.edu/api/access/datafile/`
followed by the file ID. SHA-256 checksums are recorded in
`provenance/package_reference.json`. Use only trusted, checksum-matching
model files: Python pickle is executable input, not a safe generic data format.
Consult the [TDC oracle documentation](https://tdcommons.ai/functions/oracles/)
for the predictors' source methods and citations, and the upstream records
for their terms. PharmAgent does not relicense these third-party models.

## Software and local prediction models

RDKit, FAISS, PyTDC, PyTorch, scikit-learn, Chemprop, and ADMET-AI are installed
from their respective distributions under their own licenses. ADMET-AI
provides the local ADMET prediction ensemble, and RDKit provides the SA score
fragment data. See [ADMET-AI](https://github.com/swansonk14/admet_ai),
[RDKit](https://github.com/rdkit/rdkit),
[FAISS](https://github.com/facebookresearch/faiss), and
[TDC](https://github.com/mims-harvard/TDC) for attribution and terms.

The model API is a separately operated service subject to the account holder's
provider terms and charges.
