#!/usr/bin/env python3
"""Print validated PharmAgent per-seed results and five-seed means as JSON."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
TASKS = ("gsk3b", "jnk3", "drd2", "sitagliptin_mpo", "albuterol_similarity")
PHASES = {"E1": "standard", "E2": "admet"}
BASE_METRICS = ("top_1", "top_10", "auc_top_10")


def summarize_rows(rows_by_task, *, experiment, identity_sha256):
    from pharmagent.evaluation.oracle_utils import is_complete_pmo_result
    if set(rows_by_task) != set(TASKS):
        raise ValueError("A complete experiment must contain all five tasks.")
    metrics = BASE_METRICS + (("aa_auc", "pareto_hypervolume") if experiment == "E2" else ())
    output = {}
    for task in TASKS:
        rows = rows_by_task[task]
        if (not isinstance(rows, list) or len(rows) != 5
                or any(not isinstance(row, dict) for row in rows)
                or {row.get("seed") for row in rows} != set(range(5))):
            raise ValueError(f"Incomplete or duplicate seeds: {experiment}/{task}")
        per_seed = []
        for row in sorted(rows, key=lambda value: value["seed"]):
            if not is_complete_pmo_result(
                row, task=task, seed=row["seed"], oracle_budget=1000,
                require_admet=experiment == "E2",
                require_lagrangian_phase_protocol=experiment == "E2",
                require_formal_reproduction_identity=True,
                expected_formal_identity_sha256=identity_sha256,
                require_novelty_recovery_protocol=True,
                require_near_feasible_repair_protocol=True,
                require_native_run_journal=True,
            ):
                raise ValueError(f"Completion validation failed: {experiment}/{task}/seed{row['seed']}")
            values = {name: row["metrics"][name] for name in metrics}
            if any(isinstance(value, bool) or not isinstance(value, (int, float))
                   or not math.isfinite(value) for value in values.values()):
                raise ValueError(f"Invalid metric: {experiment}/{task}/seed{row['seed']}")
            per_seed.append({"seed": row["seed"], **values})
        output[task] = {
            "n_seeds": 5, "per_seed": per_seed,
            "mean": {name: math.fsum(row[name] for row in per_seed) / 5 for name in metrics},
        }
    return output


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--experiment", choices=("E1", "E2", "both"), default="both")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "results" / "pharmagent")
    args = parser.parse_args(argv)
    root = args.output_dir.expanduser().resolve()
    try:
        manifest = json.loads((root / "run_manifest.json").read_text())
        from pharmagent.evaluation.formal_identity import build_formal_reproduction_identity
        identity = build_formal_reproduction_identity(
            code_dir=ROOT, standard_config=ROOT / "configs" / "pmo_standard.yaml",
            admet_config=ROOT / "configs" / "pmo_admet.yaml",
            matrix_scope="five_task_main", task_chain=TASKS,
        )
        selected = PHASES if args.experiment == "both" else {args.experiment: PHASES[args.experiment]}
        report = {}
        for experiment, phase in selected.items():
            aggregate = manifest.get("aggregates", {}).get(phase, {})
            if aggregate.get("formal_aggregate_published") is not True:
                report[experiment] = {"status": "incomplete", "seed_counts_by_task": aggregate.get("seed_counts_by_task", {})}
                continue
            filename = "standard_results_latest.json" if phase == "standard" else "admet_results_latest.json"
            rows = json.loads((root / "combined" / phase / filename).read_text())
            report[experiment] = {"status": "complete", "tasks": summarize_rows(
                rows, experiment=experiment, identity_sha256=identity["identity_sha256"])}
        print(json.dumps(report, indent=2, allow_nan=False))
        return 0
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(f"Cannot summarize: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
