#!/usr/bin/env python3
"""Check the fixed PharmAgent environment without making network requests."""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import socket
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent


def deny_network(*args, **kwargs):
    raise RuntimeError("Network access is disabled during installation checks.")


def check_reference():
    manifest = json.loads((ROOT / "MANIFEST.json").read_text())
    for relative, expected in manifest["files"].items():
        path = ROOT / relative
        if path.is_symlink() or not path.is_file() or ROOT not in path.resolve().parents:
            raise ValueError(f"Missing or unsafe package file: {relative}")
        observed = hashlib.sha256(path.read_bytes()).hexdigest()
        if observed != expected["sha256"] or path.stat().st_size != expected["size_bytes"]:
            raise ValueError(f"Package integrity mismatch: {relative}")
    reference = json.loads((ROOT / "provenance" / "package_reference.json").read_text())
    return reference


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--local-predictors", action="store_true",
                        help="Also load and test the real local predictors and retrieval")
    parser.add_argument("--integrity-only", action="store_true",
                        help="Check packaged files using only the Python standard library")
    args = parser.parse_args(argv)
    if args.integrity_only and args.local_predictors:
        parser.error("--integrity-only cannot be combined with --local-predictors")
    os.chdir(ROOT)
    # Imports can initialize libraries; the network guard covers those too.
    with patch.object(socket.socket, "connect", deny_network), \
         patch.object(socket.socket, "connect_ex", deny_network), \
         patch.object(socket, "getaddrinfo", deny_network):
        reference = check_reference()
        if args.integrity_only:
            print("PASS: all packaged file sizes and SHA-256 checksums.")
            return 0
        for line in (ROOT / "requirements.txt").read_text().splitlines():
            if not line.strip() or line.startswith("#"):
                continue
            name, expected = line.split("==")
            actual = importlib.metadata.version(name)
            if actual != expected:
                raise ValueError(f"Version mismatch: {name}: installed={actual}, required={expected}")
        from pharmagent.evaluation.formal_identity import build_formal_reproduction_identity
        identity = build_formal_reproduction_identity(
            code_dir=ROOT, standard_config=ROOT / "configs" / "pmo_standard.yaml",
            admet_config=ROOT / "configs" / "pmo_admet.yaml",
            matrix_scope="five_task_main",
            task_chain=json.loads((ROOT / "release_protocol.json").read_text())["task_chain"],
        )
        for name, expected in reference["assets"].items():
            if identity.get(name) != expected:
                raise ValueError(f"Scientific asset or dependency identity differs: {name}")
        if identity["critical_dependency_versions"] != reference["critical_dependency_versions"]:
            raise ValueError("Scientific dependency versions differ from the reference.")
        print("PASS: source, configuration, assets, and dependency checks.")
        if args.local_predictors:
            import yaml
            from pharmagent.evaluation.oracle_utils import create_oracle
            from pharmagent.rag.retriever import MMPRetriever
            from pharmagent.tools.admet_predictor import ADMETPredictor
            cfg = yaml.safe_load((ROOT / "configs" / "pmo_admet.yaml").read_text())
            for task in identity["task_chain"]:
                value = create_oracle(task, oracle_budget=1)("CCO")
                if not math.isfinite(value):
                    raise ValueError(f"Non-finite local oracle output: {task}")
            predictor = ADMETPredictor(backend=cfg["admet"]["backend"], config=cfg["admet"])
            predictions = predictor.predict("CCO")
            if predictions.get("prediction_backend") != "admet_ai":
                raise ValueError("Local predictor did not use ADMET-AI.")
            retrieved = MMPRetriever(cfg["rag"]).retrieve("CCO", target_property="gsk3b")
            if not retrieved:
                raise ValueError("Required public retrieval returned no context.")
            print("PASS: five real local oracles, ADMET-AI, and matched-pair retrieval.")
        print("No API requests were made; these checks are not experiment results.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
