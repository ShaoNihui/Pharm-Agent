"""Crash-safe HTTP-attempt accounting for paid formal LLM runs.

The counter is consumed *before* crossing the HTTP boundary.  Consequently a
process crash after the commit but before a response is received may
conservatively charge one attempt, but it can never make a paid attempt that is
missing from the durable count.
"""

from __future__ import annotations

from collections.abc import Mapping
import copy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sqlite3
from typing import Any

ATTEMPT_LEDGER_SCHEMA_VERSION = 1
# Normal path: one Generator + one Reviewer request.  Canonical novelty
# recovery may issue one additional Generator request only when the primary
# response contains zero Verifier-passing globally novel molecules, so three
# remains the algorithmic per-round ceiling before HTTP-level retries.  A
# full-budget protocol must cover this ceiling at every configured round: a
# lower cost fuse can terminate a legitimate novelty-recovery trajectory before
# its required oracle budget is reached.  The fixed margin covers bounded
# HTTP-level retries without changing any scientific round or oracle evidence.
FORMAL_NOMINAL_LOGICAL_REQUESTS_PER_ROUND = 2
FORMAL_MAX_LOGICAL_REQUESTS_PER_ROUND = 3
FORMAL_HTTP_ATTEMPT_RETRY_MARGIN = 100
FORMAL_MAX_ROUNDS_PER_RUN = 20_000
FORMAL_HTTP_ATTEMPT_CAP_PER_RUN = (
    FORMAL_MAX_LOGICAL_REQUESTS_PER_ROUND * FORMAL_MAX_ROUNDS_PER_RUN
    + FORMAL_HTTP_ATTEMPT_RETRY_MARGIN
)
# Alias for the normal two-agent request path.
FORMAL_LOGICAL_REQUESTS_PER_ROUND = (
    FORMAL_NOMINAL_LOGICAL_REQUESTS_PER_ROUND
)


class AttemptLedgerError(RuntimeError):
    """Base class for durable attempt-ledger failures."""


class AttemptLedgerIdentityError(AttemptLedgerError):
    """Raised when a ledger is reopened under a different protocol identity."""


class HTTPAttemptLimitError(AttemptLedgerError):
    """Raised before HTTP when the durable per-run cap is already exhausted."""


def _canonical_json(value: Mapping[str, Any]) -> str:
    try:
        return json.dumps(
            value,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        )
    except (TypeError, ValueError) as error:
        raise ValueError("attempt-ledger identity must be JSON serializable") from error


def _sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class HTTPAttemptLedger:
    """SQLite-backed counter shared safely by multiple :class:`LLMClient`s.

    A Generator and Reviewer may construct separate instances pointing at the
    same file.  ``BEGIN IMMEDIATE`` serializes their pre-request increments,
    while ``synchronous=FULL`` makes the committed count survive process
    termination.  The database stores protocol metadata and request roles, but
    never prompts, responses, tokens, or credentials.
    """

    def __init__(
        self,
        path: str | Path,
        *,
        cap: int,
        identity: Mapping[str, Any],
    ):
        if isinstance(cap, bool) or not isinstance(cap, int) or cap <= 0:
            raise ValueError("attempt-ledger cap must be a positive integer")
        if not isinstance(identity, Mapping) or not identity:
            raise ValueError("attempt-ledger identity must be a non-empty mapping")

        self.path = Path(path).expanduser().resolve()
        self.cap = cap
        self.identity = copy.deepcopy(dict(identity))
        self._identity_json = _canonical_json(self.identity)
        self.identity_sha256 = _sha256_text(self._identity_json)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        try:
            connection = sqlite3.connect(self.path, timeout=30.0)
            connection.execute("PRAGMA busy_timeout = 30000")
            connection.execute("PRAGMA synchronous = FULL")
            return connection
        except sqlite3.Error as error:
            raise AttemptLedgerError(
                f"cannot open HTTP-attempt ledger: {type(error).__name__}"
            ) from None

    def _initialize(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS metadata (
                    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
                    schema_version INTEGER NOT NULL,
                    identity_json TEXT NOT NULL,
                    identity_sha256 TEXT NOT NULL,
                    hard_cap INTEGER NOT NULL,
                    created_at TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS attempts (
                    attempt_index INTEGER PRIMARY KEY AUTOINCREMENT,
                    consumed_at TEXT NOT NULL,
                    client_role TEXT NOT NULL
                )
                """
            )
            row = connection.execute(
                """
                SELECT schema_version, identity_json, identity_sha256, hard_cap
                FROM metadata WHERE singleton = 1
                """
            ).fetchone()
            if row is None:
                connection.execute(
                    """
                    INSERT INTO metadata (
                        singleton, schema_version, identity_json,
                        identity_sha256, hard_cap, created_at
                    ) VALUES (1, ?, ?, ?, ?, ?)
                    """,
                    (
                        ATTEMPT_LEDGER_SCHEMA_VERSION,
                        self._identity_json,
                        self.identity_sha256,
                        self.cap,
                        _utc_now(),
                    ),
                )
            else:
                self._validate_metadata_row(row)
            connection.commit()
        except AttemptLedgerIdentityError:
            connection.rollback()
            raise
        except sqlite3.Error as error:
            connection.rollback()
            raise AttemptLedgerError(
                f"cannot initialize HTTP-attempt ledger: {type(error).__name__}"
            ) from None
        finally:
            connection.close()
        try:
            os.chmod(self.path, 0o600)
        except OSError:
            pass

    def _validate_metadata_row(self, row: tuple[Any, ...]) -> None:
        schema_version, identity_json, identity_sha256, hard_cap = row
        expected = (
            ATTEMPT_LEDGER_SCHEMA_VERSION,
            self._identity_json,
            self.identity_sha256,
            self.cap,
        )
        if (schema_version, identity_json, identity_sha256, hard_cap) != expected:
            raise AttemptLedgerIdentityError(
                "HTTP-attempt ledger belongs to a different protocol identity "
                "or hard cap; choose a new ledger path"
            )

    def consume(self, *, client_role: str = "unspecified") -> int:
        """Atomically reserve one paid HTTP attempt and return its 1-based index."""
        role = str(client_role).strip() or "unspecified"
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """
                SELECT schema_version, identity_json, identity_sha256, hard_cap
                FROM metadata WHERE singleton = 1
                """
            ).fetchone()
            if row is None:
                raise AttemptLedgerIdentityError(
                    "HTTP-attempt ledger metadata is missing"
                )
            self._validate_metadata_row(row)
            used = int(
                connection.execute("SELECT COUNT(*) FROM attempts").fetchone()[0]
            )
            if used >= self.cap:
                connection.rollback()
                raise HTTPAttemptLimitError(
                    f"hard paid HTTP-attempt cap reached ({used}/{self.cap})"
                )
            cursor = connection.execute(
                "INSERT INTO attempts (consumed_at, client_role) VALUES (?, ?)",
                (_utc_now(), role[:80]),
            )
            connection.commit()
            return int(cursor.lastrowid)
        except (AttemptLedgerIdentityError, HTTPAttemptLimitError):
            connection.rollback()
            raise
        except sqlite3.Error as error:
            connection.rollback()
            raise AttemptLedgerError(
                f"cannot reserve HTTP attempt: {type(error).__name__}"
            ) from None
        finally:
            connection.close()

    @property
    def attempts_used(self) -> int:
        """Return the durable number of attempts already reserved."""
        connection = self._connect()
        try:
            row = connection.execute(
                "SELECT COUNT(*) FROM attempts"
            ).fetchone()
            return int(row[0])
        except sqlite3.Error as error:
            raise AttemptLedgerError(
                f"cannot read HTTP-attempt ledger: {type(error).__name__}"
            ) from None
        finally:
            connection.close()

    def attempts_used_for_role(self, client_role: str) -> int:
        """Return the durable attempt count owned by one agent role.

        Native crash-resume restores per-agent usage from durable LLM events.
        The shared ledger therefore also needs a role-local attempt count so
        Generator and Reviewer totals aggregate to the exact matrix cost after
        process reconstruction.
        """
        role = str(client_role).strip() or "unspecified"
        connection = self._connect()
        try:
            row = connection.execute(
                "SELECT COUNT(*) FROM attempts WHERE client_role = ?",
                (role[:80],),
            ).fetchone()
            return int(row[0])
        except sqlite3.Error as error:
            raise AttemptLedgerError(
                f"cannot read role HTTP-attempt ledger: {type(error).__name__}"
            ) from None
        finally:
            connection.close()

    def snapshot(self) -> dict[str, Any]:
        """Return non-secret audit state suitable for logs and test assertions."""
        used = self.attempts_used
        return {
            "schema_version": ATTEMPT_LEDGER_SCHEMA_VERSION,
            "identity_sha256": self.identity_sha256,
            "hard_cap": self.cap,
            "attempts_used": used,
            "attempts_remaining": self.cap - used,
        }


def _scientific_protocol_sha256(config: Mapping[str, Any]) -> str:
    """Hash config semantics while excluding secrets and runtime file paths."""
    sensitive_names = {
        "api_key",
        "api_key_env",
        "password",
        "secret",
        "token",
        "attempt_ledger",
    }

    def sanitize(value: Any, *, parent: str = "") -> Any:
        if isinstance(value, Mapping):
            clean = {}
            for raw_key, child in value.items():
                key = str(raw_key)
                if key.lower() in sensitive_names:
                    continue
                if parent == "cer" and key in {"path"}:
                    continue
                clean[key] = sanitize(child, parent=key)
            return clean
        if isinstance(value, (list, tuple)):
            return [sanitize(item, parent=parent) for item in value]
        if isinstance(value, Path):
            return str(value)
        return value

    payload = _canonical_json(sanitize(config))
    return _sha256_text(payload)


def formal_ledger_path(
    ledger_root: str | Path,
    *,
    phase: str,
    task: str,
    seed: int,
) -> Path:
    """Return the deterministic isolated ledger path for one task/seed run."""
    return (
        Path(ledger_root).expanduser().resolve()
        / phase
        / task
        / f"seed_{seed}.sqlite3"
    )


def configure_formal_attempt_ledger(
    config: Mapping[str, Any],
    *,
    ledger_root: str | Path,
    phase: str,
    task: str,
    seed: int,
    formal_reproduction_identity: Mapping[str, Any],
    variant: str | None = None,
    cap: int = FORMAL_HTTP_ATTEMPT_CAP_PER_RUN,
) -> dict[str, Any]:
    """Inject one identity-bound ledger into both formal LLM agent configs."""
    configured = copy.deepcopy(dict(config))
    optimization = configured.get("optimization", {})
    max_rounds = optimization.get("max_rounds")
    if optimization.get("require_full_budget") is not True:
        raise ValueError(
            "formal attempt ledgers are only injected for require_full_budget runs"
        )
    if (
        isinstance(max_rounds, bool)
        or not isinstance(max_rounds, int)
        or max_rounds <= 0
    ):
        raise ValueError("formal optimization.max_rounds must be a positive integer")
    minimum_cap = (
        FORMAL_MAX_LOGICAL_REQUESTS_PER_ROUND * max_rounds
        + FORMAL_HTTP_ATTEMPT_RETRY_MARGIN
    )
    if cap < minimum_cap:
        raise ValueError(
            f"formal HTTP-attempt cap must be >= {minimum_cap} "
            "(the maximum primary + novelty-repair + Reviewer path for every "
            "configured round, plus the fixed retry margin)"
        )
    if isinstance(seed, bool) or not isinstance(seed, int) or seed < 0:
        raise ValueError("formal ledger seed must be a non-negative integer")
    if variant is not None and (
        not isinstance(variant, str) or not variant.strip()
    ):
        raise ValueError("formal ledger variant must be a non-empty string")
    from pharmagent.evaluation.formal_identity import (
        validate_formal_reproduction_identity,
    )

    formal_identity = validate_formal_reproduction_identity(
        formal_reproduction_identity
    )

    llm = configured.setdefault("llm", {})
    if not isinstance(llm, dict):
        raise ValueError("formal llm config must be a mapping")
    for field in ("backend", "model", "base_url", "thinking_type"):
        if not isinstance(llm.get(field), str) or not llm[field].strip():
            raise ValueError(
                f"formal llm.{field} must be explicitly pinned for ledger identity"
            )
    backend = llm["backend"].strip().lower()
    provider_transport = llm.get(
        "provider_transport", "openai_chat_completions"
    )
    max_token_parameter = llm.get(
        "max_token_parameter",
        "max_completion_tokens" if backend == "minimax" else "max_tokens",
    )
    reasoning_split = llm.get("reasoning_split")
    service_tier = llm.get("service_tier")
    if (
        not isinstance(provider_transport, str)
        or not provider_transport.strip()
    ):
        raise ValueError(
            "formal llm.provider_transport must identify the pinned transport"
        )
    if (
        not isinstance(max_token_parameter, str)
        or not max_token_parameter.strip()
    ):
        raise ValueError(
            "formal llm.max_token_parameter must identify the token-limit field"
        )
    if backend == "minimax":
        if provider_transport != "openai_chat_completions":
            raise ValueError(
                "formal MiniMax llm.provider_transport must be "
                "'openai_chat_completions'"
            )
        if llm.get("thinking_type") != "disabled":
            raise ValueError(
                "formal MiniMax llm.thinking_type must be explicitly 'disabled'"
            )
        if reasoning_split is not True:
            raise ValueError(
                "formal MiniMax llm.reasoning_split must be explicitly true"
            )
        if service_tier != "standard":
            raise ValueError(
                "formal MiniMax llm.service_tier must be explicitly 'standard'"
            )
        if max_token_parameter != "max_completion_tokens":
            raise ValueError(
                "formal MiniMax llm.max_token_parameter must be "
                "'max_completion_tokens'"
            )
    identity = {
        "kind": "pharmagent-formal-http-attempts",
        "identity_version": 4,
        "protocol_sha256": _scientific_protocol_sha256(config),
        "formal_reproduction_identity": formal_identity,
        "backend": llm.get("backend"),
        "model": llm.get("model"),
        "base_url": llm.get("base_url"),
        "thinking_type": llm.get("thinking_type"),
        "provider_transport": provider_transport,
        "reasoning_split": reasoning_split,
        "service_tier": service_tier,
        "max_token_parameter": max_token_parameter,
        "task": task,
        "seed": seed,
        "phase": phase,
    }
    if variant is not None:
        identity["variant"] = variant
    ledger_spec = {
        "path": str(
            formal_ledger_path(
                ledger_root, phase=phase, task=task, seed=seed
            )
        ),
        "cap": cap,
        "identity": identity,
    }
    llm["attempt_ledger"] = ledger_spec

    # ``load_config`` normally aliases these mappings.  Rebind explicitly so
    # configurations assembled programmatically get the same shared database.
    for agent_name in ("generator", "reviewer"):
        agent = configured.setdefault(agent_name, {})
        if not isinstance(agent, dict):
            raise ValueError(f"formal {agent_name} config must be a mapping")
        agent_llm = copy.deepcopy(llm)
        agent["llm"] = agent_llm
    return configured
