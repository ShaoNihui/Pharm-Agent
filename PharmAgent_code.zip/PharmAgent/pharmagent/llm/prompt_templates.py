"""
All prompt templates for PharmAgent agents.

Templates use Python str.format() with named placeholders.
"""

import math

from pharmagent.optimization.formal_prompt_protocol import (
    canonicalize_formal_modifications,
)

# ============================================================================
# Generator Agent Prompts
# ============================================================================

GENERATOR_SYSTEM_PROMPT = """\
You are PharmAgent-Generator, an expert medicinal chemist AI. You optimize \
molecules by proposing specific structural modifications with detailed \
pharmaceutical reasoning.

Rules:
1. Output ONLY valid JSON. No markdown, no explanation outside JSON.
2. Every proposed SMILES must be chemically valid.
3. Each modification must have explicit medicinal chemistry rationale.
4. Optimize only the stated target property and the explicitly listed active \
ADMET constraints.
5. Output a JSON object with a single key "candidates" containing an array.\
"""

GENERATOR_TARGET_ONLY_SYSTEM_PROMPT = """\
You are PharmAgent-Generator, an expert medicinal chemist AI. You optimize \
molecules for the stated target property by proposing specific structural \
modifications.

Rules:
1. Output ONLY valid JSON. No markdown, no explanation outside JSON.
2. Every proposed SMILES must be chemically valid.
3. Each modification must have explicit medicinal chemistry rationale.
4. Optimize only the stated target score. No secondary property objective \
should guide candidate selection.
5. Output a JSON object with a single key "candidates" containing an array.\
"""

GENERATOR_USER_PROMPT = """\
Optimize the following molecule for {target_property}.

Current molecule: {current_smiles}
Current target score: {current_target_score}
Current ADMET summary: {current_admet_summary}

ADMET Constraints (must satisfy ALL):
{admet_constraints_formatted}

Reference optimization cases from ChEMBL:
{rag_context}

Previous optimization feedback:
{reviewer_feedback}

Successful patterns from history:
{successful_patterns}

Failed patterns to avoid:
{failed_patterns}

Similar successful modifications (structure-aware retrieval):
{cer_experience}

{constraint_priorities}

Generate up to {n_candidates} candidate molecules in response order. Do not \
exceed {n_candidates} candidates.

Output JSON format:
{{
  "candidates": [
    {{
      "new_smiles": "...",
      "modifications": [
        {{
          "type": "substitution|addition|deletion|ring_modification|linker_change",
          "description": "describe what was changed",
          "rationale": "medicinal chemistry reasoning"
        }}
      ],
      "expected_effects": {{
        "target_activity": "increase|maintain|slight_decrease",
        "active_constraint_impacts": {{
          "explicit_active_constraint_name": "brief expected effect"
        }}
      }}
    }}
  ]
}}\
"""


GENERATOR_TARGET_ONLY_USER_PROMPT = """\
Optimize the following molecule only for {target_property}.

Current molecule: {current_smiles}
Current target score: {current_target_score}

Reference target-optimization cases from ChEMBL:
{rag_context}

Previous target-optimization feedback:
{reviewer_feedback}

Successful target-score patterns from this run:
{successful_patterns}

Target-score patterns to avoid from this run:
{failed_patterns}

Similar successful target-score transformations (structure-aware retrieval):
{cer_experience}

Generate up to {n_candidates} candidate molecules in response order. Do not \
exceed {n_candidates} candidates.

Output JSON format:
{{
  "candidates": [
    {{
      "new_smiles": "...",
      "modifications": [
        {{
          "type": "substitution|addition|deletion|ring_modification|linker_change",
          "description": "describe what was changed",
          "rationale": "why this may improve the stated target score"
        }}
      ],
      "expected_effects": {{
        "target_activity": "increase|maintain|uncertain"
      }}
    }}
  ]
}}\
"""


GENERATION_CONTEXT_RESTART_PROMPT = """\

Generation-context restart (protocol-controlled): {restart_strategy}
{restart_strategy_guidance}

This restart changes only the proposal strategy. Keep the current incumbent, \
the supplied constraints, RAG evidence, and run history intact. Do not increase \
the requested candidate count.\
"""


NOVELTY_REPAIR_PROMPT = """\

NOVELTY REPAIR — this is the second and final Generator call for this round.
The first call produced no candidate that both passed the fixed Verifier and \
was globally novel by canonical molecular identity.

Current-round rejected or duplicate proposals and exact reasons:
{repair_reasons}

The {taboo_requested_count} most similar already-seen canonical molecules \
available for this source molecule (TABOO; do not output these or equivalent \
SMILES):
{taboo_smiles}

Propose a chemically distinct alternative. The Verifier, active constraints, \
oracle budget, and maximum of {n_candidates} candidates are unchanged.\
"""


_RESTART_STRATEGY_GUIDANCE = {
    "scaffold-hop": (
        "Use a genuine scaffold hop: preserve the likely pharmacophore while "
        "changing the central chemotype or ring framework."
    ),
    "ring-linker": (
        "Explore a ring/linker re-architecture: change ring size, fusion, "
        "attachment topology, or linker geometry without merely renaming the "
        "same molecule."
    ),
    "bioisostere": (
        "Use medicinal-chemistry bioisosteres for a key group or bond while "
        "retaining the intended interaction pattern."
    ),
}


def format_generation_context_restart(strategy: str | None) -> str:
    """Render a deterministic, protocol-controlled restart instruction."""
    if strategy is None:
        return ""
    guidance = _RESTART_STRATEGY_GUIDANCE.get(strategy)
    if guidance is None:
        raise ValueError(f"unsupported generation restart strategy: {strategy!r}")
    return GENERATION_CONTEXT_RESTART_PROMPT.format(
        restart_strategy=strategy,
        restart_strategy_guidance=guidance,
    )


def format_novelty_repair(
    *,
    reasons: list[str],
    taboo_smiles: list[str],
    taboo_requested_count: int,
    n_candidates: int,
) -> str:
    """Render the bounded repair evidence without changing task objectives."""
    reasons_text = (
        "\n".join(f"- {reason}" for reason in reasons)
        if reasons
        else "- No parseable candidate objects were returned."
    )
    taboo_text = (
        "\n".join(f"{index}. {smiles}" for index, smiles in enumerate(
            taboo_smiles, start=1
        ))
        if taboo_smiles
        else "(No valid previously seen molecules are available.)"
    )
    return NOVELTY_REPAIR_PROMPT.format(
        repair_reasons=reasons_text,
        taboo_requested_count=taboo_requested_count,
        taboo_smiles=taboo_text,
        n_candidates=n_candidates,
    )

# ============================================================================
# Reviewer Agent Prompts
# ============================================================================

REVIEWER_SYSTEM_PROMPT = """\
You are PharmAgent-Reviewer, a senior medicinal chemistry advisor. You analyze \
optimization results and provide strategic guidance for the next round.

Rules:
1. Output ONLY valid JSON. No markdown, no explanation outside JSON.
2. Be specific in your suggestions — name exact structural modifications.
3. Consider target activity and only the explicitly listed active ADMET \
constraints.
4. Recommend termination if optimization has stagnated or goals are met.
5. Candidate constraint assessments are molecule-specific measurements. Never \
copy, substitute, or infer a candidate value from the current-best profile.\
"""

REVIEWER_TARGET_ONLY_SYSTEM_PROMPT = """\
You are PharmAgent-Reviewer, a senior molecular-optimization advisor. Analyze \
the target-property results and provide strategic guidance for the next round.

Rules:
1. Output ONLY valid JSON. No markdown, no explanation outside JSON.
2. Be specific in your suggestions -- name exact structural modifications.
3. In this exploration phase, optimize only the target score; all other \
property objectives are outside this phase and must not guide your analysis.
4. Recommend termination only when allowed by the run protocol.\
"""

REVIEWER_USER_PROMPT = """\
Review the following optimization round results.

Round: {round_number}
Current best molecule: {best_smiles}
Best target score: {best_target_score}
Best ADMET score: {best_admet_score}

Five-category profile for the current best molecule:
{admet_profile_formatted}

Active ADMET constraints for this curriculum phase:
{admet_constraints_formatted}

{constraint_priorities}

This round's candidates and results:
{candidates_with_scores}

Optimization trajectory (last 5 rounds):
{recent_trajectory}

Overall progress:
- Rounds completed: {rounds_completed}
- Oracle calls used: {oracle_calls_used}/{oracle_budget}
- Stagnation count: {stagnation_count} rounds without improvement
- Early termination allowed by protocol: {early_termination_allowed}

Analyze and provide guidance.

Output JSON format:
{{
  "analysis": "detailed analysis of this round",
  "what_worked": ["list of successful strategies"],
  "what_failed": ["list of failed strategies"],
  "suggestions_for_next_round": ["specific suggestion 1", "specific suggestion 2"],
  "should_continue": true,
  "termination_reason": null,
  "priority_focus": "activity|admet|balance",
  "recommended_modification_types": ["substitution", "ring_modification"]
}}\
"""

REVIEWER_TARGET_ONLY_USER_PROMPT = """\
Review the following target-optimization round results.

Round: {round_number}
Current best molecule: {best_smiles}
Best target score: {best_target_score}

This round's candidates and target results:
{candidates_with_scores}

Target-score trajectory (last 5 rounds):
{recent_trajectory}

Overall progress:
- Rounds completed: {rounds_completed}
- Oracle calls used: {oracle_calls_used}/{oracle_budget}
- Stagnation count: {stagnation_count} rounds without improvement
- Early termination allowed by protocol: {early_termination_allowed}

Analyze and provide target-focused guidance.

Output JSON format:
{{
  "analysis": "detailed analysis of this round",
  "what_worked": ["list of successful strategies"],
  "what_failed": ["list of failed strategies"],
  "suggestions_for_next_round": ["specific suggestion 1", "specific suggestion 2"],
  "should_continue": true,
  "termination_reason": null,
  "priority_focus": "activity",
  "recommended_modification_types": ["substitution", "ring_modification"]
}}\
"""


# ============================================================================
# Formatting Helpers
# ============================================================================

def format_admet_constraints(constraints: dict) -> str:
    """Format ADMET constraint config dict into human-readable text."""
    if not constraints:
        return "No specific ADMET constraints."

    lines = []
    for name, spec in constraints.items():
        ctype = spec.get("type", "max")
        threshold = spec.get("threshold", "N/A")
        if ctype == "max":
            lines.append(f"- {name}: must be <= {threshold}")
        elif ctype == "min":
            lines.append(f"- {name}: must be >= {threshold}")
        else:
            lines.append(f"- {name}: {ctype} {threshold}")
    return "\n".join(lines)


def format_optimization_history(
    entries: list[dict],
    max_entries: int = 5,
    *,
    include_admet: bool = True,
) -> str:
    """Format recent optimization memory entries for prompt injection."""
    if not entries:
        return "No optimization history yet."

    lines = []
    for entry in entries[-max_entries:]:
        smi = entry.get("smiles", "?")
        ts = entry.get("target_score", 0)
        rnd = entry.get("round", "?")
        if include_admet:
            ads = entry.get("admet_score", 0)
            cs = entry.get("combined_score", 0)
            lines.append(
                f"  Round {rnd}: {smi} "
                f"(target={ts:.3f}, admet={ads:.3f}, combined={cs:.3f})"
            )
        else:
            lines.append(f"  Round {rnd}: {smi} (target={ts:.3f})")
    return "\n".join(lines)


def format_candidates_with_scores(candidates: list[dict],
                                   target_scores: list[float],
                                   admet_results: list[dict],
                                   *,
                                   include_admet: bool = True,
                                   admet_constraints: dict | None = None,
                                   structured_modifications_only: bool = False) -> str:
    """Format candidate-specific results for the Reviewer prompt.

    When ADMET is active, every requested hard constraint is rendered from
    that candidate's own ``constraint_assessments`` row.  Missing rows are
    displayed fail-closed; values are never borrowed from the incumbent's
    five-category profile or inferred from the aggregate violation list.
    """
    if not candidates:
        return "No candidates this round."

    lines = []
    for i, (cand, score) in enumerate(zip(candidates, target_scores)):
        smi = cand.get("new_smiles", "?")
        mods = cand.get("modifications", [])
        if structured_modifications_only:
            reusable_modifications = canonicalize_formal_modifications(mods)
            modification_label = "Modification types"
            mod_desc = ", ".join(
                modification["type"]
                for modification in reusable_modifications
            ) or "none"
        else:
            modification_label = "Modifications"
            mod_desc = (
                "; ".join(m.get("description", "") for m in mods)
                if mods
                else "N/A"
            )
        candidate_lines = [
            f"  Candidate {i+1}: {smi}\n"
            f"    {modification_label}: {mod_desc}\n"
            f"    Target score: {score:.4f}"
        ]
        if include_admet:
            admet = admet_results[i] if i < len(admet_results) else {}
            admet_pass = admet.get("pass_all", False)
            admet_score = admet.get("admet_score", 0)
            violation_names = [
                row.get("name", "unknown")
                for row in admet.get("violations", [])
            ]
            candidate_lines.append(
                f"    ADMET score: {admet_score:.3f}, "
                f"pass_all: {admet_pass}"
            )
            candidate_lines.append(
                "    Active-constraint violations: "
                + (", ".join(violation_names) if violation_names else "none")
            )
            assessment_lines = _format_candidate_constraint_assessments(
                admet,
                admet_constraints,
            )
            if assessment_lines:
                candidate_lines.append(
                    "    Active constraint assessments (candidate-specific; "
                    "signed_margin >= 0 means PASS):\n"
                    + "\n".join(
                        f"      {line}" for line in assessment_lines
                    )
                )
        lines.append("\n".join(candidate_lines))
    return "\n".join(lines)


def _format_candidate_constraint_assessments(
    admet_result: dict,
    active_constraints: dict | None,
) -> list[str]:
    """Render one candidate's assessment row for every active constraint."""
    raw_assessments = admet_result.get("constraint_assessments", [])
    assessment_by_name = {
        row.get("name"): row
        for row in raw_assessments
        if isinstance(row, dict) and isinstance(row.get("name"), str)
    }

    if active_constraints is None:
        requested = [
            (row["name"], {})
            for row in raw_assessments
            if isinstance(row, dict) and isinstance(row.get("name"), str)
        ]
    else:
        requested = [
            (name, spec)
            for name, spec in active_constraints.items()
            if spec.get("threshold") is not None
        ]

    lines = []
    for name, spec in requested:
        assessment = assessment_by_name.get(name)
        if assessment is None:
            ctype = spec.get("type", "max")
            direction = "<=" if ctype == "max" else ">="
            assessment = {
                "name": name,
                "value": None,
                "threshold": spec.get("threshold"),
                "type": ctype,
                "direction": direction,
                "scale": spec.get("scale"),
                "signed_margin": None,
                "normalized_violation": None,
                "pass": False,
                "missing": True,
            }

        missing = bool(assessment.get("missing", True))
        passed = assessment.get("pass") is True and not missing
        status = "PASS" if passed else (
            "FAIL (MISSING)" if missing else "FAIL"
        )
        lines.append(
            f"- {name}: "
            f"value={_format_exact_constraint_value(assessment.get('value'))}; "
            f"threshold={_format_exact_constraint_value(assessment.get('threshold'))}; "
            f"type={assessment.get('type', 'MISSING')}; "
            f"direction={assessment.get('direction', 'MISSING')}; "
            f"scale={_format_exact_constraint_value(assessment.get('scale'))}; "
            "signed_margin="
            f"{_format_exact_constraint_value(assessment.get('signed_margin'))}; "
            "normalized_violation="
            f"{_format_exact_constraint_value(assessment.get('normalized_violation'))}; "
            f"{status}"
        )
    return lines


def _format_exact_constraint_value(value) -> str:
    """Preserve candidate numeric precision instead of prompt-time rounding."""
    if value is None:
        return "MISSING"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, float):
        return repr(value) if math.isfinite(value) else "MISSING"
    return str(value)


_ADMET_PROFILE_ORDER = (
    ("absorption", "A", "Absorption"),
    ("distribution", "D", "Distribution"),
    ("metabolism", "M", "Metabolism"),
    ("excretion", "E", "Excretion"),
    ("toxicity", "T", "Toxicity"),
)


def format_admet_profile(profile: dict, *, mode: str = "full") -> str:
    """Format a truthful curriculum-aware A/D/M/E/T status summary.

    ``active_only`` is used before the full curriculum phase and emits only
    categories with active hard constraints.  ``full`` emits all five
    categories; an unconstrained category is explicitly monitoring-only and
    must not be interpreted as passing a hard constraint.
    """
    if mode not in {"full", "active_only"}:
        raise ValueError("ADMET profile mode must be 'full' or 'active_only'")
    if not profile:
        return "Five-category profile unavailable."

    lines = []
    for category, abbreviation, title in _ADMET_PROFILE_ORDER:
        details = profile.get(category, {})
        active = list(details.get("active_constraints", []))
        if mode == "active_only" and not active:
            continue

        status = details.get("status", "MONITORED")
        if status == "MONITORED":
            status_text = "MONITORED (observed only; not a hard constraint)"
        elif status == "INACTIVE":
            status_text = "INACTIVE (not used in this curriculum phase)"
        else:
            status_text = status

        line = f"- {abbreviation} ({title}): {status_text}"
        if active:
            line += f"; active hard constraints: {', '.join(active)}"
        values = []
        for key in sorted(details):
            if key in {
                "status", "pass", "active_constraints", "inactive_constraints"
            }:
                continue
            value = details[key]
            if isinstance(value, bool):
                values.append(f"{key}={'true' if value else 'false'}")
            elif isinstance(value, (int, float)) and math.isfinite(value):
                values.append(f"{key}={value:.4g}")
        if values:
            line += f"; observed: {', '.join(values)}"
        lines.append(line)

    if not lines:
        return "No hard constraints are active in this curriculum phase."
    if mode == "active_only":
        lines.append(
            "Only explicitly active constraints are shown; unregistered, "
            "monitoring-only, and future curriculum endpoints are withheld."
        )
    return "\n".join(lines)
