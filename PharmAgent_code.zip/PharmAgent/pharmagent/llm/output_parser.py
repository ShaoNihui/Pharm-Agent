"""
Robust JSON output parsing for LLM responses.

Implements a 5-strategy parsing pipeline:
  1. Direct json.loads
  2. Strip markdown fences then parse
  3. Regex extract JSON array
  4. Regex extract JSON object
  5. Truncation repair (close brackets)
  Fallback: return empty list / default dict
"""

import json
import logging
import re
from typing import Any

from pharmagent.tools.rdkit_tools import validate_smiles

logger = logging.getLogger(__name__)


def _extract_json(text: str) -> Any | None:
    """Try multiple strategies to extract JSON from LLM output."""
    if not text or not text.strip():
        return None

    text = text.strip()

    # Strategy 1: Direct parse
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Strategy 2: Strip markdown code fences
    stripped = re.sub(r"^```(?:json)?\s*\n?", "", text)
    stripped = re.sub(r"\n?```\s*$", "", stripped).strip()
    if stripped != text:
        try:
            return json.loads(stripped)
        except json.JSONDecodeError:
            pass

    # Strategy 3: Regex extract JSON object (try object first — the prompts
    # request {"candidates": [...]}, so outermost is usually an object)
    match = re.search(r"\{[\s\S]*\}", text)
    if match:
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            pass

    # Strategy 4: Regex extract JSON array (non-greedy to avoid over-matching)
    match = re.search(r"\[[\s\S]*?\]", text)
    if match:
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            pass
    # Fallback: try greedy match for deeply nested arrays
    match = re.search(r"\[[\s\S]*\]", text)
    if match:
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            pass

    # Strategy 5: Intelligent truncation repair — count open brackets.
    # WARNING: This can produce syntactically valid but semantically incomplete
    # JSON.  Downstream consumers must validate the result structure.
    for test_text in [text, stripped]:
        open_braces = test_text.count("{") - test_text.count("}")
        open_brackets = test_text.count("[") - test_text.count("]")
        if open_braces > 0 or open_brackets > 0:
            # Try multiple closing orders: ]...}... and }...]...
            ob = max(0, open_braces)
            obr = max(0, open_brackets)
            candidates_repair = [
                "]" * obr + "}" * ob,     # close arrays first, then objects
                "}" * ob + "]" * obr,     # close objects first, then arrays
            ]
            for quote_prefix in ["", '"']:
                for repair in candidates_repair:
                    try:
                        result = json.loads(test_text + quote_prefix + repair)
                        logger.warning(
                            "Used truncation repair to parse JSON "
                            "(appended %r%s). Result may be incomplete.",
                            repair, " with quote prefix" if quote_prefix else "",
                        )
                        return result
                    except json.JSONDecodeError:
                        pass

    return None


def parse_molecule_candidates(raw_response: str) -> list[dict]:
    """Parse LLM output into a list of molecule candidate dicts.

    Each candidate dict has keys: new_smiles, modifications, expected_effects.
    Invalid SMILES are filtered out. Duplicates are removed.

    Returns empty list on total parse failure.
    """
    parsed = _extract_json(raw_response)
    if parsed is None:
        logger.warning("Failed to parse any JSON from generator response")
        logger.debug("Raw response: %s", raw_response[:500])
        return []

    # Handle {"candidates": [...]} wrapper
    if isinstance(parsed, dict):
        candidates = parsed.get("candidates", [])
        if not isinstance(candidates, list):
            # Maybe the dict itself is a single candidate
            if "new_smiles" in parsed:
                candidates = [parsed]
            else:
                logger.warning("Parsed JSON dict has no 'candidates' key")
                return []
    elif isinstance(parsed, list):
        candidates = parsed
    else:
        logger.warning("Unexpected parsed JSON type: %s", type(parsed))
        return []

    # Validate and deduplicate
    valid_candidates = []
    seen_smiles = set()

    for cand in candidates:
        if not isinstance(cand, dict):
            continue

        raw_smi = cand.get("new_smiles", "")
        canonical = validate_smiles(raw_smi)
        if canonical is None:
            logger.debug("Invalid SMILES from generator: %s", raw_smi)
            continue

        if canonical in seen_smiles:
            continue
        seen_smiles.add(canonical)

        valid_candidates.append({
            "new_smiles": canonical,
            "modifications": cand.get("modifications", []),
            "expected_effects": cand.get("expected_effects", {}),
            "reasoning": cand.get("reasoning", ""),
        })

    return valid_candidates


def parse_reviewer_output(raw_response: str) -> dict:
    """Parse LLM output into a reviewer feedback dict.

    Returns a default "continue" dict on parse failure.
    """
    default = {
        "analysis": "Unable to parse reviewer output.",
        "what_worked": [],
        "what_failed": [],
        "suggestions_for_next_round": [
            "Try different structural modifications.",
            "Consider simpler changes to improve success rate.",
        ],
        "should_continue": True,
        "termination_reason": None,
        "priority_focus": "balance",
        "recommended_modification_types": ["substitution"],
    }

    parsed = _extract_json(raw_response)
    if parsed is None:
        logger.warning("Failed to parse reviewer JSON response")
        return default

    if not isinstance(parsed, dict):
        logger.warning("Reviewer output is not a dict: %s", type(parsed))
        return default

    # Merge with defaults to ensure all keys exist
    result = {**default, **parsed}

    # Ensure should_continue is boolean
    sc = result.get("should_continue")
    if isinstance(sc, str):
        result["should_continue"] = sc.lower() not in ("false", "no", "0")
    elif not isinstance(sc, bool):
        result["should_continue"] = True

    return result
