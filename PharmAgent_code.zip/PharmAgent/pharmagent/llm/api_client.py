"""Unified client for MiniMax, DeepSeek, OpenAI, and local vLLM.

All supported backends expose an OpenAI-compatible Chat Completions transport,
but their scientific request semantics are not interchangeable.  In
particular, formal MiniMax runs pin non-reasoning behavior and use MiniMax's
``max_completion_tokens`` parameter without JSON response-format negotiation.
"""

from collections.abc import Mapping
import logging
import os
import time
from typing import Any

from openai import APIConnectionError, APIStatusError, APITimeoutError, OpenAI

from pharmagent.llm.attempt_ledger import (
    AttemptLedgerError,
    HTTPAttemptLedger,
    HTTPAttemptLimitError,
)
from pharmagent.evaluation.native_run import (
    IndeterminateLLMRequestError,
    NativeRunJournal,
    NativeRunJournalError,
)

logger = logging.getLogger(__name__)


DEEPSEEK_MODEL = "deepseek-v4-flash"
DEEPSEEK_BASE_URL = "https://api.deepseek.com"
DEEPSEEK_THINKING_TYPE = "disabled"

MINIMAX_BACKEND = "minimax"
MINIMAX_MODEL = "MiniMax-M3"
MINIMAX_BASE_URL = "https://api.minimaxi.com/v1"
MINIMAX_API_KEY_ENV = "MINIMAX_API_KEY"
MINIMAX_REGION = "cn"
MINIMAX_THINKING_TYPE = "disabled"
MINIMAX_REASONING_SPLIT = True
MINIMAX_SERVICE_TIER = "standard"
MINIMAX_PROVIDER_TRANSPORT = "openai_chat_completions"
MINIMAX_MAX_TOKEN_PARAMETER = "max_completion_tokens"
MINIMAX_RESPONSE_FORMAT = "not_sent"

OPENAI_COMPATIBLE_PROVIDER_TRANSPORT = "openai_chat_completions"
DEFAULT_MAX_TOKEN_PARAMETER = "max_tokens"

LLM_USAGE_SCHEMA_VERSION = 2
MINIMAX_CACHE_OMISSION_RULE_ID = (
    "minimax_prompt_cached_tokens_omitted_defaults_zero"
)
_USAGE_TOKEN_FIELDS = (
    "prompt_tokens",
    "prompt_cache_hit_tokens",
    "prompt_cache_miss_tokens",
    "completion_tokens",
    "total_tokens",
)


class LLMRequestError(RuntimeError):
    """Raised when an LLM request cannot produce a usable completion."""


class LLMAttemptAccountingError(LLMRequestError):
    """Raised before HTTP when the formal durable cost ledger is unusable."""


class LLMTransportRecoveryExhaustedError(LLMRequestError):
    """Raised when a formal request exhausts its bounded live recovery path.

    This is operational, not an optimization-round failure.  A caller running
    a formal experiment must stop rather than let repeated provider transport
    failures become evidence about molecular optimization.
    """


class _EmptyLLMResponseError(RuntimeError):
    """Internal marker for a successful HTTP response with no usable text."""


class _InvalidMiniMaxResponseError(RuntimeError):
    """Internal marker for a rejected or malformed MiniMax response envelope."""


class _InvalidMiniMaxUsageError(RuntimeError):
    """Internal marker for unsafe MiniMax token-usage accounting."""


# Default configurations for each backend
_BACKEND_DEFAULTS = {
    MINIMAX_BACKEND: {
        "base_url": MINIMAX_BASE_URL,
        "model": MINIMAX_MODEL,
        "api_key_env": MINIMAX_API_KEY_ENV,
    },
    "deepseek": {
        "base_url": DEEPSEEK_BASE_URL,
        "model": DEEPSEEK_MODEL,
        "api_key_env": "DEEPSEEK_API_KEY",
    },
    "openai": {
        "base_url": "https://api.openai.com/v1",
        "model": "gpt-4o",
        "api_key_env": "OPENAI_API_KEY",
    },
    "local_vllm": {
        "base_url": "http://localhost:8000/v1",
        "model": "Qwen/Qwen3-8B",
        "api_key_env": None,
    },
}


class LLMClient:
    """OpenAI-compatible LLM client with retry logic and token tracking."""

    def __init__(self, config: dict, *, client_role: str = "unspecified"):
        self.backend = config.get("backend", MINIMAX_BACKEND)
        defaults = _BACKEND_DEFAULTS.get(self.backend, {})

        self.model = config.get("model", defaults.get("model", MINIMAX_MODEL))
        base_url = config.get("base_url", defaults.get("base_url"))
        self.base_url = base_url
        api_key_env = config.get("api_key_env", defaults.get("api_key_env"))
        self.thinking_type: str | None = None
        self.reasoning_split: bool | None = None
        self.service_tier: str | None = None
        self.region: str | None = None
        self.provider_transport = config.get(
            "provider_transport", OPENAI_COMPATIBLE_PROVIDER_TRANSPORT
        )
        self.max_token_parameter = config.get(
            "max_token_parameter",
            (
                MINIMAX_MAX_TOKEN_PARAMETER
                if self.backend == MINIMAX_BACKEND
                else DEFAULT_MAX_TOKEN_PARAMETER
            ),
        )
        if self.provider_transport != OPENAI_COMPATIBLE_PROVIDER_TRANSPORT:
            raise ValueError(
                "LLM provider_transport must be "
                f"{OPENAI_COMPATIBLE_PROVIDER_TRANSPORT!r}"
            )
        if self.backend == "deepseek":
            self.thinking_type = config.get(
                "thinking_type", DEEPSEEK_THINKING_TYPE
            )
            if self.thinking_type != DEEPSEEK_THINKING_TYPE:
                raise ValueError(
                    "DeepSeek chat-compatible runs require "
                    "thinking_type='disabled'"
                )
        elif self.backend == MINIMAX_BACKEND:
            self.region = config.get("region", MINIMAX_REGION)
            self.thinking_type = config.get(
                "thinking_type", MINIMAX_THINKING_TYPE
            )
            self.reasoning_split = config.get(
                "reasoning_split", MINIMAX_REASONING_SPLIT
            )
            self.service_tier = config.get(
                "service_tier", MINIMAX_SERVICE_TIER
            )
            if self.thinking_type != MINIMAX_THINKING_TYPE:
                raise ValueError(
                    "MiniMax-M3 formal runs require thinking_type='disabled'"
                )
            if self.region != MINIMAX_REGION:
                raise ValueError("MiniMax China runs require region='cn'")
            if self.reasoning_split is not MINIMAX_REASONING_SPLIT:
                raise ValueError(
                    "MiniMax-M3 formal runs require reasoning_split=true"
                )
            if self.service_tier != MINIMAX_SERVICE_TIER:
                raise ValueError(
                    "MiniMax-M3 formal runs require service_tier='standard'"
                )
            if self.max_token_parameter != MINIMAX_MAX_TOKEN_PARAMETER:
                raise ValueError(
                    "MiniMax-M3 formal runs require "
                    "max_token_parameter='max_completion_tokens'"
                )
        elif self.max_token_parameter != DEFAULT_MAX_TOKEN_PARAMETER:
            raise ValueError(
                "non-MiniMax backends require max_token_parameter='max_tokens'"
            )

        # Resolve API key
        if api_key_env and os.environ.get(api_key_env):
            api_key = os.environ[api_key_env]
        elif self.backend == "local_vllm":
            api_key = config.get("api_key", "EMPTY")
        else:
            api_key = config.get("api_key", "EMPTY")
            if api_key == "EMPTY" and self.backend != "local_vllm":
                logger.warning(
                    "No API key found for backend '%s'. "
                    "Set %s environment variable.",
                    self.backend, api_key_env
                )

        self._api_key = api_key
        self.request_timeout = max(
            1.0, float(config.get("request_timeout", 60))
        )
        # Disable the SDK's hidden retries.  This class owns the retry policy so
        # that authentication errors cannot trigger a second layer of backoff.
        self.client = OpenAI(
            api_key=api_key,
            base_url=base_url,
            max_retries=0,
            timeout=self.request_timeout,
        )
        self.temperature = config.get("temperature", 0.7)
        self.max_tokens = config.get("max_tokens", 2048)
        # ``max_retries`` specifies the total number of attempts.
        self.max_retries = max(1, int(config.get("max_retries", 10)))
        self.retry_delay = max(0.0, float(config.get("retry_delay", 2)))
        self.max_retry_delay = max(
            0.0, float(config.get("max_retry_delay", 30))
        )
        self.max_retry_elapsed = max(
            0.0, float(config.get("max_retry_elapsed", 60))
        )
        recovery_batches = config.get("max_transport_recovery_batches", 0)
        if isinstance(recovery_batches, bool):
            raise ValueError("max_transport_recovery_batches must be an integer")
        self.max_transport_recovery_batches = max(0, int(recovery_batches))

        # Formal runners give Generator and Reviewer the same path/identity.
        # Each client opens its own lightweight wrapper; SQLite serializes the
        # durable counter before every HTTP attempt, including retries.
        self.client_role = str(client_role).strip() or "unspecified"
        self.attempt_ledger: HTTPAttemptLedger | None = None
        ledger_config = config.get("attempt_ledger")
        if ledger_config is not None:
            if not isinstance(ledger_config, dict):
                raise ValueError("llm.attempt_ledger must be a mapping")
            try:
                self.attempt_ledger = HTTPAttemptLedger(
                    ledger_config["path"],
                    cap=ledger_config["cap"],
                    identity=ledger_config["identity"],
                )
            except KeyError as error:
                raise ValueError(
                    f"llm.attempt_ledger is missing {error.args[0]!r}"
                ) from None
        self._ledger_attempts_at_client_start = (
            self.attempt_ledger.attempts_used
            if self.attempt_ledger is not None
            else None
        )

        self.native_run_journal: NativeRunJournal | None = None
        native_spec = config.get("native_run_journal")
        if native_spec is not None:
            if not isinstance(native_spec, Mapping):
                raise ValueError("llm.native_run_journal must be a mapping")
            try:
                self.native_run_journal = NativeRunJournal(
                    native_spec["path"], identity=native_spec["identity"]
                )
            except KeyError as error:
                raise ValueError(
                    "llm.native_run_journal is missing "
                    f"{error.args[0]!r}"
                ) from None

        # Token-usage counters describe responses observed by this
        # client instance only; formal runners create new Generator/Reviewer
        # clients for every task/seed run.  The durable ledger separately
        # accounts for every HTTP attempt, including failed retries.
        self.total_prompt_tokens = 0
        self.total_prompt_cache_hit_tokens = 0
        self.total_prompt_cache_miss_tokens = 0
        self.total_completion_tokens = 0
        self.total_reported_tokens = 0
        self.total_calls = 0
        self.http_attempts_local = 0
        self._responses_with_usage = 0
        self._responses_without_usage = 0
        self._usage_field_observations = {
            field: 0 for field in _USAGE_TOKEN_FIELDS
        }
        self._normalized_minimax_cache_omissions = 0
        self._durable_usage_restored = False
        if self.native_run_journal is not None:
            self._restore_durable_usage()

    def generate(self, messages: list[dict] | str,
                 temperature: float | None = None,
                 max_tokens: int | None = None,
                 json_mode: bool = True,
                 request_id: str | None = None) -> str:
        """Generate a completion from the LLM.

        Args:
            messages: Either a list of message dicts [{"role": ..., "content": ...}]
                      or a single string (converted to a user message).
            temperature: Override default temperature.
            max_tokens: Override default max_tokens.
            json_mode: If True, request JSON output format.
            request_id: Deterministic logical request identity required by a
                crash-resumable native run.

        Returns:
            The non-empty raw response text.

        Raises:
            LLMRequestError: If the API rejects the request, transient retries
                are exhausted, or the API never returns usable content.
        """
        if isinstance(messages, str):
            messages = [{"role": "user", "content": messages}]

        requested_max_tokens = (
            max_tokens if max_tokens is not None else self.max_tokens
        )
        kwargs = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature if temperature is not None else self.temperature,
            self.max_token_parameter: requested_max_tokens,
        }

        # json_mode: DeepSeek and OpenAI support response_format;
        # vLLM support varies by version — try it, fall back on error.
        use_json_mode = json_mode and self.backend in ("deepseek", "openai")
        if json_mode and self.backend == "local_vllm":
            # Attempt json_mode for vLLM; will be caught by retry if unsupported
            use_json_mode = True
        if use_json_mode:
            kwargs["response_format"] = {"type": "json_object"}
        if self.backend == "deepseek":
            # DeepSeek V4 exposes reasoning and non-reasoning behavior through
            # one Chat Completions model.  Preserve the configured
            # chat semantics explicitly instead of relying on a provider
            # default that may change.
            kwargs["extra_body"] = {
                "thinking": {"type": DEEPSEEK_THINKING_TYPE}
            }
        elif self.backend == MINIMAX_BACKEND:
            # MiniMax-M3 must use its native completion-token parameter.  JSON
            # mode is deliberately not sent: its OpenAI-compatible endpoint
            # does not accept response_format for this protocol.
            kwargs["service_tier"] = MINIMAX_SERVICE_TIER
            kwargs["extra_body"] = {
                "thinking": {"type": MINIMAX_THINKING_TYPE},
                "reasoning_split": MINIMAX_REASONING_SPLIT,
            }

        native_request = None
        if self.native_run_journal is not None:
            if not isinstance(request_id, str) or not request_id.strip():
                raise LLMAttemptAccountingError(
                    "native crash-resume requires a deterministic LLM request_id"
                )
            durable_attempts = (
                self.attempt_ledger.attempts_used
                if self.attempt_ledger is not None
                else self.http_attempts_local
            )
            try:
                native_request = self.native_run_journal.prepare_llm_request(
                    request_id=request_id.strip(),
                    client_role=self.client_role,
                    request={
                        "transport": "chat.completions.create",
                        "kwargs": kwargs,
                    },
                    durable_attempts_used=durable_attempts,
                )
            except (IndeterminateLLMRequestError, NativeRunJournalError) as error:
                raise LLMAttemptAccountingError(str(error)) from None
            if native_request["status"] == "complete":
                return str(native_request["response_text"])
            if native_request["status"] == "failed_known":
                is_transient_failure = self._is_native_transport_failure(
                    native_request
                )
                if not is_transient_failure:
                    raise LLMRequestError(
                        "durably replayed LLM request had no usable completion "
                        f"({native_request.get('error_type') or 'known failure'})"
                    )
                if not self._is_recoverable_native_transport_failure(
                    native_request
                ):
                    raise LLMTransportRecoveryExhaustedError(
                        "bounded formal LLM transport recovery exhausted; "
                        "no optimization round was advanced"
                    ) from None
                try:
                    native_request = (
                        self.native_run_journal.reopen_known_transport_failure(
                            request_id=request_id.strip(),
                            durable_attempts_used=durable_attempts,
                            max_failed_attempts=(
                                self.max_retries
                                * (1 + self.max_transport_recovery_batches)
                            ),
                        )
                    )
                except NativeRunJournalError as error:
                    raise LLMAttemptAccountingError(str(error)) from None
                if native_request is None:
                    raise LLMTransportRecoveryExhaustedError(
                        "bounded formal LLM transport recovery exhausted; "
                        "no optimization round was advanced"
                    ) from None
                logger.warning(
                    "Reopening a durably known transient LLM failure under "
                    "the formal transport-recovery protocol"
                )

        total_backoff = 0.0
        last_error: Exception | None = None
        completed_attempts = int(
            native_request.get("known_failed_attempts", 0)
            if native_request is not None
            else 0
        )
        # A completed retry batch may be reopened after a live transport
        # outage. The durable total never resets, but a resumed process must
        # continue the current batch rather than treat its allowance as spent.
        if self.native_run_journal is not None:
            completed_attempts %= self.max_retries
        attempts_made = completed_attempts
        for attempt in range(completed_attempts, self.max_retries):
            attempts_made = attempt + 1
            attempt_index = None
            if self.attempt_ledger is not None:
                try:
                    attempt_index = self.attempt_ledger.consume(
                        client_role=self.client_role
                    )
                except HTTPAttemptLimitError as error:
                    # This happens before ``create``: reaching the durable cap
                    # can never leak one more paid request.
                    raise LLMAttemptAccountingError(str(error)) from None
                except AttemptLedgerError as error:
                    # Fail closed if durable accounting itself is unavailable.
                    raise LLMAttemptAccountingError(
                        f"HTTP-attempt accounting failed: {error}"
                    ) from None
            if self.native_run_journal is not None:
                if attempt_index is None:
                    raise LLMAttemptAccountingError(
                        "native paid run requires a durable HTTP-attempt ledger"
                    )
                try:
                    self.native_run_journal.mark_llm_http_started(
                        request_id.strip(), attempt_index
                    )
                except NativeRunJournalError as error:
                    # The attempt was already consumed.  Never cross HTTP when
                    # its logical binding could not be durably recorded.
                    raise LLMAttemptAccountingError(str(error)) from None
            # Increment only after the durable reservation succeeds and
            # immediately before crossing the HTTP boundary.  This remains
            # useful for non-formal clients that do not have a ledger.
            self.http_attempts_local += 1
            usage_observation = None
            try:
                response = self.client.chat.completions.create(**kwargs)
                self._validate_provider_response(response)
                usage_before = self._usage_counters()
                self.total_calls += 1
                try:
                    self._record_response_usage(response)
                finally:
                    usage_observation = self._usage_observation_since(
                        usage_before
                    )

                choices = getattr(response, "choices", None)
                if not choices:
                    raise _EmptyLLMResponseError("empty choices")
                message = getattr(choices[0], "message", None)
                content = getattr(message, "content", None)
                if not isinstance(content, str) or not content.strip():
                    raise _EmptyLLMResponseError("empty message content")
                if self.native_run_journal is not None:
                    try:
                        self.native_run_journal.complete_llm_request(
                            request_id.strip(),
                            response_text=content,
                            usage=usage_observation,
                        )
                    except NativeRunJournalError as error:
                        raise LLMAttemptAccountingError(str(error)) from None
                return content

            except Exception as e:
                last_error = e
                status = _status_code(e)

                is_local_accounting_failure = isinstance(
                    e, LLMAttemptAccountingError
                )

                # A local vLLM may reject response_format.  Retry once without
                # that optional parameter, without sleeping.
                if (
                    self.backend == "local_vllm"
                    and status in (400, 404, 422)
                    and "response_format" in _redact(str(e), self._api_key).lower()
                    and "response_format" in kwargs
                ):
                    if self.native_run_journal is not None:
                        try:
                            self.native_run_journal.record_llm_attempt_failure(
                                request_id.strip(),
                                error_type=type(e).__name__,
                                final=False,
                                usage=usage_observation,
                            )
                        except NativeRunJournalError as journal_error:
                            raise LLMAttemptAccountingError(
                                str(journal_error)
                            ) from None
                    logger.info("Disabling json_mode (unsupported by this backend)")
                    kwargs.pop("response_format", None)
                    continue

                transient = _is_transient(e)
                next_backoff = min(
                    self.retry_delay * (2 ** attempt), self.max_retry_delay
                )
                elapsed_limit_reached = bool(
                    transient
                    and attempt < self.max_retries - 1
                    and total_backoff + next_backoff
                    > self.max_retry_elapsed
                )
                final_attempt = (
                    not transient
                    or attempt >= self.max_retries - 1
                    or elapsed_limit_reached
                )
                if self.native_run_journal is not None and not is_local_accounting_failure:
                    try:
                        self.native_run_journal.record_llm_attempt_failure(
                            request_id.strip(),
                            error_type=_failure_marker(e, transient=transient),
                            final=final_attempt,
                            usage=usage_observation,
                        )
                    except NativeRunJournalError as journal_error:
                        raise LLMAttemptAccountingError(
                            str(journal_error)
                        ) from None

                if is_local_accounting_failure:
                    raise
                if not transient:
                    detail = _non_retryable_detail(status)
                    logger.error(
                        "LLM request rejected without retry (%s): %s",
                        _error_label(e, status), detail,
                    )
                    raise LLMRequestError(
                        f"LLM request rejected ({_error_label(e, status)}): {detail}"
                    ) from None

                logger.warning(
                    "Transient LLM failure (attempt %d/%d, %s)",
                    attempt + 1, self.max_retries, _error_label(e, status),
                )
                if final_attempt:
                    if (
                        self.native_run_journal is not None
                        and self.max_transport_recovery_batches > 0
                    ):
                        # Re-enter through ``prepare_llm_request`` so the
                        # journal atomically validates/reopens the failed
                        # logical request before another HTTP attempt. This
                        # preserves one logical request and never turns a
                        # provider outage into a new optimization round.
                        return self.generate(
                            messages,
                            temperature=temperature,
                            max_tokens=max_tokens,
                            json_mode=json_mode,
                            request_id=request_id,
                        )
                    break

                backoff = next_backoff
                if total_backoff + backoff > self.max_retry_elapsed:
                    logger.warning(
                        "Stopping LLM retries at %.1fs cumulative backoff limit",
                        self.max_retry_elapsed,
                    )
                    break
                if backoff > 0:
                    time.sleep(backoff)
                total_backoff += backoff

        label = _error_label(last_error, _status_code(last_error))
        logger.error(
            "LLM request failed after %d attempt(s); no usable completion",
            attempts_made,
        )
        raise LLMRequestError(
            f"LLM request failed after {attempts_made} attempt(s) "
            f"({label}); no usable completion"
        ) from None

    def _is_recoverable_native_transport_failure(
        self, native_request: Mapping[str, Any]
    ) -> bool:
        """Return whether a closed native request can safely resume live.

        Only a failure observed and durably classified as transient by this
        still-running protocol may reopen. In-flight ``http_started`` rows
        remain fail-closed in :class:`NativeRunJournal`.
        """
        if self.max_transport_recovery_batches <= 0:
            return False
        if not self._is_native_transport_failure(native_request):
            return False
        failed_attempts = native_request.get("known_failed_attempts")
        assert isinstance(failed_attempts, int) and not isinstance(
            failed_attempts, bool
        )
        return failed_attempts < (
            self.max_retries * (1 + self.max_transport_recovery_batches)
        )

    @staticmethod
    def _is_native_transport_failure(native_request: Mapping[str, Any]) -> bool:
        """Recognize the transport recovery marker written after a transient outcome."""
        marker = native_request.get("error_type")
        failed_attempts = native_request.get("known_failed_attempts")
        if (
            not isinstance(marker, str)
            or not marker.startswith("transient_")
            or isinstance(failed_attempts, bool)
            or not isinstance(failed_attempts, int)
        ):
            return False
        return True

    @staticmethod
    def _field(container: object, field: str) -> object | None:
        """Read an SDK-model or mapping field without retaining its payload."""
        if isinstance(container, Mapping):
            return container.get(field)
        return getattr(container, field, None)

    @staticmethod
    def _field_presence(container: object, field: str) -> tuple[bool, object]:
        """Return whether a provider field was actually present and its value.

        OpenAI's Pydantic response models expose optional attributes as
        ``None`` even when the server omitted them.  ``model_fields_set`` (or
        Pydantic v1's ``__fields_set__``) is therefore authoritative when it is
        available.  This distinction is essential for MiniMax cache usage:
        omission has a documented zero default in the usage-accounting contract, whereas
        an explicit null is malformed and must fail closed.
        """
        if isinstance(container, Mapping):
            return field in container, container.get(field)
        if container is None:
            return False, None
        for attribute in ("model_fields_set", "__fields_set__"):
            fields_set = getattr(container, attribute, None)
            if isinstance(fields_set, (set, frozenset)):
                return field in fields_set, getattr(container, field, None)
        sentinel = object()
        value = getattr(container, field, sentinel)
        return value is not sentinel, None if value is sentinel else value

    def _validate_provider_response(self, response: object) -> None:
        """Fail closed on provider-level errors hidden inside HTTP 200."""
        if self.backend != MINIMAX_BACKEND:
            return
        base_response = self._field(response, "base_resp")
        status_code = self._field(base_response, "status_code")
        if (
            isinstance(status_code, bool)
            or not isinstance(status_code, int)
            or status_code != 0
        ):
            # Do not include status_msg: providers may echo request material or
            # credentials in diagnostic strings.  The numeric provider code is
            # sufficient for an operator to diagnose the rejected response.
            safe_code = status_code if isinstance(status_code, int) else "missing"
            raise _InvalidMiniMaxResponseError(
                "MiniMax base_resp rejected the response "
                f"(provider status code: {safe_code})"
            )

    @staticmethod
    def _nonnegative_usage_value(usage: object, field: str) -> tuple[int, bool]:
        """Return a provider-reported non-negative integer and availability."""
        value = (
            usage.get(field)
            if isinstance(usage, Mapping)
            else getattr(usage, field, None)
        )
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            return 0, False
        return value, True

    def _usage_counters(self) -> dict:
        """Snapshot mutable usage counters for one durable response delta."""
        return {
            "successful_http_calls": self.total_calls,
            "prompt_tokens": self.total_prompt_tokens,
            "prompt_cache_hit_tokens": self.total_prompt_cache_hit_tokens,
            "prompt_cache_miss_tokens": self.total_prompt_cache_miss_tokens,
            "completion_tokens": self.total_completion_tokens,
            "total_tokens": self.total_reported_tokens,
            "responses_with_usage": self._responses_with_usage,
            "responses_without_usage": self._responses_without_usage,
            "field_observations": dict(self._usage_field_observations),
            "normalized_minimax_cache_omissions": (
                self._normalized_minimax_cache_omissions
            ),
        }

    def _usage_observation_since(self, before: Mapping[str, Any]) -> dict:
        """Return the single-response usage observation since *before*."""
        after = self._usage_counters()
        return {
            field: max(0, int(after[field]) - int(before[field]))
            for field in (
                "prompt_tokens",
                "prompt_cache_hit_tokens",
                "prompt_cache_miss_tokens",
                "completion_tokens",
                "total_tokens",
            )
        } | {
            "response_with_usage": (
                int(after["responses_with_usage"])
                > int(before["responses_with_usage"])
            ),
            "field_observations": {
                field: max(
                    0,
                    int(after["field_observations"][field])
                    - int(before["field_observations"][field]),
                )
                for field in _USAGE_TOKEN_FIELDS
            },
            "normalized_minimax_cache_omissions": max(
                0,
                int(after["normalized_minimax_cache_omissions"])
                - int(before["normalized_minimax_cache_omissions"]),
            ),
        }

    def _restore_durable_usage(self) -> None:
        """Hydrate complete cross-process usage from native journal events."""
        assert self.native_run_journal is not None
        summary = self.native_run_journal.llm_usage_for_role(self.client_role)
        self.total_calls = int(summary["successful_http_calls"])
        self.total_prompt_tokens = int(summary["prompt_tokens"])
        self.total_prompt_cache_hit_tokens = int(
            summary["prompt_cache_hit_tokens"]
        )
        self.total_prompt_cache_miss_tokens = int(
            summary["prompt_cache_miss_tokens"]
        )
        self.total_completion_tokens = int(summary["completion_tokens"])
        self.total_reported_tokens = int(summary["total_tokens"])
        self._responses_with_usage = int(summary["responses_with_usage"])
        self._responses_without_usage = int(summary["responses_without_usage"])
        self._usage_field_observations = {
            field: int(summary["field_observations"].get(field, 0) or 0)
            for field in _USAGE_TOKEN_FIELDS
        }
        self._normalized_minimax_cache_omissions = int(
            summary.get("normalized_minimax_cache_omissions", 0) or 0
        )
        if self.attempt_ledger is not None:
            try:
                self.http_attempts_local = (
                    self.attempt_ledger.attempts_used_for_role(self.client_role)
                )
            except AttemptLedgerError as error:
                raise LLMAttemptAccountingError(
                    f"cannot restore durable role attempts: {error}"
                ) from None
            if self.total_calls > self.http_attempts_local:
                raise LLMAttemptAccountingError(
                    "durable LLM responses exceed paid attempts for role"
                )
        self._durable_usage_restored = True

    def _record_response_usage(self, response: object) -> None:
        """Accumulate billing fields without retaining request/response text."""
        usage = self._field(response, "usage")
        if usage is None:
            self._responses_without_usage += 1
            return

        self._responses_with_usage += 1
        values: dict[str, int] = {}
        available_fields: dict[str, bool] = {}
        direct_fields = list(_USAGE_TOKEN_FIELDS)
        if self.backend == MINIMAX_BACKEND:
            direct_fields.remove("prompt_cache_hit_tokens")
            direct_fields.remove("prompt_cache_miss_tokens")
        for field in direct_fields:
            value, available = self._nonnegative_usage_value(usage, field)
            values[field] = value
            available_fields[field] = available
            if available:
                self._usage_field_observations[field] += 1

        if self.backend == MINIMAX_BACKEND:
            prompt_tokens = values["prompt_tokens"]
            prompt_available = available_fields["prompt_tokens"]
            details_present, prompt_details = self._field_presence(
                usage, "prompt_tokens_details"
            )
            invalid_cache_field = False
            if details_present and prompt_details is None:
                # An explicit null is not an omission.  Do not silently turn a
                # malformed provider value into a valid usage count.
                invalid_cache_field = True
                cache_present, cache_value = True, None
            elif details_present and not (
                isinstance(prompt_details, Mapping)
                or hasattr(prompt_details, "__dict__")
            ):
                invalid_cache_field = True
                cache_present, cache_value = True, None
            elif details_present:
                cache_present, cache_value = self._field_presence(
                    prompt_details, "cached_tokens"
                )
            else:
                cache_present, cache_value = False, None

            if cache_present:
                cache_hit_available = (
                    not isinstance(cache_value, bool)
                    and isinstance(cache_value, int)
                    and cache_value >= 0
                    and prompt_available
                    and cache_value <= prompt_tokens
                )
                invalid_cache_field = (
                    invalid_cache_field or not cache_hit_available
                )
                cache_hit = int(cache_value) if cache_hit_available else 0
            else:
                # MiniMax may omit the nested cache field on an uncached
                # response.  Only true omission receives the canonical zero;
                # the explicit-invalid cases above never enter this branch.
                if not prompt_available:
                    invalid_cache_field = True
                    cache_hit_available = False
                    cache_hit = 0
                else:
                    cache_hit_available = True
                    cache_hit = 0
                    self._normalized_minimax_cache_omissions += 1

            if cache_hit_available:
                values["prompt_cache_hit_tokens"] = cache_hit
                self._usage_field_observations[
                    "prompt_cache_hit_tokens"
                ] += 1
            else:
                values["prompt_cache_hit_tokens"] = 0
            if cache_hit_available:
                values["prompt_cache_miss_tokens"] = (
                    prompt_tokens - cache_hit
                )
                self._usage_field_observations[
                    "prompt_cache_miss_tokens"
                ] += 1
            else:
                values["prompt_cache_miss_tokens"] = 0

        self.total_prompt_tokens += values["prompt_tokens"]
        self.total_prompt_cache_hit_tokens += values[
            "prompt_cache_hit_tokens"
        ]
        self.total_prompt_cache_miss_tokens += values[
            "prompt_cache_miss_tokens"
        ]
        self.total_completion_tokens += values["completion_tokens"]
        self.total_reported_tokens += values["total_tokens"]
        if self.backend == MINIMAX_BACKEND and invalid_cache_field:
            raise _InvalidMiniMaxUsageError(
                "MiniMax cached-token usage was explicitly null, invalid, "
                "negative, or greater than prompt_tokens"
            )

    def _attempt_ledger_snapshot(self) -> dict:
        """Return a path-free, credential-free durable-attempt snapshot."""
        if self.attempt_ledger is None:
            return {"available": False}
        try:
            snapshot = self.attempt_ledger.snapshot()
        except AttemptLedgerError as error:
            return {
                "available": False,
                "error_type": type(error).__name__,
            }
        attempts_at_start = (
            0
            if self._durable_usage_restored
            else int(self._ledger_attempts_at_client_start or 0)
        )
        attempts_used = int(snapshot["attempts_used"])
        return {
            "available": True,
            **snapshot,
            "attempts_at_client_start": attempts_at_start,
            "attempts_during_client_lifetime": max(
                0, attempts_used - attempts_at_start
            ),
        }

    def usage_snapshot(self) -> dict:
        """Return a secret-free per-client billing/audit snapshot.

        Missing provider usage fields contribute zero and are made explicit in
        ``usage_availability``.  ``total_tokens`` is the provider-reported
        field, while ``derived_total_tokens`` remains useful when an older
        compatible endpoint omits that field.
        """
        field_observations = dict(self._usage_field_observations)
        provider_fields_complete = all(
            field_observations[field] == self.total_calls
            for field in _USAGE_TOKEN_FIELDS
        )
        ledger_snapshot = self._attempt_ledger_snapshot()
        if self.attempt_ledger is None:
            covers_durable_attempt_history = True
        elif ledger_snapshot.get("available") is True:
            covers_durable_attempt_history = (
                int(ledger_snapshot.get("attempts_at_client_start", 0)) == 0
            )
        else:
            covers_durable_attempt_history = False
        return {
            "schema_version": LLM_USAGE_SCHEMA_VERSION,
            "client_role": self.client_role,
            "successful_http_calls": self.total_calls,
            "http_attempts_local": self.http_attempts_local,
            "prompt_tokens": self.total_prompt_tokens,
            "prompt_cache_hit_tokens": self.total_prompt_cache_hit_tokens,
            "prompt_cache_miss_tokens": self.total_prompt_cache_miss_tokens,
            "completion_tokens": self.total_completion_tokens,
            "total_tokens": self.total_reported_tokens,
            "derived_total_tokens": (
                self.total_prompt_tokens + self.total_completion_tokens
            ),
            "usage_availability": {
                "complete": (
                    provider_fields_complete
                    and covers_durable_attempt_history
                ),
                "provider_fields_complete": provider_fields_complete,
                "covers_durable_attempt_history": (
                    covers_durable_attempt_history
                ),
                "responses_with_usage": self._responses_with_usage,
                "responses_without_usage": self._responses_without_usage,
                "field_observations": field_observations,
            },
            "normalization_provenance": {
                "schema_version": 1,
                "rule_id": MINIMAX_CACHE_OMISSION_RULE_ID,
                "cached_tokens_omission_count": (
                    self._normalized_minimax_cache_omissions
                ),
            },
            "attempt_ledger": ledger_snapshot,
        }

    def get_usage_stats(self) -> dict:
        """Return cumulative usage with compatible token counters."""
        return {
            "total_calls": self.total_calls,
            "successful_http_calls": self.total_calls,
            "http_attempts_local": self.http_attempts_local,
            "total_prompt_tokens": self.total_prompt_tokens,
            "total_prompt_cache_hit_tokens": (
                self.total_prompt_cache_hit_tokens
            ),
            "total_prompt_cache_miss_tokens": (
                self.total_prompt_cache_miss_tokens
            ),
            "total_completion_tokens": self.total_completion_tokens,
            # This field is the sum of prompt and completion tokens.
            # ``usage_snapshot`` exposes the provider-reported total
            # and its availability separately.
            "total_tokens": (
                self.total_prompt_tokens + self.total_completion_tokens
            ),
            "provider_reported_total_tokens": self.total_reported_tokens,
        }


def _status_code(error: Exception | None) -> int | None:
    """Extract an HTTP status without depending on a concrete SDK version."""
    if error is None:
        return None
    value = getattr(error, "status_code", None)
    if isinstance(value, int):
        return value
    response = getattr(error, "response", None)
    value = getattr(response, "status_code", None)
    return value if isinstance(value, int) else None


def _is_transient(error: Exception) -> bool:
    """Return True only for errors for which retrying can plausibly help."""
    if isinstance(error, _EmptyLLMResponseError):
        return True
    status = _status_code(error)
    if status is not None:
        return status in (408, 429) or 500 <= status <= 599
    return isinstance(
        error,
        (APIConnectionError, APITimeoutError, TimeoutError, ConnectionError),
    ) and not isinstance(error, APIStatusError)


def _failure_marker(error: Exception, *, transient: bool) -> str:
    """Persist only a safe failure class plus its retry classification."""
    name = type(error).__name__ or "UnknownError"
    return f"transient_{name}" if transient else name


def _non_retryable_detail(status: int | None) -> str:
    if status == 401:
        return "authentication failed; check the configured API key"
    if status == 403:
        return "permission denied; check account and model access"
    if status in (400, 404, 409, 422):
        return "invalid request, parameters, endpoint, or model configuration"
    if status is not None and 400 <= status <= 499:
        return "non-retryable client error"
    return "non-transient client or response-processing error"


def _error_label(error: Exception | None, status: int | None) -> str:
    name = type(error).__name__ if error is not None else "unknown error"
    return f"HTTP {status} {name}" if status is not None else name


def _redact(value: str, secret: str | None) -> str:
    """Keep credentials out of logs even if a backend echoes them in errors."""
    if secret and secret != "EMPTY":
        return value.replace(secret, "[REDACTED]")
    return value
