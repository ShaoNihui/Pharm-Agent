"""
Shared configuration loading utilities.
"""

import yaml


def load_config(config_path: str) -> dict:
    """Load YAML config and resolve internal LLM references.

    Copies top-level 'llm' config into 'generator' and 'reviewer'
    sub-configs if they don't already have their own 'llm' key.
    """
    with open(config_path) as f:
        config = yaml.safe_load(f)

    llm_config = config.get("llm", {})
    for agent_key in ("generator", "reviewer"):
        if agent_key in config and "llm" not in config[agent_key]:
            config[agent_key]["llm"] = llm_config

    return config
