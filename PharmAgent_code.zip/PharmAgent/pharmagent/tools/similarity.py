"""
Molecular similarity and diversity computation utilities.
"""

import numpy as np
from rdkit import Chem
from rdkit.Chem import AllChem, DataStructs


def compute_fingerprint_matrix(smiles_list: list[str], radius: int = 2,
                                n_bits: int = 2048) -> np.ndarray:
    """Compute Morgan fingerprint matrix for a list of SMILES.

    Returns float32 array of shape (N, n_bits) where N = number of valid SMILES.
    Invalid SMILES are skipped (result may have fewer rows than input).
    """
    fps = []
    for smi in smiles_list:
        mol = Chem.MolFromSmiles(smi)
        if mol is None:
            continue
        fp = AllChem.GetMorganFingerprintAsBitVect(mol, radius=radius, nBits=n_bits)
        arr = np.zeros(n_bits, dtype=np.float32)
        DataStructs.ConvertToNumpyArray(fp, arr)
        fps.append(arr)
    if not fps:
        return np.zeros((0, n_bits), dtype=np.float32)
    return np.stack(fps)


def compute_internal_diversity(smiles_list: list[str], radius: int = 2,
                                n_bits: int = 2048) -> float:
    """Compute average pairwise Tanimoto distance (1 - similarity).

    Higher value means more diverse set. Returns 0.0 for <2 molecules.
    """
    mols = []
    for smi in smiles_list:
        mol = Chem.MolFromSmiles(smi)
        if mol is not None:
            mols.append(mol)
    if len(mols) < 2:
        return 0.0

    fps = [
        AllChem.GetMorganFingerprintAsBitVect(m, radius=radius, nBits=n_bits)
        for m in mols
    ]

    total_dist = 0.0
    n_pairs = 0
    for i in range(len(fps)):
        for j in range(i + 1, len(fps)):
            sim = DataStructs.TanimotoSimilarity(fps[i], fps[j])
            total_dist += 1.0 - sim
            n_pairs += 1

    return total_dist / n_pairs if n_pairs > 0 else 0.0


def compute_nearest_neighbor_similarity(query_smiles: str,
                                         reference_list: list[str],
                                         radius: int = 2,
                                         n_bits: int = 2048) -> float:
    """Compute maximum Tanimoto similarity between query and reference molecules."""
    query_mol = Chem.MolFromSmiles(query_smiles)
    if query_mol is None:
        return 0.0

    query_fp = AllChem.GetMorganFingerprintAsBitVect(query_mol, radius=radius, nBits=n_bits)
    max_sim = 0.0

    for ref_smi in reference_list:
        ref_mol = Chem.MolFromSmiles(ref_smi)
        if ref_mol is None:
            continue
        ref_fp = AllChem.GetMorganFingerprintAsBitVect(ref_mol, radius=radius, nBits=n_bits)
        sim = DataStructs.TanimotoSimilarity(query_fp, ref_fp)
        if sim > max_sim:
            max_sim = sim

    return max_sim
