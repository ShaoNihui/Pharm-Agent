"""
Core RDKit utility functions for molecular property computation.
All public functions accept SMILES strings and handle invalid input gracefully.
"""

import numpy as np
from rdkit import Chem
from rdkit.Chem import AllChem, Descriptors, QED, DataStructs
from rdkit.Chem.FilterCatalog import FilterCatalog, FilterCatalogParams

# Build filter catalogs once (expensive to construct, ~100ms each)
_pains_params = FilterCatalogParams()
_pains_params.AddCatalog(FilterCatalogParams.FilterCatalogs.PAINS)
_PAINS_CATALOG = FilterCatalog(_pains_params)

_brenk_params = FilterCatalogParams()
_brenk_params.AddCatalog(FilterCatalogParams.FilterCatalogs.BRENK)
_BRENK_CATALOG = FilterCatalog(_brenk_params)


def validate_smiles(smiles: str) -> str | None:
    """Validate and canonicalize a SMILES string.

    Returns canonical SMILES or None if invalid.
    """
    if not smiles or not isinstance(smiles, str):
        return None
    try:
        mol = Chem.MolFromSmiles(smiles.strip())
        if mol is None:
            return None
        return Chem.MolToSmiles(mol)
    except Exception:
        return None


def compute_descriptors(smiles: str) -> dict | None:
    """Compute basic molecular descriptors.

    Returns dict with MW, logP, HBD, HBA, TPSA, RotBonds, NumRings,
    NumAromaticRings, NumHeavyAtoms, or None if SMILES is invalid.
    """
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None
    return {
        "MW": Descriptors.MolWt(mol),
        "logP": Descriptors.MolLogP(mol),
        "HBD": Descriptors.NumHDonors(mol),
        "HBA": Descriptors.NumHAcceptors(mol),
        "TPSA": Descriptors.TPSA(mol),
        "RotBonds": Descriptors.NumRotatableBonds(mol),
        "NumRings": Descriptors.RingCount(mol),
        "NumAromaticRings": Descriptors.NumAromaticRings(mol),
        "NumHeavyAtoms": mol.GetNumHeavyAtoms(),
    }


def check_lipinski(smiles: str) -> dict:
    """Check Lipinski's Rule of Five.

    Returns dict with per-rule results and overall 'pass' boolean.
    """
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return {"pass": False, "error": "Invalid SMILES"}

    mw = Descriptors.MolWt(mol)
    logp = Descriptors.MolLogP(mol)
    hbd = Descriptors.NumHDonors(mol)
    hba = Descriptors.NumHAcceptors(mol)

    result = {
        "MW": mw, "MW_pass": mw <= 500,
        "logP": logp, "logP_pass": logp <= 5,
        "HBD": hbd, "HBD_pass": hbd <= 5,
        "HBA": hba, "HBA_pass": hba <= 10,
    }
    result["n_violations"] = sum(
        1 for k in ("MW_pass", "logP_pass", "HBD_pass", "HBA_pass")
        if not result[k]
    )
    result["pass"] = result["n_violations"] == 0
    return result


def check_veber(smiles: str) -> dict:
    """Check Veber's rules (oral bioavailability): TPSA < 140 and RotBonds <= 10."""
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return {"pass": False, "error": "Invalid SMILES"}

    tpsa = Descriptors.TPSA(mol)
    rot = Descriptors.NumRotatableBonds(mol)
    return {
        "TPSA": tpsa, "TPSA_pass": tpsa < 140,
        "RotBonds": rot, "RotBonds_pass": rot <= 10,
        "pass": tpsa < 140 and rot <= 10,
    }


def check_pains(smiles: str) -> dict:
    """Check for PAINS (Pan-Assay Interference Structures) alerts.

    Returns dict with 'has_pains' boolean and list of matched filter names.
    """
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return {"has_pains": False, "alerts": [], "error": "Invalid SMILES"}

    matches = []
    for entry in _PAINS_CATALOG.GetMatches(mol):
        matches.append(entry.GetDescription())

    return {"has_pains": len(matches) > 0, "alerts": matches}


def check_brenk(smiles: str) -> dict:
    """Check for Brenk structural alerts (undesirable functional groups).

    Returns dict with 'has_alerts' boolean and list of matched alert names.
    """
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return {"has_alerts": False, "alerts": [], "error": "Invalid SMILES"}

    matches = []
    for entry in _BRENK_CATALOG.GetMatches(mol):
        matches.append(entry.GetDescription())

    return {"has_alerts": len(matches) > 0, "alerts": matches}


def compute_qed(smiles: str) -> float:
    """Compute Quantitative Estimate of Drug-likeness (0-1, higher is better)."""
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return 0.0
    return QED.qed(mol)


def compute_morgan_fp(smiles: str, radius: int = 2, n_bits: int = 2048) -> np.ndarray | None:
    """Compute Morgan fingerprint as float32 numpy array (for FAISS compatibility).

    Returns array of shape (n_bits,) or None if invalid.
    """
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None
    fp = AllChem.GetMorganFingerprintAsBitVect(mol, radius=radius, nBits=n_bits)
    arr = np.zeros(n_bits, dtype=np.float32)
    DataStructs.ConvertToNumpyArray(fp, arr)
    return arr


def compute_tanimoto(smiles1: str, smiles2: str, radius: int = 2, n_bits: int = 2048) -> float:
    """Compute Tanimoto similarity between two molecules using Morgan fingerprints."""
    mol1 = Chem.MolFromSmiles(smiles1)
    mol2 = Chem.MolFromSmiles(smiles2)
    if mol1 is None or mol2 is None:
        return 0.0
    fp1 = AllChem.GetMorganFingerprintAsBitVect(mol1, radius=radius, nBits=n_bits)
    fp2 = AllChem.GetMorganFingerprintAsBitVect(mol2, radius=radius, nBits=n_bits)
    return DataStructs.TanimotoSimilarity(fp1, fp2)
