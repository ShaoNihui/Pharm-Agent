"""Unified ADMET prediction with local, reproducible backends.

Backends:
  - rdkit_only: Rule-based approximations using RDKit descriptors.
  - admet_ai:   Local ADMET-AI v1.4 ensemble predictions.
"""

import logging
import math
import sys
from collections import OrderedDict
from collections.abc import Mapping
from typing import Any

from rdkit import Chem
from rdkit.Chem import Descriptors, QED

from pharmagent.tools.rdkit_tools import _PAINS_CATALOG

logger = logging.getLogger(__name__)


ADMET_AI_INFERENCE_MODE_BATCH = "batch"
ADMET_AI_INFERENCE_MODE_CANONICAL_SINGLETON = "canonical_singleton"
_SUPPORTED_ADMET_AI_INFERENCE_MODES = {
    ADMET_AI_INFERENCE_MODE_BATCH,
    ADMET_AI_INFERENCE_MODE_CANONICAL_SINGLETON,
}


def _positive_thread_count(value: Any, config_key: str) -> int:
    """Validate one explicitly configured native-runtime thread count."""
    if isinstance(value, bool):
        raise ValueError(f"admet.{config_key} must be a positive integer")
    try:
        threads = int(value)
    except (TypeError, ValueError) as error:
        raise ValueError(
            f"admet.{config_key} must be a positive integer"
        ) from error
    if threads < 1:
        raise ValueError(f"admet.{config_key} must be a positive integer")
    return threads


def _configure_darwin_torch_runtime(config: Mapping[str, Any]) -> dict | None:
    """Apply an explicit, Darwin-only PyTorch thread-safety policy.

    ADMET-AI uses PyTorch while formal PharmAgent RAG uses FAISS.  The macOS
    wheels can bundle distinct ``libomp`` runtimes; allowing both libraries to
    create OpenMP worker teams in one process can therefore crash in native
    code.  This policy is deliberately opt-in so exploratory configurations,
    non-Darwin hosts, and the standard (RDKit-only) arm are unchanged.

    The policy runs immediately before importing ADMET-AI and constructing its
    model.  Returned values are verified effective settings suitable for logs
    and runtime inspection.
    """
    keys = {
        "intraop_threads": "darwin_torch_intraop_threads",
        "interop_threads": "darwin_torch_interop_threads",
    }
    requested = {
        label: _positive_thread_count(config[key], key)
        for label, key in keys.items()
        if config.get(key) is not None
    }
    if not requested or sys.platform != "darwin":
        return None

    try:
        import torch
    except ImportError as error:
        raise RuntimeError(
            "Darwin ADMET runtime safety was configured but PyTorch is unavailable"
        ) from error

    effective: dict[str, int] = {}
    if "intraop_threads" in requested:
        setter = getattr(torch, "set_num_threads", None)
        getter = getattr(torch, "get_num_threads", None)
        if setter is None or getter is None:
            raise RuntimeError("PyTorch does not expose intra-op thread controls")
        setter(requested["intraop_threads"])
        effective["intraop_threads"] = int(getter())
        if effective["intraop_threads"] != requested["intraop_threads"]:
            raise RuntimeError(
                "Unable to enforce the configured PyTorch intra-op thread count"
            )

    if "interop_threads" in requested:
        setter = getattr(torch, "set_num_interop_threads", None)
        getter = getattr(torch, "get_num_interop_threads", None)
        if setter is None or getter is None:
            raise RuntimeError("PyTorch does not expose inter-op thread controls")
        before = int(getter())
        if before != requested["interop_threads"]:
            try:
                setter(requested["interop_threads"])
            except RuntimeError as error:
                # PyTorch permits setting inter-op threads only before parallel
                # work starts.  Fail closed unless a prior identical policy is
                # already effective in this process.
                if int(getter()) != requested["interop_threads"]:
                    raise RuntimeError(
                        "Unable to enforce the configured PyTorch inter-op "
                        "thread count before ADMET-AI initialization"
                    ) from error
        effective["interop_threads"] = int(getter())
        if effective["interop_threads"] != requested["interop_threads"]:
            raise RuntimeError(
                "Unable to enforce the configured PyTorch inter-op thread count"
            )

    logger.info(
        "ADMET-AI Darwin PyTorch runtime policy active: intra-op=%s, inter-op=%s",
        effective.get("intraop_threads", "unchanged"),
        effective.get("interop_threads", "unchanged"),
    )
    return effective


class ADMETPredictor:
    """Multi-backend ADMET property predictor with caching and fallback."""

    _SUPPORTED_BACKENDS = {"rdkit_only", "admet_ai"}

    # ADMET-AI v1.4 endpoint IDs -> stable PharmAgent prediction keys.
    # The source IDs are defined by the ADMET-AI package's admet.csv file.
    _ADMET_AI_PROPERTY_MAP: dict[str, str] = {
        # Absorption
        "Caco2_Wang": "Caco2",
        "HIA_Hou": "HIA",
        "Bioavailability_Ma": "bioavailability",
        "Solubility_AqSolDB": "solubility",
        "Pgp_Broccatelli": "Pgp_inhibition",
        # Distribution
        "BBB_Martins": "BBB",
        "PPBR_AZ": "PPB",
        "VDss_Lombardo": "VDss",
        # Metabolism
        "CYP1A2_Veith": "CYP1A2_inh",
        "CYP2C9_Veith": "CYP2C9_inh",
        "CYP2C19_Veith": "CYP2C19_inh",
        "CYP2D6_Veith": "CYP2D6_inh",
        "CYP3A4_Veith": "CYP3A4_inh",
        "CYP2C9_Substrate_CarbonMangels": "CYP2C9_substrate",
        "CYP2D6_Substrate_CarbonMangels": "CYP2D6_substrate",
        "CYP3A4_Substrate_CarbonMangels": "CYP3A4_substrate",
        # Excretion
        "Half_Life_Obach": "half_life",
        "Clearance_Hepatocyte_AZ": "clearance",
        "Clearance_Microsome_AZ": "clearance_microsome",
        # Toxicity
        "hERG": "hERG",
        "AMES": "AMES",
        "DILI": "hepatotox",
        "ClinTox": "clinical_toxicity",
        "LD50_Zhu": "LD50",
    }

    def __init__(self, backend: str = "rdkit_only", config: dict | None = None):
        if backend not in self._SUPPORTED_BACKENDS:
            supported = ", ".join(sorted(self._SUPPORTED_BACKENDS))
            raise ValueError(
                f"Unsupported ADMET backend '{backend}'. Choose one of: {supported}."
            )

        self.backend = backend
        self.config = config or {}
        self._max_cache_size = self.config.get("max_cache_size", 10000)
        if (
            isinstance(self._max_cache_size, bool)
            or not isinstance(self._max_cache_size, int)
            or self._max_cache_size <= 0
        ):
            raise ValueError("admet.max_cache_size must be a positive integer")
        self._cache: OrderedDict[str, dict] = OrderedDict()
        self.fallback_to_rdkit = self.config.get("fallback_to_rdkit", True)
        self.allow_approximate_endpoint_fallback = self.config.get(
            "allow_approximate_endpoint_fallback", True
        )
        self.inference_mode = self.config.get(
            "inference_mode", ADMET_AI_INFERENCE_MODE_BATCH
        )
        if self.inference_mode not in _SUPPORTED_ADMET_AI_INFERENCE_MODES:
            supported = ", ".join(sorted(_SUPPORTED_ADMET_AI_INFERENCE_MODES))
            raise ValueError(
                "admet.inference_mode must be one of: " + supported
            )
        if (
            self.inference_mode
            == ADMET_AI_INFERENCE_MODE_CANONICAL_SINGLETON
            and self.backend != "admet_ai"
        ):
            raise ValueError(
                "admet.inference_mode=canonical_singleton requires "
                "backend=admet_ai"
            )

        # ADMET-AI imports and model loading are intentionally lazy: the local
        # ensemble is large and should only be loaded when that backend is used.
        self._admet_ai_model = None
        self._admet_ai_load_attempted = False
        self._admet_ai_version: str | None = None
        self.darwin_torch_runtime: dict[str, int] | None = None

    def _cache_put(self, key: str, value: dict) -> None:
        """Insert a detached value into the bounded canonical-SMILES cache."""
        if key in self._cache:
            self._cache.move_to_end(key)
        self._cache[key] = dict(value)
        while len(self._cache) > self._max_cache_size:
            self._cache.popitem(last=False)

    def _cache_get(self, key: str) -> dict:
        """Return a detached cached value so callers cannot corrupt replay."""
        self._cache.move_to_end(key)
        return dict(self._cache[key])

    def predict(self, smiles: str) -> dict:
        """Predict ADMET properties for a single SMILES.

        Always returns a dict. On failure, returns rdkit_only results.
        """
        canonical = self._canonicalize(smiles)
        if canonical is None:
            return {"error": "Invalid SMILES", "smiles": smiles}

        if canonical in self._cache:
            return self._cache_get(canonical)

        result = self._predict_rdkit(canonical)

        if self.backend == "admet_ai":
            if not self.allow_approximate_endpoint_fallback:
                self._drop_approximate_endpoints(result)
            model_result = self._predict_admet_ai_batch([canonical])[0]
            if model_result is None:
                if not self.fallback_to_rdkit:
                    raise RuntimeError(
                        "ADMET-AI prediction returned no row for a canonical "
                        "singleton"
                    )
            else:
                result.update(model_result)

        self._cache_put(canonical, result)
        return dict(result)

    def predict_batch(self, smiles_list: list[str]) -> list[dict]:
        """Predict ADMET properties for a batch of SMILES.

        Formal ADMET evaluation pins ``canonical_singleton``.  In that mode
        the public batch boundary is retained for callers, but every uncached
        canonical molecule is sent to ADMET-AI alone.  Immediate canonical
        caching means duplicates still require only one model inference.  This
        removes ADMET-AI's small batch-size/order numerical drift and makes
        online evaluation, resumed incumbents, and post-hoc annotation exact.
        """
        if (
            self.backend == "admet_ai"
            and self.inference_mode
            == ADMET_AI_INFERENCE_MODE_CANONICAL_SINGLETON
        ):
            return [self.predict(smiles) for smiles in smiles_list]

        results = []
        uncached = []
        uncached_indices = []

        for i, smi in enumerate(smiles_list):
            canonical = self._canonicalize(smi)
            if canonical is None:
                results.append({"error": "Invalid SMILES", "smiles": smi})
                continue
            if canonical in self._cache:
                results.append(self._cache_get(canonical))
            else:
                results.append(None)  # placeholder
                uncached.append(canonical)
                uncached_indices.append(i)

        if uncached:
            # Compute RDKit properties for all uncached
            for idx, smi in zip(uncached_indices, uncached):
                rdkit_result = self._predict_rdkit(smi)
                if (
                    self.backend == "admet_ai"
                    and not self.allow_approximate_endpoint_fallback
                ):
                    self._drop_approximate_endpoints(rdkit_result)
                results[idx] = rdkit_result

            # ADMET-AI performs one local vectorized prediction for the batch.
            if self.backend == "admet_ai" and uncached:
                model_results = self._predict_admet_ai_batch(uncached)
                if not self.fallback_to_rdkit and any(
                    result is None for result in model_results
                ):
                    raise RuntimeError(
                        "ADMET-AI prediction returned fewer rows than the "
                        "canonical batch"
                    )
                for idx, smi, model_result in zip(
                    uncached_indices, uncached, model_results
                ):
                    if model_result:
                        results[idx].update(model_result)
                    self._cache_put(smi, results[idx])
            else:
                for idx, smi in zip(uncached_indices, uncached):
                    self._cache_put(smi, results[idx])

        return results

    @staticmethod
    def _drop_approximate_endpoints(prediction: dict) -> None:
        """Remove heuristic endpoint substitutes from strict learned runs."""
        for key in tuple(prediction):
            if key.endswith("_approx"):
                prediction.pop(key, None)

    def _canonicalize(self, smiles: str) -> str | None:
        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            return None
        return Chem.MolToSmiles(mol)

    def _predict_rdkit(self, smiles: str) -> dict:
        """RDKit-based property computation — always available."""
        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            return {"error": "Invalid SMILES"}

        mw = Descriptors.MolWt(mol)
        logp = Descriptors.MolLogP(mol)
        hbd = Descriptors.NumHDonors(mol)
        hba = Descriptors.NumHAcceptors(mol)
        tpsa = Descriptors.TPSA(mol)
        rot_bonds = Descriptors.NumRotatableBonds(mol)
        qed_val = QED.qed(mol)

        # PAINS check
        pains_match = _PAINS_CATALOG.GetFirstMatch(mol)
        has_pains = pains_match is not None

        # Lipinski violations
        lipinski_violations = sum([mw > 500, logp > 5, hbd > 5, hba > 10])

        result = {
            "smiles": smiles,
            "MW": mw,
            "logP": logp,
            "HBD": hbd,
            "HBA": hba,
            "TPSA": tpsa,
            "RotBonds": rot_bonds,
            "QED": qed_val,
            "PAINS": 1.0 if has_pains else 0.0,
            "lipinski_violations": lipinski_violations,
        }

        # Approximate ADMET properties (rule-based)
        result.update(self._rdkit_approximate_admet(mol, mw, logp, tpsa))
        return result

    def _rdkit_approximate_admet(self, mol, mw: float, logp: float,
                                  tpsa: float) -> dict:
        """Rule-based ADMET approximations when no API is available.

        Approximate values use the same scales as the selected ADMET-AI
        endpoints so that constraint thresholds remain consistent across
        backends. They are screening heuristics, not learned predictions.
        """
        # ADMET-AI hERG and CYP endpoints are probabilities in [0, 1].
        # Lipophilic, large molecules are heuristically more likely to block hERG.
        herg_risky = logp > 3.0 and mw > 400
        herg_approx = 0.8 if herg_risky else 0.1

        cyp2d6_approx = 0.8 if (logp > 3.5 and mw > 300) else 0.1

        return {
            "Caco2_approx": -5.0 if tpsa < 140 else -6.0,
            "HIA_approx": 0.8 if (tpsa < 140 and logp > 0) else 0.3,
            "BBB_approx": 1.0 if (logp - 0.9 * tpsa / 100) > 0 else 0.0,
            "CYP2D6_inh_approx": cyp2d6_approx,
            "hERG_approx": herg_approx,
        }

    # ---- ADMET-AI local model ----

    def _load_admet_ai_model(self):
        """Load the ADMET-AI ensemble once, or apply the configured fallback."""
        if self._admet_ai_load_attempted:
            return self._admet_ai_model

        self._admet_ai_load_attempted = True
        try:
            # This must precede the ADMET-AI import/model construction: both
            # steps can initialize PyTorch's bundled OpenMP runtime.
            self.darwin_torch_runtime = _configure_darwin_torch_runtime(
                self.config
            )
            import admet_ai

            model_kwargs: dict[str, Any] = {
                "include_physchem": False,
                "drugbank_path": None,
            }
            if self.config.get("num_workers") is not None:
                model_kwargs["num_workers"] = self.config["num_workers"]
            if self.config.get("models_dir"):
                model_kwargs["models_dir"] = self.config["models_dir"]

            self._admet_ai_model = admet_ai.ADMETModel(**model_kwargs)
            self._admet_ai_version = getattr(admet_ai, "__version__", "unknown")
            logger.info("Loaded local ADMET-AI model version %s", self._admet_ai_version)
        except Exception as exc:
            message = (
                "Unable to load the ADMET-AI backend. Install the pinned "
                "dependency with `pip install -e '.[admet]'`."
            )
            if not self.fallback_to_rdkit:
                raise RuntimeError(message) from exc
            logger.warning("%s Falling back to RDKit heuristics: %s", message, exc)

        return self._admet_ai_model

    def _predict_admet_ai_batch(
        self, smiles_list: list[str]
    ) -> list[dict | None]:
        """Predict a canonical-SMILES batch with the local ADMET-AI model."""
        model = self._load_admet_ai_model()
        if model is None:
            return [None] * len(smiles_list)

        try:
            raw_predictions = model.predict(smiles=smiles_list)
            return self._parse_admet_ai_predictions(raw_predictions, len(smiles_list))
        except Exception as exc:
            message = "ADMET-AI prediction failed"
            if not self.fallback_to_rdkit:
                raise RuntimeError(message) from exc
            logger.warning("%s; falling back to RDKit heuristics: %s", message, exc)
            return [None] * len(smiles_list)

    def _parse_admet_ai_predictions(
        self, predictions: Any, expected_count: int
    ) -> list[dict | None]:
        """Map ADMET-AI endpoint IDs to PharmAgent's stable output schema."""
        rows: list[Mapping[str, Any]] = []

        if isinstance(predictions, Mapping):
            rows = [predictions]
        elif hasattr(predictions, "iloc"):
            rows = [predictions.iloc[i].to_dict() for i in range(len(predictions))]
        elif isinstance(predictions, (list, tuple)):
            rows = [row for row in predictions if isinstance(row, Mapping)]

        parsed_results: list[dict | None] = []
        for index in range(expected_count):
            if index >= len(rows):
                parsed_results.append(None)
                continue

            row = rows[index]
            parsed: dict[str, Any] = {"prediction_backend": "admet_ai"}
            if self._admet_ai_version is not None:
                parsed["admet_ai_version"] = self._admet_ai_version

            for source_key, target_key in self._ADMET_AI_PROPERTY_MAP.items():
                value = self._safe_float(row.get(source_key))
                if value is not None:
                    parsed[target_key] = value

            parsed_results.append(parsed)

        return parsed_results

    @staticmethod
    def _safe_float(val: Any) -> float | None:
        if val is None:
            return None
        try:
            numeric = float(val)
            return numeric if math.isfinite(numeric) else None
        except (ValueError, TypeError, OverflowError):
            return None
