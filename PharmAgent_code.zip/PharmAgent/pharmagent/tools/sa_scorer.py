"""Strict wrapper around RDKit's reference Synthetic Accessibility score.

The paper protocol uses the implementation distributed in
``rdkit.Contrib.SA_Score.sascorer`` together with its ``fpscores.pkl.gz``
fragment table. Formal scoring fails closed if either component is
unavailable; a heuristic substitute would change both the Verifier feasible
domain and the reported ADMET metrics.
"""

from __future__ import annotations

from functools import lru_cache
import hashlib
import math
from pathlib import Path
from typing import Any

from rdkit import Chem, rdBase


SA_SCORE_IMPLEMENTATION = "rdkit.Contrib.SA_Score.sascorer.calculateScore"
SA_SCORE_FAILURE_POLICY = "raise"
SA_SCORE_ASSET_LOGICAL_NAME = "rdkit/Contrib/SA_Score/fpscores.pkl.gz"


class SAScoreUnavailableError(RuntimeError):
    """Raised when the reference implementation or fragment table fails."""


@lru_cache(maxsize=1)
def _official_sascorer() -> tuple[Any, Path]:
    try:
        from rdkit.Contrib.SA_Score import sascorer
    except Exception as error:
        raise SAScoreUnavailableError(
            "RDKit Contrib SA_Score is required by the formal protocol"
        ) from error

    module_path = Path(sascorer.__file__).expanduser().resolve()
    asset_path = module_path.with_name("fpscores.pkl.gz")
    if not asset_path.is_file() or asset_path.stat().st_size <= 0:
        raise SAScoreUnavailableError(
            "RDKit SA_Score fragment table fpscores.pkl.gz is unavailable"
        )
    return sascorer, asset_path


@lru_cache(maxsize=1)
def _fragment_asset_identity() -> dict[str, int | str]:
    _, asset_path = _official_sascorer()
    hasher = hashlib.sha256()
    try:
        with asset_path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                hasher.update(chunk)
    except OSError as error:
        raise SAScoreUnavailableError(
            "cannot read RDKit SA_Score fragment table"
        ) from error
    return {
        "logical_name": SA_SCORE_ASSET_LOGICAL_NAME,
        "sha256": hasher.hexdigest(),
        "size_bytes": asset_path.stat().st_size,
    }


def get_sa_score_provenance(
    *, rdkit_version: str | None = None
) -> dict[str, Any]:
    """Return path-free, content-addressed provenance for formal SA scoring."""
    version = str(rdkit_version or rdBase.rdkitVersion)
    if not version:
        raise SAScoreUnavailableError("RDKit version is unavailable")
    return {
        "implementation": SA_SCORE_IMPLEMENTATION,
        "rdkit_version": version,
        "failure_policy": SA_SCORE_FAILURE_POLICY,
        "fragment_scores": dict(_fragment_asset_identity()),
    }


def compute_sa_score(smiles: str) -> float:
    """Return RDKit's reference SA score (1 easy, 10 difficult).

    Invalid SMILES receive the conventional worst score of 10. A valid
    molecule is never assigned a heuristic or neutral value: implementation,
    asset, calculation, or non-finite failures raise explicitly.
    """
    if not smiles:
        return 10.0
    molecule = Chem.MolFromSmiles(smiles)
    if molecule is None:
        return 10.0

    sascorer, _ = _official_sascorer()
    try:
        score = float(sascorer.calculateScore(molecule))
    except Exception as error:
        raise SAScoreUnavailableError(
            "RDKit reference SA Score calculation failed"
        ) from error
    if not math.isfinite(score):
        raise SAScoreUnavailableError(
            "RDKit reference SA Score returned a non-finite value"
        )
    return score
