"""FAISS-based retrieval of Matched Molecular Pairs for RAG context.

Exploratory configurations may opt into no-op behaviour when assets are not
available.  Formal configurations set ``rag.require_available: true`` and are
therefore fail-closed: an incomplete or inconsistent RAG bundle aborts the run.
"""

import json
import logging
import os
import sys

import numpy as np

from pharmagent.tools.rdkit_tools import compute_morgan_fp
from pharmagent.rag.context_formatter import format_mmp_context
from pharmagent.rag.mmp_indexer import FORMAL_TASK_TARGETS

logger = logging.getLogger(__name__)


class RAGUnavailableError(RuntimeError):
    """Raised when a required formal RAG asset cannot be used safely."""

# Case-study runners use readable target names while the prepared ChEMBL
# records store target ChEMBL IDs.  Keep the lookup local and explicit so RAG
# can actually prioritize target-matched examples.
_TARGET_PROPERTY_ALIASES = {
    "EGFR": "CHEMBL203",
    "JAK2": "CHEMBL2971",
    "BRAF_V600E": "CHEMBL5145",
    "DRD2": "CHEMBL217",
    "hERG": "CHEMBL240",
    **{
        task: spec["target_chembl_id"]
        for task, spec in FORMAL_TASK_TARGETS.items()
    },
}


def _configure_faiss_openmp(faiss_module, config: dict) -> int | None:
    """Apply the safe FAISS OpenMP policy for the current platform.

    PyTorch and FAISS wheels bundle different ``libomp`` runtimes on macOS.
    Once PyTorch has initialized its runtime, a multi-threaded FAISS search can
    segfault inside ``libomp``.  Keeping FAISS single-threaded avoids crossing
    those runtimes while leaving other platforms unchanged by default.

    ``rag.faiss_omp_threads`` explicitly overrides the platform default.  The
    return value is the effective FAISS thread count, or ``None`` when no
    setting was applied.
    """
    configured_threads = config.get("faiss_omp_threads")
    setting_source = "rag.faiss_omp_threads"

    if configured_threads is None:
        if sys.platform != "darwin":
            return None
        configured_threads = 1
        setting_source = "macOS safety default"

    if isinstance(configured_threads, bool):
        raise ValueError("rag.faiss_omp_threads must be a positive integer")
    try:
        requested_threads = int(configured_threads)
    except (TypeError, ValueError) as error:
        raise ValueError(
            "rag.faiss_omp_threads must be a positive integer"
        ) from error
    if requested_threads < 1:
        raise ValueError("rag.faiss_omp_threads must be a positive integer")

    faiss_module.omp_set_num_threads(requested_threads)
    get_threads = getattr(faiss_module, "omp_get_max_threads", None)
    effective_threads = int(get_threads()) if get_threads else requested_threads
    logger.info(
        "FAISS OpenMP threads set to %d (%s; requested=%d)",
        effective_threads,
        setting_source,
        requested_threads,
    )
    return effective_threads


class MMPRetriever:
    """Retrieves similar matched molecular pairs from a FAISS index."""

    def __init__(self, config: dict):
        self.top_k = config.get("top_k", 3)
        if isinstance(self.top_k, bool) or not isinstance(self.top_k, int) or self.top_k < 1:
            raise ValueError("rag.top_k must be a positive integer")
        self.enabled = False
        self.index = None
        self.mmp_data = []
        self.faiss_omp_threads: int | None = None
        self.allow_generic_fallback = bool(
            config.get("allow_generic_fallback", False)
        )
        self.require_available = bool(config.get("require_available", False))
        if self.require_available and self.allow_generic_fallback:
            raise RAGUnavailableError(
                "formal RAG requires allow_generic_fallback=false"
            )
        self._faiss_module = None
        self._target_rows: dict[str, list[int]] = {}
        self._target_indices: dict[str, tuple[object, list[int]]] = {}

        index_path = config.get("faiss_index_path", "")
        data_path = config.get("mmp_data_path", "")

        if not index_path or not data_path:
            message = "RAG not configured (missing index/data paths)"
            if self.require_available:
                raise RAGUnavailableError(message)
            logger.info("%s. Running in no-op mode.", message)
            return

        if not os.path.exists(index_path) or not os.path.exists(data_path):
            message = f"RAG index or data not found ({index_path}, {data_path})"
            if self.require_available:
                raise RAGUnavailableError(message)
            logger.info("%s. Running in no-op mode.", message)
            return

        try:
            import faiss
            # Must run before the first FAISS search.  On macOS this prevents a
            # native crash when PyTorch's bundled OpenMP runtime is already
            # active in the same process.
            self.faiss_omp_threads = _configure_faiss_openmp(faiss, config)
            self._faiss_module = faiss
            self.index = faiss.read_index(index_path)
            with open(data_path, "r") as f:
                self.mmp_data = json.load(f)
            if int(self.index.ntotal) != len(self.mmp_data):
                raise ValueError(
                    "FAISS/MMP row mismatch: "
                    f"{self.index.ntotal} vectors vs {len(self.mmp_data)} rows"
                )
            for row_index, mmp in enumerate(self.mmp_data):
                target_id = mmp.get("target_chembl_id", mmp.get("property"))
                if isinstance(target_id, str) and target_id:
                    self._target_rows.setdefault(target_id, []).append(row_index)
            if self.require_available:
                required_targets = {
                    spec["target_chembl_id"] for spec in FORMAL_TASK_TARGETS.values()
                }
                missing_targets = sorted(required_targets.difference(self._target_rows))
                if missing_targets:
                    raise RAGUnavailableError(
                        "required formal RAG targets have no indexed rows: "
                        + ", ".join(missing_targets)
                    )
            self.enabled = True
            logger.info(
                "RAG loaded: %d MMP entries, FAISS index with %d vectors",
                len(self.mmp_data), self.index.ntotal
            )
        except ImportError as error:
            if self.require_available:
                raise RAGUnavailableError(
                    "faiss is unavailable for required formal RAG"
                ) from error
            logger.warning("faiss not installed. RAG disabled. Install: pip install faiss-cpu")
        except Exception as e:
            if self.require_available:
                if isinstance(e, RAGUnavailableError):
                    raise
                raise RAGUnavailableError(
                    f"failed to load required formal RAG assets: {e}"
                ) from e
            logger.warning("Failed to load RAG index: %s", e)

    def retrieve(self, query_smiles: str, target_property: str | None = None,
                 top_k: int | None = None) -> str:
        """Retrieve relevant MMP cases as formatted natural language context.

        Returns a string ready for prompt injection. Returns a benign message
        if RAG is not available.
        """
        if not self.enabled:
            if self.require_available:
                raise RAGUnavailableError("required formal RAG is not enabled")
            return "No reference cases available."

        k = top_k or self.top_k
        fp = compute_morgan_fp(query_smiles)
        if fp is None:
            return "No valid molecule for retrieval."

        # Resolve an explicit formal task mapping.  Formal runs never fill a
        # target-specific query with unrelated targets when no match exists.
        property_key = _TARGET_PROPERTY_ALIASES.get(
            target_property,
            _TARGET_PROPERTY_ALIASES.get(
                str(target_property).lower() if target_property else "",
                target_property,
            ),
        )

        # Search a target-only FAISS sub-index.  Filtering the global top-N
        # would miss valid target rows whenever unrelated rows dominate those
        # N neighbours.
        query_vec = fp.reshape(1, -1)
        if property_key:
            target_index = self._get_target_index(str(property_key))
            if target_index is None:
                if self.require_available:
                    raise RAGUnavailableError(
                        "required target-specific RAG rows are unavailable for "
                        f"{property_key}"
                    )
                if not self.allow_generic_fallback:
                    return (
                        "No target-specific matched molecular pair cases "
                        f"available for {property_key}."
                    )
                n_search = min(k, self.index.ntotal)
                _distances, indices = self.index.search(query_vec, n_search)
                global_indices = indices[0]
            else:
                subindex, global_row_ids = target_index
                n_search = min(max(k * 3, k), len(global_row_ids))
                _distances, local_indices = subindex.search(query_vec, n_search)
                global_indices = [
                    global_row_ids[int(local_idx)]
                    for local_idx in local_indices[0]
                    if local_idx >= 0
                ]
        elif self.allow_generic_fallback:
            n_search = min(k, self.index.ntotal)
            _distances, indices = self.index.search(query_vec, n_search)
            global_indices = indices[0]
        else:
            if self.require_available:
                raise RAGUnavailableError(
                    f"no formal target mapping for RAG query {target_property!r}"
                )
            return "No explicit target mapping is configured for this RAG query."

        results = []
        seen_pairs: set[tuple[str, str, str]] = set()
        for idx in global_indices:
            if idx < 0 or idx >= len(self.mmp_data):
                continue
            mmp = self.mmp_data[idx]
            row_target = mmp.get("target_chembl_id", mmp.get("property"))
            if property_key and row_target != property_key:
                continue
            key = (
                str(row_target),
                str(mmp.get("source_smiles")),
                str(mmp.get("target_smiles")),
            )
            if key in seen_pairs:
                continue
            seen_pairs.add(key)
            results.append(mmp)
            if len(results) >= k:
                break

        return format_mmp_context(
            results,
            # Formal configurations have target-specific, identity-bound RAG
            # assets.  Their prompts use the structured formatter so raw
            # property/transformation/effect prose cannot introduce an
            # unregistered optimization objective.
            formal_safe=self.require_available,
        )

    def _get_target_index(self, target_id: str):
        cached = self._target_indices.get(target_id)
        if cached is not None:
            return cached
        row_ids = self._target_rows.get(target_id, [])
        if not row_ids or self.index is None or self._faiss_module is None:
            if self.require_available:
                raise RAGUnavailableError(
                    f"cannot build required target sub-index for {target_id}"
                )
            return None
        identifiers = np.asarray(row_ids, dtype=np.int64)
        try:
            vectors = self.index.reconstruct_batch(identifiers)
        except (AttributeError, TypeError):
            vectors = np.stack(
                [self.index.reconstruct(int(row_id)) for row_id in row_ids]
            )
        vectors = np.asarray(vectors, dtype=np.float32)
        if vectors.ndim != 2 or len(vectors) != len(row_ids):
            raise RAGUnavailableError(
                f"invalid reconstructed target vectors for {target_id}: "
                f"shape={vectors.shape}, expected_rows={len(row_ids)}"
            )
        target_index = self._faiss_module.IndexFlatL2(int(vectors.shape[1]))
        target_index.add(vectors)
        if int(target_index.ntotal) != len(row_ids):
            raise RAGUnavailableError(
                f"target sub-index count mismatch for {target_id}: "
                f"{target_index.ntotal} vs {len(row_ids)}"
            )
        cached = (target_index, row_ids)
        self._target_indices[target_id] = cached
        return cached
