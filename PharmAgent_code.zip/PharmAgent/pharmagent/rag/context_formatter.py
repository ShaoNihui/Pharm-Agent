"""
Format retrieved Matched Molecular Pairs as natural language context for LLM prompts.
"""

import math

from pharmagent.tools.rdkit_tools import validate_smiles


def format_mmp_context(
    mmps: list[dict], *, formal_safe: bool = False
) -> str:
    """Format a list of MMP dicts into a readable context string.

    Each MMP dict should have keys:
      source_smiles, target_smiles, transformation, property,
      source_score, target_score, effect_description
    """
    if not mmps:
        return "No relevant matched molecular pair cases found."

    parts = []
    for i, mmp in enumerate(mmps, 1):
        source_smi = mmp.get("source_smiles", "N/A")
        target_smi = mmp.get("target_smiles", "N/A")
        prop = mmp.get("property", "unknown")
        source_score = mmp.get("source_score", "N/A")
        target_score = mmp.get("target_score", "N/A")
        transform = mmp.get("transformation", "N/A")
        effect = mmp.get("effect_description", "N/A")

        if formal_safe:
            # Formal prompts must not carry free-form assay/property prose.
            # Keep only the molecule identities and the numeric target delta;
            # source rows are already bound to the target-specific retriever.
            try:
                source_canonical = validate_smiles(source_smi)
                target_canonical = validate_smiles(target_smi)
                source_value = float(source_score)
                target_value = float(target_score)
            except (TypeError, ValueError, OverflowError):
                raise ValueError(
                    "formal RAG row has invalid canonical SMILES or score"
                ) from None
            if (
                source_canonical != source_smi
                or target_canonical != target_smi
                or not math.isfinite(source_value)
                or not math.isfinite(target_value)
            ):
                raise ValueError(
                    "formal RAG row has invalid canonical SMILES or score"
                )
            delta_text = f"{target_value - source_value:+.6f}"
            part = (
                f"Case {i}:\n"
                f"- Source: {source_canonical}\n"
                f"- Target: {target_canonical}\n"
                f"- Target-score delta: {delta_text}"
            )
        else:
            part = (
                f"Case {i}: Optimizing {prop}\n"
                f"- Source: {source_smi} (score={_fmt_score(source_score)})\n"
                f"- Target: {target_smi} (score={_fmt_score(target_score)})\n"
                f"- Modification: {transform}\n"
                f"- Effect: {effect}"
            )
        parts.append(part)

    return "\n\n".join(parts)


def _fmt_score(val) -> str:
    """Format a score value for display."""
    if val is None or val == "N/A":
        return "N/A"
    try:
        return f"{float(val):.2f}"
    except (ValueError, TypeError):
        return str(val)
