"""
Offline data preparation: download ChEMBL activity data, generate Matched
Molecular Pairs (MMPs), and export to JSON format for the retriever.

This module is run once to prepare the RAG database. It requires:
  - requests
  - mmpdb (optional, for high-quality MMP extraction)
  - rdkit
"""

import csv
import gzip
import hashlib
import json
import logging
import math
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import tempfile
import time
from datetime import datetime, timezone
from typing import Any, Iterable, Mapping

from rdkit import Chem, rdBase
from rdkit.Chem import AllChem

logger = logging.getLogger(__name__)

# Official ChEMBL target records for the five formal PMO tasks.  The last two
# mappings use the established pharmacological targets of the named reference
# drugs.  They are explicit protocol choices, not fuzzy name matches.
FORMAL_TASK_TARGETS: dict[str, dict[str, str]] = {
    "gsk3b": {
        "target_chembl_id": "CHEMBL262",
        "pref_name": "Glycogen synthase kinase-3 beta",
        "target_type": "SINGLE PROTEIN",
        "organism": "Homo sapiens",
        "mapping_basis": "PMO target",
    },
    "jnk3": {
        "target_chembl_id": "CHEMBL2637",
        "pref_name": "Mitogen-activated protein kinase 10",
        "target_type": "SINGLE PROTEIN",
        "organism": "Homo sapiens",
        "mapping_basis": "PMO target (JNK3/MAPK10)",
    },
    "drd2": {
        "target_chembl_id": "CHEMBL217",
        "pref_name": "D(2) dopamine receptor",
        "target_type": "SINGLE PROTEIN",
        "organism": "Homo sapiens",
        "mapping_basis": "PMO target",
    },
    "sitagliptin_mpo": {
        "target_chembl_id": "CHEMBL284",
        "pref_name": "Dipeptidyl peptidase 4",
        "target_type": "SINGLE PROTEIN",
        "organism": "Homo sapiens",
        "mapping_basis": "reference-drug pharmacology (sitagliptin/DPP4)",
    },
    "albuterol_similarity": {
        "target_chembl_id": "CHEMBL210",
        "pref_name": "Beta-2 adrenergic receptor",
        "target_type": "SINGLE PROTEIN",
        "organism": "Homo sapiens",
        "mapping_basis": "reference-drug pharmacology (albuterol/ADRB2)",
    },
}

DEFAULT_TARGETS = {
    task: spec["target_chembl_id"] for task, spec in FORMAL_TASK_TARGETS.items()
}

CHEMBL_REST_ACTIVITY_URL = "https://www.ebi.ac.uk/chembl/api/data/activity.json"
CHEMBL_REST_TARGET_URL = "https://www.ebi.ac.uk/chembl/api/data/target/{target_id}.json"
CHEMBL_INTERFACE_ES_URL = (
    "https://www.ebi.ac.uk/chembl/interface_api/es_proxy/es_data/get_es_data"
)
CHEMBL_ACTIVITY_INDEX = "chembl_activity"
CHEMBL_ASSAY_INDEX = "chembl_assay"
CHEMBL_STANDARD_TYPES = ("IC50", "Ki", "EC50")
_RETRYABLE_HTTP_STATUS = {429, 500, 502, 503, 504}
STRICT_MMP_SCHEMA_VERSION = 2
PINNED_MMPDB_VERSION = "3.1.4"
PINNED_MMPDB_RDKIT_VERSION = "2024.09.6"
STRICT_ACTIVITY_REQUIRED_FIELDS = {
    "assay_chembl_id",
    "canonical_smiles",
    "molecule_chembl_id",
    "standard_relation",
    "standard_type",
    "standard_units",
    "standard_value",
    "target_chembl_id",
}


class ChemblDownloadError(RuntimeError):
    """Raised when official ChEMBL data could not be downloaded completely."""


def _request_json(session, method: str, url: str, *, attempts: int,
                  backoff_seconds: float, timeout_seconds: float,
                  **kwargs) -> dict[str, Any]:
    """Request JSON with bounded retries for transient network/server errors."""
    last_error: Exception | None = None
    for attempt in range(attempts):
        try:
            response = session.request(
                method,
                url,
                timeout=timeout_seconds,
                headers={
                    "Accept": "application/json",
                    "User-Agent": "PharmAgent-MedChem-RAG/1.0",
                },
                **kwargs,
            )
            if response.status_code in _RETRYABLE_HTTP_STATUS:
                raise ChemblDownloadError(
                    f"HTTP {response.status_code} from {url} "
                    f"(content-type={response.headers.get('content-type', 'unknown')})"
                )
            response.raise_for_status()
            payload = response.json()
            if not isinstance(payload, dict):
                raise ChemblDownloadError(
                    f"Expected a JSON object from {url}, got {type(payload).__name__}"
                )
            return payload
        except (ChemblDownloadError, ValueError, OSError) as exc:
            last_error = exc
            # HTTP 4xx errors raised by requests are not transient.  Avoid hiding
            # malformed queries or permission failures behind repeated retries.
            status = getattr(getattr(exc, "response", None), "status_code", None)
            if status is not None and status not in _RETRYABLE_HTTP_STATUS:
                break
            if attempt + 1 < attempts:
                delay = backoff_seconds * (2 ** attempt)
                logger.warning(
                    "ChEMBL request failed (%s); retrying in %.1fs (%d/%d)",
                    exc, delay, attempt + 2, attempts,
                )
                time.sleep(delay)

    raise ChemblDownloadError(
        f"ChEMBL request failed after {attempts} attempt(s): {last_error}"
    ) from last_error


def _normalise_activity_with_reason(
    raw: Mapping[str, Any], target_id: str, *, require_confidence_score: bool = True
) -> tuple[dict | None, str | None]:
    """Validate one exact, assay-identifiable ChEMBL activity.

    Strict MMP effects are only comparable inside the same target, assay,
    endpoint, unit, and equality relation.  Missing provenance therefore fails
    closed instead of being silently pooled.
    """
    smi = raw.get("canonical_smiles")
    standard_type = raw.get("standard_type")
    units = raw.get("standard_units")
    relation = raw.get("standard_relation")
    assay_id = raw.get("assay_chembl_id")
    if not smi:
        return None, "missing_smiles"
    if standard_type not in CHEMBL_STANDARD_TYPES:
        return None, "unsupported_standard_type"
    if units != "nM":
        return None, "non_nm_units"
    if relation != "=":
        return None, "non_exact_relation"
    if not isinstance(assay_id, str) or not assay_id.strip():
        return None, "missing_assay_chembl_id"
    mol = Chem.MolFromSmiles(str(smi))
    if mol is None:
        return None, "invalid_smiles"
    canonical_smiles = Chem.MolToSmiles(mol, canonical=True, isomericSmiles=True)
    # The official mmpdb fragmenter applies a salt remover.  Excluding
    # disconnected inputs here keeps the identifier-to-structure mapping exact
    # and auditable rather than allowing an implicit structure change.
    if "." in canonical_smiles:
        return None, "multi_component_structure"
    try:
        value = float(raw.get("standard_value"))
    except (TypeError, ValueError):
        return None, "non_numeric_standard_value"
    if not math.isfinite(value) or value <= 0:
        return None, "nonpositive_or_nonfinite_standard_value"
    validity_comment = raw.get("data_validity_comment")
    if validity_comment not in (None, ""):
        return None, "data_validity_comment_present"
    potential_duplicate = raw.get("potential_duplicate")
    if potential_duplicate not in (None, 0, "0", False):
        return None, "potential_duplicate"

    pchembl_value = raw.get("pchembl_value")
    try:
        pchembl_value = (
            float(pchembl_value) if pchembl_value not in (None, "") else None
        )
    except (TypeError, ValueError):
        pchembl_value = None
    if pchembl_value is not None and not math.isfinite(pchembl_value):
        pchembl_value = None

    confidence_score = raw.get("confidence_score")
    try:
        confidence_score = (
            int(confidence_score) if confidence_score not in (None, "") else None
        )
    except (TypeError, ValueError):
        confidence_score = None
    if require_confidence_score and confidence_score != 9:
        return None, "confidence_score_not_9"

    return {
        "activity_id": raw.get("activity_id"),
        "molecule_chembl_id": raw.get("molecule_chembl_id"),
        "canonical_smiles": canonical_smiles,
        "target_chembl_id": target_id,
        "assay_chembl_id": assay_id.strip(),
        "assay_type": raw.get("assay_type"),
        "bao_label": raw.get("bao_label"),
        "confidence_score": confidence_score,
        "relationship_type": raw.get("relationship_type"),
        "standard_type": standard_type,
        "standard_value": value,
        "standard_units": units,
        "standard_relation": relation,
        "pchembl_value": pchembl_value,
        "data_validity_comment": validity_comment,
        "potential_duplicate": potential_duplicate,
    }, None


def _normalise_activity(raw: dict[str, Any], target_id: str) -> dict | None:
    """Compatibility wrapper returning only the normalized record."""
    item, _reason = _normalise_activity_with_reason(raw, target_id)
    return item


def _record_filter_result(
    audit: dict[str, Any] | None, reason: str | None
) -> None:
    if audit is None:
        return
    audit["raw_records_seen"] = int(audit.get("raw_records_seen", 0)) + 1
    if reason is None:
        audit["accepted_records"] = int(audit.get("accepted_records", 0)) + 1
        return
    rejected = audit.setdefault("client_rejections", {})
    rejected[reason] = int(rejected.get(reason, 0)) + 1


def _validate_target_metadata(
    session: Any,
    target_ids: Iterable[str],
    *,
    attempts: int,
    backoff_seconds: float,
    timeout_seconds: float,
) -> dict[str, dict[str, Any]]:
    """Resolve and verify formal target IDs against ChEMBL's target endpoint."""
    expected_by_id = {
        spec["target_chembl_id"]: {**spec, "task": task}
        for task, spec in FORMAL_TASK_TARGETS.items()
    }
    resolved: dict[str, dict[str, Any]] = {}
    for target_id in target_ids:
        expected = expected_by_id.get(target_id)
        if expected is None:
            raise ChemblDownloadError(
                f"target {target_id} is not in the frozen formal task mapping"
            )
        payload = _request_json(
            session,
            "GET",
            CHEMBL_REST_TARGET_URL.format(target_id=target_id),
            attempts=attempts,
            backoff_seconds=backoff_seconds,
            timeout_seconds=timeout_seconds,
        )
        observed = {
            "target_chembl_id": payload.get("target_chembl_id"),
            "pref_name": payload.get("pref_name"),
            "target_type": payload.get("target_type"),
            "organism": payload.get("organism"),
        }
        for field in observed:
            if observed[field] != expected[field]:
                raise ChemblDownloadError(
                    f"ChEMBL target metadata mismatch for {target_id}: "
                    f"{field} expected {expected[field]!r}, observed "
                    f"{observed[field]!r}"
                )
        resolved[target_id] = {
            **observed,
            "task": expected["task"],
            "mapping_basis": expected["mapping_basis"],
            "source_url": CHEMBL_REST_TARGET_URL.format(target_id=target_id),
        }
    return resolved


def _fetch_target_rest(session, target_id: str, max_records: int, page_size: int,
                       attempts: int, backoff_seconds: float,
                       timeout_seconds: float,
                       audit: dict[str, Any] | None = None
                       ) -> tuple[list[dict], set[str]]:
    """Fetch one target through the documented ChEMBL REST API."""
    accepted: list[dict] = []
    offset = 0
    if audit is not None:
        audit["raw_scan_window_limit"] = max_records
    while offset < max_records:
        limit = min(page_size, max_records - offset)
        payload = _request_json(
            session,
            "GET",
            CHEMBL_REST_ACTIVITY_URL,
            params={
                "target_chembl_id": target_id,
                "standard_type__in": ",".join(CHEMBL_STANDARD_TYPES),
                "standard_units": "nM",
                "standard_relation": "=",
                "standard_value__isnull": "false",
                "canonical_smiles__isnull": "false",
                "assay_chembl_id__isnull": "false",
                "limit": limit,
                "offset": offset,
            },
            attempts=attempts,
            backoff_seconds=backoff_seconds,
            timeout_seconds=timeout_seconds,
        )
        rows = payload.get("activities")
        if not isinstance(rows, list):
            raise ChemblDownloadError(
                "ChEMBL REST response is missing the 'activities' list"
            )
        for raw in rows:
            if isinstance(raw, dict):
                item, reason = _normalise_activity_with_reason(
                    raw, target_id, require_confidence_score=False
                )
                _record_filter_result(audit, reason)
                if item is not None:
                    accepted.append(item)
        page_meta = payload.get("page_meta") or {}
        if audit is not None and page_meta.get("total_count") is not None:
            audit["server_matching_total"] = page_meta.get("total_count")
        if not rows or not page_meta.get("next"):
            break
        offset += len(rows)
    if audit is not None:
        audit["raw_records_scanned"] = int(audit.get("raw_records_seen", 0))
        total = audit.get("server_matching_total")
        truncated = isinstance(total, int) and total > audit["raw_records_scanned"]
        audit["raw_scan_window_truncated"] = truncated
        audit["truncation_reason"] = (
            "max_per_target_raw_scan_window" if truncated else None
        )
        audit["accepted_records_not_capped"] = True
    return accepted, set()


def _fetch_target_interface(session, target_id: str, max_records: int,
                            page_size: int, attempts: int,
                            backoff_seconds: float,
                            timeout_seconds: float,
                            audit: dict[str, Any] | None = None
                            ) -> tuple[list[dict], set[str]]:
    """Fetch one target through ChEMBL's official web-interface ES proxy."""
    accepted: list[dict] = []
    release_indices: set[str] = set()
    offset = 0
    if audit is not None:
        audit["raw_scan_window_limit"] = max_records
    source_fields = [
        "activity_id",
        "assay_chembl_id",
        "assay_type",
        "bao_label",
        "molecule_chembl_id",
        "canonical_smiles",
        "confidence_score",
        "data_validity_comment",
        "pchembl_value",
        "potential_duplicate",
        "target_chembl_id",
        "standard_relation",
        "standard_type",
        "standard_value",
        "standard_units",
    ]
    total_value: int | None = None
    while offset < max_records:
        query = {
            "from": offset,
            "size": min(page_size, max_records - offset),
            "track_total_hits": True,
            "_source": source_fields,
            "sort": [{"activity_id": {"order": "asc"}}],
            "query": {
                "bool": {
                    "filter": [
                        {"term": {"target_chembl_id": target_id}},
                        {"terms": {"standard_type": list(CHEMBL_STANDARD_TYPES)}},
                        {"term": {"standard_units": "nM"}},
                        {"term": {"standard_relation": "="}},
                        {"exists": {"field": "standard_value"}},
                        {"exists": {"field": "canonical_smiles"}},
                        {"exists": {"field": "assay_chembl_id"}},
                    ]
                }
            },
        }
        payload = _request_json(
            session,
            "POST",
            CHEMBL_INTERFACE_ES_URL,
            data={
                "index_name": CHEMBL_ACTIVITY_INDEX,
                "es_query": json.dumps(query, separators=(",", ":")),
            },
            attempts=attempts,
            backoff_seconds=backoff_seconds,
            timeout_seconds=timeout_seconds,
        )
        es_response = payload.get("es_response")
        if not isinstance(es_response, dict):
            raise ChemblDownloadError(
                "ChEMBL interface response is missing the 'es_response' object"
            )
        shards = es_response.get("_shards") or {}
        if shards.get("failed", 0):
            raise ChemblDownloadError(
                f"ChEMBL interface reported {shards['failed']} failed shard(s)"
            )
        hits_obj = es_response.get("hits") or {}
        hits = hits_obj.get("hits")
        if not isinstance(hits, list):
            raise ChemblDownloadError(
                "ChEMBL interface response is missing the hits list"
            )
        for hit in hits:
            if not isinstance(hit, dict):
                continue
            release_index = hit.get("_index")
            if release_index:
                release_indices.add(str(release_index))
            raw = hit.get("_source")
            if isinstance(raw, dict):
                item, reason = _normalise_activity_with_reason(
                    raw, target_id, require_confidence_score=False
                )
                _record_filter_result(audit, reason)
                if item is not None:
                    accepted.append(item)
        offset += len(hits)
        total = hits_obj.get("total", {})
        total_value = total.get("value") if isinstance(total, dict) else total
        if audit is not None and isinstance(total_value, int):
            audit["server_matching_total"] = total_value
        if not hits or (isinstance(total_value, int) and offset >= total_value):
            break
        if offset >= 10000:
            # The interface has the standard Elasticsearch result-window cap.
            # Record this truncation boundary in the source metadata below.
            break
    if audit is not None:
        audit["raw_records_scanned"] = int(audit.get("raw_records_seen", 0))
        truncated = (
            isinstance(total_value, int)
            and total_value > audit["raw_records_scanned"]
        )
        audit["raw_scan_window_truncated"] = truncated
        if truncated and offset >= 10000:
            audit["truncation_reason"] = "elasticsearch_10000_result_window"
        elif truncated:
            audit["truncation_reason"] = "max_per_target_raw_scan_window"
        else:
            audit["truncation_reason"] = None
        audit["accepted_records_not_capped"] = True
    return accepted, release_indices


def _fetch_assay_metadata_interface(
    session: Any,
    assay_chembl_ids: Iterable[str],
    *,
    attempts: int,
    backoff_seconds: float,
    timeout_seconds: float,
    chunk_size: int = 500,
) -> tuple[dict[str, dict[str, Any]], set[str]]:
    """Resolve assay confidence from the official ChEMBL assay index.

    ChEMBL activity records do not expose ``confidence_score``.  A separate
    assay-index lookup is therefore required to enforce score 9 (direct
    single-protein target assignment) without inferring assay provenance.
    """
    identifiers = sorted({str(value) for value in assay_chembl_ids if value})
    if not identifiers:
        raise ChemblDownloadError("no assay identifiers were available for validation")
    if chunk_size <= 0 or chunk_size > 1000:
        raise ValueError("assay metadata chunk_size must be in [1, 1000]")

    resolved: dict[str, dict[str, Any]] = {}
    release_indices: set[str] = set()
    for start in range(0, len(identifiers), chunk_size):
        chunk = identifiers[start:start + chunk_size]
        query = {
            "from": 0,
            "size": len(chunk),
            "track_total_hits": True,
            "_source": [
                "assay_chembl_id",
                "assay_type",
                "confidence_score",
                "relationship_type",
                "target_chembl_id",
            ],
            "sort": [{"assay_chembl_id": {"order": "asc"}}],
            "query": {"terms": {"assay_chembl_id": chunk}},
        }
        payload = _request_json(
            session,
            "POST",
            CHEMBL_INTERFACE_ES_URL,
            data={
                "index_name": CHEMBL_ASSAY_INDEX,
                "es_query": json.dumps(query, separators=(",", ":")),
            },
            attempts=attempts,
            backoff_seconds=backoff_seconds,
            timeout_seconds=timeout_seconds,
        )
        es_response = payload.get("es_response")
        if not isinstance(es_response, dict):
            raise ChemblDownloadError(
                "ChEMBL assay response is missing the 'es_response' object"
            )
        shards = es_response.get("_shards") or {}
        if shards.get("failed", 0):
            raise ChemblDownloadError(
                f"ChEMBL assay index reported {shards['failed']} failed shard(s)"
            )
        hits_obj = es_response.get("hits") or {}
        hits = hits_obj.get("hits")
        if not isinstance(hits, list):
            raise ChemblDownloadError("ChEMBL assay response is missing its hits list")
        total = hits_obj.get("total", {})
        total_value = total.get("value") if isinstance(total, dict) else total
        if total_value != len(chunk) or len(hits) != len(chunk):
            raise ChemblDownloadError(
                "ChEMBL assay metadata lookup was incomplete: "
                f"requested={len(chunk)}, reported={total_value}, returned={len(hits)}"
            )
        for hit in hits:
            if not isinstance(hit, dict) or not isinstance(hit.get("_source"), dict):
                raise ChemblDownloadError("malformed ChEMBL assay metadata hit")
            release_index = hit.get("_index")
            if release_index:
                release_indices.add(str(release_index))
            row = hit["_source"]
            assay_id = row.get("assay_chembl_id")
            if assay_id not in chunk or assay_id in resolved:
                raise ChemblDownloadError(
                    f"unexpected or duplicate assay metadata row: {assay_id!r}"
                )
            try:
                confidence_score = int(row.get("confidence_score"))
            except (TypeError, ValueError) as error:
                raise ChemblDownloadError(
                    f"assay {assay_id} has no valid confidence score"
                ) from error
            resolved[assay_id] = {
                "assay_chembl_id": assay_id,
                "assay_type": row.get("assay_type"),
                "confidence_score": confidence_score,
                "relationship_type": row.get("relationship_type"),
                "target_chembl_id": row.get("target_chembl_id"),
            }

    missing = sorted(set(identifiers).difference(resolved))
    if missing:
        raise ChemblDownloadError(
            "ChEMBL assay metadata is incomplete for: " + ", ".join(missing[:10])
        )
    return resolved, release_indices


def _write_json_atomic(path: str, value: Any, *, indent: int = 2) -> str:
    """Atomically write JSON and return its SHA-256 digest."""
    directory = os.path.dirname(path) or "."
    os.makedirs(directory, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(prefix=".pharmagent-", suffix=".json", dir=directory)
    try:
        with os.fdopen(fd, "w") as handle:
            json.dump(value, handle, indent=indent)
            handle.write("\n")
        with open(tmp_path, "rb") as handle:
            digest = hashlib.sha256(handle.read()).hexdigest()
        os.replace(tmp_path, path)
        return digest
    except Exception:
        try:
            os.unlink(tmp_path)
        except FileNotFoundError:
            pass
        raise


def download_chembl_activities(target_chembl_ids: list[str] | None = None,
                                output_dir: str = "data/matched_pairs",
                                max_per_target: int = 5000,
                                backend: str = "auto",
                                page_size: int = 500,
                                attempts: int = 3,
                                backoff_seconds: float = 1.0,
                                timeout_seconds: float = 30.0,
                                validate_targets: bool = True) -> list[dict]:
    """Download bioactivity data from ChEMBL for specified targets.

    Returns list of activity dicts with keys:
      molecule_chembl_id, canonical_smiles, target_chembl_id,
      assay_chembl_id, standard_relation, standard_type, standard_value,
      standard_units, and available assay-quality metadata.
    """
    if target_chembl_ids is None:
        target_chembl_ids = list(DEFAULT_TARGETS.values())
    if backend not in {"auto", "rest", "interface"}:
        raise ValueError("backend must be one of: auto, rest, interface")
    if not target_chembl_ids:
        raise ValueError("target_chembl_ids must not be empty")
    if max_per_target <= 0 or page_size <= 0 or attempts <= 0:
        raise ValueError("max_per_target, page_size, and attempts must be positive")
    if max_per_target > 10000:
        raise ValueError("max_per_target cannot exceed the audited 10,000-row window")

    import requests

    os.makedirs(output_dir, exist_ok=True)
    session = requests.Session()

    if validate_targets:
        target_metadata = _validate_target_metadata(
            session,
            target_chembl_ids,
            attempts=attempts,
            backoff_seconds=backoff_seconds,
            timeout_seconds=timeout_seconds,
        )
    else:
        target_metadata = {}

    def fetch_all(
        selected_backend: str,
    ) -> tuple[list[dict], dict[str, int], set[str], dict[str, dict[str, Any]]]:
        fetcher = (
            _fetch_target_rest if selected_backend == "rest"
            else _fetch_target_interface
        )
        records: list[dict] = []
        counts: dict[str, int] = {}
        indices: set[str] = set()
        filtering: dict[str, dict[str, Any]] = {}
        for target_id in target_chembl_ids:
            logger.info(
                "Downloading official ChEMBL activities for %s via %s...",
                target_id, selected_backend,
            )
            target_audit: dict[str, Any] = {}
            target_records, target_indices = fetcher(
                session,
                target_id,
                max_per_target,
                min(page_size, 1000),
                attempts,
                backoff_seconds,
                timeout_seconds,
                target_audit,
            )
            if not target_records:
                raise ChemblDownloadError(
                    f"Official ChEMBL returned no usable activities for {target_id}"
                )
            records.extend(target_records)
            counts[target_id] = len(target_records)
            filtering[target_id] = target_audit
            indices.update(target_indices)
            logger.info("  Downloaded %d activities for %s", len(target_records), target_id)
        return records, counts, indices, filtering

    selected_backend = backend
    if backend == "auto":
        selected_backend = "rest"
        try:
            all_activities, counts, release_indices, filtering = fetch_all("rest")
        except ChemblDownloadError as exc:
            logger.warning(
                "Documented ChEMBL REST API is unavailable (%s). "
                "Switching to the official ChEMBL web-interface data API.",
                exc,
            )
            selected_backend = "interface"
            all_activities, counts, release_indices, filtering = fetch_all("interface")
    else:
        all_activities, counts, release_indices, filtering = fetch_all(selected_backend)

    # Activity rows do not include the assay-to-target confidence score.  Join
    # every observed assay to the official ChEMBL assay index, then retain only
    # score-9 direct single-protein assignments to the requested target.
    assay_metadata, assay_release_indices = _fetch_assay_metadata_interface(
        session,
        (row["assay_chembl_id"] for row in all_activities),
        attempts=attempts,
        backoff_seconds=backoff_seconds,
        timeout_seconds=timeout_seconds,
    )
    confidence_filtered: list[dict[str, Any]] = []
    counts = {target_id: 0 for target_id in target_chembl_ids}
    for target_id in target_chembl_ids:
        audit = filtering[target_id]
        audit["accepted_before_assay_confidence_filter"] = int(
            audit.pop("accepted_records", 0)
        )
        audit["assay_confidence_rejections"] = {}
    for row in all_activities:
        target_id = row["target_chembl_id"]
        audit = filtering[target_id]
        assay = assay_metadata[row["assay_chembl_id"]]
        if assay.get("target_chembl_id") != target_id:
            reason = "assay_target_mismatch"
        elif assay.get("confidence_score") != 9:
            reason = "confidence_score_not_9"
        else:
            reason = None
        if reason is not None:
            rejections = audit["assay_confidence_rejections"]
            rejections[reason] = int(rejections.get(reason, 0)) + 1
            continue
        enriched = {
            **row,
            "assay_type": assay.get("assay_type"),
            "confidence_score": assay["confidence_score"],
            "relationship_type": assay.get("relationship_type"),
        }
        normalized, normalized_reason = _normalise_activity_with_reason(
            enriched, target_id
        )
        if normalized is None:
            raise ChemblDownloadError(
                "confidence-enriched activity failed strict normalization: "
                f"{normalized_reason}"
            )
        confidence_filtered.append(normalized)
        counts[target_id] += 1
    all_activities = confidence_filtered
    for target_id, count in counts.items():
        filtering[target_id]["accepted_records"] = count
        if count == 0:
            raise ChemblDownloadError(
                f"no confidence-score-9 activities survived for {target_id}"
            )

    # Only publish complete data after every requested target and assay joined
    # successfully.  The assay table is a separate immutable source artifact.
    assay_rows = [assay_metadata[key] for key in sorted(assay_metadata)]
    assay_path = os.path.join(output_dir, "chembl_assays.json")
    assay_digest = _write_json_atomic(assay_path, assay_rows)
    out_path = os.path.join(output_dir, "chembl_activities.json")
    digest = _write_json_atomic(out_path, all_activities)
    manifest = {
        "schema_version": 2,
        "source": "ChEMBL",
        "source_url": (
            CHEMBL_REST_ACTIVITY_URL
            if selected_backend == "rest"
            else CHEMBL_INTERFACE_ES_URL
        ),
        "backend": selected_backend,
        "release_indices": sorted(release_indices | assay_release_indices),
        "activity_release_indices": sorted(release_indices),
        "assay_release_indices": sorted(assay_release_indices),
        "retrieved_at_utc": datetime.now(timezone.utc).isoformat(),
        "license": {
            "identifier": "CC-BY-SA-3.0",
            "url": "https://creativecommons.org/licenses/by-sa/3.0/",
            "attribution_url": "https://www.ebi.ac.uk/chembl/",
        },
        "filters": {
            "standard_type": list(CHEMBL_STANDARD_TYPES),
            "standard_units": "nM",
            "standard_relation": "=",
            "standard_value": "finite and > 0",
            "canonical_smiles": "valid RDKit molecule",
            "multi_component_structure": "excluded",
            "assay_chembl_id": "required",
            "data_validity_comment": "must be null/empty",
            "potential_duplicate": "must be false/null/0",
            "confidence_score": {
                "required_value": 9,
                "meaning": "direct single protein target assigned",
                "source": "official ChEMBL assay index",
                "definition_url": (
                    "https://chembl.gitbook.io/chembl-interface-documentation/"
                    "frequently-asked-questions/chembl-data-questions"
                ),
            },
        },
        "server_query_and_client_filter_counts": filtering,
        "target_chembl_ids": list(target_chembl_ids),
        "target_metadata": target_metadata,
        "max_per_target": max_per_target,
        "counts_by_target": counts,
        "total_records": len(all_activities),
        "activities_file": os.path.basename(out_path),
        "activities_sha256": digest,
        "assays_file": os.path.basename(assay_path),
        "assays_sha256": assay_digest,
        "total_assays_resolved": len(assay_rows),
    }
    _write_json_atomic(
        os.path.join(output_dir, "chembl_activities_manifest.json"), manifest
    )
    logger.info("Saved %d activities to %s", len(all_activities), out_path)

    return all_activities


def generate_mmps_simple(activities: list[dict],
                          output_dir: str = "data/chembl_mmp") -> list[dict]:
    """Generate matched molecular pairs using simple RDKit-based approach.

    This is a fallback when mmpdb is not available. It finds pairs of molecules
    targeting the same target with high structural similarity but different
    activity values.
    """
    os.makedirs(output_dir, exist_ok=True)

    # Group by target
    by_target: dict[str, list[dict]] = {}
    for act in activities:
        tid = act["target_chembl_id"]
        by_target.setdefault(tid, []).append(act)

    mmp_pairs = []
    counts_by_target: dict[str, int] = {}
    considered_by_target: dict[str, int] = {}

    for target_id, acts in by_target.items():
        logger.info("Generating MMPs for target %s (%d molecules)...",
                     target_id, len(acts))

        # Compute fingerprints
        fps = []
        valid_acts = []
        for act in acts:
            mol = Chem.MolFromSmiles(act["canonical_smiles"])
            if mol is None:
                continue
            fp = AllChem.GetMorganFingerprintAsBitVect(mol, radius=2, nBits=2048)
            fps.append(fp)
            valid_acts.append(act)

        # Find similar pairs with activity difference
        from rdkit import DataStructs
        from tqdm import tqdm as _tqdm
        n = len(valid_acts)
        cap = min(n, 2000)
        considered_by_target[target_id] = cap
        for i in _tqdm(range(cap), desc=f"  MMP pairs ({target_id})", leave=False):
            for j in range(i + 1, cap):
                sim = DataStructs.TanimotoSimilarity(fps[i], fps[j])
                if 0.5 < sim < 0.95:  # similar but not identical
                    val_i = valid_acts[i]["standard_value"]
                    val_j = valid_acts[j]["standard_value"]
                    if val_i > 0 and val_j > 0:
                        delta = abs(math.log10(val_i) - math.log10(val_j))
                        if delta > 0.5:  # meaningful activity difference
                            source = valid_acts[i] if val_i > val_j else valid_acts[j]
                            target = valid_acts[j] if val_i > val_j else valid_acts[i]
                            mmp_pairs.append({
                                "source_smiles": source["canonical_smiles"],
                                "target_smiles": target["canonical_smiles"],
                                "property": target_id,
                                "source_score": -math.log10(source["standard_value"] * 1e-9),
                                "target_score": -math.log10(target["standard_value"] * 1e-9),
                                "transformation": f"Similarity={sim:.2f}",
                                "effect_description": (
                                    f"Improved {source['standard_type']} from "
                                    f"{source['standard_value']:.1f} to "
                                    f"{target['standard_value']:.1f} "
                                    f"{source['standard_units']}"
                                ),
                            })

        target_count = len([p for p in mmp_pairs if p["property"] == target_id])
        counts_by_target[target_id] = target_count
        logger.info("  Generated %d MMP pairs for %s", target_count, target_id)

    # Save
    out_path = os.path.join(output_dir, "mmp_pairs.json")
    digest = _write_json_atomic(out_path, mmp_pairs)
    activities_path = os.path.join(output_dir, "chembl_activities.json")
    activities_digest = None
    if os.path.exists(activities_path):
        with open(activities_path, "rb") as handle:
            activities_digest = hashlib.sha256(handle.read()).hexdigest()
    manifest = {
        "schema_version": 1,
        "algorithm": "morgan_similarity_activity_pair_fallback",
        "strict_fragmentation_mmp": False,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "parameters": {
            "morgan_radius": 2,
            "morgan_bits": 2048,
            "similarity_exclusive_range": [0.5, 0.95],
            "minimum_absolute_log10_activity_delta": 0.5,
            "maximum_activities_considered_per_target": 2000,
        },
        "considered_activities_by_target": considered_by_target,
        "counts_by_target": counts_by_target,
        "total_pairs": len(mmp_pairs),
        "source_activities_file": os.path.basename(activities_path),
        "source_activities_sha256": activities_digest,
        "pairs_file": os.path.basename(out_path),
        "pairs_sha256": digest,
    }
    _write_json_atomic(os.path.join(output_dir, "mmp_pairs_manifest.json"), manifest)
    logger.info("Total MMP pairs: %d, saved to %s", len(mmp_pairs), out_path)

    return mmp_pairs


def _file_sha256(path: str | os.PathLike[str]) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _write_text_atomic(path: str | os.PathLike[str], text: str) -> str:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(
        prefix=".pharmagent-", suffix=destination.suffix, dir=destination.parent
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(text)
        digest = _file_sha256(temporary)
        os.replace(temporary, destination)
        return digest
    except Exception:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def _load_activity_source(
    activities: Iterable[Mapping[str, Any]] | str | os.PathLike[str],
) -> tuple[list[dict[str, Any]], Path | None, str]:
    if isinstance(activities, (str, os.PathLike)):
        source_path = Path(activities).expanduser().resolve()
        try:
            value = json.loads(source_path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as error:
            raise ValueError(f"cannot read strict activity source {source_path}") from error
        if not isinstance(value, list):
            raise ValueError("strict activity source must be a JSON list")
        rows = value
        source_sha = _file_sha256(source_path)
    else:
        source_path = None
        rows = list(activities)
        encoded = json.dumps(
            rows, sort_keys=True, separators=(",", ":"), allow_nan=False
        ).encode("utf-8")
        source_sha = hashlib.sha256(encoded).hexdigest()
    if not rows or not all(isinstance(row, dict) for row in rows):
        raise ValueError("strict activity source must contain non-empty objects")
    return rows, source_path, source_sha


def _prepare_strict_activity_groups(
    activities: Iterable[Mapping[str, Any]],
) -> tuple[
    dict[str, str],
    dict[str, dict[tuple[str, str, str, str], dict[str, Any]]],
    dict[str, Any],
]:
    """Aggregate duplicate measurements within an exactly comparable assay."""
    measurements: dict[
        tuple[str, str, str, str], dict[str, list[dict[str, Any]]]
    ] = {}
    rejected: dict[str, int] = {}
    accepted = 0
    input_count = 0
    molecule_ids_by_smiles: dict[str, set[str]] = {}

    for raw in activities:
        input_count += 1
        missing = STRICT_ACTIVITY_REQUIRED_FIELDS.difference(raw)
        if missing:
            raise ValueError(
                "strict MMP activity is missing provenance fields: "
                + ", ".join(sorted(missing))
            )
        target_id = str(raw["target_chembl_id"])
        item, reason = _normalise_activity_with_reason(raw, target_id)
        if item is None:
            assert reason is not None
            rejected[reason] = rejected.get(reason, 0) + 1
            continue
        accepted += 1
        smiles = item["canonical_smiles"]
        group = (
            target_id,
            item["assay_chembl_id"],
            item["standard_type"],
            item["standard_units"],
        )
        measurements.setdefault(group, {}).setdefault(smiles, []).append(item)
        molecule_id = item.get("molecule_chembl_id")
        if molecule_id:
            molecule_ids_by_smiles.setdefault(smiles, set()).add(str(molecule_id))

    if not measurements:
        raise ValueError("no exactly comparable activities survived strict filtering")

    smiles_values = sorted(
        {smiles for group_rows in measurements.values() for smiles in group_rows}
    )
    smiles_to_id: dict[str, str] = {}
    observed_ids: set[str] = set()
    for smiles in smiles_values:
        compound_id = "MMP_" + hashlib.sha256(smiles.encode("utf-8")).hexdigest()[:20]
        if compound_id in observed_ids:
            raise RuntimeError("truncated compound identifier hash collision")
        observed_ids.add(compound_id)
        smiles_to_id[smiles] = compound_id

    values_by_compound: dict[
        str, dict[tuple[str, str, str, str], dict[str, Any]]
    ] = {compound_id: {} for compound_id in smiles_to_id.values()}
    duplicate_measurements_collapsed = 0
    for group, group_rows in measurements.items():
        for smiles, rows in group_rows.items():
            pactivities = [
                -math.log10(float(row["standard_value"]) * 1e-9) for row in rows
            ]
            duplicate_measurements_collapsed += len(rows) - 1
            values_by_compound[smiles_to_id[smiles]][group] = {
                "pactivity": float(statistics.median(pactivities)),
                "measurement_count": len(rows),
                "activity_ids": sorted(
                    str(row["activity_id"])
                    for row in rows
                    if row.get("activity_id") is not None
                ),
                "molecule_chembl_ids": sorted(molecule_ids_by_smiles.get(smiles, set())),
                "pchembl_values_available": sum(
                    row.get("pchembl_value") is not None for row in rows
                ),
            }

    audit = {
        "input_activity_records": input_count,
        "accepted_activity_records": accepted,
        "builder_rejections": dict(sorted(rejected.items())),
        "unique_canonical_structures": len(smiles_to_id),
        "comparable_assay_endpoint_groups": len(measurements),
        "duplicate_measurements_collapsed_with_median": duplicate_measurements_collapsed,
    }
    return smiles_to_id, values_by_compound, audit


def _resolve_mmpdb_executable(value: str | os.PathLike[str]) -> Path:
    raw = os.fspath(value)
    candidate = shutil.which(raw)
    path = Path(candidate or raw).expanduser().resolve()
    if not path.is_file() or not os.access(path, os.X_OK):
        raise FileNotFoundError(
            "mmpdb executable is unavailable; use an isolated mmpdb 3.1.4 "
            "environment so the formal PyTDC/RDKit environment is not changed"
        )
    return path


def _tool_versions(mmpdb_executable: Path) -> dict[str, str]:
    version_result = subprocess.run(
        [str(mmpdb_executable), "--version"],
        check=True,
        capture_output=True,
        text=True,
    )
    version_text = version_result.stdout.strip()
    if version_text != f"mmpdb, version {PINNED_MMPDB_VERSION}":
        raise RuntimeError(
            f"strict builder requires mmpdb {PINNED_MMPDB_VERSION}, "
            f"observed {version_text!r}"
        )
    builder_python = mmpdb_executable.with_name("python")
    rdkit_result = subprocess.run(
        [
            str(builder_python),
            "-c",
            "from rdkit import rdBase; print(rdBase.rdkitVersion)",
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    rdkit_version = rdkit_result.stdout.strip()
    if rdkit_version != PINNED_MMPDB_RDKIT_VERSION:
        raise RuntimeError(
            "strict builder requires isolated RDKit "
            f"{PINNED_MMPDB_RDKIT_VERSION}, observed {rdkit_version!r}"
        )
    return {
        "mmpdb": PINNED_MMPDB_VERSION,
        "rdkit": rdkit_version,
    }


def _reverse_transform(transformation: str) -> str:
    pieces = transformation.split(">>")
    if len(pieces) != 2 or not all(pieces):
        raise ValueError(f"invalid mmpdb transformation: {transformation!r}")
    return f"{pieces[1]}>>{pieces[0]}"


def _fragment_heavy_atom_count(smiles: str, *, label: str) -> int:
    """Count non-hydrogen, non-dummy atoms in an mmpdb fragment."""
    # Some valid mmpdb attachment fragments contain an explicit hydrogen next
    # to a dummy atom.  RDKit warns while preserving that atom; H and dummy
    # atoms are excluded below, so silence only this parser chatter.
    with rdBase.BlockLogs():
        molecule = Chem.MolFromSmiles(smiles)
    if molecule is None:
        raise ValueError(f"mmpdb emitted an invalid {label} fragment: {smiles!r}")
    return sum(atom.GetAtomicNum() > 1 for atom in molecule.GetAtoms())


def _structural_candidate_rank(candidate: Mapping[str, str]) -> tuple:
    """Chemical-size rank for competing cuts of one unordered molecule pair."""
    pieces = candidate["transformation"].split(">>")
    if len(pieces) != 2 or not all(pieces):
        raise ValueError(
            f"invalid mmpdb transformation: {candidate['transformation']!r}"
        )
    left_heavies = _fragment_heavy_atom_count(pieces[0], label="left variable")
    right_heavies = _fragment_heavy_atom_count(pieces[1], label="right variable")
    constant_heavies = _fragment_heavy_atom_count(
        candidate["constant_smiles"], label="constant"
    )
    return (
        max(left_heavies, right_heavies),
        left_heavies + right_heavies,
        -constant_heavies,
        candidate["transformation"],
        candidate["constant_smiles"],
    )


def _read_mmpdb_structural_pairs(
    path: Path,
    known_compound_ids: set[str],
) -> tuple[list[dict[str, str]], dict[str, int]]:
    """Load one deterministic minimal transformation per unordered pair."""
    best_by_pair: dict[tuple[str, str], dict[str, str]] = {}
    raw_rows = 0
    with gzip.open(path, "rt", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle, delimiter="\t")
        columns = ("SMILES1", "SMILES2", "id1", "id2", "V1>>V2", "C")
        for values in reader:
            if tuple(values) == columns:
                continue
            if len(values) != len(columns):
                raise ValueError(f"unexpected mmpdb CSV row: {values!r}")
            row = dict(zip(columns, values))
            raw_rows += 1
            id1 = row["id1"]
            id2 = row["id2"]
            if id1 not in known_compound_ids or id2 not in known_compound_ids:
                raise ValueError("mmpdb output references an unknown compound identifier")
            if id1 == id2:
                continue
            if id1 > id2:
                id1, id2 = id2, id1
                transformation = _reverse_transform(row["V1>>V2"])
            else:
                transformation = row["V1>>V2"]
            candidate = {
                "id1": id1,
                "id2": id2,
                "transformation": transformation,
                "constant_smiles": row["C"],
            }
            key = (id1, id2)
            current = best_by_pair.get(key)
            rank = _structural_candidate_rank(candidate)
            if current is None or rank < _structural_candidate_rank(current):
                best_by_pair[key] = candidate
    return [best_by_pair[key] for key in sorted(best_by_pair)], {
        "mmpdb_raw_pair_rows": raw_rows,
        "unique_unordered_structural_pairs": len(best_by_pair),
        "duplicate_structural_rows_removed": raw_rows - len(best_by_pair),
    }


def _build_strict_pair_records(
    structural_pairs: Iterable[Mapping[str, str]],
    *,
    smiles_to_id: Mapping[str, str],
    values_by_compound: Mapping[
        str, Mapping[tuple[str, str, str, str], Mapping[str, Any]]
    ],
    minimum_delta: float,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    id_to_smiles = {compound_id: smiles for smiles, compound_id in smiles_to_id.items()}
    endpoint_candidates: list[dict[str, Any]] = []
    comparable_assay_evidence = 0
    below_delta = 0

    for pair in structural_pairs:
        id1 = pair["id1"]
        id2 = pair["id2"]
        groups1 = values_by_compound[id1]
        groups2 = values_by_compound[id2]
        shared_groups = sorted(set(groups1).intersection(groups2))
        if not shared_groups:
            continue
        by_endpoint: dict[tuple[str, str, str], list[dict[str, Any]]] = {}
        for group in shared_groups:
            target_id, assay_id, standard_type, units = group
            value1 = groups1[group]
            value2 = groups2[group]
            by_endpoint.setdefault((target_id, standard_type, units), []).append({
                "assay_chembl_id": assay_id,
                "pactivity1": float(value1["pactivity"]),
                "pactivity2": float(value2["pactivity"]),
                "measurement_count1": int(value1["measurement_count"]),
                "measurement_count2": int(value2["measurement_count"]),
            })
            comparable_assay_evidence += 1

        for (target_id, standard_type, units), evidence in sorted(by_endpoint.items()):
            signed_deltas = [
                item["pactivity2"] - item["pactivity1"] for item in evidence
            ]
            median_signed_delta = float(statistics.median(signed_deltas))
            if abs(median_signed_delta) <= minimum_delta:
                below_delta += 1
                continue
            forward = median_signed_delta > 0
            if forward:
                source_id, target_compound_id = id1, id2
                transformation = pair["transformation"]
                source_scores = [item["pactivity1"] for item in evidence]
                target_scores = [item["pactivity2"] for item in evidence]
                source_measurements = sum(
                    item["measurement_count1"] for item in evidence
                )
                target_measurements = sum(
                    item["measurement_count2"] for item in evidence
                )
            else:
                source_id, target_compound_id = id2, id1
                transformation = _reverse_transform(pair["transformation"])
                source_scores = [item["pactivity2"] for item in evidence]
                target_scores = [item["pactivity1"] for item in evidence]
                source_measurements = sum(
                    item["measurement_count2"] for item in evidence
                )
                target_measurements = sum(
                    item["measurement_count1"] for item in evidence
                )

            source_score = float(statistics.median(source_scores))
            target_score = float(statistics.median(target_scores))
            # The effect is the median of *paired within-assay* deltas.  It is
            # not the difference between two unpaired marginal medians, which
            # can disagree in magnitude or even sign across heterogeneous
            # assay panels.
            paired_deltas = (
                signed_deltas if forward else [-value for value in signed_deltas]
            )
            delta = float(statistics.median(paired_deltas))
            if not delta > minimum_delta:
                raise RuntimeError(
                    "directed same-assay median delta does not exceed threshold"
                )
            variable_fragments = transformation.split(">>")
            source_variable_heavies = _fragment_heavy_atom_count(
                variable_fragments[0], label="source variable"
            )
            target_variable_heavies = _fragment_heavy_atom_count(
                variable_fragments[1], label="target variable"
            )
            constant_heavies = _fragment_heavy_atom_count(
                pair["constant_smiles"], label="constant"
            )
            endpoint_candidates.append({
                "schema_version": STRICT_MMP_SCHEMA_VERSION,
                "strict_fragmentation_mmp": True,
                "source_smiles": id_to_smiles[source_id],
                "target_smiles": id_to_smiles[target_compound_id],
                "property": target_id,
                "target_chembl_id": target_id,
                "standard_type": standard_type,
                "standard_units": units,
                "standard_relation": "=",
                "source_score": source_score,
                "target_score": target_score,
                "delta_pactivity": delta,
                "paired_assay_delta_pactivity": paired_deltas,
                "transformation": transformation,
                "constant_smiles": pair["constant_smiles"],
                "cut_count": transformation.split(">>", 1)[0].count("[*:"),
                "source_variable_heavy_atoms": source_variable_heavies,
                "target_variable_heavy_atoms": target_variable_heavies,
                "maximum_variable_heavy_atoms": max(
                    source_variable_heavies, target_variable_heavies
                ),
                "constant_heavy_atoms": constant_heavies,
                "assay_chembl_ids": sorted(
                    item["assay_chembl_id"] for item in evidence
                ),
                "assay_count": len(evidence),
                "source_measurement_count": source_measurements,
                "target_measurement_count": target_measurements,
                "effect_description": (
                    f"Median same-assay {standard_type} pActivity improvement "
                    f"of {delta:+.2f} across {len(evidence)} assay(s)"
                ),
            })

    # A source/target structural move gets one retrieval row per ChEMBL target.
    # If multiple endpoints support it, select the endpoint with the strongest
    # assay evidence deterministically instead of duplicating its fingerprint.
    best_by_directed_pair: dict[tuple[str, str, str], dict[str, Any]] = {}
    for candidate in endpoint_candidates:
        unordered = tuple(sorted((candidate["source_smiles"], candidate["target_smiles"])))
        key = (candidate["target_chembl_id"], *unordered)
        rank = (
            candidate["assay_count"],
            candidate["source_measurement_count"] + candidate["target_measurement_count"],
            abs(candidate["delta_pactivity"]),
            -CHEMBL_STANDARD_TYPES.index(candidate["standard_type"]),
        )
        current = best_by_directed_pair.get(key)
        if current is None:
            best_by_directed_pair[key] = candidate
            continue
        current_rank = (
            current["assay_count"],
            current["source_measurement_count"] + current["target_measurement_count"],
            abs(current["delta_pactivity"]),
            -CHEMBL_STANDARD_TYPES.index(current["standard_type"]),
        )
        if rank > current_rank:
            best_by_directed_pair[key] = candidate

    records = sorted(
        best_by_directed_pair.values(),
        key=lambda item: (
            item["target_chembl_id"],
            item["source_smiles"],
            item["target_smiles"],
            item["standard_type"],
        ),
    )
    counts_by_target: dict[str, int] = {}
    counts_by_endpoint: dict[str, int] = {}
    for row in records:
        target_id = row["target_chembl_id"]
        counts_by_target[target_id] = counts_by_target.get(target_id, 0) + 1
        endpoint = f"{target_id}:{row['standard_type']}:{row['standard_units']}"
        counts_by_endpoint[endpoint] = counts_by_endpoint.get(endpoint, 0) + 1
    audit = {
        "same_assay_pair_evidence": comparable_assay_evidence,
        "endpoint_candidates_below_minimum_delta": below_delta,
        "endpoint_candidates_passing_delta": len(endpoint_candidates),
        "cross_endpoint_duplicate_pairs_removed": (
            len(endpoint_candidates) - len(records)
        ),
        "final_unique_directed_pairs": len(records),
        "counts_by_target": dict(sorted(counts_by_target.items())),
        "counts_by_endpoint": dict(sorted(counts_by_endpoint.items())),
    }
    return records, audit


def generate_mmps_mmpdb(
    activities: Iterable[Mapping[str, Any]] | str | os.PathLike[str],
    output_dir: str = "data/matched_pairs",
    *,
    mmpdb_executable: str | os.PathLike[str] = "mmpdb",
    activities_manifest_path: str | os.PathLike[str] | None = None,
    minimum_delta: float = 0.5,
    num_jobs: int = 4,
) -> list[dict[str, Any]]:
    """Build strict single-cut MMPs from same-assay ChEMBL measurements.

    The builder is deliberately fail-closed: an activity without target,
    assay, endpoint, unit, relation, or structure provenance cannot contribute
    to a formal pair.  mmpdb runs in a separate pinned environment so its
    newer RDKit requirement cannot alter the PyTDC runtime environment.
    """
    if minimum_delta <= 0 or not math.isfinite(minimum_delta):
        raise ValueError("minimum_delta must be finite and positive")
    if num_jobs <= 0:
        raise ValueError("num_jobs must be positive")

    output = Path(output_dir).expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    rows, source_path, source_sha = _load_activity_source(activities)
    source_manifest: dict[str, Any] | None = None
    source_manifest_sha: str | None = None
    if activities_manifest_path is None and source_path is not None:
        candidate = source_path.with_name("chembl_activities_manifest.json")
        if candidate.is_file():
            activities_manifest_path = candidate
    if activities_manifest_path is not None:
        if source_path is None:
            raise ValueError(
                "an activity manifest can only bind a file-backed activity source"
            )
        manifest_path = Path(activities_manifest_path).expanduser().resolve()
        source_manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if not isinstance(source_manifest, dict):
            raise ValueError("ChEMBL activity manifest must be a JSON object")
        source_manifest_sha = _file_sha256(manifest_path)
        if source_manifest.get("activities_sha256") != source_sha:
            raise ValueError("ChEMBL activity manifest SHA does not match source data")
        if source_manifest.get("activities_file") != source_path.name:
            raise ValueError("ChEMBL activity manifest file identity does not match")
        if source_manifest.get("schema_version") != 2:
            raise ValueError("strict MMP builder requires ChEMBL activity manifest with assay metadata")
        metadata = source_manifest.get("target_metadata")
        expected_by_id = {
            spec["target_chembl_id"]: {**spec, "task": task}
            for task, spec in FORMAL_TASK_TARGETS.items()
        }
        expected_ids = set(expected_by_id)
        if not isinstance(metadata, dict) or set(metadata) != expected_ids:
            raise ValueError("activity manifest target metadata is incomplete")
        for target_id, expected in expected_by_id.items():
            observed = metadata[target_id]
            if not isinstance(observed, dict):
                raise ValueError(f"activity target metadata is invalid for {target_id}")
            for field in (
                "target_chembl_id", "pref_name", "target_type", "organism", "task"
            ):
                if observed.get(field) != expected[field]:
                    raise ValueError(
                        f"activity target metadata mismatch for {target_id}.{field}"
                    )
        source_filters = source_manifest.get("filters") or {}
        confidence_filter = source_filters.get("confidence_score") or {}
        if confidence_filter.get("required_value") != 9:
            raise ValueError("activity manifest does not require confidence score 9")
        if not isinstance(source_manifest.get("assays_sha256"), str) or len(
            source_manifest["assays_sha256"]
        ) != 64:
            raise ValueError("activity manifest does not bind the ChEMBL assay source")
        assays_file = source_manifest.get("assays_file")
        if not isinstance(assays_file, str) or Path(assays_file).name != assays_file:
            raise ValueError("activity manifest assay file identity is invalid")
        assays_path = manifest_path.parent / assays_file
        if not assays_path.is_file() or _file_sha256(assays_path) != source_manifest[
            "assays_sha256"
        ]:
            raise ValueError("ChEMBL assay source SHA does not match its manifest")
    elif source_path is not None:
        raise ValueError("strict file-backed MMP build requires an activity manifest")

    smiles_to_id, values_by_compound, activity_audit = _prepare_strict_activity_groups(rows)
    structures_path = output / "strict_structures.smi"
    structures_text = "".join(
        f"{smiles}\t{compound_id}\n"
        for smiles, compound_id in sorted(smiles_to_id.items())
    )
    structures_sha = _write_text_atomic(structures_path, structures_text)

    executable = _resolve_mmpdb_executable(mmpdb_executable)
    versions = _tool_versions(executable)
    fragdb_path = output / "strict_structures.fragdb"
    raw_pairs_path = output / "strict_mmp_raw.csv.gz"
    fragment_command = [
        str(executable),
        "fragment",
        str(structures_path),
        "--delimiter", "tab",
        "--num-cuts", "1",
        "--max-heavies", "100",
        "--max-rotatable-bonds", "10",
        "--salt-remover", "<none>",
        "--num-jobs", str(num_jobs),
        "--output", str(fragdb_path),
    ]
    index_command = [
        str(executable),
        "index",
        str(fragdb_path),
        "--out", "csv.gz",
        "--max-variable-heavies", "10",
        "--max-variable-ratio", "0.33",
        "--output", str(raw_pairs_path),
    ]
    logical_fragment_command = [
        "mmpdb", "fragment", structures_path.name,
        "--delimiter", "tab",
        "--num-cuts", "1",
        "--max-heavies", "100",
        "--max-rotatable-bonds", "10",
        "--salt-remover", "<none>",
        "--num-jobs", str(num_jobs),
        "--output", fragdb_path.name,
    ]
    logical_index_command = [
        "mmpdb", "index", fragdb_path.name,
        "--out", "csv.gz",
        "--max-variable-heavies", "10",
        "--max-variable-ratio", "0.33",
        "--output", raw_pairs_path.name,
    ]
    logger.info("Fragmenting %d unique structures with pinned mmpdb...", len(smiles_to_id))
    try:
        fragment_result = subprocess.run(
            fragment_command, check=True, capture_output=True, text=True
        )
        logger.info("Indexing strict single-cut matched molecular pairs...")
        index_result = subprocess.run(
            index_command, check=True, capture_output=True, text=True
        )
    except subprocess.CalledProcessError as error:
        stderr = (error.stderr or "")[-4000:]
        raise RuntimeError(f"mmpdb strict build failed: {stderr}") from error

    structural_pairs, structural_audit = _read_mmpdb_structural_pairs(
        raw_pairs_path, set(values_by_compound)
    )
    pair_records, pair_audit = _build_strict_pair_records(
        structural_pairs,
        smiles_to_id=smiles_to_id,
        values_by_compound=values_by_compound,
        minimum_delta=minimum_delta,
    )
    if not pair_records:
        raise RuntimeError("strict fragmentation produced no comparable MMP records")

    pairs_path = output / "mmp_pairs.json"
    pairs_sha = _write_json_atomic(str(pairs_path), pair_records)
    target_mapping = {
        task: {
            **spec,
            "source_url": CHEMBL_REST_TARGET_URL.format(
                target_id=spec["target_chembl_id"]
            ),
        }
        for task, spec in FORMAL_TASK_TARGETS.items()
    }
    manifest = {
        "schema_version": STRICT_MMP_SCHEMA_VERSION,
        "algorithm": "mmpdb_single_cut_same_assay_mmp",
        "strict_fragmentation_mmp": True,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source": {
            "activities_file": source_path.name if source_path else "in_memory_fixture",
            "activities_sha256": source_sha,
            "activities_manifest_file": (
                manifest_path.name if activities_manifest_path is not None else None
            ),
            "activities_manifest_sha256": source_manifest_sha,
            "assays_file": source_manifest.get("assays_file") if source_manifest else None,
            "assays_sha256": (
                source_manifest.get("assays_sha256") if source_manifest else None
            ),
            "chembl_release_indices": (
                source_manifest.get("release_indices", []) if source_manifest else []
            ),
            "license": source_manifest.get("license") if source_manifest else None,
            "activity_filters": (
                source_manifest.get("filters") if source_manifest else None
            ),
        },
        "target_mapping": target_mapping,
        "comparability_protocol": {
            "server_and_client_relation": "=",
            "same_target_required": True,
            "same_assay_chembl_id_required": True,
            "same_standard_type_required": True,
            "same_standard_units_required": True,
            "canonical_molecule_duplicate_aggregation": "median pActivity within assay",
            "cross_assay_effect_aggregation": "median signed delta within target/endpoint",
            "minimum_absolute_median_delta_pactivity": minimum_delta,
            "cross_endpoint_pair_selection": (
                "highest assay count, then measurement count, absolute delta, "
                "then IC50/Ki/EC50 priority"
            ),
        },
        "fragmentation_protocol": {
            "implementation": "rdkit/mmpdb",
            "license": "BSD-3-Clause",
            "versions": versions,
            "num_cuts": 1,
            "max_heavies": 100,
            "max_rotatable_bonds": 10,
            "salt_remover": "disabled after multi-component exclusion",
            "smallest_transformation_only": False,
            "smallest_transformation_option_disabled_reason": (
                "mmpdb 3.1.4 Variable_Reducability_Filter raises an RDKit "
                "explicit-valence error followed by CanonSmiles(None) for valid "
                "single-cut fragments with RDKit 2024.09.6 and 2026.03.5"
            ),
            "structural_pair_selection": (
                "all mmpdb single-cut candidates; per unordered compound pair "
                "minimize max(left_variable_heavies, right_variable_heavies), "
                "then minimize their sum, then maximize constant-core heavy "
                "atoms; transformation and constant strings are tie-breakers only"
            ),
            "max_variable_heavies": 10,
            "max_variable_ratio": 0.33,
        },
        "commands": {
            "fragment_argv": logical_fragment_command,
            "index_argv": logical_index_command,
            "fragment_returncode": fragment_result.returncode,
            "index_returncode": index_result.returncode,
        },
        "intermediate_artifacts": {
            "structures_file": structures_path.name,
            "structures_sha256": structures_sha,
            "fragdb_file": fragdb_path.name,
            "fragdb_sha256": _file_sha256(fragdb_path),
            "raw_pairs_file": raw_pairs_path.name,
            "raw_pairs_sha256": _file_sha256(raw_pairs_path),
        },
        "counts": {**activity_audit, **structural_audit, **pair_audit},
        "pairs_file": pairs_path.name,
        "pairs_sha256": pairs_sha,
        "total_pairs": len(pair_records),
    }
    _write_json_atomic(str(output / "mmp_pairs_manifest.json"), manifest)
    logger.info("Generated %d strict MMP pairs at %s", len(pair_records), pairs_path)
    return pair_records
