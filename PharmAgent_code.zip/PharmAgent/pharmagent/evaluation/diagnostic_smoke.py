"""Fail-closed labeling and launch guards for reduced-budget paid smokes.

Diagnostic smokes exercise the real oracle, ADMET backend, and paid LLM, but
they are deliberately not formal experiment runs.  The helpers in this module
keep that distinction explicit without changing the formal PMO completion
contract.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any


DIAGNOSTIC_SMOKE_STATUS = "diagnostic_complete"
DIAGNOSTIC_SMOKE_RUN_MODE = "paid_diagnostic_smoke"
DIAGNOSTIC_SMOKE_ELIGIBILITY_STATUS = (
    "diagnostic_only_not_submission_eligible"
)


def validate_run_budget_mode(
    *,
    diagnostic_smoke: bool,
    require_full_budget: bool,
    configured_formal_budget: int,
    oracle_budget: int,
    formal_identity: Mapping[str, Any] | None,
) -> None:
    """Reject ambiguous reduced-budget use of a formal runner.

    A formal configuration may run below its configured budget only behind the
    explicit diagnostic flag and a ``paid_smoke_*`` identity.  Conversely, an
    unflagged formal run must use the exact configured budget.  This guard is
    runner-side and leaves the formal result validator unchanged.
    """
    for value, label in (
        (configured_formal_budget, "configured formal budget"),
        (oracle_budget, "oracle budget"),
    ):
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            raise RuntimeError(f"{label} must be a positive integer")

    matrix_scope = (
        formal_identity.get("matrix_scope")
        if isinstance(formal_identity, Mapping)
        else None
    )
    paid_smoke_scope = (
        isinstance(matrix_scope, str)
        and matrix_scope.startswith("paid_smoke_")
    )

    if diagnostic_smoke:
        if not require_full_budget or formal_identity is None:
            raise RuntimeError(
                "--diagnostic-smoke requires a formal configuration and "
                "--formal-reproduction-identity"
            )
        if not paid_smoke_scope:
            raise RuntimeError(
                "--diagnostic-smoke requires identity matrix_scope "
                "paid_smoke_*"
            )
        if oracle_budget >= configured_formal_budget:
            raise RuntimeError(
                "--diagnostic-smoke requires oracle_budget below the "
                f"configured formal budget ({configured_formal_budget})"
            )
        return

    if paid_smoke_scope:
        raise RuntimeError(
            "a paid_smoke_* identity requires explicit --diagnostic-smoke"
        )
    if require_full_budget and oracle_budget != configured_formal_budget:
        raise RuntimeError(
            "formal runs require the exact configured oracle budget "
            f"({configured_formal_budget}); use --diagnostic-smoke only with "
            "a paid_smoke_* identity for a reduced-budget diagnostic"
        )


def label_result(
    result: Mapping[str, Any],
    *,
    phase: str,
    configured_formal_budget: int,
) -> dict[str, Any]:
    """Return a visibly non-submission-eligible diagnostic result.

    Only an optimizer result that was otherwise complete may be labeled.  Real
    optimizer/API failures remain failures and can never be promoted by this
    helper.
    """
    if phase not in {"standard", "admet"}:
        raise ValueError("diagnostic smoke phase must be 'standard' or 'admet'")
    if result.get("status") != "complete":
        raise ValueError(
            "only an otherwise complete optimizer result can be labeled as "
            "a diagnostic smoke"
        )
    observed_budget = result.get("oracle_budget")
    if (
        isinstance(observed_budget, bool)
        or not isinstance(observed_budget, int)
        or observed_budget <= 0
        or observed_budget >= configured_formal_budget
    ):
        raise ValueError(
            "diagnostic result must use a positive budget below the formal budget"
        )

    labeled = dict(result)
    underlying_termination_reason = result.get("termination_reason")
    transition_events = result.get("lagrangian_transition_events")
    observed_expansions = (
        len(transition_events) if isinstance(transition_events, list) else 0
    )
    labeled.update(
        {
            "status": DIAGNOSTIC_SMOKE_STATUS,
            "termination_reason": "diagnostic_smoke_budget_complete",
            "run_mode": DIAGNOSTIC_SMOKE_RUN_MODE,
            "eligibility_status": DIAGNOSTIC_SMOKE_ELIGIBILITY_STATUS,
            "formal_table_eligible": False,
            "submission_eligible": False,
            "diagnostic_smoke": {
                "schema_version": 1,
                "phase": phase,
                "configured_formal_oracle_budget": configured_formal_budget,
                "observed_oracle_budget": observed_budget,
                "reduced_budget": True,
                "publication_eligible": False,
                "underlying_optimizer_status": "complete",
                "underlying_termination_reason": underlying_termination_reason,
                "formal_active_set_expansions_required": (
                    2 if phase == "admet" else None
                ),
                "observed_active_set_expansions": (
                    observed_expansions if phase == "admet" else None
                ),
            },
        }
    )
    return labeled
