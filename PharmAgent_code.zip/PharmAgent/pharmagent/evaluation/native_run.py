"""Crash-safe native PharmAgent task/seed journals.

This module provides one identity-bound SQLite journal per phase/task/seed
run. It persists oracle scores, model responses, and optimizer state at their
respective commit boundaries so that interrupted runs can be resumed safely.

The journal deliberately separates three durability boundaries:

* every canonical oracle molecule is reserved and its raw target score is
  committed before later ADMET or optimizer work;
* every LLM logical request is prepared before HTTP and its response/usage is
  committed before parsing or applying the response;
* the complete optimizer state is atomically replaced at round boundaries.

An LLM request left in ``http_started`` is *indeterminate*: the provider may
have received it even though no response was durably observed.  Resuming such
a request automatically would risk duplicate payment and a different sampled
response, so callers must fail closed instead.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sqlite3
from typing import Any


NATIVE_RUN_SCHEMA_VERSION = 1
NATIVE_PUBLIC_SNAPSHOT_SCHEMA_VERSION = 2


class NativeRunJournalError(RuntimeError):
    """Base class for unsafe or inconsistent native journal state."""


class NativeRunIdentityError(NativeRunJournalError):
    """Raised when a journal belongs to another scientific run."""


class IndeterminateLLMRequestError(NativeRunJournalError):
    """Raised when retrying could duplicate a paid provider request."""


class IndeterminateOracleCallError(NativeRunJournalError):
    """Raised when an interrupted oracle call cannot be replayed safely."""


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _canonical_json(value: Any) -> str:
    try:
        return json.dumps(
            value,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        )
    except (TypeError, ValueError) as error:
        raise NativeRunJournalError(
            f"native journal value is not canonical JSON: {error}"
        ) from error


def _sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _canonical_sha256(value: Any) -> str:
    return _sha256_text(_canonical_json(value))


def _public_optimizer_state(state: Mapping[str, Any]) -> dict[str, Any] | None:
    """Project the private resume state into path-free scientific evidence.

    RNG arrays and the full memory buffer are intentionally not published.
    The buffer is bound by canonical digest and cardinality; every mechanism
    trace needed for independent validation remains explicit.
    """
    if not isinstance(state.get("state_schema_version"), int):
        return None
    memory = state.get("memory_buffer")
    if not isinstance(memory, list):
        return None
    best_smiles = state.get("best_smiles")
    current_smiles = state.get("current_smiles")
    seed_smiles = state.get("seed_smiles")

    def smiles_binding(value: object) -> dict[str, Any]:
        return {
            "canonical_smiles": deepcopy(value),
            "canonical_smiles_sha256": (
                _sha256_text(value) if isinstance(value, str) else None
            ),
        }

    public = {
        "state_schema_version": state.get("state_schema_version"),
        "stage": state.get("stage"),
        "target_property": state.get("target_property"),
        "max_rounds": state.get("max_rounds"),
        "oracle_budget": state.get("oracle_budget"),
        "next_round": state.get("next_round"),
        "trajectory": deepcopy(state.get("trajectory")),
        "round_failure_history": deepcopy(
            state.get("round_failure_history")
        ),
        "lagrangian_runtime": deepcopy(state.get("lagrangian")),
        "curriculum_runtime": deepcopy(state.get("curriculum")),
        "final_stagnation_count": state.get("stagnation_count"),
        "global_seen_canonical": deepcopy(
            state.get("global_seen_canonical")
        ),
        "global_seen_initialized": state.get("global_seen_initialized"),
        "best_feasible": deepcopy(state.get("best_feasible")),
        "near_feasible_anchors": deepcopy(
            state.get("near_feasible_anchors")
        ),
        "memory_buffer_binding": {
            "count": len(memory),
            "sha256": _canonical_sha256(memory),
        },
        "critical_counters": {
            key: deepcopy(state.get(key))
            for key in (
                "round_error_count",
                "consecutive_round_errors",
                "successful_scored_rounds",
                "cer_experiences_committed",
                "zero_novel_rounds",
                "failure_count",
                "generation_restart_cursor",
                "pending_generation_restart",
            )
        },
        "terminal_best": {
            "seed": smiles_binding(seed_smiles),
            "current": smiles_binding(current_smiles),
            "best": smiles_binding(best_smiles),
            "best_target_score": state.get("best_target_score"),
            "best_admet_score": state.get("best_admet_score"),
            "best_combined_score": state.get("best_combined"),
        },
    }
    return public


def native_journal_path(
    root: str | Path, *, phase: str, task: str, seed: int
) -> Path:
    """Return the isolated journal path for one phase/task/seed run."""
    return (
        Path(root).expanduser().resolve()
        / phase
        / task
        / f"seed_{seed}.sqlite3"
    )


def configure_native_run_journal(
    config: Mapping[str, Any],
    *,
    journal_root: str | Path,
    phase: str,
    task: str,
    seed: int,
    oracle_budget: int,
    formal_reproduction_identity: Mapping[str, Any],
) -> dict[str, Any]:
    """Inject one shared native journal spec into a task/seed config."""
    if phase not in {"standard", "admet"}:
        raise ValueError("native journal phase must be 'standard' or 'admet'")
    if not isinstance(task, str) or not task.strip():
        raise ValueError("native journal task must be non-empty")
    if isinstance(seed, bool) or not isinstance(seed, int) or seed < 0:
        raise ValueError("native journal seed must be a non-negative integer")
    if (
        isinstance(oracle_budget, bool)
        or not isinstance(oracle_budget, int)
        or oracle_budget <= 0
    ):
        raise ValueError("native journal oracle_budget must be positive")
    from pharmagent.evaluation.formal_identity import (
        validate_formal_reproduction_identity,
    )

    formal_identity = validate_formal_reproduction_identity(
        formal_reproduction_identity
    )
    configured = deepcopy(dict(config))
    identity = {
        "kind": "pharmagent-native-run",
        "identity_version": 1,
        "formal_reproduction_identity": formal_identity,
        "phase": phase,
        "task": task.strip(),
        "seed": seed,
        "oracle_budget": oracle_budget,
        "objective": configured.get("optimization", {}).get("objective"),
    }
    spec = {
        "path": str(
            native_journal_path(
                journal_root, phase=phase, task=task.strip(), seed=seed
            )
        ),
        "identity": identity,
    }
    configured["native_run_journal"] = deepcopy(spec)
    llm = configured.setdefault("llm", {})
    if not isinstance(llm, dict):
        raise ValueError("native journal llm config must be a mapping")
    llm["native_run_journal"] = deepcopy(spec)
    for role in ("generator", "reviewer"):
        agent = configured.setdefault(role, {})
        if not isinstance(agent, dict):
            raise ValueError(f"native journal {role} config must be a mapping")
        agent_llm = deepcopy(agent.get("llm", llm))
        if not isinstance(agent_llm, dict):
            raise ValueError(f"native journal {role}.llm must be a mapping")
        agent_llm["native_run_journal"] = deepcopy(spec)
        agent["llm"] = agent_llm
    return configured


def reject_unjournaled_partial_resume(
    config: Mapping[str, Any],
    *,
    journal_path: str | Path,
    task: str,
    seed: int,
    checkpoint_rows: Sequence[Mapping[str, Any]] = (),
) -> None:
    """Fail closed when partial artifacts cannot reconstruct native state.

    A completed result is handled by the runners before this check.  This
    function specifically prevents a paid-attempt ledger or Chemical-CER row
    from being mistaken for a round-resumable trace.
    """
    if Path(journal_path).expanduser().resolve().exists():
        return
    reasons: list[str] = []
    attempt_spec = config.get("llm", {}).get("attempt_ledger")
    if isinstance(attempt_spec, Mapping):
        attempt_path = Path(attempt_spec.get("path", "")).expanduser()
        if str(attempt_spec.get("path", "")) and attempt_path.exists():
            from pharmagent.llm.attempt_ledger import HTTPAttemptLedger

            ledger = HTTPAttemptLedger(
                attempt_spec["path"],
                cap=attempt_spec["cap"],
                identity=attempt_spec["identity"],
            )
            if ledger.attempts_used > 0:
                reasons.append("paid HTTP-attempt ledger")
    cer = config.get("cer", {})
    if isinstance(cer, Mapping) and cer.get("path"):
        cer_path = Path(cer["path"]).expanduser()
        if cer_path.exists():
            from pharmagent.optimization.experience_replay import ExperienceDB

            with ExperienceDB(dict(cer)) as database:
                if any(
                    row.get("task_name") == task for row in database.entries
                ):
                    reasons.append("Chemical-CER rows")
    for row in checkpoint_rows:
        if row.get("seed") != seed:
            continue
        history = row.get("evaluation_history")
        if isinstance(history, list) and history:
            reasons.append("partial JSON oracle history")
            break
    if reasons:
        raise NativeRunJournalError(
            "unjournaled partial state is not a complete native resume for "
            f"{task}/seed_{seed} ({', '.join(dict.fromkeys(reasons))}); "
            "use a new output/ledger/CER root or obtain the missing native "
            "journal—CER rows do not contain full optimizer state"
        )


class NativeRunJournal:
    """Identity-bound durable event/state store for one native run."""

    def __init__(self, path: str | Path, *, identity: Mapping[str, Any]):
        if not isinstance(identity, Mapping) or not identity:
            raise ValueError("native journal identity must be a non-empty mapping")
        self.path = Path(path).expanduser().resolve()
        self.identity = deepcopy(dict(identity))
        self._identity_json = _canonical_json(self.identity)
        self.identity_sha256 = _sha256_text(self._identity_json)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        try:
            connection = sqlite3.connect(str(self.path), timeout=30.0)
            connection.execute("PRAGMA busy_timeout = 30000")
            connection.execute("PRAGMA foreign_keys = ON")
            connection.execute("PRAGMA synchronous = FULL")
            return connection
        except sqlite3.Error as error:
            raise NativeRunJournalError(
                f"cannot open native run journal: {type(error).__name__}"
            ) from None

    def _initialize(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS metadata (
                    singleton INTEGER PRIMARY KEY CHECK(singleton = 1),
                    schema_version INTEGER NOT NULL,
                    identity_json TEXT NOT NULL,
                    identity_sha256 TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS oracle_calls (
                    call_index INTEGER PRIMARY KEY,
                    smiles TEXT NOT NULL UNIQUE,
                    stage TEXT NOT NULL CHECK(
                        stage IN ('pending', 'raw_scored', 'complete')
                    ),
                    context_json TEXT NOT NULL,
                    raw_target_score REAL,
                    record_json TEXT,
                    record_sha256 TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS llm_requests (
                    request_id TEXT PRIMARY KEY,
                    client_role TEXT NOT NULL,
                    request_sha256 TEXT NOT NULL,
                    request_json TEXT NOT NULL,
                    status TEXT NOT NULL CHECK(
                        status IN (
                            'prepared', 'http_started', 'complete',
                            'failed_known'
                        )
                    ),
                    attempts_at_prepare INTEGER NOT NULL,
                    last_accounted_attempt INTEGER NOT NULL,
                    known_failed_attempts INTEGER NOT NULL,
                    response_text TEXT,
                    usage_json TEXT,
                    error_type TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS optimizer_state (
                    singleton INTEGER PRIMARY KEY CHECK(singleton = 1),
                    revision INTEGER NOT NULL,
                    state_json TEXT NOT NULL,
                    state_sha256 TEXT NOT NULL,
                    oracle_complete_count INTEGER NOT NULL,
                    llm_complete_count INTEGER NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )
            row = connection.execute(
                """
                SELECT schema_version, identity_json, identity_sha256
                FROM metadata WHERE singleton = 1
                """
            ).fetchone()
            expected = (
                NATIVE_RUN_SCHEMA_VERSION,
                self._identity_json,
                self.identity_sha256,
            )
            if row is None:
                connection.execute(
                    """
                    INSERT INTO metadata(
                        singleton, schema_version, identity_json,
                        identity_sha256, created_at
                    ) VALUES (1, ?, ?, ?, ?)
                    """,
                    (*expected, _utc_now()),
                )
            elif tuple(row) != expected:
                raise NativeRunIdentityError(
                    "native journal belongs to a different protocol identity"
                )
            connection.commit()
        except NativeRunIdentityError:
            connection.rollback()
            raise
        except sqlite3.Error as error:
            connection.rollback()
            raise NativeRunJournalError(
                f"cannot initialize native run journal: {type(error).__name__}"
            ) from None
        finally:
            connection.close()
        try:
            os.chmod(self.path, 0o600)
        except OSError:
            pass

    @property
    def oracle_complete_count(self) -> int:
        connection = self._connect()
        try:
            return int(
                connection.execute(
                    "SELECT COUNT(*) FROM oracle_calls WHERE stage = 'complete'"
                ).fetchone()[0]
            )
        finally:
            connection.close()

    @property
    def oracle_reserved_count(self) -> int:
        connection = self._connect()
        try:
            return int(
                connection.execute("SELECT COUNT(*) FROM oracle_calls").fetchone()[0]
            )
        finally:
            connection.close()

    @property
    def oracle_scored_count(self) -> int:
        """Return calls whose finite target score is durably known."""
        connection = self._connect()
        try:
            return int(
                connection.execute(
                    """
                    SELECT COUNT(*) FROM oracle_calls
                    WHERE stage IN ('raw_scored', 'complete')
                    """
                ).fetchone()[0]
            )
        finally:
            connection.close()

    def reserve_oracle_call(
        self, smiles: str, *, context: Mapping[str, Any] | None = None
    ) -> dict[str, Any]:
        """Reserve one logical canonical call or return its existing state."""
        if not isinstance(smiles, str) or not smiles:
            raise ValueError("oracle journal smiles must be non-empty")
        context_json = _canonical_json(dict(context or {}))
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """
                SELECT call_index, smiles, stage, context_json,
                       raw_target_score, record_json, record_sha256
                FROM oracle_calls WHERE smiles = ?
                """,
                (smiles,),
            ).fetchone()
            newly_reserved = row is None
            if newly_reserved:
                next_index = int(
                    connection.execute(
                        "SELECT COALESCE(MAX(call_index), 0) + 1 FROM oracle_calls"
                    ).fetchone()[0]
                )
                now = _utc_now()
                connection.execute(
                    """
                    INSERT INTO oracle_calls(
                        call_index, smiles, stage, context_json,
                        created_at, updated_at
                    ) VALUES (?, ?, 'pending', ?, ?, ?)
                    """,
                    (next_index, smiles, context_json, now, now),
                )
                row = (
                    next_index,
                    smiles,
                    "pending",
                    context_json,
                    None,
                    None,
                    None,
                )
            else:
                # Context is scientific provenance.  Replaying a previously
                # scored molecule from another round is allowed, but its first
                # call context must never be rewritten.
                context_json = str(row[3])
            connection.commit()
            state = self._oracle_row(row)
            state["newly_reserved"] = newly_reserved
            return state
        except sqlite3.Error as error:
            connection.rollback()
            raise NativeRunJournalError(
                f"cannot reserve oracle call: {type(error).__name__}"
            ) from None
        finally:
            connection.close()

    def record_raw_oracle_score(self, smiles: str, score: float) -> dict[str, Any]:
        """Commit a finite raw target score immediately after oracle return."""
        numeric = float(score)
        if not math_isfinite(numeric):
            raise ValueError("raw oracle score must be finite")
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """
                SELECT stage, raw_target_score FROM oracle_calls WHERE smiles = ?
                """,
                (smiles,),
            ).fetchone()
            if row is None:
                raise NativeRunJournalError("raw oracle score has no reservation")
            stage, existing = row
            if stage in {"raw_scored", "complete"}:
                if float(existing) != numeric:
                    raise NativeRunJournalError(
                        "raw oracle replay disagrees with durable score"
                    )
            else:
                connection.execute(
                    """
                    UPDATE oracle_calls
                    SET stage = 'raw_scored', raw_target_score = ?, updated_at = ?
                    WHERE smiles = ?
                    """,
                    (numeric, _utc_now(), smiles),
                )
            connection.commit()
            return self.oracle_call_for_smiles(smiles) or {}
        except sqlite3.Error as error:
            connection.rollback()
            raise NativeRunJournalError(
                f"cannot persist raw oracle score: {type(error).__name__}"
            ) from None
        finally:
            connection.close()

    def complete_oracle_call(
        self, smiles: str, record: Mapping[str, Any]
    ) -> dict[str, Any]:
        """Commit the complete publication trace row for one logical call."""
        detached = deepcopy(dict(record))
        record_json = _canonical_json(detached)
        record_sha = _sha256_text(record_json)
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """
                SELECT call_index, stage, raw_target_score,
                       record_json, record_sha256
                FROM oracle_calls WHERE smiles = ?
                """,
                (smiles,),
            ).fetchone()
            if row is None:
                raise NativeRunJournalError("completed oracle call has no reservation")
            call_index, stage, raw_score, existing_json, existing_sha = row
            if detached.get("call_index") != int(call_index):
                raise NativeRunJournalError("oracle record call_index mismatch")
            if detached.get("smiles") != smiles:
                raise NativeRunJournalError("oracle record smiles mismatch")
            if raw_score is None:
                raise NativeRunJournalError(
                    "oracle record cannot complete before raw target score"
                )
            if float(detached.get("raw_target_score")) != float(raw_score):
                raise NativeRunJournalError("oracle record raw score mismatch")
            if stage == "complete":
                if existing_sha != record_sha or existing_json != record_json:
                    raise NativeRunJournalError(
                        "completed oracle replay disagrees with durable record"
                    )
            else:
                connection.execute(
                    """
                    UPDATE oracle_calls
                    SET stage = 'complete', record_json = ?, record_sha256 = ?,
                        updated_at = ?
                    WHERE smiles = ?
                    """,
                    (record_json, record_sha, _utc_now(), smiles),
                )
            connection.commit()
            return detached
        except (TypeError, ValueError) as error:
            connection.rollback()
            if isinstance(error, NativeRunJournalError):
                raise
            raise NativeRunJournalError("oracle record contains invalid score") from error
        except sqlite3.Error as error:
            connection.rollback()
            raise NativeRunJournalError(
                f"cannot complete oracle call: {type(error).__name__}"
            ) from None
        finally:
            connection.close()

    @staticmethod
    def _oracle_row(row: Sequence[Any]) -> dict[str, Any]:
        record = json.loads(row[5]) if row[5] is not None else None
        return {
            "call_index": int(row[0]),
            "smiles": str(row[1]),
            "stage": str(row[2]),
            "context": json.loads(row[3]),
            "raw_target_score": (
                None if row[4] is None else float(row[4])
            ),
            "record": record,
            "record_sha256": row[6],
        }

    def oracle_call_for_smiles(self, smiles: str) -> dict[str, Any] | None:
        connection = self._connect()
        try:
            row = connection.execute(
                """
                SELECT call_index, smiles, stage, context_json,
                       raw_target_score, record_json, record_sha256
                FROM oracle_calls WHERE smiles = ?
                """,
                (smiles,),
            ).fetchone()
            return None if row is None else self._oracle_row(row)
        finally:
            connection.close()

    def oracle_calls(self, *, complete_only: bool = False) -> list[dict[str, Any]]:
        connection = self._connect()
        try:
            where = "WHERE stage = 'complete'" if complete_only else ""
            rows = connection.execute(
                f"""
                SELECT call_index, smiles, stage, context_json,
                       raw_target_score, record_json, record_sha256
                FROM oracle_calls {where} ORDER BY call_index
                """
            ).fetchall()
            return [self._oracle_row(row) for row in rows]
        finally:
            connection.close()

    def evaluation_history(self) -> list[dict[str, Any]]:
        """Return the exact complete call trace in canonical call order."""
        calls = self.oracle_calls(complete_only=True)
        return [deepcopy(call["record"]) for call in calls]

    def prepare_llm_request(
        self,
        *,
        request_id: str,
        client_role: str,
        request: Mapping[str, Any],
        durable_attempts_used: int,
    ) -> dict[str, Any]:
        """Persist/validate one logical request before any HTTP attempt."""
        if not request_id or not client_role:
            raise ValueError("LLM request_id and client_role must be non-empty")
        if durable_attempts_used < 0:
            raise ValueError("durable_attempts_used must be non-negative")
        request_json = _canonical_json(dict(request))
        request_sha = _sha256_text(request_json)
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """
                SELECT request_id, client_role, request_sha256, request_json,
                       status, attempts_at_prepare, last_accounted_attempt,
                       known_failed_attempts, response_text, usage_json,
                       error_type
                FROM llm_requests WHERE request_id = ?
                """,
                (request_id,),
            ).fetchone()
            if row is None:
                now = _utc_now()
                connection.execute(
                    """
                    INSERT INTO llm_requests(
                        request_id, client_role, request_sha256, request_json,
                        status, attempts_at_prepare, last_accounted_attempt,
                        known_failed_attempts, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, 'prepared', ?, ?, 0, ?, ?)
                    """,
                    (
                        request_id,
                        client_role,
                        request_sha,
                        request_json,
                        durable_attempts_used,
                        durable_attempts_used,
                        now,
                        now,
                    ),
                )
                row = (
                    request_id,
                    client_role,
                    request_sha,
                    request_json,
                    "prepared",
                    durable_attempts_used,
                    durable_attempts_used,
                    0,
                    None,
                    None,
                    None,
                )
            if (
                row[1] != client_role
                or row[2] != request_sha
                or row[3] != request_json
            ):
                raise NativeRunJournalError(
                    "LLM request identity/hash mismatch on resume"
                )
            state = self._llm_row(row)
            if state["status"] == "http_started":
                raise IndeterminateLLMRequestError(
                    "paid LLM request was in flight when the process stopped; "
                    "refusing automatic duplicate payment"
                )
            if (
                state["status"] == "prepared"
                and durable_attempts_used != state["last_accounted_attempt"]
            ):
                raise IndeterminateLLMRequestError(
                    "paid-attempt ledger advanced beyond the durable LLM "
                    "request event; refusing automatic resend"
                )
            connection.commit()
            return state
        except (NativeRunJournalError, IndeterminateLLMRequestError):
            connection.rollback()
            raise
        except sqlite3.Error as error:
            connection.rollback()
            raise NativeRunJournalError(
                f"cannot prepare LLM request: {type(error).__name__}"
            ) from None
        finally:
            connection.close()

    @staticmethod
    def _llm_row(row: Sequence[Any]) -> dict[str, Any]:
        return {
            "request_id": str(row[0]),
            "client_role": str(row[1]),
            "request_sha256": str(row[2]),
            "request": json.loads(row[3]),
            "status": str(row[4]),
            "attempts_at_prepare": int(row[5]),
            "last_accounted_attempt": int(row[6]),
            "known_failed_attempts": int(row[7]),
            "response_text": row[8],
            "usage": None if row[9] is None else json.loads(row[9]),
            "error_type": row[10],
        }

    def mark_llm_http_started(self, request_id: str, attempt_index: int) -> None:
        """Bind a pre-consumed paid attempt to its logical request."""
        if attempt_index <= 0:
            raise ValueError("attempt_index must be positive")
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """
                SELECT status, last_accounted_attempt
                FROM llm_requests WHERE request_id = ?
                """,
                (request_id,),
            ).fetchone()
            if row is None or row[0] != "prepared":
                raise NativeRunJournalError(
                    "LLM HTTP attempt has no prepared logical request"
                )
            if attempt_index != int(row[1]) + 1:
                raise NativeRunJournalError(
                    "LLM paid-attempt index is not contiguous with request state"
                )
            connection.execute(
                """
                UPDATE llm_requests
                SET status = 'http_started', last_accounted_attempt = ?,
                    updated_at = ?
                WHERE request_id = ?
                """,
                (attempt_index, _utc_now(), request_id),
            )
            connection.commit()
        except NativeRunJournalError:
            connection.rollback()
            raise
        except sqlite3.Error as error:
            connection.rollback()
            raise NativeRunJournalError(
                f"cannot mark LLM HTTP attempt: {type(error).__name__}"
            ) from None
        finally:
            connection.close()

    def record_llm_attempt_failure(
        self,
        request_id: str,
        *,
        error_type: str,
        final: bool,
        usage: Mapping[str, Any] | None = None,
    ) -> None:
        """Record a provider outcome known not to contain a usable response."""
        safe_error = str(error_type).strip()[:120] or "UnknownError"
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """
                SELECT status, known_failed_attempts, usage_json
                FROM llm_requests WHERE request_id = ?
                """,
                (request_id,),
            ).fetchone()
            if row is None or row[0] != "http_started":
                raise NativeRunJournalError(
                    "LLM failure has no in-flight durable request"
                )
            aggregate = self._merge_llm_usage(
                None if row[2] is None else json.loads(row[2]), usage
            )
            connection.execute(
                """
                UPDATE llm_requests
                SET status = ?, known_failed_attempts = ?, error_type = ?,
                    usage_json = ?, updated_at = ?
                WHERE request_id = ?
                """,
                (
                    "failed_known" if final else "prepared",
                    int(row[1]) + 1,
                    safe_error,
                    None if aggregate is None else _canonical_json(aggregate),
                    _utc_now(),
                    request_id,
                ),
            )
            connection.commit()
        except NativeRunJournalError:
            connection.rollback()
            raise
        except sqlite3.Error as error:
            connection.rollback()
            raise NativeRunJournalError(
                f"cannot record LLM failure: {type(error).__name__}"
            ) from None
        finally:
            connection.close()

    def reopen_known_transport_failure(
        self,
        *,
        request_id: str,
        durable_attempts_used: int,
        max_failed_attempts: int,
    ) -> dict[str, Any] | None:
        """Reopen one known transient failure before a new HTTP retry batch.

        The client reaches this state only after observing and persisting a
        failed HTTP outcome. In-flight ``http_started`` rows remain
        indeterminate and are never automatically resent. ``None`` signals
        that the fixed transport-recovery fuse has been reached.
        """
        if durable_attempts_used < 0:
            raise ValueError("durable_attempts_used must be non-negative")
        if max_failed_attempts <= 0:
            raise ValueError("max_failed_attempts must be positive")
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """
                SELECT request_id, client_role, request_sha256, request_json,
                       status, attempts_at_prepare, last_accounted_attempt,
                       known_failed_attempts, response_text, usage_json,
                       error_type
                FROM llm_requests WHERE request_id = ?
                """,
                (request_id,),
            ).fetchone()
            if row is None or row[4] != "failed_known":
                raise NativeRunJournalError(
                    "LLM transport recovery has no durably failed request"
                )
            if durable_attempts_used != int(row[6]):
                raise IndeterminateLLMRequestError(
                    "paid-attempt ledger advanced beyond the durably failed "
                    "LLM request; refusing automatic resend"
                )
            if int(row[7]) >= max_failed_attempts:
                connection.commit()
                return None
            connection.execute(
                """
                UPDATE llm_requests
                SET status = 'prepared', updated_at = ?
                WHERE request_id = ?
                """,
                (_utc_now(), request_id),
            )
            reopened = list(row)
            reopened[4] = "prepared"
            connection.commit()
            return self._llm_row(reopened)
        except (NativeRunJournalError, IndeterminateLLMRequestError):
            connection.rollback()
            raise
        except sqlite3.Error as error:
            connection.rollback()
            raise NativeRunJournalError(
                f"cannot reopen LLM transport failure: {type(error).__name__}"
            ) from None
        finally:
            connection.close()

    def complete_llm_request(
        self,
        request_id: str,
        *,
        response_text: str,
        usage: Mapping[str, Any],
    ) -> None:
        """Commit a usable response and its exact usage before local parsing."""
        if not isinstance(response_text, str) or not response_text.strip():
            raise ValueError("durable LLM response must be non-empty text")
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """
                SELECT status, usage_json FROM llm_requests
                WHERE request_id = ?
                """,
                (request_id,),
            ).fetchone()
            if row is None or row[0] != "http_started":
                raise NativeRunJournalError(
                    "LLM response has no in-flight durable request"
                )
            aggregate = self._merge_llm_usage(
                None if row[1] is None else json.loads(row[1]), usage
            )
            assert aggregate is not None
            connection.execute(
                """
                UPDATE llm_requests
                SET status = 'complete', response_text = ?, usage_json = ?,
                    error_type = NULL, updated_at = ?
                WHERE request_id = ?
                """,
                (
                    response_text,
                    _canonical_json(aggregate),
                    _utc_now(),
                    request_id,
                ),
            )
            connection.commit()
        except NativeRunJournalError:
            connection.rollback()
            raise
        except sqlite3.Error as error:
            connection.rollback()
            raise NativeRunJournalError(
                f"cannot persist LLM response: {type(error).__name__}"
            ) from None
        finally:
            connection.close()

    @staticmethod
    def _merge_llm_usage(
        existing: Mapping[str, Any] | None,
        observation: Mapping[str, Any] | None,
    ) -> dict[str, Any] | None:
        """Merge one provider response observation into a logical request."""
        if existing is None and observation is None:
            return None
        fields = (
            "prompt_tokens",
            "prompt_cache_hit_tokens",
            "prompt_cache_miss_tokens",
            "completion_tokens",
            "total_tokens",
        )
        aggregate = {
            "successful_http_calls": 0,
            **{field: 0 for field in fields},
            "responses_with_usage": 0,
            "responses_without_usage": 0,
            "field_observations": {field: 0 for field in fields},
            "normalized_minimax_cache_omissions": 0,
        }
        if existing is not None:
            aggregate["successful_http_calls"] = int(
                existing.get("successful_http_calls", 0) or 0
            )
            for field in fields:
                aggregate[field] = int(existing.get(field, 0) or 0)
                aggregate["field_observations"][field] = int(
                    existing.get("field_observations", {}).get(field, 0) or 0
                )
            for field in ("responses_with_usage", "responses_without_usage"):
                aggregate[field] = int(existing.get(field, 0) or 0)
            aggregate["normalized_minimax_cache_omissions"] = int(
                existing.get("normalized_minimax_cache_omissions", 0) or 0
            )
        if observation is not None:
            aggregate["successful_http_calls"] += 1
            for field in fields:
                aggregate[field] += int(observation.get(field, 0) or 0)
                aggregate["field_observations"][field] += int(
                    observation.get("field_observations", {}).get(field, 0) or 0
                )
            aggregate[
                "responses_with_usage"
                if observation.get("response_with_usage") is True
                else "responses_without_usage"
            ] += 1
            aggregate["normalized_minimax_cache_omissions"] += int(
                observation.get("normalized_minimax_cache_omissions", 0) or 0
            )
        return aggregate

    def llm_usage_for_role(self, client_role: str) -> dict[str, Any]:
        """Aggregate durable successful-response usage for one agent role."""
        connection = self._connect()
        try:
            rows = connection.execute(
                """
                SELECT usage_json FROM llm_requests
                WHERE client_role = ? AND usage_json IS NOT NULL
                ORDER BY rowid
                """,
                (client_role,),
            ).fetchall()
        finally:
            connection.close()
        totals = {
            "successful_http_calls": 0,
            "prompt_tokens": 0,
            "prompt_cache_hit_tokens": 0,
            "prompt_cache_miss_tokens": 0,
            "completion_tokens": 0,
            "total_tokens": 0,
            "responses_with_usage": 0,
            "responses_without_usage": 0,
            "field_observations": {
                field: 0
                for field in (
                    "prompt_tokens",
                    "prompt_cache_hit_tokens",
                    "prompt_cache_miss_tokens",
                    "completion_tokens",
                    "total_tokens",
                )
            },
            "normalized_minimax_cache_omissions": 0,
        }
        for (payload,) in rows:
            usage = json.loads(payload)
            totals["successful_http_calls"] += int(
                usage.get("successful_http_calls", 0) or 0
            )
            for field in (
                "prompt_tokens",
                "prompt_cache_hit_tokens",
                "prompt_cache_miss_tokens",
                "completion_tokens",
                "total_tokens",
            ):
                totals[field] += int(usage.get(field, 0) or 0)
            for field in ("responses_with_usage", "responses_without_usage"):
                totals[field] += int(usage.get(field, 0) or 0)
            totals["normalized_minimax_cache_omissions"] += int(
                usage.get("normalized_minimax_cache_omissions", 0) or 0
            )
            observations = usage.get("field_observations", {})
            for field in totals["field_observations"]:
                totals["field_observations"][field] += int(
                    observations.get(field, 0) or 0
                )
        return totals

    def llm_request_counts(self) -> dict[str, int]:
        connection = self._connect()
        try:
            rows = connection.execute(
                "SELECT status, COUNT(*) FROM llm_requests GROUP BY status"
            ).fetchall()
            return {str(status): int(count) for status, count in rows}
        finally:
            connection.close()

    def llm_request_audit(self) -> list[dict[str, Any]]:
        """Return path/prompt/response-free logical request evidence."""
        connection = self._connect()
        try:
            rows = connection.execute(
                """
                SELECT request_id, client_role, status,
                       known_failed_attempts, last_accounted_attempt
                FROM llm_requests ORDER BY rowid
                """
            ).fetchall()
        finally:
            connection.close()
        return [
            {
                "request_id": str(row[0]),
                "client_role": str(row[1]),
                "status": str(row[2]),
                "known_failed_attempts": int(row[3]),
                "last_accounted_attempt": int(row[4]),
            }
            for row in rows
        ]

    def completed_llm_responses(self) -> dict[str, str]:
        """Return durable response text keyed by logical request id.

        This private resume-only view is intentionally absent from public
        snapshots.  It lets the formal optimizer reconstruct the exact
        structured Reviewer feedback that is permitted to cross a round
        boundary, without trusting the mutable optimizer checkpoint.
        """
        connection = self._connect()
        try:
            rows = connection.execute(
                """
                SELECT request_id, response_text
                FROM llm_requests
                WHERE status = 'complete'
                ORDER BY rowid
                """
            ).fetchall()
        finally:
            connection.close()
        responses: dict[str, str] = {}
        for request_id, response_text in rows:
            if not isinstance(response_text, str) or not response_text:
                raise NativeRunJournalError(
                    "completed LLM request has no durable response text"
                )
            responses[str(request_id)] = response_text
        return responses

    def save_optimizer_state(self, state: Mapping[str, Any]) -> dict[str, Any]:
        """Atomically replace the complete round-resume state."""
        detached = deepcopy(dict(state))
        state_json = _canonical_json(detached)
        state_sha = _sha256_text(state_json)
        oracle_count = self.oracle_complete_count
        llm_complete_count = self.llm_request_counts().get("complete", 0)
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            existing = connection.execute(
                "SELECT revision FROM optimizer_state WHERE singleton = 1"
            ).fetchone()
            revision = 1 if existing is None else int(existing[0]) + 1
            connection.execute(
                """
                INSERT INTO optimizer_state(
                    singleton, revision, state_json, state_sha256,
                    oracle_complete_count, llm_complete_count, updated_at
                ) VALUES (1, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(singleton) DO UPDATE SET
                    revision = excluded.revision,
                    state_json = excluded.state_json,
                    state_sha256 = excluded.state_sha256,
                    oracle_complete_count = excluded.oracle_complete_count,
                    llm_complete_count = excluded.llm_complete_count,
                    updated_at = excluded.updated_at
                """,
                (
                    revision,
                    state_json,
                    state_sha,
                    oracle_count,
                    llm_complete_count,
                    _utc_now(),
                ),
            )
            connection.commit()
            return {
                "revision": revision,
                "state_sha256": state_sha,
                "oracle_complete_count": oracle_count,
                "llm_complete_count": llm_complete_count,
            }
        except sqlite3.Error as error:
            connection.rollback()
            raise NativeRunJournalError(
                f"cannot persist optimizer state: {type(error).__name__}"
            ) from None
        finally:
            connection.close()

    def load_optimizer_state(self) -> dict[str, Any] | None:
        connection = self._connect()
        try:
            row = connection.execute(
                """
                SELECT revision, state_json, state_sha256,
                       oracle_complete_count, llm_complete_count
                FROM optimizer_state WHERE singleton = 1
                """
            ).fetchone()
        finally:
            connection.close()
        if row is None:
            return None
        state_json = str(row[1])
        if _sha256_text(state_json) != row[2]:
            raise NativeRunJournalError("optimizer state hash mismatch")
        state = json.loads(state_json)
        if not isinstance(state, dict):
            raise NativeRunJournalError("optimizer state root is not an object")
        return {
            "revision": int(row[0]),
            "state": state,
            "state_sha256": str(row[2]),
            "oracle_complete_count": int(row[3]),
            "llm_complete_count": int(row[4]),
        }

    def snapshot(self) -> dict[str, Any]:
        """Return a path-free audit suitable for final result provenance."""
        state = self.load_optimizer_state()
        calls = self.oracle_calls(complete_only=True)
        trace_json = _canonical_json([call["record"] for call in calls])
        request_counts = self.llm_request_counts()
        request_audit = self.llm_request_audit()
        public_state = (
            None
            if state is None
            else _public_optimizer_state(state["state"])
        )
        public_state_sha = (
            None if public_state is None else _canonical_sha256(public_state)
        )
        public_binding_sha = (
            None
            if public_state is None
            else _canonical_sha256({
                "identity_sha256": self.identity_sha256,
                "optimizer_public_state_sha256": public_state_sha,
            })
        )
        return {
            "schema_version": NATIVE_RUN_SCHEMA_VERSION,
            "public_snapshot_schema_version": (
                NATIVE_PUBLIC_SNAPSHOT_SCHEMA_VERSION
            ),
            "identity": deepcopy(self.identity),
            "identity_sha256": self.identity_sha256,
            "oracle_complete_count": len(calls),
            "oracle_trace_sha256": _sha256_text(trace_json),
            "llm_request_counts": request_counts,
            "llm_request_audit": request_audit,
            "llm_request_audit_sha256": _canonical_sha256(request_audit),
            "optimizer_state_revision": (
                None if state is None else state["revision"]
            ),
            "optimizer_state_sha256": (
                None if state is None else state["state_sha256"]
            ),
            "optimizer_public_state": public_state,
            "optimizer_public_state_sha256": public_state_sha,
            "public_state_identity_binding_sha256": public_binding_sha,
        }


def math_isfinite(value: float) -> bool:
    # Local helper keeps the module's dependency surface limited to stdlib.
    import math

    return math.isfinite(value)


__all__ = [
    "configure_native_run_journal",
    "reject_unjournaled_partial_resume",
    "IndeterminateLLMRequestError",
    "IndeterminateOracleCallError",
    "NATIVE_RUN_SCHEMA_VERSION",
    "NATIVE_PUBLIC_SNAPSHOT_SCHEMA_VERSION",
    "NativeRunIdentityError",
    "NativeRunJournal",
    "NativeRunJournalError",
    "native_journal_path",
]
