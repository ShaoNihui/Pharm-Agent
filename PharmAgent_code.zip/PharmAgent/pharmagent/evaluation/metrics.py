"""
Additional evaluation metrics: diversity, Pareto hypervolume, results aggregation.
"""

from collections.abc import Mapping
import json
import math
import os

import numpy as np
import pandas as pd

from pharmagent.tools.similarity import compute_internal_diversity
from pharmagent.optimization.pareto import compute_pareto_front, compute_hypervolume_2d


def build_evaluation_history(mol_buffer: dict) -> list[dict]:
    """Convert an oracle buffer into a call-ordered, serializable history.

    PharmAgent's :class:`TrackedOracle` stores ``smiles -> score`` in insertion
    order, while the reference PMO implementation stores
    ``smiles -> [score, call_index]``.  This helper accepts both layouts so the
    metric implementation below follows the official PMO call ordering.
    """
    history = []
    for insertion_index, (smiles, value) in enumerate(mol_buffer.items(), start=1):
        call_index = insertion_index

        if isinstance(value, dict):
            score = value.get("raw_target_score", value.get("score", 0.0))
            call_index = value.get("call_index", call_index)
        elif isinstance(value, (list, tuple)):
            score = value[0] if value else 0.0
            if len(value) > 1:
                call_index = value[1]
        else:
            score = value

        history.append({
            "call_index": int(call_index),
            "smiles": smiles,
            "raw_target_score": float(score),
        })

    return sorted(history, key=lambda row: row["call_index"])


def annotate_history_with_admet(
    history: list[dict], analyst, batch_size: int = 256
) -> list[dict]:
    """Add paper-protocol ADMET fields to a raw oracle history.

    The supplied analyst is reused across batches and runs, which also reuses
    the ADMET-AI model and its canonical-SMILES cache.  ``batch_size`` only
    bounds annotation memory: the formal predictor itself is pinned to one
    uncached canonical SMILES per ADMET-AI inference.  Only the fields needed
    to reproduce the paper metrics are persisted.
    """
    if isinstance(batch_size, bool) or not isinstance(batch_size, int):
        raise ValueError("batch_size must be a positive integer")
    if batch_size <= 0:
        raise ValueError("batch_size must be a positive integer")
    annotated = [dict(row) for row in history]

    for start in range(0, len(annotated), batch_size):
        batch = annotated[start:start + batch_size]
        output = analyst.run({"smiles_list": [row["smiles"] for row in batch]})
        if not isinstance(output, Mapping):
            raise RuntimeError("ADMET annotation returned no result mapping")
        admet_results = output.get("admet_results")
        if not isinstance(admet_results, list) or len(admet_results) != len(batch):
            raise RuntimeError(
                "ADMET annotation result count differs from the input batch"
            )

        for row, admet_result in zip(batch, admet_results):
            if not isinstance(admet_result, Mapping):
                raise RuntimeError("ADMET annotation row is not a mapping")
            predictions = admet_result.get("admet_predictions")
            violations = admet_result.get("violations")
            admet_score = admet_result.get("admet_score")
            pass_all = admet_result.get("pass_all")
            if (
                not isinstance(predictions, Mapping)
                or predictions.get("prediction_backend") != "admet_ai"
                or not isinstance(predictions.get("admet_ai_version"), str)
                or not predictions["admet_ai_version"]
            ):
                raise RuntimeError(
                    "formal ADMET annotation lacks strict ADMET-AI provenance"
                )
            if not isinstance(violations, list) or any(
                not isinstance(violation, Mapping)
                or not isinstance(violation.get("name"), str)
                or not violation["name"]
                for violation in violations
            ):
                raise RuntimeError("ADMET annotation violations are malformed")
            if (
                isinstance(admet_score, bool)
                or not isinstance(admet_score, (int, float))
                or not math.isfinite(float(admet_score))
                or not 0.0 <= float(admet_score) <= 1.0
            ):
                raise RuntimeError("ADMET annotation score is not finite in [0, 1]")
            if not isinstance(pass_all, bool) or pass_all != (not violations):
                raise RuntimeError("ADMET annotation pass flag is inconsistent")
            row.update({
                "admet_score": float(admet_score),
                "pass_all": pass_all,
                "n_violations": len(violations),
                "violation_names": [v["name"] for v in violations],
                "admet_backend": predictions["prediction_backend"],
                "admet_ai_version": predictions["admet_ai_version"],
            })

    return annotated


def compute_top_auc(
    history: list[dict],
    top_n: int = 10,
    oracle_budget: int = 1000,
    freq_log: int = 100,
    finish: bool = True,
) -> float:
    """Compute the normalized PMO AUC Top-N metric.

    This mirrors ``top_auc`` in the official ``wenhao-gao/mol_opt`` runner:
    the mean of the running Top-N is sampled every ``freq_log`` calls and
    integrated with the trapezoidal rule.  A completed run that stops before
    the budget is padded with its final Top-N value.
    """
    if oracle_budget <= 0 or top_n <= 0:
        return 0.0

    ordered = sorted(history, key=lambda row: row.get("call_index", 0))
    ordered = ordered[:oracle_budget]
    if not ordered:
        return 0.0

    scores = [float(row.get("raw_target_score", 0.0)) for row in ordered]
    area = 0.0
    previous = 0.0
    called = 0

    for index in range(freq_log, min(len(scores), oracle_budget), freq_log):
        current = float(np.mean(sorted(scores[:index], reverse=True)[:top_n]))
        area += freq_log * (current + previous) / 2.0
        previous = current
        called = index

    current = float(np.mean(sorted(scores, reverse=True)[:top_n]))
    area += (len(scores) - called) * (current + previous) / 2.0

    if finish and len(scores) < oracle_budget:
        area += (oracle_budget - len(scores)) * current

    return area / oracle_budget


def compute_admet_adjusted_auc_from_history(
    history: list[dict], oracle_budget: int = 1000
) -> float:
    """Compute the paper's call-level ADMET-adjusted AUC definition.

    At call ``n`` the curve value is the best *raw* target score among all
    molecules seen through that call that pass every configured constraint.
    """
    if oracle_budget <= 0:
        return 0.0

    ordered = sorted(history, key=lambda row: row.get("call_index", 0))
    ordered = ordered[:oracle_budget]
    best_passing = 0.0
    area = 0.0

    for row in ordered:
        if row.get("pass_all", False):
            best_passing = max(
                best_passing, float(row.get("raw_target_score", 0.0))
            )
        area += best_passing

    if len(ordered) < oracle_budget:
        area += (oracle_budget - len(ordered)) * best_passing

    return area / oracle_budget


def compute_pmo_run_metrics(
    history: list[dict], oracle_budget: int, freq_log: int = 100
) -> dict:
    """Compute every per-run metric required by the evaluation protocol."""
    scores = [float(row.get("raw_target_score", 0.0)) for row in history]
    metrics = {
        "n_oracle_calls": len(history),
        "top_1": max(scores) if scores else 0.0,
        "top_10": float(np.mean(sorted(scores, reverse=True)[:10])) if scores else 0.0,
        "auc_top_10": compute_top_auc(
            history,
            top_n=10,
            oracle_budget=oracle_budget,
            freq_log=freq_log,
            finish=True,
        ),
    }

    has_admet = bool(history) and all(
        "admet_score" in row and "pass_all" in row for row in history
    )
    if has_admet:
        pass_flags = [bool(row["pass_all"]) for row in history]
        admet_scores = [float(row["admet_score"]) for row in history]
        metrics.update({
            "pr_at_10": compute_admet_pass_rate_at_k(scores, pass_flags, k=10),
            "aa_auc": compute_admet_adjusted_auc_from_history(
                history, oracle_budget=oracle_budget
            ),
            "pareto_hypervolume": compute_pareto_hypervolume(
                scores, admet_scores, reference_point=(0.0, 0.0)
            ),
        })

        first_versioned = next(
            (row for row in history if row.get("admet_backend")), None
        )
        if first_versioned:
            metrics["admet_backend"] = first_versioned.get("admet_backend")
            if first_versioned.get("admet_ai_version"):
                metrics["admet_ai_version"] = first_versioned["admet_ai_version"]

    return metrics


def compute_diversity(smiles_list: list[str]) -> float:
    """Compute internal diversity of a set of molecules."""
    return compute_internal_diversity(smiles_list)


def compute_pareto_hypervolume(target_scores: list[float],
                                admet_scores: list[float],
                                reference_point: tuple[float, float] = (0.0, 0.0)) -> float:
    """Compute hypervolume of the Pareto front for target vs ADMET scores.

    Args:
        target_scores: List of target property scores.
        admet_scores: List of ADMET compliance scores.
        reference_point: Lower-left reference point for hypervolume.

    Returns:
        Hypervolume indicator value.
    """
    if not target_scores or not admet_scores:
        return 0.0

    points = np.array(list(zip(target_scores, admet_scores)))
    pareto_idx = compute_pareto_front(points)

    if len(pareto_idx) == 0:
        return 0.0

    pareto_points = points[pareto_idx]
    ref = np.array(reference_point)
    return compute_hypervolume_2d(pareto_points, ref)


def aggregate_results(results_dir: str, tasks: list[str] | None = None) -> pd.DataFrame:
    """Aggregate results from multiple experiment runs into a DataFrame.

    Expects results_dir to contain JSON files with structure:
    {task_name: [{seed_result}, ...], ...}

    Returns DataFrame with columns:
        task, seed, best_score, best_combined, oracle_calls, n_admet_pass, ...
    """
    rows = []

    for fname in os.listdir(results_dir):
        if not fname.endswith(".json"):
            continue
        filepath = os.path.join(results_dir, fname)
        with open(filepath, "r") as f:
            data = json.load(f)

        for task_name, seed_results in data.items():
            if tasks and task_name not in tasks:
                continue
            if not isinstance(seed_results, list):
                seed_results = [seed_results]
            for seed_idx, result in enumerate(seed_results):
                row = {
                    "task": task_name,
                    "seed": seed_idx,
                    "file": fname,
                }
                if isinstance(result, dict):
                    row["best_target_score"] = result.get("best_target_score", 0)
                    row["best_combined_score"] = result.get("best_combined_score", 0)
                    row["total_oracle_calls"] = result.get("total_oracle_calls", 0)
                    row["best_smiles"] = result.get("best_smiles", "")

                    traj = result.get("trajectory", [])
                    if traj:
                        last = traj[-1]
                        row["n_rounds"] = len(traj)
                        row["final_n_admet_pass"] = last.get("n_admet_pass", 0)
                rows.append(row)

    df = pd.DataFrame(rows)
    return df


def compute_admet_pass_rate_at_k(scores: list[float],
                                  admet_pass: list[bool],
                                  k: int = 10) -> float:
    """ADMET Pass Rate@Top-K: fraction of top-K molecules passing all ADMET.

    Sorts molecules by score (descending), takes top-K, and computes
    the fraction that pass all ADMET constraints.
    """
    if not scores or not admet_pass:
        return 0.0
    paired = sorted(zip(scores, admet_pass), key=lambda x: -x[0])
    top_k = paired[:k]
    n_pass = sum(1 for _, p in top_k if p)
    return n_pass / len(top_k)


def compute_admet_adjusted_auc(trajectory: list[dict]) -> float:
    """AUC computed only over ADMET-passing molecules.

    For each round in the trajectory, uses the best score among
    ADMET-passing molecules. Returns the normalized area under curve.
    """
    if not trajectory:
        return 0.0

    admet_scores = []
    for entry in trajectory:
        # Use n_admet_pass > 0 as proxy for having passing molecules
        if entry.get("n_admet_pass", 0) > 0:
            admet_scores.append(entry.get("best_score", 0))
        else:
            admet_scores.append(0.0)

    if not admet_scores:
        return 0.0

    # Running best (monotonically non-decreasing)
    running_best = []
    best_so_far = 0.0
    for s in admet_scores:
        best_so_far = max(best_so_far, s)
        running_best.append(best_so_far)

    return sum(running_best) / len(running_best)


def compute_constraint_violation_trajectory(
    lagrangian_trajectory: list[dict],
) -> dict:
    """Extract violation and lambda trajectories for convergence plots.

    Returns dict with:
        total_violations: list[float] — sum of violations per round
        per_constraint_lambdas: dict[str, list[float]] — lambda trajectories
        rho_values: list[float] — penalty parameter over time
    """
    if not lagrangian_trajectory:
        return {"total_violations": [], "per_constraint_lambdas": {}, "rho_values": []}

    total_violations = [t["total_violation"] for t in lagrangian_trajectory]
    rho_values = [t["rho"] for t in lagrangian_trajectory]

    # Collect per-constraint lambda trajectories
    all_names = set()
    for t in lagrangian_trajectory:
        all_names.update(t.get("lambdas", {}).keys())

    per_constraint = {}
    for name in sorted(all_names):
        per_constraint[name] = [
            t.get("lambdas", {}).get(name, 0.0) for t in lagrangian_trajectory
        ]

    return {
        "total_violations": total_violations,
        "per_constraint_lambdas": per_constraint,
        "rho_values": rho_values,
    }


def compute_summary_table(df: pd.DataFrame) -> pd.DataFrame:
    """Compute summary statistics per task from aggregated results.

    Returns DataFrame with: task, mean_score, std_score, mean_combined,
    std_combined, mean_oracle_calls
    """
    if df.empty:
        return pd.DataFrame()

    summary = df.groupby("task").agg(
        mean_target_score=("best_target_score", "mean"),
        std_target_score=("best_target_score", "std"),
        mean_combined_score=("best_combined_score", "mean"),
        std_combined_score=("best_combined_score", "std"),
        mean_oracle_calls=("total_oracle_calls", "mean"),
        n_seeds=("seed", "count"),
    ).reset_index()

    summary["std_target_score"] = summary["std_target_score"].fillna(0)
    summary["std_combined_score"] = summary["std_combined_score"].fillna(0)

    return summary
