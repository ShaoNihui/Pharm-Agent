"""Fail-closed validation for PharmAgent per-run LLM usage provenance.

Formal experiments persist a deliberately small, path-free accounting
snapshot.  This module validates that snapshot before a native checkpoint can
be resumed or normalized.  Exact field sets are intentional: an unexpected
field could contain a prompt, response, credential, endpoint, or local path
and must never be copied into a canonical paper artifact.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from copy import deepcopy
import re
from typing import Any

from pharmagent.llm.api_client import (
    LLM_USAGE_SCHEMA_VERSION,
    MINIMAX_CACHE_OMISSION_RULE_ID,
)


class LLMUsageError(ValueError):
    """Raised when an LLM usage audit is missing, unsafe, or inconsistent."""


_TOKEN_FIELDS = (
    "prompt_tokens",
    "prompt_cache_hit_tokens",
    "prompt_cache_miss_tokens",
    "completion_tokens",
    "total_tokens",
    "derived_total_tokens",
)
_PROVIDER_TOKEN_FIELDS = tuple(
    field for field in _TOKEN_FIELDS if field != "derived_total_tokens"
)
_COUNTER_FIELDS = (
    "successful_http_calls",
    "http_attempts_local",
    *_TOKEN_FIELDS,
)
_TOP_LEVEL_FIELDS = {
    "schema_version",
    "scope",
    *_COUNTER_FIELDS,
    "usage_availability",
    "durable_http_attempts",
    "attempt_ledgers",
    "agents",
    "normalization_provenance",
}
_AGENT_FIELDS = {
    "schema_version",
    "client_role",
    *_COUNTER_FIELDS,
    "usage_availability",
    "normalization_provenance",
    "attempt_ledger",
}
_AVAILABILITY_FIELDS = {
    "complete",
    "provider_fields_complete",
    "covers_durable_attempt_history",
    "responses_with_usage",
    "responses_without_usage",
    "field_observations",
}
_AVAILABLE_LEDGER_FIELDS = {
    "available",
    "schema_version",
    "identity_sha256",
    "hard_cap",
    "attempts_used",
    "attempts_remaining",
    "attempts_at_client_start",
    "attempts_during_client_lifetime",
}
_SAFE_ERROR_TYPE = re.compile(r"^[A-Za-z_][A-Za-z0-9_.]{0,127}$")
_NORMALIZATION_FIELDS = {
    "schema_version",
    "rule_id",
    "cached_tokens_omission_count",
}


def _mapping(value: object, label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise LLMUsageError(f"{label} must be a mapping")
    if not all(isinstance(key, str) for key in value):
        raise LLMUsageError(f"{label} contains a non-string field name")
    return value


def _exact_fields(
    value: Mapping[str, Any], expected: set[str], label: str
) -> None:
    observed = set(value)
    if observed != expected:
        missing = sorted(expected - observed)
        unexpected = sorted(observed - expected)
        details = []
        if missing:
            details.append("missing=" + ",".join(missing))
        if unexpected:
            details.append("unexpected=" + ",".join(unexpected))
        raise LLMUsageError(
            f"{label} fields are not canonical ({'; '.join(details)})"
        )


def _nonnegative_int(value: object, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise LLMUsageError(f"{label} must be a non-negative integer")
    return value


def _boolean(value: object, label: str) -> bool:
    if not isinstance(value, bool):
        raise LLMUsageError(f"{label} must be a boolean")
    return value


def _safe_error_type(value: object, label: str) -> None:
    if not isinstance(value, str) or _SAFE_ERROR_TYPE.fullmatch(value) is None:
        raise LLMUsageError(f"{label} must contain only an exception class name")


def _validate_normalization_provenance(
    raw: object,
    *,
    label: str,
    successful_calls: int,
    cache_field_observations: int,
) -> dict[str, Any]:
    value = _mapping(raw, label)
    _exact_fields(value, set(_NORMALIZATION_FIELDS), label)
    if value["schema_version"] != 1:
        raise LLMUsageError(f"{label}.schema_version is unsupported")
    if value["rule_id"] != MINIMAX_CACHE_OMISSION_RULE_ID:
        raise LLMUsageError(f"{label}.rule_id is unsupported")
    count = _nonnegative_int(
        value["cached_tokens_omission_count"],
        f"{label}.cached_tokens_omission_count",
    )
    if count > successful_calls:
        raise LLMUsageError(
            f"{label}.cached_tokens_omission_count exceeds successful calls"
        )
    if count > cache_field_observations:
        raise LLMUsageError(
            f"{label}.cached_tokens_omission_count exceeds canonical cache "
            "observations"
        )
    return dict(value)


def _validate_availability(
    raw: object,
    *,
    label: str,
    successful_calls: int,
    allow_snapshot_error: bool,
) -> dict[str, Any]:
    value = _mapping(raw, label)
    expected = set(_AVAILABILITY_FIELDS)
    if allow_snapshot_error and "snapshot_error_type" in value:
        expected.add("snapshot_error_type")
    _exact_fields(value, expected, label)
    if "snapshot_error_type" in value:
        _safe_error_type(value["snapshot_error_type"], f"{label}.snapshot_error_type")

    complete = _boolean(value["complete"], f"{label}.complete")
    provider_complete = _boolean(
        value["provider_fields_complete"],
        f"{label}.provider_fields_complete",
    )
    durable_complete = _boolean(
        value["covers_durable_attempt_history"],
        f"{label}.covers_durable_attempt_history",
    )
    with_usage = _nonnegative_int(
        value["responses_with_usage"], f"{label}.responses_with_usage"
    )
    without_usage = _nonnegative_int(
        value["responses_without_usage"],
        f"{label}.responses_without_usage",
    )
    if with_usage + without_usage != successful_calls:
        raise LLMUsageError(
            f"{label} response counts do not equal successful_http_calls"
        )

    observations = _mapping(
        value["field_observations"], f"{label}.field_observations"
    )
    _exact_fields(
        observations,
        set(_PROVIDER_TOKEN_FIELDS),
        f"{label}.field_observations",
    )
    observation_counts = {
        field: _nonnegative_int(
            observations[field], f"{label}.field_observations.{field}"
        )
        for field in _PROVIDER_TOKEN_FIELDS
    }
    if any(count > with_usage for count in observation_counts.values()):
        raise LLMUsageError(
            f"{label} field observations exceed responses_with_usage"
        )
    expected_provider_complete = all(
        observation_counts[field] == successful_calls
        for field in _PROVIDER_TOKEN_FIELDS
    )
    if provider_complete != expected_provider_complete:
        raise LLMUsageError(
            f"{label}.provider_fields_complete contradicts field observations"
        )
    if complete != (provider_complete and durable_complete):
        raise LLMUsageError(
            f"{label}.complete contradicts provider/durable availability"
        )
    return dict(value)


def _validate_ledger(raw: object, *, label: str) -> dict[str, Any]:
    value = _mapping(raw, label)
    available = _boolean(value.get("available"), f"{label}.available")
    if not available:
        expected = {"available"}
        if "error_type" in value:
            expected.add("error_type")
        _exact_fields(value, expected, label)
        if "error_type" in value:
            _safe_error_type(value["error_type"], f"{label}.error_type")
        return dict(value)

    _exact_fields(value, set(_AVAILABLE_LEDGER_FIELDS), label)
    if value["schema_version"] != 1:
        raise LLMUsageError(f"{label}.schema_version is unsupported")
    digest = value["identity_sha256"]
    if (
        not isinstance(digest, str)
        or len(digest) != 64
        or any(character not in "0123456789abcdef" for character in digest)
    ):
        raise LLMUsageError(f"{label}.identity_sha256 is malformed")
    hard_cap = _nonnegative_int(value["hard_cap"], f"{label}.hard_cap")
    if hard_cap <= 0:
        raise LLMUsageError(f"{label}.hard_cap must be positive")
    used = _nonnegative_int(value["attempts_used"], f"{label}.attempts_used")
    remaining = _nonnegative_int(
        value["attempts_remaining"], f"{label}.attempts_remaining"
    )
    at_start = _nonnegative_int(
        value["attempts_at_client_start"],
        f"{label}.attempts_at_client_start",
    )
    during = _nonnegative_int(
        value["attempts_during_client_lifetime"],
        f"{label}.attempts_during_client_lifetime",
    )
    if used > hard_cap or remaining != hard_cap - used:
        raise LLMUsageError(f"{label} hard-cap accounting is inconsistent")
    if at_start > used or during != used - at_start:
        raise LLMUsageError(f"{label} client-lifetime accounting is inconsistent")
    return dict(value)


def _validate_agent(
    raw: object, *, role: str, usage_schema_version: int
) -> dict[str, Any]:
    label = f"llm_usage.agents.{role}"
    value = _mapping(raw, label)
    expected_fields = set(_AGENT_FIELDS)
    if usage_schema_version == 1:
        expected_fields.remove("normalization_provenance")
    _exact_fields(value, expected_fields, label)
    if value["schema_version"] != usage_schema_version:
        raise LLMUsageError(f"{label}.schema_version is unsupported")
    if value["client_role"] != role:
        raise LLMUsageError(f"{label}.client_role must be {role!r}")
    counters = {
        field: _nonnegative_int(value[field], f"{label}.{field}")
        for field in _COUNTER_FIELDS
    }
    if counters["http_attempts_local"] < counters["successful_http_calls"]:
        raise LLMUsageError(f"{label} has fewer attempts than successful calls")
    if counters["derived_total_tokens"] != (
        counters["prompt_tokens"] + counters["completion_tokens"]
    ):
        raise LLMUsageError(f"{label}.derived_total_tokens is inconsistent")
    availability = _validate_availability(
        value["usage_availability"],
        label=f"{label}.usage_availability",
        successful_calls=counters["successful_http_calls"],
        allow_snapshot_error=True,
    )
    if usage_schema_version >= 2:
        _validate_normalization_provenance(
            value["normalization_provenance"],
            label=f"{label}.normalization_provenance",
            successful_calls=counters["successful_http_calls"],
            cache_field_observations=availability["field_observations"][
                "prompt_cache_hit_tokens"
            ],
        )
    if availability["provider_fields_complete"]:
        if counters["prompt_cache_hit_tokens"] + counters[
            "prompt_cache_miss_tokens"
        ] != counters["prompt_tokens"]:
            raise LLMUsageError(f"{label} prompt cache totals are inconsistent")
        if counters["total_tokens"] != counters["derived_total_tokens"]:
            raise LLMUsageError(f"{label} provider total_tokens is inconsistent")
    ledger = _validate_ledger(value["attempt_ledger"], label=f"{label}.attempt_ledger")
    if ledger["available"] is True:
        expected_coverage = ledger["attempts_at_client_start"] == 0
        if availability["covers_durable_attempt_history"] != expected_coverage:
            raise LLMUsageError(f"{label} durable-history coverage is inconsistent")
    return dict(value)


def validate_llm_usage(
    value: object, *, require_complete: bool = False
) -> dict[str, Any]:
    """Validate and return a detached, unchanged usage audit.

    ``require_complete`` enforces full provenance for formal experiments.
    It rejects missing provider fields, a resumed/incomplete durable history,
    and missing or ambiguous paid-attempt ledgers.  Non-formal failed runs may
    still retain an explicitly incomplete audit for diagnostics.
    """

    usage = _mapping(value, "llm_usage")
    schema_version = usage.get("schema_version")
    if (
        isinstance(schema_version, bool)
        or schema_version not in (1, LLM_USAGE_SCHEMA_VERSION)
    ):
        raise LLMUsageError("llm_usage.schema_version is unsupported")
    expected_fields = set(_TOP_LEVEL_FIELDS)
    if schema_version == 1:
        expected_fields.remove("normalization_provenance")
    _exact_fields(usage, expected_fields, "llm_usage")
    if usage["scope"] != "single_task_seed_run":
        raise LLMUsageError("llm_usage.scope must be 'single_task_seed_run'")
    counters = {
        field: _nonnegative_int(usage[field], f"llm_usage.{field}")
        for field in _COUNTER_FIELDS
    }
    if counters["http_attempts_local"] < counters["successful_http_calls"]:
        raise LLMUsageError("llm_usage has fewer attempts than successful calls")
    if counters["derived_total_tokens"] != (
        counters["prompt_tokens"] + counters["completion_tokens"]
    ):
        raise LLMUsageError("llm_usage.derived_total_tokens is inconsistent")

    agents_raw = _mapping(usage["agents"], "llm_usage.agents")
    _exact_fields(agents_raw, {"generator", "reviewer"}, "llm_usage.agents")
    agents = {
        role: _validate_agent(
            agents_raw[role],
            role=role,
            usage_schema_version=int(schema_version),
        )
        for role in ("generator", "reviewer")
    }
    for field in _COUNTER_FIELDS:
        if counters[field] != sum(int(agent[field]) for agent in agents.values()):
            raise LLMUsageError(f"llm_usage.{field} does not equal agent totals")

    availability = _validate_availability(
        usage["usage_availability"],
        label="llm_usage.usage_availability",
        successful_calls=counters["successful_http_calls"],
        allow_snapshot_error=False,
    )
    if schema_version >= 2:
        normalization = _validate_normalization_provenance(
            usage["normalization_provenance"],
            label="llm_usage.normalization_provenance",
            successful_calls=counters["successful_http_calls"],
            cache_field_observations=availability["field_observations"][
                "prompt_cache_hit_tokens"
            ],
        )
        if normalization["cached_tokens_omission_count"] != sum(
            int(
                agent["normalization_provenance"][
                    "cached_tokens_omission_count"
                ]
            )
            for agent in agents.values()
        ):
            raise LLMUsageError(
                "llm_usage.normalization_provenance count does not equal "
                "agent totals"
            )
    for field in (
        "complete",
        "provider_fields_complete",
        "covers_durable_attempt_history",
    ):
        if availability[field] != all(
            agent["usage_availability"][field] is True
            for agent in agents.values()
        ):
            raise LLMUsageError(f"llm_usage.usage_availability.{field} is inconsistent")
    for field in ("responses_with_usage", "responses_without_usage"):
        if availability[field] != sum(
            int(agent["usage_availability"][field]) for agent in agents.values()
        ):
            raise LLMUsageError(f"llm_usage.usage_availability.{field} is inconsistent")
    for field in _PROVIDER_TOKEN_FIELDS:
        if availability["field_observations"][field] != sum(
            int(agent["usage_availability"]["field_observations"][field])
            for agent in agents.values()
        ):
            raise LLMUsageError(
                "llm_usage.usage_availability.field_observations."
                f"{field} is inconsistent"
            )
    if availability["provider_fields_complete"]:
        if counters["prompt_cache_hit_tokens"] + counters[
            "prompt_cache_miss_tokens"
        ] != counters["prompt_tokens"]:
            raise LLMUsageError("llm_usage prompt cache totals are inconsistent")
        if counters["total_tokens"] != counters["derived_total_tokens"]:
            raise LLMUsageError("llm_usage provider total_tokens is inconsistent")

    ledgers_raw = usage["attempt_ledgers"]
    if not isinstance(ledgers_raw, Sequence) or isinstance(
        ledgers_raw, (str, bytes, bytearray)
    ):
        raise LLMUsageError("llm_usage.attempt_ledgers must be a list")
    ledgers = [
        _validate_ledger(item, label=f"llm_usage.attempt_ledgers[{index}]")
        for index, item in enumerate(ledgers_raw)
    ]
    if any(ledger["available"] is not True for ledger in ledgers):
        raise LLMUsageError("aggregate attempt ledgers must be available")

    # Reproduce the aggregator's deterministic shared-ledger deduplication.
    expected_by_identity: dict[tuple[str, int], dict[str, Any]] = {}
    for agent in agents.values():
        ledger = agent["attempt_ledger"]
        if ledger["available"] is not True:
            continue
        key = (ledger["identity_sha256"], ledger["hard_cap"])
        prior = expected_by_identity.get(key)
        if prior is None or ledger["attempts_used"] > prior["attempts_used"]:
            expected_by_identity[key] = ledger
    expected_ledgers = [
        expected_by_identity[key] for key in sorted(expected_by_identity)
    ]
    if ledgers != expected_ledgers:
        raise LLMUsageError(
            "llm_usage.attempt_ledgers does not match deduplicated agent ledgers"
        )
    durable = usage["durable_http_attempts"]
    if ledgers:
        durable_count = _nonnegative_int(durable, "llm_usage.durable_http_attempts")
        if durable_count != sum(ledger["attempts_used"] for ledger in ledgers):
            raise LLMUsageError("llm_usage durable attempt total is inconsistent")
    elif durable is not None:
        raise LLMUsageError(
            "llm_usage.durable_http_attempts must be null without a ledger"
        )

    if require_complete:
        if not all(
            availability[field] is True
            for field in (
                "complete",
                "provider_fields_complete",
                "covers_durable_attempt_history",
            )
        ):
            raise LLMUsageError(
                "formal complete run requires complete provider and durable usage"
            )
        if counters["successful_http_calls"] <= 0:
            raise LLMUsageError("formal complete run reports no successful LLM calls")
        if len(ledgers) != 1:
            raise LLMUsageError(
                "formal complete run requires exactly one paid-attempt ledger"
            )
        if usage["durable_http_attempts"] != counters["http_attempts_local"]:
            raise LLMUsageError(
                "formal complete run has incomplete local/durable attempt accounting"
            )
        if any(
            agent["attempt_ledger"]["available"] is not True
            or agent["attempt_ledger"]["attempts_at_client_start"] != 0
            for agent in agents.values()
        ):
            raise LLMUsageError(
                "formal complete run does not cover its full ledger history"
            )

    # All strings are fixed tokens, hashes, roles, or validated exception class
    # names; exact schemas above leave no slot for prompts, responses, keys, or
    # paths.  Return a detached copy without altering the audited values.
    return deepcopy(dict(usage))


def normalize_minimax_cache_omissions(
    value: object, *, omission_attested: bool = False
) -> dict[str, Any]:
    """Normalize a usage record after an externally verified cache-field omission.

    A schema-1 record cannot distinguish an omitted MiniMax
    ``prompt_tokens_details.cached_tokens`` field from an explicit invalid
    value.  Consequently this function never infers omission from the artifact
    alone: callers must explicitly attest that the provider field
    was absent.  Once attested, the repair is deterministic.  Each missing
    cache-hit observation becomes zero and the corresponding aggregate prompt
    tokens become cache misses; all other counters remain unchanged.
    """
    if omission_attested is not True:
        raise LLMUsageError(
            "cache-field normalization requires explicit omission attestation"
        )
    repaired = validate_llm_usage(value, require_complete=False)
    if repaired["schema_version"] != 1:
        raise LLMUsageError("cache-field normalization requires schema 1")

    total_omissions = 0
    for role in ("generator", "reviewer"):
        agent = repaired["agents"][role]
        calls = int(agent["successful_http_calls"])
        availability = agent["usage_availability"]
        observations = availability["field_observations"]
        if (
            availability["responses_with_usage"] != calls
            or availability["responses_without_usage"] != 0
            or availability["covers_durable_attempt_history"] is not True
        ):
            raise LLMUsageError(
                f"schema-1 {role} audit has a non-cache availability gap"
            )
        for field in ("prompt_tokens", "completion_tokens", "total_tokens"):
            if observations[field] != calls:
                raise LLMUsageError(
                    f"schema-1 {role} audit is missing non-cache field {field}"
                )
        cache_hit_observations = observations["prompt_cache_hit_tokens"]
        cache_miss_observations = observations[
            "prompt_cache_miss_tokens"
        ]
        if cache_hit_observations != cache_miss_observations:
            raise LLMUsageError(
                f"schema-1 {role} cache observation counts disagree"
            )
        omissions = calls - cache_hit_observations
        if omissions < 0:
            raise LLMUsageError(
                f"schema-1 {role} cache observations exceed successful calls"
            )
        residual_prompt_tokens = (
            int(agent["prompt_tokens"])
            - int(agent["prompt_cache_hit_tokens"])
            - int(agent["prompt_cache_miss_tokens"])
        )
        if residual_prompt_tokens < 0 or (
            omissions == 0 and residual_prompt_tokens != 0
        ):
            raise LLMUsageError(
                f"schema-1 {role} cache totals cannot be repaired deterministically"
            )
        agent["prompt_cache_miss_tokens"] += residual_prompt_tokens
        observations["prompt_cache_hit_tokens"] = calls
        observations["prompt_cache_miss_tokens"] = calls
        availability["provider_fields_complete"] = True
        availability["complete"] = (
            availability["covers_durable_attempt_history"] is True
        )
        agent["schema_version"] = LLM_USAGE_SCHEMA_VERSION
        agent["normalization_provenance"] = {
            "schema_version": 1,
            "rule_id": MINIMAX_CACHE_OMISSION_RULE_ID,
            "cached_tokens_omission_count": omissions,
        }
        total_omissions += omissions

    if total_omissions <= 0:
        raise LLMUsageError("usage record contains no cache omission to repair")

    agents = repaired["agents"]
    for field in _COUNTER_FIELDS:
        repaired[field] = sum(int(agent[field]) for agent in agents.values())
    aggregate_availability = repaired["usage_availability"]
    aggregate_availability["complete"] = all(
        agent["usage_availability"]["complete"] is True
        for agent in agents.values()
    )
    aggregate_availability["provider_fields_complete"] = all(
        agent["usage_availability"]["provider_fields_complete"] is True
        for agent in agents.values()
    )
    aggregate_availability["covers_durable_attempt_history"] = all(
        agent["usage_availability"]["covers_durable_attempt_history"] is True
        for agent in agents.values()
    )
    for field in _PROVIDER_TOKEN_FIELDS:
        aggregate_availability["field_observations"][field] = sum(
            int(agent["usage_availability"]["field_observations"][field])
            for agent in agents.values()
        )
    repaired["schema_version"] = LLM_USAGE_SCHEMA_VERSION
    repaired["normalization_provenance"] = {
        "schema_version": 1,
        "rule_id": MINIMAX_CACHE_OMISSION_RULE_ID,
        "cached_tokens_omission_count": total_omissions,
    }
    return validate_llm_usage(repaired, require_complete=True)


__all__ = [
    "LLMUsageError",
    "normalize_minimax_cache_omissions",
    "validate_llm_usage",
]
