"""Canonical identity and validation for the paper's ADMET evaluation."""

from __future__ import annotations

import hashlib
from importlib.metadata import PackageNotFoundError, version as package_version
import json
import math
from collections.abc import Mapping, Sequence
from typing import Any

from rdkit import rdBase

from pharmagent.agents.admet_analyst import (
    ADMETAnalystAgent,
    _DEFAULT_PROPERTY_SCALES,
)
from pharmagent.tools.admet_predictor import (
    ADMET_AI_INFERENCE_MODE_CANONICAL_SINGLETON,
    ADMETPredictor,
)
from pharmagent.tools.sa_scorer import (
    SAScoreUnavailableError,
    SA_SCORE_FAILURE_POLICY,
    SA_SCORE_IMPLEMENTATION,
    get_sa_score_provenance,
)


PROTOCOL_SCHEMA_VERSION = "pharmagent.admet-evaluation"


class ADMETProtocolError(ValueError):
    """Raised when ADMET provenance is absent, malformed, or inconsistent."""


def _canonical_number(value: object, field: str) -> int | float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ADMETProtocolError(f"{field} must be numeric")
    number = float(value)
    if not math.isfinite(number):
        raise ADMETProtocolError(f"{field} must be finite")
    return int(number) if number.is_integer() else number


def _canonical_json(value: Mapping[str, Any]) -> str:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    )


def semantic_sha256(descriptor: Mapping[str, Any]) -> str:
    """Hash an ADMET descriptor independently of the surrounding run config."""
    return hashlib.sha256(_canonical_json(descriptor).encode("utf-8")).hexdigest()


def _installed_admet_ai_version() -> str:
    try:
        return package_version("admet-ai")
    except PackageNotFoundError as error:
        raise ADMETProtocolError(
            "the admet-ai package must be installed to identify the formal protocol"
        ) from error


def _source_endpoint(prediction_key: str) -> str | None:
    matches = [
        source
        for source, target in ADMETPredictor._ADMET_AI_PROPERTY_MAP.items()
        if target == prediction_key
    ]
    if len(matches) > 1:
        raise ADMETProtocolError(
            f"prediction key {prediction_key!r} maps to multiple ADMET-AI endpoints"
        )
    return matches[0] if matches else None


def build_admet_protocol(
    config: Mapping[str, Any],
    *,
    admet_ai_version: str | None = None,
    rdkit_version: str | None = None,
) -> dict[str, Any]:
    """Return the canonical, self-hashing ADMET semantic provenance block.

    Only fields that affect ADMET annotation are represented.  LLM, RAG,
    optimizer, scheduling, and filesystem fields therefore cannot invalidate
    an otherwise identical post-hoc evaluation protocol.
    """
    admet = config.get("admet", config)
    if not isinstance(admet, Mapping):
        raise ADMETProtocolError("admet config must be a mapping")
    if admet.get("backend") != "admet_ai":
        raise ADMETProtocolError("formal ADMET evaluation requires backend=admet_ai")
    if admet.get("fallback_to_rdkit", True) is not False:
        raise ADMETProtocolError("formal ADMET evaluation forbids RDKit fallback")
    if admet.get("allow_approximate_endpoint_fallback", True) is not False:
        raise ADMETProtocolError(
            "formal ADMET evaluation forbids approximate endpoint fallback"
        )
    if (
        admet.get("inference_mode")
        != ADMET_AI_INFERENCE_MODE_CANONICAL_SINGLETON
    ):
        raise ADMETProtocolError(
            "formal ADMET evaluation requires "
            "inference_mode=canonical_singleton"
        )
    if admet.get("models_dir") not in (None, ""):
        raise ADMETProtocolError(
            "custom ADMET-AI models_dir is not supported without model-asset hashes"
        )
    missing_prediction_policy = admet.get("missing_prediction_policy", "neutral")
    if missing_prediction_policy not in {"neutral", "fail"}:
        raise ADMETProtocolError(
            "admet.missing_prediction_policy must be 'neutral' or 'fail'"
        )

    constraints = admet.get("admet_constraints")
    if not isinstance(constraints, Mapping) or not constraints:
        raise ADMETProtocolError("admet_constraints must be a non-empty mapping")

    normalized_constraints = []
    aliases = ADMETAnalystAgent._CONSTRAINT_ALIASES
    for name in sorted(constraints):
        definition = constraints[name]
        if not isinstance(name, str) or not isinstance(definition, Mapping):
            raise ADMETProtocolError("each ADMET constraint must be a named mapping")
        constraint_type = definition.get("type", "max")
        if constraint_type not in {"min", "max"}:
            raise ADMETProtocolError(
                f"constraint {name!r} has invalid type {constraint_type!r}"
            )
        if "threshold" not in definition:
            raise ADMETProtocolError(f"constraint {name!r} has no threshold")
        threshold = _canonical_number(
            definition["threshold"], f"admet_constraints.{name}.threshold"
        )
        prediction_key = aliases.get(name, name)
        scale_value = definition.get("scale")
        if scale_value is None:
            scale_value = _DEFAULT_PROPERTY_SCALES.get(
                name,
                abs(float(threshold)) if abs(float(threshold)) > 1e-6 else 1.0,
            )
        normalized_constraints.append(
            {
                "name": name,
                "type": constraint_type,
                "threshold": threshold,
                "weight": _canonical_number(
                    definition.get("weight", 1.0),
                    f"admet_constraints.{name}.weight",
                ),
                "steepness": _canonical_number(
                    definition.get("steepness", 5.0),
                    f"admet_constraints.{name}.steepness",
                ),
                "scale": _canonical_number(
                    scale_value, f"admet_constraints.{name}.scale"
                ),
                "prediction_key": prediction_key,
                "admet_ai_source_endpoint": _source_endpoint(prediction_key),
            }
        )

    resolved_admet_version = admet_ai_version or _installed_admet_ai_version()
    resolved_rdkit_version = rdkit_version or rdBase.rdkitVersion
    if not resolved_admet_version or not resolved_rdkit_version:
        raise ADMETProtocolError("ADMET-AI and RDKit versions must be non-empty")
    try:
        sa_score_provenance = get_sa_score_provenance(
            rdkit_version=str(resolved_rdkit_version)
        )
    except SAScoreUnavailableError as error:
        raise ADMETProtocolError(
            f"formal SA Score implementation is unavailable: {error}"
        ) from error

    descriptor = {
        "backend": {
            "name": "admet_ai",
            "version": str(resolved_admet_version),
            "fallback_to_rdkit": False,
            "inference_mode": ADMET_AI_INFERENCE_MODE_CANONICAL_SINGLETON,
            "model_source": "package_default",
            "model_options": {
                "include_physchem": False,
                "drugbank_path": None,
            },
        },
        "descriptor_backend": {
            "name": "rdkit",
            "version": str(resolved_rdkit_version),
        },
        "sa_score": sa_score_provenance,
        "constraint_logic": {
            "allow_approximate_endpoint_fallback": False,
            "max_violation": "value > threshold",
            "min_violation": "value < threshold",
            "missing_prediction_policy": missing_prediction_policy,
            "missing_prediction": (
                "discrete_violation_and_zero_continuous_score"
                if missing_prediction_policy == "fail"
                else "no_discrete_violation_and_neutral_continuous_score"
            ),
            "continuous_score": "weighted_sigmoid_mean",
        },
        "constraints": normalized_constraints,
    }
    return {
        "schema_version": PROTOCOL_SCHEMA_VERSION,
        "semantic_sha256": semantic_sha256(descriptor),
        "descriptor": descriptor,
    }


def validate_admet_protocol(
    protocol: object,
    *,
    expected_semantic_sha256: str | None = None,
) -> str:
    """Validate a persisted protocol block and return its semantic hash."""
    if not isinstance(protocol, Mapping):
        raise ADMETProtocolError("ADMET protocol provenance must be a mapping")
    if protocol.get("schema_version") != PROTOCOL_SCHEMA_VERSION:
        raise ADMETProtocolError("unsupported ADMET protocol provenance schema")
    descriptor = protocol.get("descriptor")
    if not isinstance(descriptor, Mapping):
        raise ADMETProtocolError("ADMET protocol descriptor must be a mapping")
    observed_hash = protocol.get("semantic_sha256")
    if not isinstance(observed_hash, str) or len(observed_hash) != 64:
        raise ADMETProtocolError("ADMET semantic_sha256 is malformed")
    recomputed = semantic_sha256(descriptor)
    if observed_hash != recomputed:
        raise ADMETProtocolError("ADMET semantic_sha256 does not match its descriptor")
    if expected_semantic_sha256 is not None and observed_hash != expected_semantic_sha256:
        raise ADMETProtocolError(
            "ADMET protocol differs from the expected thresholds/backend/version"
        )

    backend = descriptor.get("backend")
    if not isinstance(backend, Mapping) or any(
        (
            backend.get("name") != "admet_ai",
            backend.get("fallback_to_rdkit") is not False,
            backend.get("inference_mode")
            != ADMET_AI_INFERENCE_MODE_CANONICAL_SINGLETON,
            not isinstance(backend.get("version"), str),
            not backend.get("version"),
        )
    ):
        raise ADMETProtocolError("ADMET backend provenance is not strict ADMET-AI")
    if any(
        (
            backend.get("model_source") != "package_default",
            backend.get("model_options")
            != {"include_physchem": False, "drugbank_path": None},
        )
    ):
        raise ADMETProtocolError("ADMET-AI model provenance is not the package default")
    descriptor_backend = descriptor.get("descriptor_backend")
    if not isinstance(descriptor_backend, Mapping) or any(
        (
            descriptor_backend.get("name") != "rdkit",
            not isinstance(descriptor_backend.get("version"), str),
            not descriptor_backend.get("version"),
        )
    ):
        raise ADMETProtocolError("RDKit descriptor backend provenance is malformed")
    sa_score = descriptor.get("sa_score")
    if not isinstance(sa_score, Mapping) or set(sa_score) != {
        "implementation",
        "rdkit_version",
        "failure_policy",
        "fragment_scores",
    }:
        raise ADMETProtocolError("SA Score provenance is incomplete")
    fragment_scores = sa_score.get("fragment_scores")
    if (
        sa_score.get("implementation") != SA_SCORE_IMPLEMENTATION
        or sa_score.get("failure_policy") != SA_SCORE_FAILURE_POLICY
        or sa_score.get("rdkit_version") != descriptor_backend.get("version")
        or not isinstance(fragment_scores, Mapping)
        or set(fragment_scores) != {"logical_name", "sha256", "size_bytes"}
        or fragment_scores.get("logical_name")
        != "rdkit/Contrib/SA_Score/fpscores.pkl.gz"
        or not isinstance(fragment_scores.get("sha256"), str)
        or len(fragment_scores["sha256"]) != 64
        or any(
            character not in "0123456789abcdef"
            for character in fragment_scores["sha256"]
        )
        or isinstance(fragment_scores.get("size_bytes"), bool)
        or not isinstance(fragment_scores.get("size_bytes"), int)
        or fragment_scores["size_bytes"] <= 0
    ):
        raise ADMETProtocolError("SA Score provenance is malformed")
    constraint_logic = descriptor.get("constraint_logic")
    if (
        not isinstance(constraint_logic, Mapping)
        or constraint_logic.get("missing_prediction_policy") not in {"neutral", "fail"}
        or constraint_logic.get("allow_approximate_endpoint_fallback") is not False
    ):
        raise ADMETProtocolError("ADMET constraint-logic provenance is malformed")
    constraints = descriptor.get("constraints")
    if not isinstance(constraints, list) or not constraints:
        raise ADMETProtocolError("ADMET protocol constraints are missing")
    names = set()
    required_fields = {
        "name",
        "type",
        "threshold",
        "weight",
        "steepness",
        "scale",
        "prediction_key",
        "admet_ai_source_endpoint",
    }
    for index, constraint in enumerate(constraints):
        if not isinstance(constraint, Mapping) or not required_fields.issubset(
            constraint
        ):
            raise ADMETProtocolError(
                f"ADMET protocol constraint {index} is malformed"
            )
        name = constraint["name"]
        if not isinstance(name, str) or not name or name in names:
            raise ADMETProtocolError("ADMET protocol constraint names are invalid")
        names.add(name)
        if constraint["type"] not in {"min", "max"}:
            raise ADMETProtocolError(
                f"ADMET protocol constraint {name!r} has an invalid type"
            )
        for field in ("threshold", "weight", "steepness", "scale"):
            _canonical_number(constraint[field], f"constraints.{name}.{field}")
    return observed_hash


def validate_admet_records(
    records: Sequence[Mapping[str, Any]], protocol: Mapping[str, Any]
) -> None:
    """Ensure every annotated record used the declared backend and version."""
    validate_admet_protocol(protocol)
    descriptor = protocol["descriptor"]
    expected_backend = descriptor["backend"]["name"]
    expected_version = descriptor["backend"]["version"]
    constraint_names = {
        constraint["name"] for constraint in descriptor["constraints"]
    }
    if not records:
        raise ADMETProtocolError("ADMET records must be non-empty")
    for index, record in enumerate(records):
        if not isinstance(record, Mapping):
            raise ADMETProtocolError(f"ADMET record {index} must be a mapping")
        if record.get("admet_backend") != expected_backend:
            raise ADMETProtocolError(
                f"ADMET record {index} backend differs from provenance"
            )
        if record.get("admet_ai_version") != expected_version:
            raise ADMETProtocolError(
                f"ADMET record {index} ADMET-AI version differs from provenance"
            )
        names = record.get("violation_names")
        count = record.get("n_violations")
        if not isinstance(names, list) or any(
            name not in constraint_names for name in names
        ):
            raise ADMETProtocolError(
                f"ADMET record {index} contains missing or unknown constraint violations"
            )
        if isinstance(count, bool) or not isinstance(count, int) or count != len(names):
            raise ADMETProtocolError(
                f"ADMET record {index} violation count is inconsistent"
            )
        if not isinstance(record.get("pass_all"), bool) or record.get(
            "pass_all"
        ) != (len(names) == 0):
            raise ADMETProtocolError(
                f"ADMET record {index} pass_all is inconsistent"
            )


def protocol_from_run(run: Mapping[str, Any]) -> Mapping[str, Any]:
    provenance = run.get("provenance")
    if not isinstance(provenance, Mapping):
        raise ADMETProtocolError("run provenance must be a mapping")
    protocol = provenance.get("admet_evaluation_protocol")
    if not isinstance(protocol, Mapping):
        raise ADMETProtocolError("run has no canonical ADMET protocol provenance")
    return protocol
