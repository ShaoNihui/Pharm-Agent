"""
Shared oracle wrappers used across experiment scripts.

Provides deduplication, call counting, and budget enforcement.
"""

import logging
import math
import hashlib
import json
from copy import deepcopy
from typing import Any, Mapping

from rdkit import Chem

from pharmagent.optimization.novelty_recovery import (
    NoveltyRecoveryProtocolError,
    replay_novelty_recovery_lineage,
    validate_novelty_recovery_result,
)
from pharmagent.optimization.curriculum_protocol import (
    validate_curriculum_lagrangian_evidence,
)
from pharmagent.optimization.lagrangian import (
    compute_canonical_lagrangian_score,
)
from pharmagent.optimization.run_state_protocol import (
    PublicRunStateError,
    replay_native_loop_state,
)
from pharmagent.optimization.llm_request_protocol import (
    validate_public_llm_request_audit,
)
from pharmagent.optimization.near_feasible_archive import (
    CANONICAL_FULL_ADMET_CONSTRAINTS,
    NearFeasibleRepairProtocolError,
    normalize_constraint_assessments,
    validate_near_feasible_repair_result,
)
from pharmagent.evaluation.native_run import (
    IndeterminateOracleCallError,
    NativeRunJournal,
)

logger = logging.getLogger(__name__)


# Fixed active-set schedule for the PharmAgent ADMET experiment.
# The resume validator requires checkpoints to match this schedule exactly.
_FORMAL_EASY_ADMET_CONSTRAINTS = (
    "lipinski_mw",
    "lipinski_logp",
    "qed",
    "sa_score",
)
_FORMAL_FULL_ADMET_CONSTRAINTS = _FORMAL_EASY_ADMET_CONSTRAINTS + (
    "cyp2d6_inh",
    "herg",
    "caco2",
)
_FORMAL_LAGRANGIAN_PROTOCOL = {
    "rho_init": 1.0,
    "rho_growth": 1.5,
    "rho_max": 100.0,
    "rho_growth_rule": "accepted_violation_only",
    "reset_rho_on_phase_transition": True,
    "phase_transition_rule": "strict_active_constraint_set_expansion",
    "rho_lower_bound": 1.0,
    "lambda_transition_rule": "retain_all_learned_lambdas",
}
_FORMAL_ACTIVE_SET_TRANSITIONS = (
    ((), _FORMAL_EASY_ADMET_CONSTRAINTS),
    (_FORMAL_EASY_ADMET_CONSTRAINTS, _FORMAL_FULL_ADMET_CONSTRAINTS),
)


def _has_formal_rho_trajectory(result: Mapping[str, Any]) -> bool:
    """Validate every formal dual update against controller/oracle evidence."""
    trajectory = result.get("lagrangian_trajectory")
    outer_trajectory = result.get("trajectory")
    transition_events = result.get("lagrangian_transition_events")
    history = result.get("evaluation_history")
    if (
        not isinstance(trajectory, list)
        or not isinstance(outer_trajectory, list)
        or not isinstance(transition_events, list)
        or not isinstance(history, list)
    ):
        return False

    allowed_active_sets = {
        _FORMAL_EASY_ADMET_CONSTRAINTS,
        _FORMAL_FULL_ADMET_CONSTRAINTS,
    }
    allowed_outer_active_sets = allowed_active_sets | {()}
    outer_dual_rows = []
    transition_outer_rows: list[
        tuple[Mapping[str, Any], tuple[str, ...], tuple[str, ...]]
    ] = []
    seen_outer_rounds: set[int] = set()
    previous_outer_round = -1
    previous_outer_oracle_calls = 0
    previous_outer_active: tuple[str, ...] = ()
    for outer in outer_trajectory:
        if not isinstance(outer, Mapping):
            return False
        round_idx = outer.get("round")
        if (
            isinstance(round_idx, bool)
            or not isinstance(round_idx, int)
            or round_idx < 0
            or round_idx in seen_outer_rounds
            or round_idx <= previous_outer_round
        ):
            return False
        seen_outer_rounds.add(round_idx)
        active = outer.get("active_constraints")
        n_candidates = outer.get("n_candidates")
        oracle_calls = outer.get("oracle_calls")
        if (
            not isinstance(active, list)
            or tuple(active) not in allowed_outer_active_sets
            or isinstance(n_candidates, bool)
            or not isinstance(n_candidates, int)
            or n_candidates < 0
            or isinstance(oracle_calls, bool)
            or not isinstance(oracle_calls, int)
            or oracle_calls < previous_outer_oracle_calls
            or oracle_calls > len(history)
        ):
            return False
        previous_outer_round = round_idx
        previous_outer_oracle_calls = oracle_calls
        active_tuple = tuple(active)
        if active_tuple != previous_outer_active:
            expected_next = (
                _FORMAL_EASY_ADMET_CONSTRAINTS
                if previous_outer_active == ()
                else (
                    _FORMAL_FULL_ADMET_CONSTRAINTS
                    if previous_outer_active
                    == _FORMAL_EASY_ADMET_CONSTRAINTS
                    else None
                )
            )
            if active_tuple != expected_next:
                return False
            transition_outer_rows.append(
                (outer, previous_outer_active, active_tuple)
            )
            previous_outer_active = active_tuple
        if (
            active_tuple in allowed_active_sets
            and n_candidates > 0
        ):
            outer_dual_rows.append(outer)
    if len(trajectory) != len(outer_dual_rows):
        return False
    if len(transition_events) != len(transition_outer_rows):
        return False
    for event, (outer, previous_active, active) in zip(
        transition_events, transition_outer_rows, strict=True
    ):
        if (
            not isinstance(event, Mapping)
            or event.get("round") != outer.get("round")
            or event.get("previous_active_constraints")
            != list(previous_active)
            or event.get("active_constraints") != list(active)
        ):
            return False

    history_by_smiles: dict[str, Mapping[str, Any]] = {}
    for expected_index, history_row in enumerate(history, start=1):
        context = (
            history_row.get("oracle_context")
            if isinstance(history_row, Mapping)
            else None
        )
        if (
            not isinstance(history_row, Mapping)
            or history_row.get("call_index") != expected_index
            or not isinstance(history_row.get("smiles"), str)
            or history_row["smiles"] in history_by_smiles
            or not isinstance(context, Mapping)
        ):
            return False
        if expected_index <= min(26, len(history)):
            if dict(context) != {
                "scope": "seed_pool",
                "seed_pool_index": expected_index - 1,
            }:
                return False
        else:
            context_round = context.get("round")
            candidate_index = context.get("candidate_index")
            if (
                set(context) != {"scope", "round", "candidate_index"}
                or context.get("scope") != "optimization_round"
                or isinstance(context_round, bool)
                or not isinstance(context_round, int)
                or context_round < 0
                or isinstance(candidate_index, bool)
                or not isinstance(candidate_index, int)
                or candidate_index < 0
            ):
                return False
        history_by_smiles[history_row["smiles"]] = history_row

    def _finite_nonnegative_number(value: object) -> bool:
        return (
            not isinstance(value, bool)
            and isinstance(value, (int, float))
            and math.isfinite(float(value))
            and float(value) >= 0.0
        )

    def _record_sha256(record: Mapping[str, Any]) -> str | None:
        try:
            payload = json.dumps(
                dict(record),
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=False,
                allow_nan=False,
            ).encode("utf-8")
        except (TypeError, ValueError, OverflowError):
            return None
        return hashlib.sha256(payload).hexdigest()

    previous_active: tuple[str, ...] = ()
    previous_lambdas = {
        name: 0.0 for name in _FORMAL_FULL_ADMET_CONSTRAINTS
    }
    previous_rho = _FORMAL_LAGRANGIAN_PROTOCOL["rho_init"]
    observed_transition_events: list[Mapping[str, Any]] = []
    previous_transition_round = -1

    for row, outer in zip(trajectory, outer_dual_rows, strict=True):
        if not isinstance(row, Mapping) or row.get("event") != "dual_update":
            return False
        round_idx = row.get("round")
        active = row.get("active_constraints")
        if (
            round_idx != outer.get("round")
            or not isinstance(active, list)
            or tuple(active) not in allowed_active_sets
            or active != outer.get("active_constraints")
        ):
            return False
        active_tuple = tuple(active)
        if previous_active and not set(previous_active).issubset(active_tuple):
            return False

        accepted_smiles = row.get("accepted_smiles")
        accepted_call_index = row.get("accepted_oracle_call_index")
        accepted_record_sha = row.get("accepted_oracle_record_sha256")
        history_row = history_by_smiles.get(accepted_smiles)
        if (
            not isinstance(accepted_smiles, str)
            or history_row is None
            or accepted_smiles != outer.get("accepted_smiles")
            or accepted_call_index != outer.get("accepted_oracle_call_index")
            or accepted_record_sha
            != outer.get("accepted_oracle_record_sha256")
            or history_row.get("call_index") != accepted_call_index
            or _record_sha256(history_row) != accepted_record_sha
        ):
            return False
        try:
            accepted_assessments = normalize_constraint_assessments(
                row.get("accepted_constraint_assessments"),
                expected_names=active,
                reject_missing=True,
            )
            full_history_assessments = normalize_constraint_assessments(
                history_row.get("constraint_assessments"),
                expected_names=CANONICAL_FULL_ADMET_CONSTRAINTS,
                reject_missing=True,
            )
        except NearFeasibleRepairProtocolError:
            return False
        history_by_name = {
            assessment["name"]: assessment
            for assessment in full_history_assessments
        }
        if accepted_assessments != [history_by_name[name] for name in active]:
            return False

        violations = row.get("violations")
        lambdas = row.get("lambdas")
        expected_violations = {
            assessment["name"]: float(
                assessment["normalized_violation"]
            )
            for assessment in accepted_assessments
        }
        if (
            not isinstance(violations, Mapping)
            or set(violations) != set(active)
            or not isinstance(lambdas, Mapping)
            or set(lambdas) != set(_FORMAL_FULL_ADMET_CONSTRAINTS)
            or any(
                not _finite_nonnegative_number(value)
                for value in violations.values()
            )
            or any(
                not _finite_nonnegative_number(value)
                for value in lambdas.values()
            )
            or any(
                not math.isclose(
                    float(violations[name]),
                    expected_violations[name],
                    abs_tol=1e-12,
                )
                for name in active
            )
            or not _finite_nonnegative_number(row.get("total_violation"))
            or not _finite_nonnegative_number(row.get("rho_used"))
            or not _finite_nonnegative_number(row.get("rho"))
        ):
            return False
        violation_values = [float(violations[name]) for name in active]
        lambda_values = [
            float(lambdas[name]) for name in _FORMAL_FULL_ADMET_CONSTRAINTS
        ]
        total = float(row["total_violation"])
        rho_used = float(row["rho_used"])
        rho_after = float(row["rho"])
        if (
            not math.isclose(total, sum(violation_values), abs_tol=1e-12)
            or rho_used < _FORMAL_LAGRANGIAN_PROTOCOL["rho_init"]
            or rho_after < _FORMAL_LAGRANGIAN_PROTOCOL["rho_init"]
            or rho_used > _FORMAL_LAGRANGIAN_PROTOCOL["rho_max"]
            or rho_after > _FORMAL_LAGRANGIAN_PROTOCOL["rho_max"]
        ):
            return False

        embedded_events = row.get("active_set_events")
        if not isinstance(embedded_events, list):
            return False
        transition_active = previous_active
        transition_rho = previous_rho
        for embedded in embedded_events:
            if not isinstance(embedded, Mapping):
                return False
            next_active = embedded.get("active_constraints")
            event_round = embedded.get("round")
            retained_lambdas = embedded.get("lambdas_retained")
            if (
                not isinstance(next_active, list)
                or tuple(next_active) not in allowed_active_sets
                or not set(transition_active) < set(next_active)
                or embedded.get("event") != "active_set_expansion"
                or embedded.get("previous_active_constraints")
                != list(transition_active)
                or embedded.get("added_constraints")
                != [
                    name
                    for name in next_active
                    if name not in transition_active
                ]
                or embedded.get("removed_constraints") != []
                or embedded.get("rho_reset") is not True
                or embedded.get("rho_after_transition")
                != _FORMAL_LAGRANGIAN_PROTOCOL["rho_init"]
                or not _finite_nonnegative_number(
                    embedded.get("rho_before_transition")
                )
                or not math.isclose(
                    float(embedded["rho_before_transition"]),
                    transition_rho,
                    abs_tol=1e-12,
                )
                or isinstance(event_round, bool)
                or not isinstance(event_round, int)
                or event_round <= previous_transition_round
                or event_round > round_idx
                or not isinstance(retained_lambdas, Mapping)
                or set(retained_lambdas)
                != set(_FORMAL_FULL_ADMET_CONSTRAINTS)
                or any(
                    not _finite_nonnegative_number(value)
                    for value in retained_lambdas.values()
                )
                or any(
                    not math.isclose(
                        float(retained_lambdas[name]),
                        previous_lambdas[name],
                        abs_tol=1e-12,
                    )
                    for name in _FORMAL_FULL_ADMET_CONSTRAINTS
                )
            ):
                return False
            observed_transition_events.append(embedded)
            transition_active = tuple(next_active)
            transition_rho = _FORMAL_LAGRANGIAN_PROTOCOL["rho_init"]
            previous_transition_round = event_round
        if embedded_events:
            if transition_active != active_tuple:
                return False
            expected_rho_used = _FORMAL_LAGRANGIAN_PROTOCOL["rho_init"]
        else:
            if active_tuple != previous_active:
                return False
            expected_rho_used = previous_rho
        if not math.isclose(rho_used, expected_rho_used, abs_tol=1e-12):
            return False

        def _history_violation_vector(
            record: Mapping[str, Any],
        ) -> dict[str, float] | None:
            try:
                all_assessments = normalize_constraint_assessments(
                    record.get("constraint_assessments"),
                    expected_names=CANONICAL_FULL_ADMET_CONSTRAINTS,
                    reject_missing=True,
                )
            except NearFeasibleRepairProtocolError:
                return None
            by_name = {
                assessment["name"]: assessment
                for assessment in all_assessments
            }
            return {
                name: float(by_name[name]["normalized_violation"])
                for name in active
            }

        def _preupdate_score(record: Mapping[str, Any]) -> float | None:
            vector = _history_violation_vector(record)
            try:
                target = float(record.get("raw_target_score"))
            except (TypeError, ValueError, OverflowError):
                return None
            if vector is None or not math.isfinite(target):
                return None
            return compute_canonical_lagrangian_score(
                target,
                vector,
                previous_lambdas,
                rho_used,
                active,
            )

        source_smiles = outer.get("source_smiles")
        source_record = history_by_smiles.get(source_smiles)
        outer_oracle_calls = outer.get("oracle_calls")
        outer_n_candidates = outer.get("n_candidates")
        if (
            source_record is None
            or isinstance(outer_oracle_calls, bool)
            or not isinstance(outer_oracle_calls, int)
            or isinstance(outer_n_candidates, bool)
            or not isinstance(outer_n_candidates, int)
            or outer_n_candidates <= 0
            or outer_n_candidates > outer_oracle_calls
            or outer_oracle_calls > len(history)
        ):
            return False
        candidate_start = outer_oracle_calls - outer_n_candidates + 1
        candidate_records = history[
            candidate_start - 1:outer_oracle_calls
        ]
        novelty_audit = outer.get("novelty_audit")
        globally_novel_count = (
            novelty_audit.get("globally_novel_count")
            if isinstance(novelty_audit, Mapping)
            else None
        )
        if (
            isinstance(globally_novel_count, bool)
            or not isinstance(globally_novel_count, int)
            or globally_novel_count < outer_n_candidates
        ):
            return False
        candidate_context_indices = []
        for candidate_record in candidate_records:
            context = candidate_record.get("oracle_context")
            if (
                not isinstance(context, Mapping)
                or context.get("scope") != "optimization_round"
                or context.get("round") != round_idx
            ):
                return False
            candidate_context_indices.append(context.get("candidate_index"))
        if any(
            isinstance(index, bool) or not isinstance(index, int)
            for index in candidate_context_indices
        ) or any(
            index < 0 or index >= globally_novel_count
            for index in candidate_context_indices
        ) or any(
            previous >= current
            for previous, current in zip(
                candidate_context_indices,
                candidate_context_indices[1:],
                strict=False,
            )
        ):
            return False
        source_score = _preupdate_score(source_record)
        if source_score is None:
            return False
        winner_record = None
        winner_score = float("-inf")
        for candidate_record in candidate_records:
            candidate_score = _preupdate_score(candidate_record)
            if candidate_score is None:
                return False
            if candidate_score > winner_score:
                winner_record = candidate_record
                winner_score = candidate_score
        expected_improves = bool(
            winner_record is not None and winner_score > source_score
        )
        expected_accepted_smiles = (
            winner_record["smiles"]
            if expected_improves
            else source_smiles
        )
        expected_accepted_score = (
            winner_score if expected_improves else source_score
        )
        try:
            controller_values_match = (
                math.isclose(
                    float(outer.get("source_combined_score")),
                    source_score,
                    abs_tol=1e-12,
                )
                and math.isclose(
                    float(outer.get("best_combined")),
                    expected_accepted_score,
                    abs_tol=1e-12,
                )
                and math.isclose(
                    float(outer.get("best_score")),
                    float(
                        history_by_smiles[expected_accepted_smiles][
                            "raw_target_score"
                        ]
                    ),
                    abs_tol=1e-12,
                )
            )
        except (KeyError, TypeError, ValueError, OverflowError):
            return False
        if (
            outer.get("candidate_improves") is not expected_improves
            or accepted_smiles != expected_accepted_smiles
            or not controller_values_match
        ):
            return False

        for name in _FORMAL_FULL_ADMET_CONSTRAINTS:
            expected_lambda = previous_lambdas[name]
            if name in active:
                expected_lambda += rho_used * float(violations[name])
            if not math.isclose(
                float(lambdas[name]), expected_lambda, abs_tol=1e-12
            ):
                return False
        expected_growth_trigger = total > 0.0
        expected_rho = (
            min(
                rho_used * _FORMAL_LAGRANGIAN_PROTOCOL["rho_growth"],
                _FORMAL_LAGRANGIAN_PROTOCOL["rho_max"],
            )
            if expected_growth_trigger
            else rho_used
        )
        expected_numeric_increase = expected_rho > rho_used
        if (
            row.get("rho_growth_rule")
            != _FORMAL_LAGRANGIAN_PROTOCOL["rho_growth_rule"]
            or row.get("rho_grew") is not expected_growth_trigger
            or row.get("rho_increased") is not expected_numeric_increase
            or not math.isclose(rho_after, expected_rho, abs_tol=1e-12)
            or not isinstance(row.get("rho_reset"), bool)
            or row.get("rho_reset") is not bool(embedded_events)
        ):
            return False
        previous_active = active_tuple
        previous_lambdas = {
            name: lambda_values[index]
            for index, name in enumerate(_FORMAL_FULL_ADMET_CONSTRAINTS)
        }
        previous_rho = rho_after
    return observed_transition_events == transition_events


def _has_lagrangian_phase_protocol_prefix(
    result: Mapping[str, Any], *, expected_event_count: int | None
) -> bool:
    """Validate all observed transitions as a strict formal-protocol prefix."""
    protocol = result.get("lagrangian_protocol")
    if (
        not isinstance(protocol, Mapping)
        or dict(protocol) != _FORMAL_LAGRANGIAN_PROTOCOL
        or not _has_formal_rho_trajectory(result)
    ):
        return False

    events = result.get("lagrangian_transition_events")
    if not isinstance(events, list):
        return False
    if expected_event_count is None:
        if len(events) > len(_FORMAL_ACTIVE_SET_TRANSITIONS):
            return False
    elif len(events) != expected_event_count:
        return False

    for event, (previous, active) in zip(
        events, _FORMAL_ACTIVE_SET_TRANSITIONS, strict=False
    ):
        if not isinstance(event, Mapping):
            return False
        round_index = event.get("round")
        if (
            event.get("event") != "active_set_expansion"
            or isinstance(round_index, bool)
            or not isinstance(round_index, int)
            or round_index < 0
            or event.get("previous_active_constraints") != list(previous)
            or event.get("active_constraints") != list(active)
            or event.get("added_constraints")
            != [name for name in active if name not in previous]
            or event.get("removed_constraints") != []
            or event.get("rho_reset") is not True
            or event.get("rho_after_transition")
            != _FORMAL_LAGRANGIAN_PROTOCOL["rho_init"]
        ):
            return False
        rho_before = event.get("rho_before_transition")
        lambdas = event.get("lambdas_retained")
        if (
            isinstance(rho_before, bool)
            or not isinstance(rho_before, (int, float))
            or not math.isfinite(float(rho_before))
            or float(rho_before) <= 0
            or not isinstance(lambdas, Mapping)
            or set(lambdas) != set(_FORMAL_FULL_ADMET_CONSTRAINTS)
        ):
            return False
        for value in lambdas.values():
            if (
                isinstance(value, bool)
                or not isinstance(value, (int, float))
                or not math.isfinite(float(value))
                or float(value) < 0
            ):
                return False
    return all(
        previous["round"] < current["round"]
        for previous, current in zip(events, events[1:], strict=False)
    )


def _has_current_lagrangian_phase_protocol(result: Mapping[str, Any]) -> bool:
    """Validate the complete formal curriculum/rho-reset provenance.

    This intentionally applies only when a caller opts in.  Some evaluation
    ablations disable the Lagrangian or curriculum, so ``require_admet=True``
    alone must not impose the full-method transition protocol on those runs.
    """
    return (
        validate_curriculum_lagrangian_evidence(
            trajectory=result.get("trajectory"),
            round_failure_history=result.get("round_failure_history"),
            curriculum_transition_history=result.get(
                "curriculum_transition_history"
            ),
            final_stagnation_count=result.get("final_stagnation_count"),
            lagrangian_transition_events=result.get(
                "lagrangian_transition_events"
            ),
            require_terminal=True,
        )
        and _has_lagrangian_phase_protocol_prefix(
            result, expected_event_count=len(_FORMAL_ACTIVE_SET_TRANSITIONS)
        )
    )


def canonicalize_oracle_smiles(smiles: object) -> str | None:
    """Return one RDKit-canonical molecule identity, or ``None`` if invalid."""
    if not isinstance(smiles, str) or not smiles.strip():
        return None
    try:
        molecule = Chem.MolFromSmiles(smiles)
    except Exception:
        return None
    if molecule is None:
        return None
    return Chem.MolToSmiles(molecule)


class TrackedOracle:
    """Wraps a base oracle with call tracking, deduplication, and budget.

    Args:
        base_oracle: Underlying scoring function (TDC Oracle or callable).
        name: Task name.
        max_calls: Maximum allowed oracle invocations.
    """

    def __init__(
        self,
        base_oracle,
        name: str,
        max_calls: int,
        *,
        native_journal: NativeRunJournal | None = None,
    ):
        self.oracle = base_oracle
        self.name = name
        self.max_calls = max_calls
        self.native_journal = native_journal
        self._native_call_context: dict[str, Any] = {}
        self.call_count = 0
        self.mol_buffer: dict[str, float] = {}
        self.finish = False
        self.oracle_backend = "tdc"
        self.used_dummy_oracle = False
        if self.native_journal is not None:
            self._hydrate_native_calls()

    def _hydrate_native_calls(self) -> None:
        """Restore exact target scores without invoking the base oracle."""
        assert self.native_journal is not None
        for call in self.native_journal.oracle_calls():
            if call["stage"] == "pending":
                # We cannot know whether the local scorer returned before the
                # process stopped.  Reissuing would violate no-repeat resume.
                raise IndeterminateOracleCallError(
                    "oracle call was interrupted before its score was durably "
                    "recorded; refusing automatic duplicate evaluation"
                )
            score = float(call["raw_target_score"])
            self.mol_buffer[call["smiles"]] = score
            if call["stage"] == "raw_scored":
                self.native_journal.complete_oracle_call(
                    call["smiles"],
                    {
                        "call_index": call["call_index"],
                        "smiles": call["smiles"],
                        "raw_target_score": score,
                        "oracle_context": deepcopy(call["context"]),
                    },
                )
        self.call_count = self.native_journal.oracle_scored_count
        self.finish = self.call_count >= self.max_calls

    def set_native_call_context(self, context: Mapping[str, Any] | None) -> None:
        self._native_call_context = dict(context or {})

    def __call__(self, smiles):
        if isinstance(smiles, list):
            return [self(s) for s in smiles]

        canonical = canonicalize_oracle_smiles(smiles)
        if canonical is None:
            logger.warning("Invalid SMILES was not counted by oracle: %r", smiles)
            return 0.0

        # Deduplicate by molecular identity, never by user-supplied notation.
        if canonical in self.mol_buffer:
            return self.mol_buffer[canonical]
        if self.finish:
            return 0.0

        native_call = None
        if self.native_journal is not None:
            native_call = self.native_journal.reserve_oracle_call(
                canonical, context=self._native_call_context
            )
            if not native_call["newly_reserved"]:
                if native_call["stage"] == "pending":
                    raise IndeterminateOracleCallError(
                        "oracle call is indeterminate; refusing automatic replay"
                    )
                return float(native_call["raw_target_score"])

        try:
            score = float(self.oracle(canonical))
        except Exception:
            logger.warning(
                "Oracle scoring failed for %s, not counting toward budget", canonical
            )
            return 0.0
        if not math.isfinite(score):
            logger.warning(
                "Oracle returned a non-finite score for %s; not counting toward budget",
                canonical,
            )
            return 0.0

        if self.native_journal is not None:
            assert native_call is not None
            self.native_journal.record_raw_oracle_score(canonical, score)
            self.native_journal.complete_oracle_call(
                canonical,
                {
                    "call_index": native_call["call_index"],
                    "smiles": canonical,
                    "raw_target_score": score,
                    "oracle_context": deepcopy(native_call["context"]),
                },
            )

        self.call_count += 1
        self.mol_buffer[canonical] = score

        if self.call_count >= self.max_calls:
            self.finish = True

        return score


class DummyOracle:
    """QED-based dummy oracle for testing without TDC installed.

    Uses RDKit QED as a proxy score so experiments can run without
    external oracle dependencies.
    """

    def __init__(self, name: str, max_calls: int):
        self.name = name
        self.max_calls = max_calls
        self.call_count = 0
        self.mol_buffer: dict[str, float] = {}
        self.finish = False
        self.oracle_backend = "dummy_qed"
        self.used_dummy_oracle = True

    def __call__(self, smiles):
        if isinstance(smiles, list):
            return [self(s) for s in smiles]
        canonical = canonicalize_oracle_smiles(smiles)
        if canonical is None:
            return 0.0
        if canonical in self.mol_buffer:
            return self.mol_buffer[canonical]
        if self.finish:
            return 0.0

        from rdkit import Chem
        from rdkit.Chem import QED

        mol = Chem.MolFromSmiles(canonical)
        score = QED.qed(mol) if mol else 0.0

        self.call_count += 1
        self.mol_buffer[canonical] = score
        if self.call_count >= self.max_calls:
            self.finish = True
        return score


def create_oracle(
    task_name: str,
    oracle_budget: int,
    *,
    allow_dummy: bool = False,
    native_journal: NativeRunJournal | None = None,
):
    """Create a strict PyTDC oracle for a PMO task.

    The QED dummy exists only for explicit smoke tests.  Formal experiment
    runners use the strict default and fail rather than emitting fake PMO
    results when PyTDC is unavailable.
    """
    try:
        from tdc import Oracle
        base = Oracle(name=task_name)
        return TrackedOracle(
            base,
            name=task_name,
            max_calls=oracle_budget,
            native_journal=native_journal,
        )
    except ImportError as error:
        if not allow_dummy:
            raise RuntimeError(
                "PyTDC is required for formal PMO experiments; refusing to "
                "substitute the QED dummy oracle. Install PyTDC, or pass "
                "allow_dummy=True only for an explicitly labeled smoke test."
            ) from error
        logger.warning(
            "SMOKE TEST ONLY: PyTDC is unavailable; using the dummy QED "
            "oracle for task %s. These results are not valid PMO results.",
            task_name,
        )
        return DummyOracle(name=task_name, max_calls=oracle_budget)


def is_complete_pmo_result(
    result: Mapping[str, Any],
    *,
    task: str,
    seed: int,
    oracle_budget: int,
    require_admet: bool = False,
    require_lagrangian_phase_protocol: bool = False,
    require_formal_reproduction_identity: bool = False,
    expected_formal_identity_sha256: str | None = None,
    require_novelty_recovery_protocol: bool = False,
    novelty_recovery_reviewer_enabled: bool = True,
    require_near_feasible_repair_protocol: bool = False,
    require_native_run_journal: bool = False,
) -> bool:
    """Validate a resumable formal result from its per-call trace."""
    if not isinstance(result, Mapping):
        return False
    if (
        isinstance(seed, bool)
        or not isinstance(seed, int)
        or seed < 0
        or isinstance(oracle_budget, bool)
        or not isinstance(oracle_budget, int)
        or oracle_budget <= 0
    ):
        return False
    if not (
        result.get("status") == "complete"
        and result.get("task") == task
        and result.get("seed") == seed
        and result.get("oracle_budget") == oracle_budget
        and result.get("oracle_backend") == "tdc"
        and result.get("used_dummy_oracle") is False
    ):
        return False

    history = result.get("evaluation_history")
    metrics = result.get("metrics")
    if (
        not isinstance(history, list)
        or len(history) != oracle_budget
        or not isinstance(metrics, Mapping)
    ):
        return False
    call_indices = []
    canonical_smiles = []
    for row in history:
        if not isinstance(row, Mapping):
            return False
        call_index = row.get("call_index")
        molecule = row.get("smiles")
        if (
            isinstance(call_index, bool)
            or not isinstance(call_index, int)
            or not isinstance(molecule, str)
            or not molecule
        ):
            return False
        call_indices.append(call_index)
        canonical = canonicalize_oracle_smiles(molecule)
        if canonical is None or molecule != canonical:
            return False
        canonical_smiles.append(canonical)
    if sorted(call_indices) != list(range(1, oracle_budget + 1)):
        return False
    if len(set(canonical_smiles)) != oracle_budget:
        return False
    if require_admet and not all(
        isinstance(row, Mapping)
        and "admet_score" in row
        and "pass_all" in row
        for row in history
    ):
        return False
    if (
        require_lagrangian_phase_protocol
        and not _has_current_lagrangian_phase_protocol(result)
    ):
        return False
    if (
        require_formal_reproduction_identity
        or expected_formal_identity_sha256 is not None
    ):
        try:
            from pharmagent.evaluation.formal_identity import (
                validate_formal_reproduction_identity,
            )

            formal_identity = validate_formal_reproduction_identity(
                result.get("formal_reproduction_identity")
            )
            from pharmagent.evaluation.llm_usage import validate_llm_usage
            from pharmagent.optimization.formal_prompt_protocol import (
                validate_formal_prompt_reuse_memory,
                validate_formal_prompt_reuse_protocol,
            )
            validate_llm_usage(result.get("llm_usage"), require_complete=True)
            validate_formal_prompt_reuse_protocol(
                result.get("formal_prompt_reuse_protocol")
            )
            validate_formal_prompt_reuse_memory(
                result.get("memory"),
                evaluation_history=history,
                target_property=task,
                allowed_active_constraint_names=(
                    _FORMAL_FULL_ADMET_CONSTRAINTS
                    if require_admet
                    else ()
                ),
            )
            attempted_rounds = [
                int(row["round"])
                for row in result.get("trajectory", [])
            ] + [
                int(event["round"])
                for event in result.get("round_failure_history", [])
            ]
            inferred_max_rounds = (
                max(attempted_rounds) + 1 if attempted_rounds else 1
            )
            snapshot = result.get("native_run_journal")
            public_state = (
                snapshot.get("optimizer_public_state")
                if isinstance(snapshot, Mapping)
                else None
            )
            max_rounds = (
                public_state.get("max_rounds")
                if isinstance(public_state, Mapping)
                and isinstance(public_state.get("max_rounds"), int)
                and not isinstance(public_state.get("max_rounds"), bool)
                and public_state["max_rounds"] > 0
                else inferred_max_rounds
            )
            selected_seed = max(
                enumerate(history[:26]),
                key=lambda pair: (
                    float(pair[1]["raw_target_score"]), -pair[0]
                ),
            )[1]["smiles"]
            replayed = replay_native_loop_state(
                trajectory=result.get("trajectory"),
                round_failure_history=result.get(
                    "round_failure_history"
                ),
                evaluation_history=history,
                seed_smiles=selected_seed,
                target_property=task,
                stage="terminal",
                next_round=max_rounds,
                max_rounds=max_rounds,
                allowed_active_constraint_names=(
                    _FORMAL_FULL_ADMET_CONSTRAINTS
                    if require_admet
                    else ()
                ),
                curriculum_transition_history=result.get(
                    "curriculum_transition_history"
                ),
                oracle_complete_count=len(history),
                lagrangian_enabled=isinstance(
                    result.get("lagrangian_trajectory"), list
                ),
                reviewer_enabled=novelty_recovery_reviewer_enabled,
                require_reviewer_feedback=False,
                memory_capacity=(
                    0 if result.get("variant") == "single_agent" else 100
                ),
                initial_admet_score=0.0 if require_admet else 1.0,
            )
            if result.get("memory") != replayed["memory_buffer"]:
                return False
        except ValueError:
            return False
        if (
            expected_formal_identity_sha256 is not None
            and formal_identity["identity_sha256"]
            != expected_formal_identity_sha256
        ):
            return False
    if (
        require_novelty_recovery_protocol
        and not validate_novelty_recovery_result(
            result,
            require_evaluation_history_binding=True,
            expected_reviewer_enabled=(
                novelty_recovery_reviewer_enabled
            ),
        )
    ):
        return False
    if (
        require_near_feasible_repair_protocol
        and not validate_near_feasible_repair_result(
            result, require_evaluation_history_binding=True
        )
    ):
        return False
    if require_native_run_journal and not _has_valid_native_run_snapshot(
        result,
        history=history,
        oracle_budget=oracle_budget,
        expected_phase="admet" if require_admet else "standard",
        require_full_controller=require_lagrangian_phase_protocol,
    ):
        return False

    try:
        from pharmagent.evaluation.metrics import compute_pmo_run_metrics

        expected_metrics = compute_pmo_run_metrics(
            history, oracle_budget=oracle_budget
        )
        call_count = len(history)
        return (
            dict(metrics) == expected_metrics
            and call_count == oracle_budget
            and result.get("total_oracle_calls") == oracle_budget
            and result.get("actual_oracle_calls") == oracle_budget
        )
    except (KeyError, TypeError, ValueError):
        return False


def is_complete_diagnostic_smoke_result(
    result: Mapping[str, Any],
    *,
    task: str,
    seed: int,
    oracle_budget: int,
    expected_formal_identity_sha256: str,
    require_admet: bool = False,
    require_lagrangian_phase_protocol_prefix: bool = False,
    require_novelty_recovery_protocol: bool = False,
    require_near_feasible_repair_protocol: bool = False,
    require_native_run_journal: bool = False,
) -> bool:
    """Validate a real, paid, reduced-budget smoke as diagnostic-only.

    A diagnostic result has its own status and explicit non-eligibility labels;
    a detached copy is then checked by the formal trace/identity/usage logic.
    For ADMET smokes, observed active-set expansions must be an exact prefix of
    the two-transition formal protocol, but the prefix may be incomplete.
    """
    if not isinstance(result, Mapping):
        return False
    if (
        result.get("status") != "diagnostic_complete"
        or result.get("run_mode") != "paid_diagnostic_smoke"
        or result.get("eligibility_status")
        != "diagnostic_only_not_submission_eligible"
        or result.get("formal_table_eligible") is not False
        or result.get("submission_eligible") is not False
    ):
        return False
    diagnostic = result.get("diagnostic_smoke")
    if (
        not isinstance(diagnostic, Mapping)
        or diagnostic.get("schema_version") != 1
        or diagnostic.get("observed_oracle_budget") != oracle_budget
        or diagnostic.get("reduced_budget") is not True
        or diagnostic.get("publication_eligible") is not False
        or diagnostic.get("underlying_optimizer_status") != "complete"
        or diagnostic.get("underlying_termination_reason")
        != "oracle_budget_exhausted"
    ):
        return False
    configured_formal_budget = diagnostic.get(
        "configured_formal_oracle_budget"
    )
    if (
        isinstance(configured_formal_budget, bool)
        or not isinstance(configured_formal_budget, int)
        or configured_formal_budget <= oracle_budget
    ):
        return False

    formal_identity = result.get("formal_reproduction_identity")
    if (
        not isinstance(formal_identity, Mapping)
        or not isinstance(formal_identity.get("matrix_scope"), str)
        or not formal_identity["matrix_scope"].startswith("paid_smoke_")
    ):
        return False

    formal_candidate = dict(result)
    formal_candidate["status"] = "complete"
    formal_candidate["termination_reason"] = diagnostic.get(
        "underlying_termination_reason"
    )
    if not is_complete_pmo_result(
        formal_candidate,
        task=task,
        seed=seed,
        oracle_budget=oracle_budget,
        require_admet=require_admet,
        require_lagrangian_phase_protocol=False,
        require_novelty_recovery_protocol=(
            require_novelty_recovery_protocol
        ),
        require_near_feasible_repair_protocol=(
            require_near_feasible_repair_protocol
        ),
        require_native_run_journal=require_native_run_journal,
        expected_formal_identity_sha256=expected_formal_identity_sha256,
    ):
        return False
    if require_lagrangian_phase_protocol_prefix:
        if not require_admet or diagnostic.get("phase") != "admet":
            return False
        events = result.get("lagrangian_transition_events")
        if (
            not isinstance(events, list)
            or diagnostic.get("formal_active_set_expansions_required")
            != len(_FORMAL_ACTIVE_SET_TRANSITIONS)
            or diagnostic.get("observed_active_set_expansions") != len(events)
            or not _has_lagrangian_phase_protocol_prefix(
                result, expected_event_count=None
            )
        ):
            return False
    elif diagnostic.get("phase") != "standard":
        return False
    return True


def _has_valid_native_run_snapshot(
    result: Mapping[str, Any],
    *,
    history: list,
    oracle_budget: int,
    expected_phase: str,
    require_full_controller: bool,
) -> bool:
    """Validate path-free native provenance against the publication trace."""
    snapshot = result.get("native_run_journal")
    expected_snapshot_keys = {
        "schema_version",
        "public_snapshot_schema_version",
        "identity",
        "identity_sha256",
        "oracle_complete_count",
        "oracle_trace_sha256",
        "llm_request_counts",
        "llm_request_audit",
        "llm_request_audit_sha256",
        "optimizer_state_revision",
        "optimizer_state_sha256",
        "optimizer_public_state",
        "optimizer_public_state_sha256",
        "public_state_identity_binding_sha256",
    }
    if (
        not isinstance(snapshot, Mapping)
        or set(snapshot) != expected_snapshot_keys
        or snapshot.get("schema_version") != 1
        or snapshot.get("public_snapshot_schema_version") != 2
        or result.get("budget_complete") is not True
        or result.get("termination_reason") != "oracle_budget_exhausted"
    ):
        return False
    identity = snapshot.get("identity")
    identity_sha = snapshot.get("identity_sha256")
    state_sha = snapshot.get("optimizer_state_sha256")
    revision = snapshot.get("optimizer_state_revision")
    public_state = snapshot.get("optimizer_public_state")
    public_state_sha = snapshot.get("optimizer_public_state_sha256")
    public_binding_sha = snapshot.get(
        "public_state_identity_binding_sha256"
    )
    if (
        not isinstance(identity, Mapping)
        or not isinstance(identity_sha, str)
        or len(identity_sha) != 64
        or not isinstance(state_sha, str)
        or len(state_sha) != 64
        or isinstance(revision, bool)
        or not isinstance(revision, int)
        or revision <= 0
        or snapshot.get("oracle_complete_count") != oracle_budget
        or not isinstance(public_state, Mapping)
        or not isinstance(public_state_sha, str)
        or len(public_state_sha) != 64
        or not isinstance(public_binding_sha, str)
        or len(public_binding_sha) != 64
    ):
        return False
    try:
        canonical_identity_payload = json.dumps(
            dict(identity),
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        ).encode("utf-8")
        canonical_public_payload = json.dumps(
            dict(public_state),
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        ).encode("utf-8")
        binding_payload = json.dumps(
            {
                "identity_sha256": identity_sha,
                "optimizer_public_state_sha256": public_state_sha,
            },
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        ).encode("utf-8")
        trace_payload = json.dumps(
            history,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        ).encode("utf-8")
    except (TypeError, ValueError):
        return False
    if (
        hashlib.sha256(canonical_identity_payload).hexdigest()
        != identity_sha
        or hashlib.sha256(canonical_public_payload).hexdigest()
        != public_state_sha
        or hashlib.sha256(binding_payload).hexdigest()
        != public_binding_sha
    ):
        return False
    expected_formal_identity = result.get("formal_reproduction_identity")
    expected_objective = (
        "admet_constrained" if expected_phase == "admet" else "target_only"
    )
    if dict(identity) != {
        "kind": "pharmagent-native-run",
        "identity_version": 1,
        "formal_reproduction_identity": expected_formal_identity,
        "phase": expected_phase,
        "task": result.get("task"),
        "seed": result.get("seed"),
        "oracle_budget": oracle_budget,
        "objective": expected_objective,
    }:
        return False
    if snapshot.get("oracle_trace_sha256") != hashlib.sha256(
        trace_payload
    ).hexdigest():
        return False

    lagrangian_runtime = public_state.get("lagrangian_runtime")
    curriculum_runtime = public_state.get("curriculum_runtime")
    memory = result.get("memory")
    memory_binding = public_state.get("memory_buffer_binding")
    critical_counters = public_state.get("critical_counters")
    terminal_best = public_state.get("terminal_best")
    expected_public_keys = {
        "state_schema_version",
        "stage",
        "target_property",
        "max_rounds",
        "oracle_budget",
        "next_round",
        "trajectory",
        "round_failure_history",
        "lagrangian_runtime",
        "curriculum_runtime",
        "final_stagnation_count",
        "global_seen_canonical",
        "global_seen_initialized",
        "best_feasible",
        "near_feasible_anchors",
        "memory_buffer_binding",
        "critical_counters",
        "terminal_best",
    }
    max_rounds = public_state.get("max_rounds")
    try:
        selected_seed = max(
            enumerate(history[:26]),
            key=lambda pair: (
                float(pair[1]["raw_target_score"]), -pair[0]
            ),
        )[1]["smiles"]
        replayed_public_state = replay_native_loop_state(
            trajectory=result.get("trajectory"),
            round_failure_history=result.get("round_failure_history"),
            evaluation_history=history,
            seed_smiles=selected_seed,
            target_property=result.get("task"),
            stage="terminal",
            next_round=max_rounds,
            max_rounds=max_rounds,
            allowed_active_constraint_names=(
                CANONICAL_FULL_ADMET_CONSTRAINTS
                if expected_phase == "admet"
                else ()
            ),
            curriculum_transition_history=result.get(
                "curriculum_transition_history"
            ),
            oracle_complete_count=len(history),
            lagrangian_enabled=isinstance(
                result.get("lagrangian_trajectory"), list
            ),
            reviewer_enabled=True,
            require_reviewer_feedback=False,
            memory_capacity=(
                0 if result.get("variant") == "single_agent" else 100
            ),
            initial_admet_score=(
                0.0 if expected_phase == "admet" else 1.0
            ),
        )
    except (KeyError, TypeError, ValueError, PublicRunStateError):
        return False
    expected_counters = {
        key: replayed_public_state[key]
        for key in (
            "round_error_count",
            "consecutive_round_errors",
            "successful_scored_rounds",
            "cer_experiences_committed",
            "zero_novel_rounds",
            "failure_count",
            "generation_restart_cursor",
            "pending_generation_restart",
        )
    }
    expected_best_admet_score = replayed_public_state["best_admet_score"]
    expected_memory = replayed_public_state["memory_buffer"]
    if (
        set(public_state) != expected_public_keys
        or public_state.get("stage") != "terminal"
        or public_state.get("state_schema_version") != 6
        or isinstance(max_rounds, bool)
        or not isinstance(max_rounds, int)
        or max_rounds <= 0
        or public_state.get("next_round") != max_rounds
        or public_state.get("target_property") != result.get("task")
        or public_state.get("oracle_budget") != oracle_budget
        or public_state.get("trajectory") != result.get("trajectory")
        or public_state.get("round_failure_history")
        != result.get("round_failure_history")
        or public_state.get("best_feasible") != result.get("best_feasible")
        or public_state.get("near_feasible_anchors")
        != result.get("near_feasible_anchors")
        or not isinstance(memory, list)
        or not isinstance(memory_binding, Mapping)
        or set(memory_binding) != {"count", "sha256"}
        or memory != expected_memory
        or memory_binding.get("count") != len(expected_memory)
        or not isinstance(critical_counters, Mapping)
        or dict(critical_counters) != expected_counters
        or result.get("round_error_count")
        != expected_counters["round_error_count"]
        or result.get("successful_scored_rounds")
        != expected_counters["successful_scored_rounds"]
        or result.get("cer_experiences_committed")
        != expected_counters["cer_experiences_committed"]
        or not isinstance(terminal_best, Mapping)
        or set(terminal_best) != {
            "seed",
            "current",
            "best",
            "best_target_score",
            "best_admet_score",
            "best_combined_score",
        }
        or terminal_best.get("best_target_score")
        != result.get("best_target_score")
        or terminal_best.get("best_admet_score")
        != result.get("best_admet_score")
        or terminal_best.get("best_combined_score")
        != result.get("best_combined_score")
        or result.get("best_target_score")
        != replayed_public_state["best_target_score"]
        or result.get("best_admet_score") != expected_best_admet_score
        or result.get("best_combined_score")
        != replayed_public_state["best_combined"]
    ):
        return False
    try:
        memory_payload = json.dumps(
            memory,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        ).encode("utf-8")
    except (TypeError, ValueError):
        return False
    if memory_binding.get("sha256") != hashlib.sha256(
        memory_payload
    ).hexdigest():
        return False

    for binding_name, replay_key in (
        ("seed", "selected_seed_smiles"),
        ("current", "current_smiles"),
        ("best", "best_smiles"),
    ):
        binding = terminal_best.get(binding_name)
        expected_smiles = replayed_public_state[replay_key]
        if (
            not isinstance(binding, Mapping)
            or set(binding) != {
                "canonical_smiles",
                "canonical_smiles_sha256",
            }
            or dict(binding) != {
                "canonical_smiles": expected_smiles,
                "canonical_smiles_sha256": hashlib.sha256(
                    expected_smiles.encode("utf-8")
                ).hexdigest(),
            }
        ):
            return False
    if result.get("best_smiles") != replayed_public_state["best_smiles"]:
        return False

    try:
        expected_global_seen = replay_novelty_recovery_lineage(
            result,
            require_evaluation_history_binding=True,
            expected_reviewer_enabled=None,
        )
    except NoveltyRecoveryProtocolError:
        return False
    if (
        public_state.get("global_seen_initialized") is not True
        or public_state.get("global_seen_canonical") != expected_global_seen
    ):
        return False

    if expected_phase == "admet":
        lagrangian_keys = {
            "lambdas",
            "rho",
            "trajectory",
            "transition_events",
            "active_constraint_names",
            "pending_transition_events",
        }
        curriculum_keys = {
            "current_phase",
            "last_transition",
            "transition_history",
        }
        if require_full_controller:
            curriculum_history = result.get("curriculum_transition_history")
            dual_trajectory = result.get("lagrangian_trajectory")
            if (
                not isinstance(lagrangian_runtime, Mapping)
                or set(lagrangian_runtime) != lagrangian_keys
                or not isinstance(curriculum_runtime, Mapping)
                or set(curriculum_runtime) != curriculum_keys
                or not isinstance(curriculum_history, list)
                or len(curriculum_history) != 2
                or not isinstance(dual_trajectory, list)
                or not dual_trajectory
                or curriculum_runtime.get("current_phase") != 3
                or curriculum_runtime.get("last_transition")
                != curriculum_history[-1]
            ):
                return False
        if isinstance(lagrangian_runtime, Mapping):
            dual_trajectory = result.get("lagrangian_trajectory")
            if (
                set(lagrangian_runtime) != lagrangian_keys
                or lagrangian_runtime.get("trajectory") != dual_trajectory
                or lagrangian_runtime.get("transition_events")
                != result.get("lagrangian_transition_events")
                or lagrangian_runtime.get("pending_transition_events") != []
                or not isinstance(dual_trajectory, list)
                or not dual_trajectory
                or lagrangian_runtime.get("lambdas")
                != dual_trajectory[-1].get("lambdas")
                or lagrangian_runtime.get("rho")
                != dual_trajectory[-1].get("rho")
                or lagrangian_runtime.get("active_constraint_names")
                != dual_trajectory[-1].get("active_constraints")
            ):
                return False
        elif lagrangian_runtime is not None or require_full_controller:
            return False
        if isinstance(curriculum_runtime, Mapping):
            curriculum_history = result.get("curriculum_transition_history")
            if (
                set(curriculum_runtime) != curriculum_keys
                or curriculum_runtime.get("transition_history")
                != curriculum_history
                or public_state.get("final_stagnation_count")
                != result.get("final_stagnation_count")
            ):
                return False
        elif curriculum_runtime is not None or require_full_controller:
            return False
    elif lagrangian_runtime is not None or curriculum_runtime is not None:
        return False
    counts = snapshot.get("llm_request_counts")
    request_audit = snapshot.get("llm_request_audit")
    if not isinstance(counts, Mapping):
        return False
    allowed = {"prepared", "http_started", "complete", "failed_known"}
    if not set(counts).issubset(allowed):
        return False
    if any(
        isinstance(value, bool)
        or not isinstance(value, int)
        or value < 0
        for value in counts.values()
    ):
        return False
    try:
        request_audit_sha = hashlib.sha256(
            json.dumps(
                request_audit,
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=False,
                allow_nan=False,
            ).encode("utf-8")
        ).hexdigest()
    except (TypeError, ValueError):
        return False
    if (
        not isinstance(request_audit, list)
        or snapshot.get("llm_request_audit_sha256")
        != request_audit_sha
        or not validate_public_llm_request_audit(
            trajectory=result.get("trajectory"),
            round_failure_history=result.get("round_failure_history"),
            request_audit=request_audit,
            request_counts=counts,
        )
    ):
        return False
    return (
        int(counts.get("prepared", 0)) == 0
        and int(counts.get("http_started", 0)) == 0
    )


def upsert_seed_result(seed_results: list, result: Mapping[str, Any]) -> None:
    """Replace any stale/failed entry for the same seed in one task scope."""
    seed = result.get("seed")
    seed_results[:] = [
        previous
        for previous in seed_results
        if not isinstance(previous, Mapping) or previous.get("seed") != seed
    ]
    seed_results.append(dict(result))
    seed_results.sort(
        key=lambda row: int(row.get("seed", -1))
        if isinstance(row, Mapping)
        else -1
    )
