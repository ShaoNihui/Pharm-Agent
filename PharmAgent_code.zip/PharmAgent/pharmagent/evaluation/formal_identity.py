"""Content-addressed identity for paid formal PharmAgent experiments.

The identity binds resumable runs to the canonical MiniMax request protocol,
transitive PharmAgent Python source, formal runners/configs, large RAG assets,
ADMET semantics, and critical dependency versions.  It deliberately excludes
mtimes and absolute paths.
"""

from __future__ import annotations

import hashlib
from importlib.metadata import PackageNotFoundError, version as package_version
import json
from pathlib import Path
from typing import Any, Mapping, MutableMapping, Sequence

import yaml

from pharmagent.config import load_config
from pharmagent.evaluation.admet_protocol import build_admet_protocol
from pharmagent.llm.api_client import (
    MINIMAX_API_KEY_ENV,
    MINIMAX_BACKEND,
    MINIMAX_BASE_URL,
    MINIMAX_MAX_TOKEN_PARAMETER,
    MINIMAX_MODEL,
    MINIMAX_PROVIDER_TRANSPORT,
    MINIMAX_REASONING_SPLIT,
    MINIMAX_REGION,
    MINIMAX_RESPONSE_FORMAT,
    MINIMAX_SERVICE_TIER,
    MINIMAX_THINKING_TYPE,
)
from pharmagent.llm.attempt_ledger import FORMAL_MAX_ROUNDS_PER_RUN
from pharmagent.optimization.novelty_recovery import (
    validate_novelty_recovery_config,
)


FORMAL_IDENTITY_SCHEMA_VERSION = "pharmagent.formal-reproduction"
SOURCE_BUNDLE_SCHEMA_VERSION = "pharmagent.formal-source-bundle"

CANONICAL_MINIMAX_LLM_PROTOCOL = {
    "backend": MINIMAX_BACKEND,
    "model": MINIMAX_MODEL,
    "base_url": MINIMAX_BASE_URL,
    "region": MINIMAX_REGION,
    "provider_transport": MINIMAX_PROVIDER_TRANSPORT,
    "thinking_type": MINIMAX_THINKING_TYPE,
    "reasoning_split": MINIMAX_REASONING_SPLIT,
    "service_tier": MINIMAX_SERVICE_TIER,
    "max_token_parameter": MINIMAX_MAX_TOKEN_PARAMETER,
    "response_format": MINIMAX_RESPONSE_FORMAT,
    "temperature": 0.7,
    "max_tokens": 2048,
    "max_retries": 10,
    "retry_delay": 2,
    "max_retry_delay": 30,
    "max_retry_elapsed": 180,
    "max_transport_recovery_batches": 3,
}

FORMAL_VALIDITY_ONLY_VERIFIER = {
    "check_lipinski": False,
    "check_veber": False,
    "check_pains": False,
    "check_brenk": False,
    "check_sa": False,
    "check_qed": False,
    "max_sa_score": 6.0,
    "min_qed": 0.3,
}
FORMAL_ADMET_CONSTRAINT_SPECS = {
    "lipinski_mw": {"type": "max", "threshold": 500},
    "lipinski_logp": {"type": "max", "threshold": 5.0},
    "qed": {"type": "min", "threshold": 0.3},
    "sa_score": {"type": "max", "threshold": 6.0},
    "cyp2d6_inh": {"type": "max", "threshold": 0.5},
    "herg": {"type": "max", "threshold": 0.5, "scale": 0.3},
    "caco2": {"type": "min", "threshold": -5.15},
}
FORMAL_EASY_ADMET_CONSTRAINTS = (
    "lipinski_mw",
    "lipinski_logp",
    "qed",
    "sa_score",
)
FORMAL_LAGRANGIAN_CONFIG = {
    "enabled": True,
    "rho_init": 1.0,
    "rho_growth": 1.5,
    "rho_max": 100.0,
    "rho_growth_rule": "accepted_violation_only",
    "reset_rho_on_phase_transition": True,
}
FORMAL_CURRICULUM_CONFIG = {
    "enabled": True,
    "transition_policy": "round_boundary_only",
    "phase1_rounds": 20,
    "phase2_rounds": 60,
    "easy_constraints": list(FORMAL_EASY_ADMET_CONSTRAINTS),
    "stagnation_trigger": 5,
}

_FORMAL_GENERATOR_CONFIG = {"n_candidates": 5}
_FORMAL_REVIEWER_CONFIG = {
    "max_stagnation_rounds": 5,
    "allow_early_termination": False,
}
_FORMAL_RAG_POLICY = {
    "require_available": True,
    "allow_generic_fallback": False,
    "top_k": 3,
}
_FORMAL_CER_CONFIG = {
    "enabled": True,
    "max_size": 1000,
    "top_k": 5,
    "fp_radius": 2,
    "fp_nbits": 2048,
}
_FORMAL_EVALUATION_CONFIG = {
    "seeds": 5,
    "save_trajectories": True,
}
_FORMAL_STANDARD_OPTIMIZATION = {
    "objective": "target_only",
    "max_rounds": FORMAL_MAX_ROUNDS_PER_RUN,
    "oracle_budget": 1000,
    "require_full_budget": True,
    "alpha": 1.0,
    "memory_size": 100,
}
_FORMAL_ADMET_OPTIMIZATION = {
    "objective": "admet_constrained",
    "max_rounds": FORMAL_MAX_ROUNDS_PER_RUN,
    "oracle_budget": 1000,
    "require_full_budget": True,
    "alpha": 0.7,
    "memory_size": 100,
}
_FORMAL_STANDARD_ADMET_CONFIG = {
    "backend": "rdkit_only",
    "admet_constraints": {},
}
_FORMAL_ADMET_CONFIG = {
    "backend": "admet_ai",
    "fallback_to_rdkit": False,
    "inference_mode": "canonical_singleton",
    "max_cache_size": 10000,
    "num_workers": 0,
    "darwin_torch_intraop_threads": 1,
    "darwin_torch_interop_threads": 1,
    "missing_prediction_policy": "fail",
    "allow_approximate_endpoint_fallback": False,
    "admet_constraints": FORMAL_ADMET_CONSTRAINT_SPECS,
}

_CRITICAL_DISTRIBUTIONS = {
    "pytdc": "PyTDC",
    "rdkit": "rdkit",
    "admet_ai": "admet-ai",
    "faiss": "faiss-cpu",
}
_FORMAL_SCRIPT_NAMES = (
    "run_pmo_benchmark.py",
    "run_admet_pmo.py",
    "run_distributed_pharmagent.py",
    "prepare_mmp_data.py",
    "build_faiss_index.py",
)
_REQUIRED_LOCAL_ORACLE_ASSETS = (
    "drd2_current.pkl",
    "gsk3b_current.pkl",
    "jnk3_current.pkl",
)


class FormalIdentityError(ValueError):
    """Raised when formal reproduction provenance is absent or inconsistent."""


def _canonical_json(value: Mapping[str, Any]) -> str:
    try:
        return json.dumps(
            value,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=True,
            allow_nan=False,
        )
    except (TypeError, ValueError) as error:
        raise FormalIdentityError(
            "formal reproduction identity must be canonical-JSON serializable"
        ) from error


def _mapping_sha256(value: Mapping[str, Any]) -> str:
    return hashlib.sha256(_canonical_json(value).encode("utf-8")).hexdigest()


def _is_sha256(value: object) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 64
        and all(character in "0123456789abcdef" for character in value)
    )


def _file_sha256(
    path: Path, cache: MutableMapping[Path, str]
) -> tuple[str, int]:
    resolved = path.expanduser().resolve()
    if not resolved.is_file():
        raise FormalIdentityError(f"formal identity input is unavailable: {resolved}")
    digest = cache.get(resolved)
    if digest is None:
        hasher = hashlib.sha256()
        try:
            with resolved.open("rb") as handle:
                for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
                    hasher.update(chunk)
        except OSError as error:
            raise FormalIdentityError(
                f"cannot hash formal identity input {resolved}: {error}"
            ) from error
        digest = hasher.hexdigest()
        cache[resolved] = digest
    return digest, resolved.stat().st_size


def _resolve_asset(code_dir: Path, declared_path: object, label: str) -> Path:
    if not isinstance(declared_path, str) or not declared_path.strip():
        raise FormalIdentityError(f"{label} must be a non-empty path")
    path = Path(declared_path).expanduser()
    return path.resolve() if path.is_absolute() else (code_dir / path).resolve()


def _load_yaml_mapping(path: Path) -> dict[str, Any]:
    try:
        value = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, yaml.YAMLError) as error:
        raise FormalIdentityError(f"cannot read formal config {path}: {error}") from error
    if not isinstance(value, dict):
        raise FormalIdentityError(f"formal config root is not a mapping: {path}")
    return value


def validate_formal_arm_config(
    value: Mapping[str, Any], phase: str
) -> None:
    """Reject any non-canonical formal arm before identity or paid work.

    ``load_config`` injects the top-level LLM mapping into Generator and
    Reviewer at runtime.  Those two derived ``llm`` keys are ignored; every
    scientific field originating in the YAML remains exact.  In particular,
    callers must validate the on-disk 1000-call protocol before applying a
    diagnostic runtime budget override.
    """
    if phase not in {"standard", "admet"}:
        raise FormalIdentityError(f"unknown formal arm: {phase!r}")
    if not isinstance(value, Mapping):
        raise FormalIdentityError(
            f"{phase} formal config must be a mapping"
        )

    expected_top_level = {
        "llm",
        "generator",
        "novelty_recovery",
        "admet",
        "verifier",
        "reviewer",
        "rag",
        "optimization",
        "cer",
        "evaluation",
    }
    if phase == "admet":
        expected_top_level.update({"lagrangian", "curriculum"})
    if set(value) != expected_top_level:
        raise FormalIdentityError(
            f"{phase} formal config top-level protocol is not exact"
        )

    expected_llm = {
        **CANONICAL_MINIMAX_LLM_PROTOCOL,
        "api_key_env": MINIMAX_API_KEY_ENV,
    }
    expected_llm.pop("response_format")
    if value.get("llm") != expected_llm:
        raise FormalIdentityError(
            f"{phase} formal LLM config is not canonical MiniMax-M3 CN"
        )

    def without_derived_llm(item: object) -> object:
        if not isinstance(item, Mapping):
            return item
        normalized = dict(item)
        normalized.pop("llm", None)
        return normalized

    if without_derived_llm(value.get("generator")) != (
        _FORMAL_GENERATOR_CONFIG
    ):
        raise FormalIdentityError(
            f"{phase} formal Generator config is not canonical"
        )
    if without_derived_llm(value.get("reviewer")) != (
        _FORMAL_REVIEWER_CONFIG
    ):
        raise FormalIdentityError(
            f"{phase} formal Reviewer config is not canonical"
        )
    try:
        validate_novelty_recovery_config(
            value.get("novelty_recovery"),
            require_canonical=True,
            generator_candidate_cap=5,
        )
    except ValueError as error:
        raise FormalIdentityError(
            f"{phase} formal novelty-recovery config is not canonical: "
            f"{error}"
        ) from error
    if value.get("verifier") != FORMAL_VALIDITY_ONLY_VERIFIER:
        raise FormalIdentityError(
            f"{phase} formal verifier must be the exact validity-only mapping"
        )

    rag = value.get("rag")
    rag_paths = {
        "faiss_index_path",
        "mmp_data_path",
        "mmp_manifest_path",
        "asset_manifest_path",
    }
    if (
        not isinstance(rag, Mapping)
        or set(rag) != rag_paths | set(_FORMAL_RAG_POLICY)
        or {
            field: rag.get(field) for field in _FORMAL_RAG_POLICY
        }
        != _FORMAL_RAG_POLICY
        or any(
            not isinstance(rag.get(field), str)
            or not str(rag[field]).strip()
            for field in rag_paths
        )
    ):
        raise FormalIdentityError(
            f"{phase} formal RAG config is not canonical strict retrieval"
        )
    if value.get("cer") != _FORMAL_CER_CONFIG:
        raise FormalIdentityError(
            f"{phase} formal CER config is not canonical"
        )
    if value.get("evaluation") != _FORMAL_EVALUATION_CONFIG:
        raise FormalIdentityError(
            f"{phase} formal evaluation config is not canonical"
        )

    if phase == "standard":
        if value.get("optimization") != _FORMAL_STANDARD_OPTIMIZATION:
            raise FormalIdentityError(
                "standard formal optimization must be exact target_only "
                "PMO-1K"
            )
        if value.get("admet") != _FORMAL_STANDARD_ADMET_CONFIG:
            raise FormalIdentityError(
                "standard formal arm must have no ADMET constraints"
            )
        return

    admet = value.get("admet")
    if not isinstance(admet, Mapping):
        raise FormalIdentityError("ADMET formal config is not a mapping")
    if admet.get("inference_mode") != "canonical_singleton":
        raise FormalIdentityError(
            "formal ADMET protocol requires "
            "inference_mode=canonical_singleton"
        )
    constraints = admet.get("admet_constraints")
    if (
        not isinstance(constraints, Mapping)
        or list(constraints) != list(FORMAL_ADMET_CONSTRAINT_SPECS)
        or dict(constraints) != FORMAL_ADMET_CONSTRAINT_SPECS
    ):
        raise FormalIdentityError(
            "ADMET formal arm must pin the exact ordered seven constraints"
        )
    if dict(admet) != _FORMAL_ADMET_CONFIG:
        raise FormalIdentityError(
            "ADMET formal backend config is not canonical fail-closed ADMET-AI"
        )
    if value.get("optimization") != _FORMAL_ADMET_OPTIMIZATION:
        raise FormalIdentityError(
            "ADMET formal optimization must be exact constrained PMO-1K"
        )
    if value.get("lagrangian") != FORMAL_LAGRANGIAN_CONFIG:
        raise FormalIdentityError(
            "ADMET formal augmented-Lagrangian config is not canonical"
        )
    curriculum = value.get("curriculum")
    if curriculum != FORMAL_CURRICULUM_CONFIG:
        raise FormalIdentityError(
            "ADMET formal curriculum must be boundary-only at rounds 20/60 "
            "with the exact easy active set"
        )


def _load_json_mapping(path: Path, label: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise FormalIdentityError(f"cannot read {label} {path}: {error}") from error
    if not isinstance(value, dict):
        raise FormalIdentityError(f"{label} is not a JSON object: {path}")
    return value


def _build_llm_protocol(configs: Mapping[str, Path]) -> dict[str, Any]:
    """Validate both formal arms against one canonical MiniMax protocol."""
    expected_config = {
        **CANONICAL_MINIMAX_LLM_PROTOCOL,
        "api_key_env": MINIMAX_API_KEY_ENV,
    }
    # ``response_format`` records transport behavior implemented by the
    # client; it is intentionally not a provider request/config field.
    expected_config.pop("response_format")
    for phase, config_path in configs.items():
        config = _load_yaml_mapping(config_path)
        llm = config.get("llm")
        observed = {
            field: llm.get(field) if isinstance(llm, Mapping) else None
            for field in expected_config
        }
        if observed != expected_config:
            raise FormalIdentityError(
                f"{phase} formal LLM config is not canonical MiniMax-M3 CN"
            )
    return dict(CANONICAL_MINIMAX_LLM_PROTOCOL)


def _validate_canonical_novelty_recovery(
    configs: Mapping[str, Path],
) -> None:
    """Fail identity construction unless both arms pin one exact protocol."""
    for phase, config_path in configs.items():
        config = _load_yaml_mapping(config_path)
        generator = config.get("generator")
        candidate_cap = (
            generator.get("n_candidates")
            if isinstance(generator, Mapping)
            else None
        )
        try:
            validate_novelty_recovery_config(
                config.get("novelty_recovery"),
                require_canonical=True,
                generator_candidate_cap=candidate_cap,
            )
        except ValueError as error:
            raise FormalIdentityError(
                f"{phase} formal novelty-recovery config is not canonical: "
                f"{error}"
            ) from error


def _validate_strict_rag_lineage(
    phase: str,
    paths: Mapping[str, Path],
    assets: Mapping[str, Mapping[str, Any]],
    cache: MutableMapping[Path, str],
) -> None:
    mmp_manifest = _load_json_mapping(
        paths["mmp_manifest_path"], f"{phase} strict MMP manifest"
    )
    asset_manifest = _load_json_mapping(
        paths["asset_manifest_path"], f"{phase} RAG asset manifest"
    )
    if (
        mmp_manifest.get("schema_version") != 2
        or mmp_manifest.get("strict_fragmentation_mmp") is not True
        or mmp_manifest.get("algorithm") != "mmpdb_single_cut_same_assay_mmp"
    ):
        raise FormalIdentityError(f"{phase} RAG manifest is not strict MMP")
    if (
        asset_manifest.get("artifact_type")
        != "pharmagent_strict_mmp_faiss_bundle"
        or asset_manifest.get("strict_fragmentation_mmp") is not True
    ):
        raise FormalIdentityError(f"{phase} FAISS manifest is not a strict MMP bundle")
    mmp_data_sha = assets["mmp_data_path"]["sha256"]
    index_sha = assets["faiss_index_path"]["sha256"]
    mmp_manifest_sha = assets["mmp_manifest_path"]["sha256"]
    source = mmp_manifest.get("source")
    upstream = asset_manifest.get("upstream")
    indexed = asset_manifest.get("indexed_data")
    faiss_spec = asset_manifest.get("faiss")
    if not all(isinstance(item, Mapping) for item in (
        source, upstream, indexed, faiss_spec
    )):
        raise FormalIdentityError(f"{phase} RAG provenance chain is incomplete")
    assert isinstance(source, Mapping)
    assert isinstance(upstream, Mapping)
    assert isinstance(indexed, Mapping)
    assert isinstance(faiss_spec, Mapping)
    source_names = {
        "activities": source.get("activities_file"),
        "activities_manifest": source.get("activities_manifest_file"),
        "assays": source.get("assays_file"),
    }
    if any(
        not isinstance(name, str) or Path(name).name != name
        for name in source_names.values()
    ):
        raise FormalIdentityError(
            f"{phase} strict MMP source artifact identity is malformed"
        )
    source_paths = {
        key: paths["mmp_manifest_path"].parent / str(name)
        for key, name in source_names.items()
    }
    source_hashes = {
        key: _file_sha256(path, cache)[0]
        for key, path in source_paths.items()
    }
    if (
        source_hashes["activities"] != source.get("activities_sha256")
        or source_hashes["activities_manifest"]
        != source.get("activities_manifest_sha256")
        or source_hashes["assays"] != source.get("assays_sha256")
    ):
        raise FormalIdentityError(
            f"{phase} strict MMP ChEMBL source SHA chain is inconsistent"
        )
    activity_manifest = _load_json_mapping(
        source_paths["activities_manifest"],
        f"{phase} ChEMBL activity manifest",
    )
    filters = activity_manifest.get("filters")
    confidence = (
        filters.get("confidence_score")
        if isinstance(filters, Mapping)
        else None
    )
    if (
        activity_manifest.get("schema_version") != 2
        or activity_manifest.get("activities_sha256")
        != source.get("activities_sha256")
        or activity_manifest.get("assays_sha256")
        != source.get("assays_sha256")
        or not isinstance(confidence, Mapping)
        or confidence.get("required_value") != 9
    ):
        raise FormalIdentityError(
            f"{phase} strict ChEMBL activity lineage is inconsistent"
        )
    if (
        mmp_manifest.get("pairs_sha256") != mmp_data_sha
        or upstream.get("mmp_pairs_sha256") != mmp_data_sha
        or upstream.get("mmp_pairs_manifest_sha256") != mmp_manifest_sha
        or upstream.get("chembl_activity_source_sha256")
        != source.get("activities_sha256")
        or upstream.get("chembl_activity_manifest_sha256")
        != source.get("activities_manifest_sha256")
        or upstream.get("chembl_assay_source_sha256")
        != source.get("assays_sha256")
        or indexed.get("sha256") != mmp_data_sha
        or faiss_spec.get("index_sha256") != index_sha
    ):
        raise FormalIdentityError(f"{phase} RAG provenance SHA chain is inconsistent")


def build_formal_reproduction_identity(
    *,
    code_dir: str | Path,
    standard_config: str | Path,
    admet_config: str | Path,
    matrix_scope: str,
    task_chain: Sequence[str],
    file_hash_cache: MutableMapping[Path, str] | None = None,
) -> dict[str, Any]:
    """Build one deterministic identity, hashing each large asset at most once.

    ``file_hash_cache`` is intentionally caller-owned and in-memory only.  A
    distributed driver can therefore hash a shared 932-MB FAISS asset once per
    invocation without trusting stale filesystem metadata on a later resume.
    """
    root = Path(code_dir).expanduser().resolve()
    if not isinstance(matrix_scope, str) or not matrix_scope.strip():
        raise FormalIdentityError("formal matrix_scope must be a non-empty string")
    ordered_tasks = tuple(task_chain)
    if (
        not ordered_tasks
        or any(not isinstance(task, str) or not task.strip() for task in ordered_tasks)
        or len(ordered_tasks) != len(set(ordered_tasks))
    ):
        raise FormalIdentityError(
            "formal task_chain must contain unique non-empty task names"
        )
    configs = {
        "standard": Path(standard_config).expanduser().resolve(),
        "admet": Path(admet_config).expanduser().resolve(),
    }
    for phase, config_path in configs.items():
        validate_formal_arm_config(_load_yaml_mapping(config_path), phase)
    llm_protocol = _build_llm_protocol(configs)
    _validate_canonical_novelty_recovery(configs)
    cache: MutableMapping[Path, str] = (
        file_hash_cache if file_hash_cache is not None else {}
    )

    source_inputs: list[tuple[str, Path]] = [
        (path.relative_to(root).as_posix(), path)
        for path in sorted((root / "pharmagent").rglob("*.py"))
    ]
    if not source_inputs:
        raise FormalIdentityError("formal source bundle contains no pharmagent Python")
    for name in _FORMAL_SCRIPT_NAMES:
        source_inputs.append((f"scripts/{name}", root / "scripts" / name))
    source_inputs.extend(
        (f"formal_configs/{phase}.yaml", path)
        for phase, path in configs.items()
    )
    # Bind the execution entry point, protocol, and dependency specification.
    for name in ("run.py", "release_protocol.json", "requirements.txt"):
        source_inputs.append((name, root / name))

    source_files: dict[str, dict[str, Any]] = {}
    for logical_name, path in sorted(source_inputs):
        digest, size = _file_sha256(path, cache)
        source_files[logical_name] = {"sha256": digest, "size_bytes": size}
    source_descriptor = {
        "schema_version": SOURCE_BUNDLE_SCHEMA_VERSION,
        "files": source_files,
    }

    assets: dict[str, dict[str, dict[str, Any]]] = {}
    for phase, config_path in configs.items():
        config = _load_yaml_mapping(config_path)
        rag = config.get("rag")
        if not isinstance(rag, Mapping):
            raise FormalIdentityError(f"{phase} config has no RAG mapping")
        assets[phase] = {}
        phase_paths: dict[str, Path] = {}
        for field in (
            "faiss_index_path",
            "mmp_data_path",
            "mmp_manifest_path",
            "asset_manifest_path",
        ):
            asset_path = _resolve_asset(
                root, rag.get(field), f"{phase}.rag.{field}"
            )
            phase_paths[field] = asset_path
            digest, size = _file_sha256(asset_path, cache)
            assets[phase][field] = {
                "sha256": digest,
                "size_bytes": size,
            }
        _validate_strict_rag_lineage(
            phase, phase_paths, assets[phase], cache
        )

    # PyTDC resolves these three learned scorers from ``CODE_DIR/oracle`` when
    # the suite runs from the repository.  The package version alone therefore
    # cannot identify the actual PMO oracle semantics.
    local_oracle_assets: dict[str, dict[str, Any]] = {}
    for filename in _REQUIRED_LOCAL_ORACLE_ASSETS:
        digest, size = _file_sha256(root / "oracle" / filename, cache)
        local_oracle_assets[filename] = {
            "sha256": digest,
            "size_bytes": size,
        }

    dependencies: dict[str, str] = {}
    for logical_name, distribution in _CRITICAL_DISTRIBUTIONS.items():
        try:
            installed = package_version(distribution)
        except PackageNotFoundError as error:
            raise FormalIdentityError(
                f"critical formal dependency is not installed: {distribution}"
            ) from error
        if not installed:
            raise FormalIdentityError(
                f"critical formal dependency has no version: {distribution}"
            )
        dependencies[logical_name] = str(installed)

    try:
        admet_protocol = build_admet_protocol(load_config(str(configs["admet"])))
    except Exception as error:
        raise FormalIdentityError(
            f"cannot identify formal ADMET semantics: {error}"
        ) from error

    descriptor = {
        "schema_version": FORMAL_IDENTITY_SCHEMA_VERSION,
        "matrix_scope": matrix_scope.strip(),
        "task_chain": list(ordered_tasks),
        "llm_protocol": llm_protocol,
        "source_bundle_sha256": _mapping_sha256(source_descriptor),
        "source_bundle_file_count": len(source_files),
        "formal_config_sha256": {
            phase: source_files[f"formal_configs/{phase}.yaml"]["sha256"]
            for phase in configs
        },
        "rag_assets": assets,
        "local_oracle_assets": local_oracle_assets,
        "sa_score_asset": dict(
            admet_protocol["descriptor"]["sa_score"]["fragment_scores"]
        ),
        "admet_semantic_sha256": admet_protocol["semantic_sha256"],
        "critical_dependency_versions": dependencies,
    }
    return {**descriptor, "identity_sha256": _mapping_sha256(descriptor)}


def validate_formal_reproduction_identity(value: object) -> dict[str, Any]:
    """Validate and return a detached canonical formal identity mapping."""
    if not isinstance(value, Mapping):
        raise FormalIdentityError("formal reproduction identity must be a mapping")
    identity = dict(value)
    required = {
        "schema_version",
        "matrix_scope",
        "task_chain",
        "llm_protocol",
        "source_bundle_sha256",
        "source_bundle_file_count",
        "formal_config_sha256",
        "rag_assets",
        "local_oracle_assets",
        "sa_score_asset",
        "admet_semantic_sha256",
        "critical_dependency_versions",
        "identity_sha256",
    }
    if set(identity) != required:
        raise FormalIdentityError("formal reproduction identity fields are incomplete")
    if identity.get("schema_version") != FORMAL_IDENTITY_SCHEMA_VERSION:
        raise FormalIdentityError("unsupported formal reproduction identity schema")
    matrix_scope = identity.get("matrix_scope")
    if not isinstance(matrix_scope, str) or not matrix_scope.strip():
        raise FormalIdentityError("formal matrix_scope is malformed")
    task_chain = identity.get("task_chain")
    if (
        not isinstance(task_chain, list)
        or not task_chain
        or any(not isinstance(task, str) or not task.strip() for task in task_chain)
        or len(task_chain) != len(set(task_chain))
    ):
        raise FormalIdentityError("formal task_chain is malformed")
    if identity.get("llm_protocol") != CANONICAL_MINIMAX_LLM_PROTOCOL:
        raise FormalIdentityError(
            "formal LLM protocol is not canonical MiniMax-M3 CN"
        )
    if not _is_sha256(identity.get("source_bundle_sha256")):
        raise FormalIdentityError("formal source-bundle SHA-256 is malformed")
    count = identity.get("source_bundle_file_count")
    if isinstance(count, bool) or not isinstance(count, int) or count <= 0:
        raise FormalIdentityError("formal source-bundle file count is invalid")

    config_hashes = identity.get("formal_config_sha256")
    if not isinstance(config_hashes, Mapping) or set(config_hashes) != {
        "standard", "admet"
    } or not all(_is_sha256(item) for item in config_hashes.values()):
        raise FormalIdentityError("formal config SHA-256 mapping is malformed")

    assets = identity.get("rag_assets")
    if not isinstance(assets, Mapping) or set(assets) != {"standard", "admet"}:
        raise FormalIdentityError("formal RAG asset identity is incomplete")
    for phase, phase_assets in assets.items():
        if not isinstance(phase_assets, Mapping) or set(phase_assets) != {
            "faiss_index_path",
            "mmp_data_path",
            "mmp_manifest_path",
            "asset_manifest_path",
        }:
            raise FormalIdentityError(f"{phase} RAG asset identity is incomplete")
        for asset in phase_assets.values():
            if (
                not isinstance(asset, Mapping)
                or set(asset) != {"sha256", "size_bytes"}
                or not _is_sha256(asset.get("sha256"))
                or isinstance(asset.get("size_bytes"), bool)
                or not isinstance(asset.get("size_bytes"), int)
                or asset["size_bytes"] <= 0
            ):
                raise FormalIdentityError("formal RAG asset identity is malformed")

    oracle_assets = identity.get("local_oracle_assets")
    if (
        not isinstance(oracle_assets, Mapping)
        or set(oracle_assets) != set(_REQUIRED_LOCAL_ORACLE_ASSETS)
    ):
        raise FormalIdentityError("formal local-oracle asset identity is incomplete")
    for asset in oracle_assets.values():
        if (
            not isinstance(asset, Mapping)
            or set(asset) != {"sha256", "size_bytes"}
            or not _is_sha256(asset.get("sha256"))
            or isinstance(asset.get("size_bytes"), bool)
            or not isinstance(asset.get("size_bytes"), int)
            or asset["size_bytes"] <= 0
        ):
            raise FormalIdentityError("formal local-oracle asset identity is malformed")

    sa_score_asset = identity.get("sa_score_asset")
    if (
        not isinstance(sa_score_asset, Mapping)
        or set(sa_score_asset) != {"logical_name", "sha256", "size_bytes"}
        or sa_score_asset.get("logical_name")
        != "rdkit/Contrib/SA_Score/fpscores.pkl.gz"
        or not _is_sha256(sa_score_asset.get("sha256"))
        or isinstance(sa_score_asset.get("size_bytes"), bool)
        or not isinstance(sa_score_asset.get("size_bytes"), int)
        or sa_score_asset["size_bytes"] <= 0
    ):
        raise FormalIdentityError("formal SA Score asset identity is malformed")

    if not _is_sha256(identity.get("admet_semantic_sha256")):
        raise FormalIdentityError("formal ADMET semantic SHA-256 is malformed")
    dependencies = identity.get("critical_dependency_versions")
    if not isinstance(dependencies, Mapping) or set(dependencies) != set(
        _CRITICAL_DISTRIBUTIONS
    ) or not all(
        isinstance(item, str) and item.strip() for item in dependencies.values()
    ):
        raise FormalIdentityError("critical dependency versions are incomplete")

    observed = identity.pop("identity_sha256")
    if not _is_sha256(observed) or observed != _mapping_sha256(identity):
        raise FormalIdentityError("formal reproduction identity SHA-256 mismatch")
    identity["identity_sha256"] = observed
    return json.loads(_canonical_json(identity))


def validate_formal_identity_against_current_workspace(
    value: object,
    *,
    code_dir: str | Path,
    matrix_scope: str,
    task_chain: Sequence[str],
    file_hash_cache: MutableMapping[Path, str] | None = None,
) -> dict[str, Any]:
    """Require an identity to equal a fresh full-workspace reconstruction.

    Syntactic self-validation is insufficient for a resumable formal run: an
    identity produced by a different source bundle can remain internally
    consistent.  This validator rebuilds the descriptor from the current
    PharmAgent source tree, both canonical formal configs, all bound assets,
    semantic descriptors, and installed critical dependencies, then compares
    the complete mapping.  Callers supply the expected task order and scope so
    those execution dimensions are part of the same exact comparison.
    """
    supplied = validate_formal_reproduction_identity(value)
    expected = build_formal_reproduction_identity(
        code_dir=code_dir,
        standard_config=Path(code_dir) / "configs" / "pmo_standard.yaml",
        admet_config=Path(code_dir) / "configs" / "pmo_admet.yaml",
        matrix_scope=matrix_scope,
        task_chain=task_chain,
        file_hash_cache=file_hash_cache,
    )
    if supplied != expected:
        mismatched_fields = sorted(
            field
            for field in supplied
            if supplied.get(field) != expected.get(field)
        )
        detail = ", ".join(mismatched_fields) or "unknown field"
        raise FormalIdentityError(
            "formal reproduction identity does not match the current "
            f"workspace reconstruction ({detail})"
        )
    return supplied


def parse_formal_reproduction_identity_json(value: str) -> dict[str, Any]:
    """Parse a command-line identity without accepting non-object JSON."""
    try:
        parsed = json.loads(value)
    except (TypeError, json.JSONDecodeError) as error:
        raise FormalIdentityError(
            "--formal-reproduction-identity must be valid JSON"
        ) from error
    return validate_formal_reproduction_identity(parsed)
