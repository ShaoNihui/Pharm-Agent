__all__ = ["PharmAgentOptimizer"]


def __getattr__(name):
    """Import the optimizer lazily to keep low-level journal imports acyclic."""
    if name == "PharmAgentOptimizer":
        from pharmagent.evaluation.pmo_evaluator import PharmAgentOptimizer

        return PharmAgentOptimizer
    raise AttributeError(name)
