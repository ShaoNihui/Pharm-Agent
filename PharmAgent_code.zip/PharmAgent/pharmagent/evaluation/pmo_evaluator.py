"""
PMO Benchmark adapter — wraps PharmAgent as a PMO-compatible optimizer.

Usage:
    from pharmagent.evaluation.pmo_evaluator import PharmAgentOptimizer
    optimizer = PharmAgentOptimizer(config=pharmagent_config)
    # Use with PMO benchmark runner
"""

import logging
import math
import random
from copy import deepcopy
from typing import Any

from pharmagent.agents.orchestrator import PharmAgentOrchestrator
from pharmagent.llm.api_client import (
    LLM_USAGE_SCHEMA_VERSION,
    MINIMAX_CACHE_OMISSION_RULE_ID,
)
from pharmagent.evaluation.native_run import NativeRunJournal

logger = logging.getLogger(__name__)

# The 23 PMO benchmark tasks
PMO_TASKS = [
    "albuterol_similarity", "amlodipine_mpo", "celecoxib_rediscovery",
    "deco_hop", "drd2", "fexofenadine_mpo", "gsk3b",
    "isomers_c7h8n2o2", "isomers_c9h10n2o2pf2cl", "jnk3",
    "median1", "median2", "mestranol_similarity",
    "osimertinib_mpo", "perindopril_mpo", "qed", "ranolazine_mpo",
    "scaffold_hop", "sitagliptin_mpo", "thiothixene_rediscovery",
    "troglitazone_rediscovery", "valsartan_smarts", "zaleplon_mpo",
]

# Diverse seed molecules covering aromatic, heteroaromatic, aliphatic, and drug-like scaffolds
DEFAULT_SEEDS = [
    # Simple aromatics / heterocycles
    "c1ccccc1",                      # benzene
    "c1ccncc1",                      # pyridine
    "c1ccoc1",                       # furan
    "c1ccsc1",                       # thiophene
    "c1cc[nH]c1",                    # pyrrole
    "C1CCNCC1",                      # piperidine
    "C1CCOCC1",                      # tetrahydropyran
    "C1CCSCC1",                      # tetrahydrothiopyran
    # Approved drugs (diverse scaffolds)
    "CC(=O)Oc1ccccc1C(=O)O",        # aspirin
    "CC(C)Cc1ccc(cc1)C(C)C(=O)O",   # ibuprofen
    "CC(=O)Nc1ccc(O)cc1",           # acetaminophen
    "CC(C)NCC(O)c1ccc(O)c(O)c1",    # isoproterenol
    # Bicyclic / polycyclic
    "c1ccc2ncccc2c1",               # quinoline
    "c1ccc2c(c1)[nH]c1ccccc12",     # carbazole
    "c1ccc2c(c1)cc1ccccc1n2",       # acridine
    # Aliphatic chains / saturated rings
    "CCCCCCCC(=O)O",                 # octanoic acid
    "CC(C)(C)C(=O)O",               # pivalic acid
    "C1CCC(CC1)O",                   # cyclohexanol
    "CC(C)(C)O",                     # tert-butanol
    # Drug-like with functional groups
    "O=C(O)c1ccccc1O",              # salicylic acid
    "c1ccc(cc1)O",                   # phenol
    "NC(=O)c1ccccc1",               # benzamide
    "c1ccc(cc1)S(=O)(=O)N",         # benzenesulfonamide
    "CC(=O)c1ccccc1",               # acetophenone
    # Morpholine / piperazine (common drug motifs)
    "C1COCCN1",                      # morpholine
    "C1CNCCN1",                      # piperazine
]


_AUDITED_TOKEN_FIELDS = (
    "prompt_tokens",
    "prompt_cache_hit_tokens",
    "prompt_cache_miss_tokens",
    "completion_tokens",
    "total_tokens",
    "derived_total_tokens",
)


def _empty_agent_usage(role: str, *, error_type: str | None = None) -> dict:
    availability: dict[str, Any] = {
        "complete": False,
        "provider_fields_complete": False,
        "covers_durable_attempt_history": False,
        "responses_with_usage": 0,
        "responses_without_usage": 0,
        "field_observations": {
            field: 0
            for field in _AUDITED_TOKEN_FIELDS
            if field != "derived_total_tokens"
        },
    }
    if error_type is not None:
        availability["snapshot_error_type"] = error_type
    return {
        "schema_version": LLM_USAGE_SCHEMA_VERSION,
        "client_role": role,
        "successful_http_calls": 0,
        "http_attempts_local": 0,
        **{field: 0 for field in _AUDITED_TOKEN_FIELDS},
        "usage_availability": availability,
        "normalization_provenance": {
            "schema_version": 1,
            "rule_id": MINIMAX_CACHE_OMISSION_RULE_ID,
            "cached_tokens_omission_count": 0,
        },
        "attempt_ledger": {"available": False},
    }


def _agent_usage(orchestrator: object, agent_name: str) -> dict:
    """Collect one agent without allowing audit serialization to hide a run."""
    try:
        agent = getattr(orchestrator, agent_name)
        llm = getattr(agent, "llm")
        snapshot = llm.usage_snapshot()
        if not isinstance(snapshot, dict):
            raise TypeError("usage_snapshot did not return a mapping")
        return snapshot
    except Exception as error:
        # Keep only the exception class.  Provider messages can contain request
        # details, while the audit artifact must never retain prompts or keys.
        return _empty_agent_usage(agent_name, error_type=type(error).__name__)


def _aggregate_llm_usage(orchestrator: object) -> dict:
    """Return a path-free, single-run Generator+Reviewer usage audit."""
    agents = {
        name: _agent_usage(orchestrator, name)
        for name in ("generator", "reviewer")
    }
    totals = {
        "successful_http_calls": sum(
            int(value.get("successful_http_calls", 0) or 0)
            for value in agents.values()
        ),
        "http_attempts_local": sum(
            int(value.get("http_attempts_local", 0) or 0)
            for value in agents.values()
        ),
    }
    for field in _AUDITED_TOKEN_FIELDS:
        totals[field] = sum(
            int(value.get(field, 0) or 0) for value in agents.values()
        )

    field_observations = {
        field: sum(
            int(
                value.get("usage_availability", {})
                .get("field_observations", {})
                .get(field, 0)
                or 0
            )
            for value in agents.values()
        )
        for field in _AUDITED_TOKEN_FIELDS
        if field != "derived_total_tokens"
    }
    availability = {
        "complete": all(
            value.get("usage_availability", {}).get("complete") is True
            for value in agents.values()
        ),
        "provider_fields_complete": all(
            value.get("usage_availability", {}).get(
                "provider_fields_complete"
            ) is True
            for value in agents.values()
        ),
        "covers_durable_attempt_history": all(
            value.get("usage_availability", {}).get(
                "covers_durable_attempt_history"
            ) is True
            for value in agents.values()
        ),
        "responses_with_usage": sum(
            int(
                value.get("usage_availability", {}).get(
                    "responses_with_usage", 0
                )
                or 0
            )
            for value in agents.values()
        ),
        "responses_without_usage": sum(
            int(
                value.get("usage_availability", {}).get(
                    "responses_without_usage", 0
                )
                or 0
            )
            for value in agents.values()
        ),
        "field_observations": field_observations,
    }
    normalized_cache_omissions = sum(
        int(
            value.get("normalization_provenance", {}).get(
                "cached_tokens_omission_count", 0
            )
            or 0
        )
        for value in agents.values()
    )

    # Generator and Reviewer share one formal ledger.  Deduplicate by its
    # non-secret protocol identity hash so the matrix-wide attempt count is not
    # doubled in the aggregate result.
    ledgers_by_identity: dict[tuple[str, int], dict] = {}
    for value in agents.values():
        ledger = value.get("attempt_ledger", {})
        if not isinstance(ledger, dict) or ledger.get("available") is not True:
            continue
        key = (
            str(ledger.get("identity_sha256", "")),
            int(ledger.get("hard_cap", 0) or 0),
        )
        prior = ledgers_by_identity.get(key)
        if prior is None or int(ledger.get("attempts_used", 0) or 0) > int(
            prior.get("attempts_used", 0) or 0
        ):
            ledgers_by_identity[key] = dict(ledger)
    attempt_ledgers = [
        ledgers_by_identity[key] for key in sorted(ledgers_by_identity)
    ]

    return {
        "schema_version": LLM_USAGE_SCHEMA_VERSION,
        "scope": "single_task_seed_run",
        **totals,
        "usage_availability": availability,
        "normalization_provenance": {
            "schema_version": 1,
            "rule_id": MINIMAX_CACHE_OMISSION_RULE_ID,
            "cached_tokens_omission_count": normalized_cache_omissions,
        },
        "durable_http_attempts": (
            sum(
                int(ledger.get("attempts_used", 0) or 0)
                for ledger in attempt_ledgers
            )
            if attempt_ledgers
            else None
        ),
        "attempt_ledgers": attempt_ledgers,
        "agents": agents,
    }


def build_failed_pmo_checkpoint(
    error: Exception,
    *,
    optimizer: "PharmAgentOptimizer",
    oracle: object,
    task: str,
    seed: int,
    oracle_budget: int,
    elapsed_time: float,
    evaluation_history: list[dict],
) -> dict:
    """Build a safe, resumable diagnostic record for a failed native run.

    Exception messages are deliberately excluded because provider errors can
    contain request material.  When the optimizer reached agent construction,
    the path-free usage snapshot attached to the exception is validated before
    it is persisted.  A failed record can never satisfy the strict completion
    validator.
    """
    from pharmagent.evaluation.llm_usage import validate_llm_usage
    from pharmagent.evaluation.metrics import compute_pmo_run_metrics

    usage = getattr(error, "llm_usage", None)
    if usage is None:
        usage = optimizer.last_llm_usage

    result = {
        "status": "failed",
        "termination_reason": "optimizer_exception",
        "exception_type": type(error).__name__,
        "task": task,
        "seed": seed,
        "oracle_budget": oracle_budget,
        "total_oracle_calls": int(getattr(oracle, "call_count", 0) or 0),
        "actual_oracle_calls": int(getattr(oracle, "call_count", 0) or 0),
        "oracle_backend": getattr(oracle, "oracle_backend", "unknown"),
        "used_dummy_oracle": bool(
            getattr(oracle, "used_dummy_oracle", False)
        ),
        "elapsed_time": float(elapsed_time),
        "evaluation_history": deepcopy(evaluation_history),
        "metrics": compute_pmo_run_metrics(
            evaluation_history, oracle_budget=oracle_budget
        ),
    }
    if usage is not None:
        try:
            result["llm_usage"] = validate_llm_usage(
                usage, require_complete=False
            )
        except ValueError as usage_error:
            # Never copy an unsafe/noncanonical snapshot into a checkpoint.
            result["llm_usage_audit_error_type"] = type(usage_error).__name__
    native_journal = getattr(optimizer, "native_run_journal", None)
    if native_journal is not None:
        result["native_run_journal"] = native_journal.snapshot()
    return result


class PharmAgentOptimizer:
    """PMO-compatible optimizer wrapping PharmAgent.

    This class can be used standalone or integrated with the mol_opt
    BaseOptimizer framework.
    """

    def __init__(self, config: dict, *, admet_predictor=None):
        self.config = config
        self.model_name = "PharmAgent"
        # The ADMET runner supplies the same predictor used by its recording
        # oracle.  Sharing the object means the orchestrator and wrapper use
        # one model instance, one endpoint configuration, and one LRU cache.
        self.admet_predictor = admet_predictor
        self.last_llm_usage: dict | None = None
        self.native_run_journal: NativeRunJournal | None = None
        native_spec = config.get("native_run_journal")
        if native_spec is not None:
            self.native_run_journal = NativeRunJournal(
                native_spec["path"], identity=native_spec["identity"]
            )

    def optimize(self, oracle, config: dict | None = None,
                 seed: int = 0) -> dict:
        """Run optimization compatible with PMO benchmark.

        Args:
            oracle: PMO Oracle object or callable.
            config: Optional config overrides.
            seed: Random seed.

        Returns:
            Result dict from PharmAgentOrchestrator.
        """
        random.seed(seed)
        run_config = {**self.config, **(config or {})}
        opt_config = run_config.get("optimization", {})

        oracle_budget = opt_config.get("oracle_budget", 10000)
        max_rounds = opt_config.get("max_rounds", 200)
        require_full_budget = opt_config.get("require_full_budget", False)
        allow_reviewer_termination = run_config.get("reviewer", {}).get(
            "allow_early_termination", True
        )
        if require_full_budget and allow_reviewer_termination:
            raise ValueError(
                "Formal full-budget PMO runs require "
                "reviewer.allow_early_termination=false"
            )
        if require_full_budget and max_rounds < oracle_budget:
            raise ValueError(
                "Formal full-budget PMO runs require max_rounds >= "
                "oracle_budget; refusing to spend oracle calls under an "
                "insufficient round cap"
            )

        # Determine target property name
        target_property = getattr(oracle, "name", "target")
        if hasattr(oracle, "evaluator_name"):
            target_property = oracle.evaluator_name

        # Construct the agents before seed scoring so even a formal seed-pool
        # oracle failure retains an exact zero-attempt ledger/usage snapshot.
        orchestrator = PharmAgentOrchestrator(
            run_config, admet_predictor=self.admet_predictor
        )
        try:
            # Select seed molecule: score the fixed 26-molecule starting pool.
            seed_smiles = self._select_seed(
                oracle,
                oracle_budget,
                require_full_budget=require_full_budget,
            )
            result = orchestrator.optimize(
                seed_smiles=seed_smiles,
                oracle=oracle,
                target_property=target_property,
                max_rounds=max_rounds,
                oracle_budget=oracle_budget,
            )
        except Exception as error:
            self.last_llm_usage = _aggregate_llm_usage(orchestrator)
            # Runners cannot persist a result that was never returned, but the
            # optimizer and exception retain the safe snapshot for callers that
            # convert fatal errors into failed checkpoints.
            try:
                setattr(error, "llm_usage", self.last_llm_usage)
            except Exception:
                pass
            raise

        self.last_llm_usage = _aggregate_llm_usage(orchestrator)
        result["llm_usage"] = self.last_llm_usage

        # Include the oracle's own call count (more accurate than the
        # orchestrator's internal counter when seed selection also uses
        # the oracle).
        if hasattr(oracle, "call_count"):
            result["actual_oracle_calls"] = oracle.call_count
        result["oracle_backend"] = getattr(oracle, "oracle_backend", "unknown")
        result["used_dummy_oracle"] = bool(
            getattr(oracle, "used_dummy_oracle", False)
        )

        logger.info(
            "Optimization ended: status=%s, reason=%s, best=%s, "
            "score=%.4f, oracle_calls=%d",
            result.get("status", "unknown"),
            result.get("termination_reason", "unknown"),
            result["best_smiles"],
            result["best_combined_score"],
            result["total_oracle_calls"],
        )

        return result

    def _select_seed(
        self,
        oracle,
        oracle_budget: int,
        *,
        require_full_budget: bool = False,
    ) -> str:
        """Select the best of the fixed 26-molecule starting pool.

        These evaluations count toward the PMO oracle budget.  A smaller
        smoke-test budget is handled by taking a deterministic prefix rather
        than asking the exhausted oracle to score the rest of the pool.
        """
        n_candidates = min(len(DEFAULT_SEEDS), max(1, oracle_budget))
        candidates = DEFAULT_SEEDS[:n_candidates]

        best_smi = candidates[0]
        best_score = -1.0

        from pharmagent.evaluation.oracle_utils import canonicalize_oracle_smiles

        for seed_pool_index, smi in enumerate(candidates):
            canonical = canonicalize_oracle_smiles(smi)
            oracle_buffer = getattr(oracle, "mol_buffer", None)
            was_cached = bool(
                canonical is not None
                and isinstance(oracle_buffer, dict)
                and canonical in oracle_buffer
            )
            count_before = getattr(oracle, "call_count", None)
            try:
                context_setter = getattr(oracle, "set_native_call_context", None)
                if callable(context_setter):
                    context_setter({
                        "scope": "seed_pool",
                        "seed_pool_index": seed_pool_index,
                    })
                score = oracle(smi)
                if isinstance(score, (list, tuple)):
                    if not score:
                        raise ValueError("oracle returned an empty score sequence")
                    score = score[0]
                score = float(score)
                if not math.isfinite(score):
                    raise ValueError("oracle returned a non-finite seed score")
            except Exception as error:
                if require_full_budget:
                    raise RuntimeError(
                        "formal seed-pool oracle evaluation failed; refusing "
                        "to continue with a silently altered starting pool"
                    ) from error
                continue

            if require_full_budget:
                count_after = getattr(oracle, "call_count", None)
                if (
                    isinstance(count_before, bool)
                    or not isinstance(count_before, int)
                    or isinstance(count_after, bool)
                    or not isinstance(count_after, int)
                    or count_after
                    != count_before + (0 if was_cached else 1)
                ):
                    raise RuntimeError(
                        "formal seed-pool oracle evaluation did not consume "
                        "exactly one new canonical oracle call (or zero for "
                        "a durable cached replay)"
                    )

            if score > best_score:
                best_score = score
                # The oracle/journal budget identity is canonical.  Returning
                # the original spelling here would make a non-canonical fixed
                # seed impossible to bind to its durable source record in the
                # first optimization round.
                best_smi = canonical or smi

        logger.info(
            "Selected seed molecule: %s (score=%.4f from %d candidates)",
            best_smi, best_score, len(candidates)
        )
        return best_smi


def create_pmo_compatible_optimizer(config: dict):
    """Factory function for creating a PMO-compatible optimizer.

    For use with the mol_opt BaseOptimizer framework:
        from main.optimizer import BaseOptimizer

        class PharmAgentPMO(BaseOptimizer):
            def __init__(self, args=None):
                super().__init__(args)
                self.model_name = "pharmagent"

            def _optimize(self, oracle, config):
                pa_config = load_config("configs/default.yaml")
                optimizer = PharmAgentOptimizer(pa_config)
                return optimizer.optimize(oracle, seed=0)
    """
    return PharmAgentOptimizer(config)
