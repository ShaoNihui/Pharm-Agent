"""
Optimization Memory Buffer — stores history of optimization steps
for the Generator and Reviewer to learn from.
"""

from collections import Counter

from pharmagent.optimization.formal_prompt_protocol import (
    canonicalize_formal_modifications,
)


class OptimizationMemory:
    """FIFO buffer storing optimization trajectory entries.

    Optionally backed by a Chemical-CER ExperienceDB for cross-task
    structure-aware experience retrieval.
    """

    def __init__(
        self,
        max_size: int = 100,
        experience_db=None,
        *,
        structured_modifications_only: bool = False,
    ):
        self.max_size = max_size
        self.buffer: list[dict] = []
        self.experience_db = experience_db  # Optional ExperienceDB instance
        self.structured_modifications_only = bool(
            structured_modifications_only
        )

    def _project_entry(self, entry: dict) -> dict:
        projected = dict(entry)
        if self.structured_modifications_only:
            # Generator-authored modification metadata has no physical oracle
            # row and therefore cannot be reconstructed during crash resume.
            # Formal same-round Reviewer input still receives the validated
            # candidate enums directly; nothing authored is persisted as a
            # cross-round FIFO/CER operand.
            projected["modifications"] = []
        return projected

    def add(self, entry: dict):
        """Add one scored candidate to the task-local FIFO history.

        Chemical-CER is deliberately committed separately, once per scored
        round, via :meth:`commit_experience`.  Keeping these operations
        separate lets the Reviewer inspect every candidate without turning a
        five-candidate round into five cross-task experiences.
        """
        self.buffer.append(self._project_entry(entry))
        if len(self.buffer) > self.max_size:
            self.buffer.pop(0)

    def commit_experience(self, entry: dict) -> bool:
        """Commit the selected round-level outcome to Chemical-CER.

        Returns ``True`` only when a persistent/in-memory CER row was newly
        inserted.  With CER disabled this is a transparent ``False``.
        """
        if self.experience_db is None:
            return False
        required_deltas = ("delta_target", "delta_admet", "delta_combined")
        missing = [field for field in required_deltas if field not in entry]
        if missing:
            raise ValueError(
                "CER-backed OptimizationMemory requires explicit delta field(s): "
                + ", ".join(missing)
            )
        entry = self._project_entry(entry)
        return bool(self.experience_db.add_experience({
            "source_smiles": entry.get(
                "previous_smiles", entry.get("smiles", "")
            ),
            "target_smiles": entry.get("smiles", ""),
            "modifications": entry.get("modifications", []),
            "delta_target": entry["delta_target"],
            "delta_admet": entry["delta_admet"],
            "delta_combined": entry["delta_combined"],
            "task_name": entry.get("task_name", ""),
            "round": entry.get("round", 0),
        }))

    def has_committed_experience(self, entry: dict) -> bool:
        """Check an exact CER row when reconciling a crash-window replay."""
        if self.experience_db is None:
            return False
        contains = getattr(self.experience_db, "contains_experience", None)
        if not callable(contains):
            return False
        entry = self._project_entry(entry)
        return bool(contains({
            "source_smiles": entry.get(
                "previous_smiles", entry.get("smiles", "")
            ),
            "target_smiles": entry.get("smiles", ""),
            "modifications": entry.get("modifications", []),
            "delta_target": entry["delta_target"],
            "delta_admet": entry["delta_admet"],
            "delta_combined": entry["delta_combined"],
            "task_name": entry.get("task_name", ""),
            "round": entry.get("round", 0),
        }))

    def get_recent(self, n: int = 10) -> list[dict]:
        """Get the most recent n entries."""
        return self.buffer[-n:]

    def preview_recent(
        self, pending_entries: list[dict], n: int = 10
    ) -> list[dict]:
        """Preview FIFO history after pending entries without committing it."""
        preview = list(self.buffer)
        for entry in pending_entries:
            preview.append(self._project_entry(entry))
            if len(preview) > self.max_size:
                preview.pop(0)
        return preview[-n:]

    def get_best(self) -> dict | None:
        """Get the entry with the highest combined score."""
        if not self.buffer:
            return None
        return max(self.buffer, key=lambda e: e.get("combined_score", 0))

    def get_summary(self) -> str:
        """Get a text summary of recent optimization history for prompt injection."""
        recent = self.get_recent(5)
        if not recent:
            return "No optimization history yet."

        lines = []
        for entry in recent:
            smi = entry.get("smiles", "?")
            ts = entry.get("target_score", 0)
            ads = entry.get("admet_score", 0)
            cs = entry.get("combined_score", 0)
            rnd = entry.get("round", "?")
            delta = entry.get("delta_score", 0)
            direction = "+" if delta > 0 else ""
            lines.append(
                f"  Round {rnd}: {smi} "
                f"(target={ts:.3f}, admet={ads:.3f}, combined={cs:.3f}, "
                f"delta={direction}{delta:.3f})"
            )
        return "\n".join(lines)

    def get_successful_patterns(self) -> str:
        """Extract successful modification patterns (delta_score > 0)."""
        successful = [e for e in self.buffer if e.get("delta_score", 0) > 0]
        if not successful:
            return "No successful patterns recorded yet."

        # Count modification types that worked
        mod_types = Counter()
        examples = []
        for entry in successful[-10:]:  # last 10 successes
            mods = entry.get("modifications", [])
            if self.structured_modifications_only:
                mods = canonicalize_formal_modifications(mods)
            for mod in mods:
                if isinstance(mod, dict):
                    mod_types[mod.get("type", "unknown")] += 1

            if len(examples) < 3:
                delta = entry.get("delta_score", 0)
                smi = entry.get("smiles", "?")
                mod_descs = []
                for m in mods:
                    if isinstance(m, dict):
                        mod_descs.append(
                            m.get("type", "unknown")
                            if self.structured_modifications_only
                            else m.get("description", str(m))
                        )
                examples.append(
                    f"  - {smi} (delta=+{delta:.3f}): "
                    + ("; ".join(mod_descs) if mod_descs else "N/A")
                )

        lines = ["Successful modification types:"]
        for mtype, count in mod_types.most_common(5):
            lines.append(f"  - {mtype}: {count} successes")
        if examples:
            lines.append("Recent successful examples:")
            lines.extend(examples)

        return "\n".join(lines)

    def get_failed_patterns(self) -> str:
        """Extract failed modification patterns (delta_score <= 0)."""
        failed = [e for e in self.buffer if e.get("delta_score", 0) <= 0]
        if not failed:
            return "No failed patterns recorded yet."

        mod_types = Counter()
        examples = []
        for entry in failed[-10:]:
            mods = entry.get("modifications", [])
            if self.structured_modifications_only:
                mods = canonicalize_formal_modifications(mods)
            for mod in mods:
                if isinstance(mod, dict):
                    mod_types[mod.get("type", "unknown")] += 1

            if len(examples) < 3:
                delta = entry.get("delta_score", 0)
                smi = entry.get("smiles", "?")
                mod_descs = []
                for m in mods:
                    if isinstance(m, dict):
                        mod_descs.append(
                            m.get("type", "unknown")
                            if self.structured_modifications_only
                            else m.get("description", str(m))
                        )
                examples.append(
                    f"  - {smi} (delta={delta:.3f}): "
                    + ("; ".join(mod_descs) if mod_descs else "N/A")
                )

        lines = ["Failed modification types to avoid:"]
        for mtype, count in mod_types.most_common(5):
            lines.append(f"  - {mtype}: {count} failures")
        if examples:
            lines.append("Recent failed examples:")
            lines.extend(examples)

        return "\n".join(lines)

    def get_relevant_experiences(
        self,
        current_smiles: str,
        top_k: int = 5,
        mode: str = "combined",
        max_origin_round: int | None = None,
    ) -> str:
        """Retrieve structurally similar experiences from the global DB.

        Returns formatted text for prompt injection. Falls back to empty
        message if no experience DB is configured.
        """
        if self.experience_db is None:
            return "No cross-task experience database available."
        if self.structured_modifications_only:
            return self.experience_db.retrieve_and_format(
                current_smiles,
                top_k,
                mode=mode,
                structured_modifications_only=True,
                max_origin_round=max_origin_round,
            )
        return self.experience_db.retrieve_and_format(
            current_smiles,
            top_k,
            mode=mode,
            max_origin_round=max_origin_round,
        )

    def clear(self):
        """Clear the buffer."""
        self.buffer.clear()
