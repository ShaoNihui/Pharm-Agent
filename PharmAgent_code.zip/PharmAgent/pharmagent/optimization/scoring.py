"""
Scoring functions for combining target activity and ADMET compliance.
"""

from pharmagent.optimization.lagrangian import (
    compute_canonical_lagrangian_score,
)


def compute_combined_score(target_score: float, admet_score: float,
                            alpha: float = 0.7) -> float:
    """Compute weighted combination of target and ADMET scores.

    Args:
        target_score: Target property score (typically 0-1 from PMO oracle).
        admet_score: ADMET compliance score (0-1, fraction of constraints passed).
        alpha: Weight for target score. ADMET weight = 1 - alpha.

    Returns:
        Combined score in [0, 1].
    """
    return alpha * target_score + (1.0 - alpha) * admet_score


def compute_admet_constrained_score(target_score: float,
                                     n_violations: int,
                                     total_constraints: int) -> float:
    """Compute ADMET-constrained score for the ADMET-PMO benchmark variant.

    If all ADMET constraints pass, returns the full target_score.
    Otherwise, applies a penalty proportional to the number of violations.

    Args:
        target_score: Raw target property score from the oracle.
        n_violations: Number of ADMET constraint violations.
        total_constraints: Total number of ADMET constraints checked.

    Returns:
        Penalized score.
    """
    if n_violations == 0:
        return target_score

    if total_constraints <= 0:
        return target_score

    penalty = (1.0 - n_violations / total_constraints) * 0.5
    return target_score * max(0.0, penalty)


def compute_admet_score(n_violations: int, total_constraints: int) -> float:
    """Compute ADMET compliance score as fraction of constraints passed.

    Returns 1.0 if all pass, 0.0 if all fail.
    """
    if total_constraints <= 0:
        return 1.0
    return (total_constraints - n_violations) / total_constraints


def compute_lagrangian_score(target_score: float,
                              violation_dict: dict[str, float],
                              lambdas: dict[str, float],
                              rho: float) -> float:
    """Compute augmented Lagrangian objective (standalone function).

    L = target_score - sum_i [lambda_i * v_i + (rho/2) * v_i^2]

    Iterates over all keys in lambdas (not just violation_dict) to ensure
    constraints with zero violation still get zero penalty contribution,
    consistent with LagrangianOptimizer.compute_lagrangian_score().

    Args:
        target_score: Oracle score for the molecule.
        violation_dict: Mapping constraint_name -> normalized violation amount.
        lambdas: Current dual variable values.
        rho: Current penalty parameter.

    Returns:
        Lagrangian score (higher is better).
    """
    return compute_canonical_lagrangian_score(
        target_score,
        violation_dict,
        lambdas,
        rho,
        list(lambdas),
    )
