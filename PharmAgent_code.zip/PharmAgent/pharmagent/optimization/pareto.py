"""
Multi-objective Pareto front computation and hypervolume indicator.
"""

import numpy as np


def compute_pareto_front(points: np.ndarray) -> np.ndarray:
    """Find Pareto-optimal indices for a set of points (all objectives maximized).

    Args:
        points: array of shape (N, M) where N = number of points, M = objectives.
                All objectives are assumed to be maximized.

    Returns:
        1D array of indices of non-dominated (Pareto-optimal) points.
    """
    points = np.asarray(points)
    n = len(points)
    if n == 0:
        return np.array([], dtype=int)

    if points.ndim != 2:
        raise ValueError("points must be a two-dimensional array")

    # PHV is two-dimensional throughout PharmAgent.  Collapse exact plateau
    # duplicates, solve the unique frontier in O(n log n), then expand back to
    # every original tied index (duplicates do not strictly dominate each other).
    if points.shape[1] == 2 and np.all(np.isfinite(points)):
        unique, inverse = np.unique(points, axis=0, return_inverse=True)
        # Primary key x descending. Equal-x groups are handled together so a
        # point only dominates its peers when its y value is strictly larger.
        order = np.argsort(-unique[:, 0], kind="stable")
        unique_pareto = np.zeros(len(unique), dtype=bool)
        best_y_at_larger_x = -np.inf
        start = 0
        while start < len(order):
            end = start + 1
            x_value = unique[order[start], 0]
            while end < len(order) and unique[order[end], 0] == x_value:
                end += 1
            group = order[start:end]
            group_max_y = float(np.max(unique[group, 1]))
            for unique_index in group:
                y_value = float(unique[unique_index, 1])
                dominated = (
                    best_y_at_larger_x >= y_value
                    or group_max_y > y_value
                )
                unique_pareto[unique_index] = not dominated
            best_y_at_larger_x = max(best_y_at_larger_x, group_max_y)
            start = end
        return np.flatnonzero(unique_pareto[inverse])

    # Generic/non-finite fallback retains the all-objective logic.
    is_pareto = np.ones(n, dtype=bool)

    for i in range(n):
        if not is_pareto[i]:
            continue
        for j in range(n):
            if i == j or not is_pareto[j]:
                continue
            # Check if j dominates i (j >= i on all objectives and j > i on at least one)
            if np.all(points[j] >= points[i]) and np.any(points[j] > points[i]):
                is_pareto[i] = False
                break

    return np.where(is_pareto)[0]


def compute_hypervolume_2d(pareto_points: np.ndarray,
                            reference_point: np.ndarray | None = None) -> float:
    """Compute 2D hypervolume indicator.

    Args:
        pareto_points: array of shape (N, 2) — Pareto-optimal points.
        reference_point: (2,) array — lower-left reference point.
                         Defaults to origin [0, 0].

    Returns:
        Hypervolume (area) dominated by the Pareto front above the reference point.
    """
    if len(pareto_points) == 0:
        return 0.0

    if reference_point is None:
        reference_point = np.zeros(2)

    # Filter points that dominate the reference point
    valid = pareto_points[
        np.all(pareto_points > reference_point, axis=1)
    ]
    if len(valid) == 0:
        return 0.0

    # Sort by first objective (descending)
    sorted_idx = np.argsort(-valid[:, 0])
    sorted_points = valid[sorted_idx]

    # Compute area using the inclusion method
    hv = 0.0
    prev_y = reference_point[1]

    for point in sorted_points:
        x = point[0] - reference_point[0]
        y = point[1]
        if y > prev_y:
            hv += x * (y - prev_y)
            prev_y = y

    return hv


def select_best_from_pareto(target_scores: list[float],
                             admet_scores: list[float],
                             alpha: float = 0.7) -> int:
    """Select the best candidate considering both target and ADMET scores.

    First identifies Pareto-optimal candidates, then selects from them
    using weighted combination as tiebreaker.

    Args:
        target_scores: list of target property scores.
        admet_scores: list of ADMET compliance scores.
        alpha: weight for target score (1-alpha for ADMET).

    Returns:
        Index of the selected best candidate.
    """
    if not target_scores:
        return 0

    n = len(target_scores)
    points = np.array(list(zip(target_scores, admet_scores)))
    pareto_idx = compute_pareto_front(points)

    if len(pareto_idx) == 0:
        pareto_idx = np.arange(n)

    # Weighted combination among Pareto-optimal
    best_idx = pareto_idx[0]
    best_score = -float("inf")
    for idx in pareto_idx:
        combined = alpha * target_scores[idx] + (1 - alpha) * admet_scores[idx]
        if combined > best_score:
            best_score = combined
            best_idx = idx

    return int(best_idx)
