"""Canonical, arm-independent novelty-recovery protocol.

The formal Standard and ADMET arms use this exact mapping.  Keeping the
scientific knobs in one immutable descriptor lets runner preflight fail closed
and makes the existing config/source hashes bind every paid run to the same
generation-recovery semantics.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from copy import deepcopy
from typing import Any

from pharmagent.tools.rdkit_tools import compute_tanimoto, validate_smiles


NOVELTY_AUDIT_SCHEMA_VERSION = 2

CANONICAL_NOVELTY_RECOVERY_PROTOCOL: dict[str, Any] = {
    "schema_version": 1,
    "enabled": True,
    "global_canonical_dedup": True,
    "candidate_cap_per_generator_call": 5,
    "max_generator_calls_per_round": 2,
    "repair_only_when_zero_verified_globally_novel": True,
    "nearest_taboo_count": 20,
    "zero_novel_restart_threshold": 5,
    "restart_strategies": [
        "scaffold-hop",
        "ring-linker",
        "bioisostere",
    ],
    "restart_preserves": [
        "incumbent",
        "lagrangian_duals",
        "cer",
        "active_constraints",
    ],
}


class NoveltyRecoveryProtocolError(ValueError):
    """Raised when novelty recovery is not the canonical formal protocol."""


def canonical_novelty_recovery_protocol() -> dict[str, Any]:
    """Return a detached copy of the canonical protocol descriptor."""
    return deepcopy(CANONICAL_NOVELTY_RECOVERY_PROTOCOL)


def formal_repair_reason_lines(primary_audit: object) -> list[str]:
    """Project primary evidence to prompt-safe ordinal/reason enums."""
    if not isinstance(primary_audit, Mapping):
        raise NoveltyRecoveryProtocolError(
            "primary repair evidence is malformed"
        )
    rejections = primary_audit.get("rejections")
    duplicates = primary_audit.get("duplicates")
    if not isinstance(rejections, list) or not isinstance(duplicates, list):
        raise NoveltyRecoveryProtocolError(
            "primary repair evidence is malformed"
        )
    reasons: list[str] = []
    for index, row in enumerate(rejections, start=1):
        if (
            not isinstance(row, Mapping)
            or not isinstance(row.get("smiles"), str)
            or not isinstance(row.get("reason"), str)
        ):
            raise NoveltyRecoveryProtocolError(
                "primary verifier rejection is malformed"
            )
        reasons.append(f"Candidate {index}: verifier_rejected.")
    offset = len(reasons)
    for index, row in enumerate(duplicates, start=1):
        scope = row.get("reason") if isinstance(row, Mapping) else None
        canonical = (
            row.get("canonical_smiles")
            if isinstance(row, Mapping)
            else None
        )
        if (
            not isinstance(row, Mapping)
            or not isinstance(row.get("smiles"), str)
            or not isinstance(canonical, str)
            or validate_smiles(canonical) != canonical
            or scope not in {"within_generator_call", "global_seen"}
        ):
            raise NoveltyRecoveryProtocolError(
                "primary duplicate evidence is malformed"
            )
        reasons.append(
            f"Candidate {offset + index}: duplicate_{scope}."
        )
    return reasons or ["No parseable candidate objects were returned."]


def validate_novelty_recovery_config(
    value: object,
    *,
    require_canonical: bool,
    generator_candidate_cap: object,
) -> dict[str, Any] | None:
    """Validate configuration without silently filling scientific defaults.

    Exploratory configurations may omit the feature.  A formal/full-budget
    configuration must provide the exact canonical mapping, including the
    unchanged five-candidate cap shared by both arms.
    """
    if value is None:
        if require_canonical:
            raise NoveltyRecoveryProtocolError(
                "formal runs require canonical novelty_recovery configuration"
            )
        return None
    if not isinstance(value, Mapping):
        raise NoveltyRecoveryProtocolError(
            "novelty_recovery must be a mapping"
        )
    observed = dict(value)
    if observed != CANONICAL_NOVELTY_RECOVERY_PROTOCOL:
        raise NoveltyRecoveryProtocolError(
            "novelty_recovery does not match the canonical formal protocol"
        )
    if (
        isinstance(generator_candidate_cap, bool)
        or not isinstance(generator_candidate_cap, int)
        or generator_candidate_cap
        != CANONICAL_NOVELTY_RECOVERY_PROTOCOL[
            "candidate_cap_per_generator_call"
        ]
    ):
        raise NoveltyRecoveryProtocolError(
            "generator.n_candidates must remain fixed at the canonical "
            "novelty-recovery candidate cap"
        )
    return canonical_novelty_recovery_protocol()


def _validate_novelty_recovery_structure(value: object) -> bool:
    """Validate the run-level protocol and every persisted round audit.

    This is deliberately structural and result-independent.  It proves the
    bounded control flow was recorded; it never judges whether an outcome is
    scientifically favourable.
    """
    if not isinstance(value, Mapping):
        return False
    if value.get("novelty_recovery_protocol") != (
        CANONICAL_NOVELTY_RECOVERY_PROTOCOL
    ):
        return False
    trajectory = value.get("trajectory")
    round_failure_history = value.get("round_failure_history")
    round_error_count = value.get("round_error_count")
    if (
        not isinstance(trajectory, list)
        or not isinstance(round_failure_history, list)
        or isinstance(round_error_count, bool)
        or not isinstance(round_error_count, int)
        or round_error_count < 0
        or round_error_count != len(round_failure_history)
    ):
        return False
    expected_failure_fields = {
        "round",
        "failure_class",
        "error_type",
        "oracle_calls_before",
        "oracle_calls_after",
        "oracle_record_sha256",
    }
    previous_failure_round = -1
    for event in round_failure_history:
        if not isinstance(event, Mapping) or set(event) != (
            expected_failure_fields
        ):
            return False
        round_index = event.get("round")
        before = event.get("oracle_calls_before")
        after = event.get("oracle_calls_after")
        error_type = event.get("error_type")
        record_hashes = event.get("oracle_record_sha256")
        if (
            event.get("failure_class") != "recoverable_round_error"
            or isinstance(round_index, bool)
            or not isinstance(round_index, int)
            or round_index <= previous_failure_round
            or isinstance(before, bool)
            or not isinstance(before, int)
            or before < 0
            or isinstance(after, bool)
            or not isinstance(after, int)
            or after < before
            or not isinstance(error_type, str)
            or not error_type.isidentifier()
            or not isinstance(record_hashes, list)
            or len(record_hashes) != after - before
            or any(
                not isinstance(digest, str)
                or len(digest) != 64
                or any(character not in "0123456789abcdef" for character in digest)
                for digest in record_hashes
            )
        ):
            return False
        previous_failure_round = round_index
    strategies = set(
        CANONICAL_NOVELTY_RECOVERY_PROTOCOL["restart_strategies"]
    )
    candidate_cap = int(
        CANONICAL_NOVELTY_RECOVERY_PROTOCOL[
            "candidate_cap_per_generator_call"
        ]
    )
    taboo_cap = int(
        CANONICAL_NOVELTY_RECOVERY_PROTOCOL["nearest_taboo_count"]
    )
    restart_threshold = int(
        CANONICAL_NOVELTY_RECOVERY_PROTOCOL[
            "zero_novel_restart_threshold"
        ]
    )
    expected_fields = {
        "schema_version",
        "parsed_count",
        "verified_count",
        "duplicate_count",
        "globally_novel_count",
        "globally_novel_smiles",
        "generator_calls",
        "reviewer_calls",
        "repair_used",
        "repair_reasons",
        "taboo_smiles",
        "restart_applied",
        "restart_scheduled",
        "zero_novel_round_streak",
        "global_seen_count_before",
        "global_seen_count_after",
        "primary",
        "repair",
    }
    stage_fields = {
        "parsed_count",
        "verified_count",
        "duplicate_count",
        "globally_novel_count",
        "rejections",
        "duplicates",
    }
    pending_restart: str | None = None
    restart_cursor = 0
    recovery_streak = 0

    for row in trajectory:
        if not isinstance(row, Mapping):
            return False
        audit = row.get("novelty_audit")
        if not isinstance(audit, Mapping) or set(audit) != expected_fields:
            return False
        if audit.get("schema_version") != NOVELTY_AUDIT_SCHEMA_VERSION:
            return False
        globally_novel_smiles = audit.get("globally_novel_smiles")
        if (
            not isinstance(globally_novel_smiles, list)
            or len(globally_novel_smiles)
            != audit.get("globally_novel_count")
            or len(globally_novel_smiles)
            != len(set(globally_novel_smiles))
            or any(
                not isinstance(smiles, str)
                or not smiles
                or validate_smiles(smiles) != smiles
                for smiles in globally_novel_smiles
            )
        ):
            return False
        primary = audit.get("primary")
        repair = audit.get("repair")
        if (
            not isinstance(primary, Mapping)
            or not isinstance(repair, Mapping)
            or set(primary) != stage_fields
            or set(repair) != stage_fields
        ):
            return False
        for stage in (primary, repair):
            counts = [
                stage.get("parsed_count"),
                stage.get("verified_count"),
                stage.get("duplicate_count"),
                stage.get("globally_novel_count"),
            ]
            if any(
                isinstance(count, bool)
                or not isinstance(count, int)
                or count < 0
                for count in counts
            ):
                return False
            parsed, verified, duplicates, novel = counts
            if (
                parsed > candidate_cap
                or verified > parsed
                or duplicates + novel != verified
                or not isinstance(stage.get("rejections"), list)
                or not isinstance(stage.get("duplicates"), list)
                or len(stage["rejections"]) != parsed - verified
                or len(stage["duplicates"]) != duplicates
            ):
                return False

        integer_fields = (
            "parsed_count",
            "verified_count",
            "duplicate_count",
            "globally_novel_count",
            "generator_calls",
            "reviewer_calls",
            "zero_novel_round_streak",
            "global_seen_count_before",
            "global_seen_count_after",
        )
        if any(
            isinstance(audit.get(field), bool)
            or not isinstance(audit.get(field), int)
            or audit[field] < 0
            for field in integer_fields
        ):
            return False
        if any(
            audit[field] != primary[field] + repair[field]
            for field in (
                "parsed_count",
                "verified_count",
                "duplicate_count",
                "globally_novel_count",
            )
        ):
            return False
        repair_used = audit.get("repair_used")
        if not isinstance(repair_used, bool):
            return False
        if audit["generator_calls"] != (2 if repair_used else 1):
            return False
        if audit["reviewer_calls"] not in {0, 1}:
            return False
        if repair_used:
            if primary["globally_novel_count"] != 0:
                return False
        elif any(
            repair[field] != 0
            for field in (
                "parsed_count",
                "verified_count",
                "duplicate_count",
                "globally_novel_count",
            )
        ):
            return False
        if audit["globally_novel_count"] > candidate_cap:
            return False
        if audit["global_seen_count_after"] != (
            audit["global_seen_count_before"]
            + audit["globally_novel_count"]
        ):
            return False
        if not isinstance(audit.get("repair_reasons"), list):
            return False
        taboo = audit.get("taboo_smiles")
        if (
            not isinstance(taboo, list)
            or len(taboo) != (
                min(audit["global_seen_count_before"], taboo_cap)
                if repair_used else 0
            )
            or len(taboo) != len(set(taboo))
            or any(
                not isinstance(smiles, str)
                or not smiles
                or validate_smiles(smiles) != smiles
                for smiles in taboo
            )
            or (not repair_used and taboo)
        ):
            return False
        restart_applied = audit.get("restart_applied")
        restart_scheduled = audit.get("restart_scheduled")
        if restart_applied is not None and restart_applied not in strategies:
            return False
        if restart_scheduled is not None and restart_scheduled not in strategies:
            return False
        if restart_applied != pending_restart:
            return False
        pending_restart = None
        streak = audit["zero_novel_round_streak"]
        if streak > restart_threshold:
            return False
        if audit["globally_novel_count"] > 0:
            recovery_streak = 0
        else:
            recovery_streak += 1
        if streak != recovery_streak:
            return False
        if recovery_streak == restart_threshold:
            expected_strategy = CANONICAL_NOVELTY_RECOVERY_PROTOCOL[
                "restart_strategies"
            ][restart_cursor % len(strategies)]
            if restart_scheduled != expected_strategy:
                return False
            pending_restart = restart_scheduled
            restart_cursor += 1
            recovery_streak = 0
        elif restart_scheduled is not None:
            return False
    return True


def _oracle_record_sha256(record: Mapping[str, Any]) -> str:
    """Return the native journal's canonical digest for one oracle row."""
    try:
        payload = json.dumps(
            dict(record),
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        ).encode("utf-8")
    except (TypeError, ValueError, OverflowError) as error:
        raise NoveltyRecoveryProtocolError(
            "oracle record is not canonical-JSON serializable"
        ) from error
    return hashlib.sha256(payload).hexdigest()


def replay_novelty_recovery_lineage(
    value: object,
    *,
    require_evaluation_history_binding: bool,
    expected_reviewer_enabled: bool | None = None,
    allow_pending_round: int | None = None,
    expected_next_round: int | None = None,
) -> list[str]:
    """Validate and replay the exact run-global canonical identity set.

    The round audit is an ordered ledger of Verifier-approved, globally novel
    canonical identities.  With formal evaluation history available, every
    seed-pool and optimization-round oracle record is bound to that ledger.
    The returned list is the canonical sorted set expected in a native
    optimizer checkpoint.

    Raises:
        NoveltyRecoveryProtocolError: if any structural, lineage, or history
            binding invariant is violated.
    """
    if not _validate_novelty_recovery_structure(value):
        raise NoveltyRecoveryProtocolError(
            "invalid novelty-recovery protocol or round audit"
        )
    assert isinstance(value, Mapping)
    trajectory = value["trajectory"]
    assert isinstance(trajectory, list)

    evaluation_history = value.get("evaluation_history")
    if require_evaluation_history_binding and not isinstance(
        evaluation_history, list
    ):
        raise NoveltyRecoveryProtocolError(
            "formal novelty lineage requires evaluation_history"
        )
    if (
        expected_reviewer_enabled is not None
        and (
            not isinstance(expected_reviewer_enabled, bool)
            or not isinstance(evaluation_history, list)
        )
    ):
        raise NoveltyRecoveryProtocolError(
            "Reviewer-call binding requires evaluation_history"
        )

    seed_seen: set[str] = set()
    if isinstance(evaluation_history, list):
        seed_pool_size = min(26, len(evaluation_history))
        all_history_smiles: set[str] = set()
        for expected_call_index, record in enumerate(
            evaluation_history, start=1
        ):
            if not isinstance(record, Mapping):
                raise NoveltyRecoveryProtocolError(
                    "evaluation_history contains a non-mapping record"
                )
            smiles = record.get("smiles")
            context = record.get("oracle_context")
            if (
                record.get("call_index") != expected_call_index
                or not isinstance(smiles, str)
                or validate_smiles(smiles) != smiles
                or smiles in all_history_smiles
                or not isinstance(context, Mapping)
            ):
                raise NoveltyRecoveryProtocolError(
                    "evaluation_history is not canonical, unique, and ordered"
                )
            all_history_smiles.add(smiles)
            if expected_call_index <= seed_pool_size:
                if dict(context) != {
                    "scope": "seed_pool",
                    "seed_pool_index": expected_call_index - 1,
                }:
                    raise NoveltyRecoveryProtocolError(
                        "seed-pool history context is not exact"
                    )
                seed_seen.add(smiles)
                continue
            round_index = context.get("round")
            candidate_index = context.get("candidate_index")
            if (
                set(context) != {"scope", "round", "candidate_index"}
                or context.get("scope") != "optimization_round"
                or isinstance(round_index, bool)
                or not isinstance(round_index, int)
                or round_index < 0
                or isinstance(candidate_index, bool)
                or not isinstance(candidate_index, int)
                or candidate_index < 0
            ):
                raise NoveltyRecoveryProtocolError(
                    "optimization history context is not exact"
                )

    if (
        allow_pending_round is not None
        and (
            isinstance(allow_pending_round, bool)
            or not isinstance(allow_pending_round, int)
            or allow_pending_round < 0
            or not isinstance(evaluation_history, list)
        )
    ):
        raise NoveltyRecoveryProtocolError(
            "pending-round allowance is not an exact nonnegative round"
        )
    if (
        expected_next_round is not None
        and (
            isinstance(expected_next_round, bool)
            or not isinstance(expected_next_round, int)
            or expected_next_round < 0
        )
    ):
        raise NoveltyRecoveryProtocolError(
            "expected next round is not a nonnegative integer"
        )
    if (
        allow_pending_round is not None
        and expected_next_round != allow_pending_round
    ):
        raise NoveltyRecoveryProtocolError(
            "pending trace must belong to the exact expected next round"
        )

    round_failure_history = value["round_failure_history"]
    assert isinstance(round_failure_history, list)
    outer_by_round: dict[int, Mapping[str, Any]] = {}
    for trajectory_row in trajectory:
        assert isinstance(trajectory_row, Mapping)
        round_index = trajectory_row.get("round")
        if (
            isinstance(round_index, bool)
            or not isinstance(round_index, int)
            or round_index < 0
            or round_index in outer_by_round
        ):
            raise NoveltyRecoveryProtocolError(
                "novelty trajectory rounds are not unique nonnegative integers"
            )
        outer_by_round[round_index] = trajectory_row
    if list(outer_by_round) != sorted(outer_by_round):
        raise NoveltyRecoveryProtocolError(
            "novelty trajectory rounds are not strictly ordered"
        )
    failure_by_round = {
        int(event["round"]): event for event in round_failure_history
    }
    if set(outer_by_round) & set(failure_by_round):
        raise NoveltyRecoveryProtocolError(
            "one attempted round cannot be both successful and failed"
        )
    outcome_rounds = sorted(set(outer_by_round) | set(failure_by_round))
    if outcome_rounds != list(range(len(outcome_rounds))):
        raise NoveltyRecoveryProtocolError(
            "successful and failed rounds do not form an exact attempt prefix"
        )
    if (
        allow_pending_round is not None
        and outcome_rounds != list(range(allow_pending_round))
    ):
        raise NoveltyRecoveryProtocolError(
            "round-pending checkpoint outcomes do not precede next_round exactly"
        )
    if (
        expected_next_round is not None
        and outcome_rounds != list(range(expected_next_round))
    ):
        raise NoveltyRecoveryProtocolError(
            "checkpoint outcomes do not match next_round exactly"
        )

    oracle_budget = value.get("oracle_budget")
    if isinstance(evaluation_history, list):
        if oracle_budget is None:
            oracle_budget = len(evaluation_history)
        if (
            isinstance(oracle_budget, bool)
            or not isinstance(oracle_budget, int)
            or oracle_budget <= 0
            or len(evaluation_history) > oracle_budget
        ):
            raise NoveltyRecoveryProtocolError(
                "novelty lineage has an invalid oracle budget"
            )

    seen = set(seed_seen)
    history_cursor = len(seed_seen)
    previous_audit_after: int | None = None
    candidate_cap = int(
        CANONICAL_NOVELTY_RECOVERY_PROTOCOL[
            "candidate_cap_per_generator_call"
        ]
    )

    def exact_round_records(
        records: list[Mapping[str, Any]],
        *,
        round_index: int,
    ) -> None:
        if len(records) > candidate_cap:
            raise NoveltyRecoveryProtocolError(
                "one attempted round exceeds the candidate cap"
            )
        contexts = [record["oracle_context"] for record in records]
        if any(
            context["round"] != round_index
            for context in contexts
        ) or [
            context["candidate_index"] for context in contexts
        ] != list(range(len(records))):
            raise NoveltyRecoveryProtocolError(
                "round oracle contexts are not an exact candidate prefix"
            )

    for round_index in outcome_rounds:
        if (
            isinstance(evaluation_history, list)
            and history_cursor >= int(oracle_budget)
        ):
            raise NoveltyRecoveryProtocolError(
                "an attempted round appears after the oracle budget gate"
            )

        failure_event = failure_by_round.get(round_index)
        if failure_event is not None:
            if isinstance(evaluation_history, list):
                before = failure_event["oracle_calls_before"]
                after = failure_event["oracle_calls_after"]
                if (
                    before != history_cursor
                    or after > len(evaluation_history)
                ):
                    raise NoveltyRecoveryProtocolError(
                        "failed-round oracle prefix is not exact"
                    )
                failed_records = evaluation_history[before:after]
                exact_round_records(
                    failed_records, round_index=round_index
                )
                if failure_event["oracle_record_sha256"] != [
                    _oracle_record_sha256(record)
                    for record in failed_records
                ]:
                    raise NoveltyRecoveryProtocolError(
                        "failed-round oracle record digests do not match history"
                    )
                for record in failed_records:
                    smiles = record["smiles"]
                    if smiles in seen:
                        raise NoveltyRecoveryProtocolError(
                            "failed-round identity repeats the global lineage"
                        )
                    seen.add(smiles)
                history_cursor = after
            elif previous_audit_after is not None:
                previous_audit_after += (
                    failure_event["oracle_calls_after"]
                    - failure_event["oracle_calls_before"]
                )
            continue

        trajectory_row = outer_by_round[round_index]
        audit = trajectory_row.get("novelty_audit")
        assert isinstance(audit, Mapping)
        before = audit["global_seen_count_before"]
        after = audit["global_seen_count_after"]
        novel_smiles = audit["globally_novel_smiles"]
        assert isinstance(novel_smiles, list)

        if isinstance(evaluation_history, list):
            n_candidates = trajectory_row.get("n_candidates")
            oracle_calls = trajectory_row.get("oracle_calls")
            if (
                isinstance(n_candidates, bool)
                or not isinstance(n_candidates, int)
                or n_candidates < 0
                or isinstance(oracle_calls, bool)
                or not isinstance(oracle_calls, int)
                or oracle_calls != history_cursor + n_candidates
                or oracle_calls > len(evaluation_history)
            ):
                raise NoveltyRecoveryProtocolError(
                    "round candidate/oracle counts do not form an exact prefix"
                )
            scored_records = evaluation_history[
                history_cursor:oracle_calls
            ]
            exact_round_records(scored_records, round_index=round_index)
            if [
                record["smiles"] for record in scored_records
            ] != novel_smiles[:n_candidates]:
                raise NoveltyRecoveryProtocolError(
                    "round oracle identities do not match novelty lineage"
                )
            if (
                n_candidates != len(novel_smiles)
                and oracle_calls != oracle_budget
            ):
                raise NoveltyRecoveryProtocolError(
                    "only the terminal budget boundary may retain an "
                    "unscored globally novel tail"
                )
            if expected_reviewer_enabled is not None:
                expected_reviewer_calls = int(
                    expected_reviewer_enabled and n_candidates > 0
                )
                if audit["reviewer_calls"] != expected_reviewer_calls:
                    raise NoveltyRecoveryProtocolError(
                        "Reviewer-call count does not match the scored round"
                    )
            history_cursor = oracle_calls

        if (
            before != len(seen)
            if isinstance(evaluation_history, list)
            else (
                previous_audit_after is not None
                and before != previous_audit_after
            )
        ):
            raise NoveltyRecoveryProtocolError(
                "global-seen before count does not match replayed state"
            )
        if audit["repair_used"] and require_evaluation_history_binding:
            expected_repair_reasons = formal_repair_reason_lines(
                audit["primary"]
            )
        elif audit["repair_used"]:
            try:
                expected_repair_reasons = [
                    f"{record['smiles']!r}: Verifier rejected "
                    f"({record['reason']})"
                    for record in audit["primary"]["rejections"]
                ]
                expected_repair_reasons.extend(
                    f"{record['smiles']!r} -> "
                    f"{record['canonical_smiles']}: duplicate "
                    f"({record['reason']})"
                    for record in audit["primary"]["duplicates"]
                )
            except (KeyError, TypeError):
                raise NoveltyRecoveryProtocolError(
                    "primary repair evidence is malformed"
                ) from None
            if not expected_repair_reasons:
                expected_repair_reasons = [
                    "No parseable candidate objects were returned."
                ]
        else:
            expected_repair_reasons = []
        if audit["repair_reasons"] != expected_repair_reasons:
            raise NoveltyRecoveryProtocolError(
                "repair reasons do not replay from primary evidence"
            )
        if isinstance(evaluation_history, list):
            source_smiles = trajectory_row.get("source_smiles")
            if (
                not isinstance(source_smiles, str)
                or validate_smiles(source_smiles) != source_smiles
            ):
                raise NoveltyRecoveryProtocolError(
                    "outer source is not a canonical identity"
                )
            expected_taboo = (
                sorted(
                    seen,
                    key=lambda smiles: (
                        -compute_tanimoto(source_smiles, smiles),
                        smiles,
                    ),
                )[:20]
                if audit["repair_used"]
                else []
            )
            if audit["taboo_smiles"] != expected_taboo:
                raise NoveltyRecoveryProtocolError(
                    "repair taboo is not the exact nearest global-seen set"
                )
        if any(smiles in seen for smiles in novel_smiles):
            raise NoveltyRecoveryProtocolError(
                "globally novel identities repeat across rounds or seed pool"
            )
        seen.update(novel_smiles)
        if after != before + len(novel_smiles):
            raise NoveltyRecoveryProtocolError(
                "global-seen after count does not match exact union"
            )
        previous_audit_after = after

    if isinstance(evaluation_history, list):
        pending_records = evaluation_history[history_cursor:]
        if pending_records:
            if allow_pending_round is None:
                raise NoveltyRecoveryProtocolError(
                    "oracle history has no successful or failed round outcome"
                )
            exact_round_records(
                pending_records, round_index=allow_pending_round
            )
            for record in pending_records:
                smiles = record["smiles"]
                if smiles in seen:
                    raise NoveltyRecoveryProtocolError(
                        "pending-round identity repeats the global lineage"
                    )
                seen.add(smiles)
            history_cursor = len(evaluation_history)
        if history_cursor != len(evaluation_history):
            raise NoveltyRecoveryProtocolError(
                "oracle history was not consumed exactly"
            )
    return sorted(seen)


def validate_novelty_recovery_result(
    value: object,
    *,
    require_evaluation_history_binding: bool = False,
    expected_reviewer_enabled: bool | None = None,
) -> bool:
    """Return whether the exact novelty-control and lineage audit is valid."""
    try:
        replay_novelty_recovery_lineage(
            value,
            require_evaluation_history_binding=(
                require_evaluation_history_binding
            ),
            expected_reviewer_enabled=expected_reviewer_enabled,
        )
    except NoveltyRecoveryProtocolError:
        return False
    return True


__all__ = [
    "CANONICAL_NOVELTY_RECOVERY_PROTOCOL",
    "NOVELTY_AUDIT_SCHEMA_VERSION",
    "NoveltyRecoveryProtocolError",
    "canonical_novelty_recovery_protocol",
    "replay_novelty_recovery_lineage",
    "validate_novelty_recovery_config",
    "validate_novelty_recovery_result",
]
