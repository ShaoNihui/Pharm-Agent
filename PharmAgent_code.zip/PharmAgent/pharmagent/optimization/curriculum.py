"""
Curriculum Constraint Scheduling for progressive ADMET constraint activation.

Starts with target-only optimization (Phase 1), adds easy constraints
(Phase 2), then activates all constraints (Phase 3). This allows the
optimizer to first find high-scoring regions before narrowing to
drug-like chemical space.

Inspired by curriculum learning approaches in molecular generation
(DPO + Curriculum, ECML PKDD 2025) showing ~6x convergence speedup.
"""

import logging

logger = logging.getLogger(__name__)

ROUND_BOUNDARY_ONLY = "round_boundary_only"
ROUND_OR_STAGNATION = "round_or_stagnation"
_TRANSITION_POLICIES = {ROUND_BOUNDARY_ONLY, ROUND_OR_STAGNATION}


class ConstraintScheduler:
    """Progressive constraint activation scheduler.

    Divides the optimization into phases with increasing constraint sets:
      Phase 1 (exploration): No ADMET constraints, maximize target only.
      Phase 2 (easy constraints): Lipinski, QED, SA Score.
      Phase 3 (full constraints): All ADMET constraints active.

    Formal transitions use exact round boundaries.  The optional adaptive mode
    remains available explicitly for non-formal experiments.

    Args:
        all_constraints: Full ADMET constraint dict from config.
        config: Scheduler config with phase1_rounds, phase2_rounds,
                easy_constraints list, and transition thresholds.
    """

    def __init__(self, all_constraints: dict, config: dict):
        self.all_constraints = all_constraints
        self.current_phase = 1
        self.last_transition: dict | None = None
        # Append-only scientific state used by the native resume validator.
        # ``last_transition`` is intentionally ephemeral (it is cleared on a
        # no-transition scheduler call), so it cannot by itself prove when or
        # why the curriculum advanced across repeated failed rounds.
        self.transition_history: list[dict] = []

        # Phase transition boundaries
        self.phase1_rounds = config.get("phase1_rounds", 20)
        self.phase2_rounds = config.get("phase2_rounds", 60)
        if self.phase2_rounds < self.phase1_rounds:
            logger.warning(
                "phase2_rounds (%d) < phase1_rounds (%d), clamping",
                self.phase2_rounds, self.phase1_rounds,
            )
            self.phase2_rounds = self.phase1_rounds

        self.transition_policy = config.get(
            "transition_policy", ROUND_OR_STAGNATION
        )
        if self.transition_policy not in _TRANSITION_POLICIES:
            raise ValueError(
                "curriculum.transition_policy must be one of "
                f"{sorted(_TRANSITION_POLICIES)}, got "
                f"{self.transition_policy!r}"
            )

        # Easy constraints (Phase 2) — typically physicochemical properties
        easy_names = config.get("easy_constraints", [
            "lipinski_mw", "lipinski_logp", "qed", "sa_score",
        ])
        missing = set(easy_names) - set(self.all_constraints.keys())
        if missing:
            logger.warning("Easy constraints not found in config: %s", missing)
        self.easy_constraints = {
            name: self.all_constraints[name]
            for name in easy_names
            if name in self.all_constraints
        }

        # Stagnation threshold for early phase transition
        self.stagnation_trigger = config.get("stagnation_trigger", 5)

        logger.info(
            "Curriculum scheduler initialized: "
            "Phase 1 (0-%d rounds, target only), "
            "Phase 2 (%d-%d rounds, %d easy constraints), "
            "Phase 3 (%d+ rounds, all %d constraints)",
            self.phase1_rounds,
            self.phase1_rounds, self.phase2_rounds,
            len(self.easy_constraints),
            self.phase2_rounds,
            len(self.all_constraints),
        )
        logger.info(
            "Curriculum transition policy: %s", self.transition_policy
        )

    def get_active_constraints(self, round_idx: int,
                                best_target_score: float = 0.0,
                                stagnation_count: int = 0) -> dict:
        """Return the constraint set active for the current round.

        Under ``round_boundary_only`` the transitions occur exactly when the
        corresponding boundary is first reached.  ``round_or_stagnation``
        additionally permits a phase-local stagnation transition.
        """
        prev_phase = self.current_phase
        self.last_transition = None
        transition_reasons = []

        # Evaluate transitions from the phase at method entry.  At most one
        # phase may advance per round; otherwise one stagnation signal can
        # cascade Phase 1 -> 2 -> 3 and silently skip the easy-constraint phase.
        if prev_phase == 1:
            if round_idx >= self.phase1_rounds:
                transition_reasons.append("round_boundary")
            elif (
                self.transition_policy == ROUND_OR_STAGNATION
                and stagnation_count >= self.stagnation_trigger
            ):
                transition_reasons.append("phase_local_stagnation")
            if transition_reasons:
                self.current_phase = 2

        # Phase 2 -> Phase 3
        elif prev_phase == 2:
            if round_idx >= self.phase2_rounds:
                transition_reasons.append("round_boundary")
            elif (
                self.transition_policy == ROUND_OR_STAGNATION
                and stagnation_count >= self.stagnation_trigger
            ):
                transition_reasons.append("phase_local_stagnation")
            if transition_reasons:
                self.current_phase = 3

        if self.current_phase != prev_phase:
            self.last_transition = {
                "event": "curriculum_phase_transition",
                "round": round_idx,
                "from_phase": prev_phase,
                "to_phase": self.current_phase,
                "reasons": transition_reasons,
                "incoming_stagnation_count": stagnation_count,
            }
            self.transition_history.append({
                **self.last_transition,
                "reasons": list(self.last_transition["reasons"]),
            })
            logger.info(
                "Curriculum transition: Phase %d -> %d at round %d "
                "(target=%.3f, stagnation=%d)",
                prev_phase, self.current_phase, round_idx,
                best_target_score, stagnation_count,
            )

        if self.current_phase == 1:
            return {}
        elif self.current_phase == 2:
            return self.easy_constraints
        else:
            return self.all_constraints

    def get_phase_description(self) -> str:
        """Render only the objective names active in the current phase."""
        if self.current_phase == 1:
            return "Current optimization objective: target score only."
        active_constraints = (
            self.easy_constraints
            if self.current_phase == 2
            else self.all_constraints
        )
        return (
            "Current explicitly active constraint names: "
            + ", ".join(active_constraints)
            + "."
        )


__all__ = [
    "ConstraintScheduler",
    "ROUND_BOUNDARY_ONLY",
    "ROUND_OR_STAGNATION",
]
