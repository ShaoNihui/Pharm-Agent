"""
Augmented Lagrangian constraint optimization for ADMET-constrained molecular optimization.

Replaces fixed-alpha weighting with adaptive dual variables that automatically
tighten constraints that are repeatedly violated.  The formal
claim is limited to vanishing clipped violation under its stated bounded-dual
and positive-penalty assumptions; it does not claim KKT stationarity.

Reference:
    Bertsekas, D. P. (1999). Nonlinear Programming, 2nd ed. Athena Scientific.
    Adapted here for LLM-agent black-box molecular optimization loops.
"""

import logging
import math
from copy import deepcopy

logger = logging.getLogger(__name__)

# Approximate natural ranges for normalizing constraint violations,
# so that different property scales contribute comparably.
_VIOLATION_SCALES: dict[str, float] = {
    "lipinski_mw": 150.0,
    "lipinski_logp": 2.0,
    "qed": 0.2,
    "sa_score": 2.0,
    "cyp2d6_inh": 0.3,
    "herg": 1.5,
    "caco2": 1.0,
}


def compute_canonical_lagrangian_score(
    target_score: float,
    violations: dict[str, float],
    lambdas: dict[str, float],
    rho: float,
    active_constraint_names: list[str] | tuple[str, ...],
) -> float:
    """Return the byte-replayable augmented-Lagrangian score.

    Floating-point association is part of the formal persistence protocol.
    Keep the defined summation order—linear term, then quadratic term, for each
    active constraint—and share this helper with physical replay.  Algebraic
    rewrites using ``sum`` or ``v ** 2`` can differ by one ULP and therefore
    cannot be substituted in an exact native-state gate.
    """
    penalty = 0.0
    for name in active_constraint_names:
        violation = violations.get(name, 0.0)
        multiplier = lambdas.get(name, 0.0)
        penalty += multiplier * violation
        penalty += 0.5 * rho * violation * violation
    return target_score - penalty


class LagrangianOptimizer:
    """Augmented Lagrangian handler for ADMET constraint optimization.

    Instead of a fixed combined score ``alpha * target + (1 - alpha) * admet``,
    this optimizer solves:

        max  L(x, lambda) = f(x) - sum_i lambda_i * v_i - (rho/2) * sum_i v_i^2

    where v_i = max(0, normalized_violation_i) and lambda_i are dual variables
    updated via dual ascent after each round.

    Args:
        constraints: ADMET constraint definitions from YAML config.
        config: Lagrangian-specific config (rho_init, rho_growth, rho_max,
            rho_growth_rule, reset_rho_on_phase_transition).
    """

    def __init__(self, constraints: dict, config: dict):
        self.constraints = constraints
        self.constraint_names = list(constraints.keys())

        # Dual variables — one per constraint, initialized to 0
        self.lambdas: dict[str, float] = {
            name: 0.0 for name in self.constraint_names
        }

        # Penalty parameters
        self.rho_init = float(config.get("rho_init", 1.0))
        self.rho = self.rho_init
        self.rho_growth = float(config.get("rho_growth", 1.5))
        self.rho_max = float(config.get("rho_max", 100.0))
        self.rho_growth_rule = config.get("rho_growth_rule", "always")
        if self.rho_growth_rule not in {
            "always",
            "accepted_violation_only",
        }:
            raise ValueError(
                "rho_growth_rule must be 'always' or "
                "'accepted_violation_only'"
            )
        reset_setting = config.get("reset_rho_on_phase_transition", False)
        if not isinstance(reset_setting, bool):
            raise ValueError(
                "reset_rho_on_phase_transition must be a boolean"
            )
        self.reset_rho_on_phase_transition = reset_setting
        if self.rho_init <= 0:
            raise ValueError("rho_init must be positive")
        if self.rho_growth < 1:
            raise ValueError("rho_growth must be >= 1")
        if self.rho_max < self.rho_init:
            raise ValueError("rho_max must be >= rho_init")
        self.missing_prediction_violation = config.get(
            "missing_prediction_violation", 0.5
        )
        self.allow_approximate_endpoint_fallback = config.get(
            "allow_approximate_endpoint_fallback", True
        )
        if self.missing_prediction_violation < 0:
            raise ValueError("missing_prediction_violation must be non-negative")

        # Trajectory for convergence analysis
        self.trajectory: list[dict] = []
        self.transition_events: list[dict] = []
        self._active_constraint_names: tuple[str, ...] = ()
        self._pending_transition_events: list[dict] = []

    def prepare_active_constraints(
        self,
        active_constraint_names=None,
        *,
        round_idx: int | None = None,
    ) -> dict | None:
        """Apply a curriculum active-set transition before candidate scoring.

        A scalar augmented-Lagrangian penalty accumulated for an easier phase
        is not transferable to newly activated constraints.  When configured,
        a strict active-set expansion therefore resets only ``rho`` to its
        preregistered positive initial value.  Learned non-negative lambdas are
        retained, including those belonging to constraints already active.

        The method must run before source and candidate scores are compared in
        a round.  Repeated calls for the same active set are idempotent.
        """
        active_names = self._active_names(active_constraint_names)
        previous_names = self._active_constraint_names
        if active_names == previous_names:
            return None

        previous_set = set(previous_names)
        active_set = set(active_names)
        expanded = previous_set < active_set
        rho_before = self.rho
        rho_reset = bool(
            expanded and self.reset_rho_on_phase_transition
        )
        if rho_reset:
            self.rho = self.rho_init

        event = {
            "event": (
                "active_set_expansion" if expanded else "active_set_change"
            ),
            "round": round_idx,
            "previous_active_constraints": list(previous_names),
            "active_constraints": list(active_names),
            "added_constraints": [
                name for name in active_names if name not in previous_set
            ],
            "removed_constraints": [
                name for name in previous_names if name not in active_set
            ],
            "rho_reset": rho_reset,
            "rho_before_transition": rho_before,
            "rho_after_transition": self.rho,
            "lambdas_retained": deepcopy(self.lambdas),
        }
        self._active_constraint_names = active_names
        self.transition_events.append(deepcopy(event))
        self._pending_transition_events.append(deepcopy(event))

        if rho_reset:
            logger.info(
                "Reset Lagrangian rho %.4g -> %.4g for active-set "
                "expansion at round %s; added=%s",
                rho_before,
                self.rho,
                round_idx,
                event["added_constraints"],
            )
        return event

    def compute_violation_vector(
        self,
        admet_result: dict,
        active_constraint_names=None,
    ) -> dict[str, float]:
        """Extract normalized continuous violation for each constraint.

        For "max" constraints (value should be <= threshold):
            violation = max(0, value - threshold) / scale
        For "min" constraints (value should be >= threshold):
            violation = max(0, threshold - value) / scale

        ``active_constraint_names`` masks the vector to the constraints enabled
        by the curriculum in the current round.  ``None`` retains the default
        all-constraint behaviour; an empty iterable deliberately returns an
        empty vector for target-only curriculum phases.

        Returns dict mapping constraint name -> normalized violation (0 = satisfied).
        """
        violations = {}
        predictions = admet_result.get("admet_predictions", {})
        descriptors = admet_result.get("descriptors", {})
        merged = {**predictions, **descriptors}

        active_names = self._active_names(active_constraint_names)
        for name in active_names:
            cdef = self.constraints[name]
            threshold = cdef.get("threshold")
            if threshold is None:
                violations[name] = 0.0
                continue

            ctype = cdef.get("type", "max")
            value = self._resolve_value(merged, name)

            if value is None:
                # Formal configurations use a fail-closed value of 1.0.  The
                # configurable default remains available for smoke runs.
                violations[name] = self.missing_prediction_violation
                continue

            if isinstance(value, bool):
                value = 1.0 if value else 0.0

            scale = cdef.get("scale")
            if scale is None:
                scale = _VIOLATION_SCALES.get(
                    name,
                    abs(threshold) if abs(threshold) > 1e-6 else 1.0,
                )
            if scale <= 0:
                raise ValueError(f"Constraint scale must be positive: {name}")

            if ctype == "max":
                raw = max(0.0, value - threshold)
            else:
                raw = max(0.0, threshold - value)

            violations[name] = raw / scale

        return violations

    def compute_lagrangian_score(
        self,
        target_score: float,
        violations: dict[str, float],
        active_constraint_names=None,
    ) -> float:
        """Compute augmented Lagrangian objective.

        L = target_score - sum_i [lambda_i * v_i + (rho/2) * v_i^2]

        Higher is better (maximization).
        """
        return compute_canonical_lagrangian_score(
            target_score,
            violations,
            self.lambdas,
            self.rho,
            self._active_names(active_constraint_names),
        )

    def update_duals(
        self,
        round_violations: dict[str, float],
        active_constraint_names=None,
        *,
        round_idx: int | None = None,
        accepted_smiles: str | None = None,
        accepted_constraint_assessments: list[dict] | None = None,
        accepted_oracle_call_index: int | None = None,
        accepted_oracle_record_sha256: str | None = None,
    ) -> None:
        """Dual ascent update after each round.

        lambda_i = max(0, lambda_i + rho * violation_i)

        Under ``accepted_violation_only``, rho grows only when the accepted
        iterate has positive total clipped violation.  A feasible iterate
        leaves rho unchanged; active-set expansion may still reset it to the
        preregistered positive lower bound before scoring.
        """
        active_names = self._active_names(active_constraint_names)
        if not active_names:
            return

        # Direct users that do not have an orchestrator still get consistent
        # transition bookkeeping.  The orchestrator calls this before scoring,
        # so this is normally an idempotent no-op.
        self.prepare_active_constraints(active_names)

        rho_used = self.rho

        for name in active_names:
            v = round_violations.get(name, 0.0)
            self.lambdas[name] = max(0.0, self.lambdas[name] + rho_used * v)

        total_violation = sum(
            round_violations.get(name, 0.0) for name in active_names
        )
        # The formal protocol grows the quadratic penalty only while the
        # accepted iterate remains infeasible.  Continuing to increase rho
        # for a fully feasible incumbent turns a local repair problem into an
        # unnecessarily hard barrier and is not an informative response to
        # constraint progress.  The optional unconditional rule remains
        # available for exploratory configurations.
        rho_grew = bool(
            self.rho_growth_rule == "always" or total_violation > 0.0
        )
        self.rho = (
            min(rho_used * self.rho_growth, self.rho_max)
            if rho_grew
            else rho_used
        )
        rho_increased = self.rho > rho_used

        transition_events = deepcopy(self._pending_transition_events)
        self._pending_transition_events.clear()

        # Record trajectory
        self.trajectory.append({
            "event": "dual_update",
            "lambdas": deepcopy(self.lambdas),
            "violations": deepcopy(round_violations),
            "active_constraints": list(active_names),
            "total_violation": total_violation,
            "rho_used": rho_used,
            "rho": self.rho,
            "rho_growth_rule": self.rho_growth_rule,
            "rho_grew": rho_grew,
            "rho_increased": rho_increased,
            "rho_reset": any(
                event.get("rho_reset", False) for event in transition_events
            ),
            "active_set_events": transition_events,
            "round": round_idx,
            "accepted_smiles": accepted_smiles,
            "accepted_constraint_assessments": deepcopy(
                accepted_constraint_assessments
            ),
            "accepted_oracle_call_index": accepted_oracle_call_index,
            "accepted_oracle_record_sha256": (
                accepted_oracle_record_sha256
            ),
        })

        logger.debug(
            "Lagrangian update: rho=%.2f, total_violation=%.4f, "
            "lambdas=%s",
            self.rho,
            sum(round_violations.get(name, 0.0) for name in active_names),
            {k: f"{v:.3f}" for k, v in self.lambdas.items() if v > 0},
        )

    def get_constraint_priorities(
        self,
        active_constraint_names=None,
        current_assessments: list[dict] | None = None,
    ) -> str:
        """Format truthful current status and accumulated dual pressure.

        A multiplier records accumulated optimization pressure; it is *not* a
        measurement of whether the current molecule passes a constraint.  The
        current pass/fail statement therefore comes only from the analyst's
        value/threshold assessment.  Keeping the two concepts in separate
        sections prevents a stale positive multiplier from being presented to
        the LLM as a current violation (or a zero multiplier as satisfaction).
        """
        active_names = self._active_names(active_constraint_names)
        if not active_names:
            return ""

        assessments_by_name = {
            row.get("name"): row
            for row in (current_assessments or [])
            if isinstance(row, dict) and row.get("name") in active_names
        }
        lines = [
            "Current active-constraint status "
            "(measured for the current molecule):"
        ]
        for name in active_names:
            row = assessments_by_name.get(name)
            cdef = self.constraints.get(name, {})
            threshold = cdef.get("threshold", "?")
            ctype = cdef.get("type", "max")
            op = "<=" if ctype == "max" else ">="
            if row is None:
                lines.append(
                    f"  - {name}: status unavailable; required {op} "
                    f"{threshold}. Do not infer pass/fail from dual pressure."
                )
                continue
            if row.get("missing") is True:
                lines.append(
                    f"  - {name}: FAIL (prediction missing); required "
                    f"{op} {threshold}."
                )
                continue
            value = row.get("value")
            margin = row.get("signed_margin")
            violation = row.get("normalized_violation")
            passed = row.get("pass") is True
            status = "PASS" if passed else "FAIL"
            try:
                value_text = f"{float(value):.6g}"
                margin_text = f"{float(margin):+.6g}"
                violation_text = f"{float(violation):.6g}"
            except (TypeError, ValueError):
                value_text = str(value)
                margin_text = str(margin)
                violation_text = str(violation)
            lines.append(
                f"  - {name}: {status}; value={value_text}, required "
                f"{op} {threshold}, signed_margin={margin_text}, "
                f"normalized_violation={violation_text}."
            )

        sorted_constraints = sorted(
            ((name, self.lambdas[name]) for name in active_names),
            key=lambda x: x[1],
            reverse=True,
        )
        active = [(name, lam) for name, lam in sorted_constraints if lam > 0.01]

        lines.append(
            "Historical dual pressure "
            "(optimization memory; not a current pass/fail test):"
        )
        if active:
            for name, lam in active:
                lines.append(f"  - {name}: accumulated_pressure={lam:.6g}")
        else:
            lines.append("  - none accumulated yet")

        return "\n".join(lines)

    def get_trajectory_summary(self) -> dict:
        """Return summary statistics for convergence analysis."""
        if not self.trajectory:
            return {
                "n_rounds": 0,
                "transition_events": deepcopy(self.transition_events),
            }

        violations_over_time = [t["total_violation"] for t in self.trajectory]
        return {
            "n_rounds": len(self.trajectory),
            "initial_violation": violations_over_time[0] if violations_over_time else 0,
            "final_violation": violations_over_time[-1] if violations_over_time else 0,
            "min_violation": min(violations_over_time),
            "final_rho": self.trajectory[-1]["rho"],
            "final_lambdas": self.trajectory[-1]["lambdas"],
            "transition_events": deepcopy(self.transition_events),
        }

    def get_protocol_metadata(self) -> dict:
        """Return static optimizer provenance for persisted paper runs."""
        return {
            "rho_init": self.rho_init,
            "rho_growth": self.rho_growth,
            "rho_max": self.rho_max,
            "rho_growth_rule": self.rho_growth_rule,
            "reset_rho_on_phase_transition": (
                self.reset_rho_on_phase_transition
            ),
            "phase_transition_rule": "strict_active_constraint_set_expansion",
            "rho_lower_bound": self.rho_init,
            "lambda_transition_rule": "retain_all_learned_lambdas",
        }

    def snapshot_runtime_state(self) -> dict:
        """Capture mutable state so a failed optimization round can roll back."""
        return {
            "lambdas": deepcopy(self.lambdas),
            "rho": self.rho,
            "trajectory": deepcopy(self.trajectory),
            "transition_events": deepcopy(self.transition_events),
            "active_constraint_names": self._active_constraint_names,
            "pending_transition_events": deepcopy(
                self._pending_transition_events
            ),
        }

    def restore_runtime_state(self, state: dict) -> None:
        """Restore a state produced by :meth:`snapshot_runtime_state`."""
        self.lambdas = deepcopy(state["lambdas"])
        self.rho = state["rho"]
        self.trajectory = deepcopy(state["trajectory"])
        self.transition_events = deepcopy(state["transition_events"])
        self._active_constraint_names = tuple(
            state["active_constraint_names"]
        )
        self._pending_transition_events = deepcopy(
            state["pending_transition_events"]
        )

    # --- Internal helpers ---

    def _active_names(self, active_constraint_names) -> tuple[str, ...]:
        """Return a deterministic, validated subset of configured constraints."""
        if active_constraint_names is None:
            return tuple(self.constraint_names)
        requested = set(active_constraint_names)
        return tuple(name for name in self.constraint_names if name in requested)

    # Shared alias table — kept in sync with ADMETAnalystAgent._CONSTRAINT_ALIASES
    _ALIASES: dict[str, str] = {
        "lipinski_mw": "MW",
        "lipinski_logp": "logP",
        "qed": "QED",
        "sa_score": "SA_score",
        "cyp2d6_inh": "CYP2D6_inh",
        "cyp2d6_inh_approx": "CYP2D6_inh_approx",
        "herg": "hERG",
        "herg_approx": "hERG_approx",
        "caco2": "Caco2",
        "caco2_approx": "Caco2_approx",
        "pains": "PAINS",
    }

    def _resolve_value(self, pred: dict, constraint_name: str):
        """Resolve a constraint name to its predicted value."""
        if constraint_name in pred:
            return self._finite_constraint_value(pred[constraint_name])
        mapped = self._ALIASES.get(constraint_name)
        if mapped and mapped in pred:
            return self._finite_constraint_value(pred[mapped])
        if not self.allow_approximate_endpoint_fallback:
            return None
        if mapped:
            approx = f"{mapped}_approx"
            if approx in pred:
                return self._finite_constraint_value(pred[approx])
        approx_key = f"{constraint_name}_approx"
        if approx_key in pred:
            return self._finite_constraint_value(pred[approx_key])
        return None

    @staticmethod
    def _finite_constraint_value(value):
        """Return a numeric finite constraint value, or ``None`` if missing."""
        if value is None or isinstance(value, bool):
            return value
        try:
            numeric = float(value)
        except (TypeError, ValueError, OverflowError):
            return None
        return numeric if math.isfinite(numeric) else None
