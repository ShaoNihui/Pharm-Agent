"""Canonical near-feasible Pareto repair context and result validation.

This archive is deliberately *context only*.  It never participates in
incumbent selection, ADMET pass/fail decisions, Lagrangian updates, candidate
caps, or oracle/LLM budgets.  During the full-constraint phase it retains at
most two deterministic representatives of the observed near-feasible Pareto
front for a later Generator prompt: the highest-target point and the easiest
point to repair.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from copy import deepcopy
import hashlib
import json
import math
from typing import Any


NEAR_FEASIBLE_AUDIT_SCHEMA_VERSION = 2

NEAR_FEASIBLE_ANCHOR_ROLES = (
    "highest_target_activity",
    "lowest_total_normalized_violation",
)

CANONICAL_FULL_ADMET_CONSTRAINTS = (
    "lipinski_mw",
    "lipinski_logp",
    "qed",
    "sa_score",
    "cyp2d6_inh",
    "herg",
    "caco2",
)
CANONICAL_EASY_ADMET_CONSTRAINTS = CANONICAL_FULL_ADMET_CONSTRAINTS[:4]
CANONICAL_FULL_ADMET_CONSTRAINT_SPECS: dict[str, dict[str, float | str]] = {
    "lipinski_mw": {"type": "max", "threshold": 500.0, "scale": 150.0},
    "lipinski_logp": {"type": "max", "threshold": 5.0, "scale": 2.0},
    "qed": {"type": "min", "threshold": 0.3, "scale": 0.2},
    "sa_score": {"type": "max", "threshold": 6.0, "scale": 2.0},
    "cyp2d6_inh": {"type": "max", "threshold": 0.5, "scale": 0.3},
    "herg": {"type": "max", "threshold": 0.5, "scale": 0.3},
    "caco2": {"type": "min", "threshold": -5.15, "scale": 1.0},
}

CANONICAL_NEAR_FEASIBLE_REPAIR_PROTOCOL: dict[str, Any] = {
    "schema_version": 2,
    "scope": "phase3_full_active_set",
    "activation_stagnation_count": 5,
    "max_anchors": 2,
    "eligibility": "infeasible_and_target_strictly_above_best_feasible",
    "dominance": (
        "target_maximize_and_total_normalized_violation_minimize"
    ),
    "roles": list(NEAR_FEASIBLE_ANCHOR_ROLES),
    "normalized_violation_aggregation": "sum",
    "optimizer_influence": "generation_context_only",
}

_ASSESSMENT_FIELDS = {
    "name",
    "value",
    "threshold",
    "type",
    "direction",
    "scale",
    "signed_margin",
    "normalized_violation",
    "pass",
    "missing",
}
_BEST_FEASIBLE_FIELDS = {
    "smiles",
    "target_score",
    "admet_score",
    "round",
    "constraint_assessments",
}
_ANCHOR_FIELDS = _BEST_FEASIBLE_FIELDS | {
    "total_normalized_violation",
    "roles",
}
_EVIDENCE_FIELDS = _BEST_FEASIBLE_FIELDS | {
    "pass_all",
    "oracle_call_index",
    "oracle_record_sha256",
}
_AUDIT_FIELDS = {
    "schema_version",
    "full_active_set",
    "phase_stagnation_count",
    "injection_triggered",
    "current_constraint_assessments",
    "current_record",
    "candidate_records",
    "anchors_injected",
    "best_feasible_before",
    "best_feasible_after",
    "anchors_before",
    "anchors_after",
    "candidate_count",
    "feasible_candidate_count",
    "eligible_candidate_count",
    "dominated_candidate_count",
    "invalid_assessment_count",
    "pareto_front_size",
    "best_feasible_updated",
    "archive_changed",
}


class NearFeasibleRepairProtocolError(ValueError):
    """Raised when structured near-feasible evidence is malformed."""


def canonical_near_feasible_repair_protocol() -> dict[str, Any]:
    """Return a detached copy of the result-level protocol descriptor."""
    return deepcopy(CANONICAL_NEAR_FEASIBLE_REPAIR_PROTOCOL)


def _finite_number(value: object, *, label: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise NearFeasibleRepairProtocolError(f"{label} must be numeric")
    numeric = float(value)
    if not math.isfinite(numeric):
        raise NearFeasibleRepairProtocolError(f"{label} must be finite")
    return numeric


def normalize_constraint_assessments(
    value: object,
    *,
    expected_names: Sequence[str] | None = None,
    reject_missing: bool = False,
) -> list[dict[str, Any]]:
    """Validate and detach the analyst's factual hard-constraint rows.

    The arithmetic is checked, rather than trusting a claimed ``pass`` flag or
    normalized violation.  When ``expected_names`` is supplied, the rows must
    cover that ordered active set exactly once.
    """
    if not isinstance(value, list):
        raise NearFeasibleRepairProtocolError(
            "constraint_assessments must be a list"
        )
    expected = list(expected_names) if expected_names is not None else None
    normalized: list[dict[str, Any]] = []
    seen: set[str] = set()
    for index, raw in enumerate(value):
        if not isinstance(raw, Mapping) or set(raw) != _ASSESSMENT_FIELDS:
            raise NearFeasibleRepairProtocolError(
                f"constraint assessment {index} has an invalid schema"
            )
        name = raw.get("name")
        if not isinstance(name, str) or not name or name in seen:
            raise NearFeasibleRepairProtocolError(
                "constraint assessment names must be unique and non-empty"
            )
        seen.add(name)
        constraint_type = raw.get("type")
        if constraint_type not in {"max", "min"}:
            raise NearFeasibleRepairProtocolError(
                f"constraint assessment {name} has an invalid type"
            )
        expected_direction = "<=" if constraint_type == "max" else ">="
        if raw.get("direction") != expected_direction:
            raise NearFeasibleRepairProtocolError(
                f"constraint assessment {name} has an invalid direction"
            )
        threshold = _finite_number(
            raw.get("threshold"), label=f"{name}.threshold"
        )
        scale = _finite_number(raw.get("scale"), label=f"{name}.scale")
        if scale <= 0.0:
            raise NearFeasibleRepairProtocolError(
                f"constraint assessment {name} scale must be positive"
            )
        missing = raw.get("missing")
        passed = raw.get("pass")
        if not isinstance(missing, bool) or not isinstance(passed, bool):
            raise NearFeasibleRepairProtocolError(
                f"constraint assessment {name} flags must be boolean"
            )

        if missing:
            if reject_missing:
                raise NearFeasibleRepairProtocolError(
                    f"constraint assessment {name} is missing"
                )
            if (
                raw.get("value") is not None
                or raw.get("signed_margin") is not None
                or raw.get("normalized_violation") is not None
                or passed
            ):
                raise NearFeasibleRepairProtocolError(
                    f"missing constraint assessment {name} is inconsistent"
                )
            row = {
                "name": name,
                "value": None,
                "threshold": threshold,
                "type": constraint_type,
                "direction": expected_direction,
                "scale": scale,
                "signed_margin": None,
                "normalized_violation": None,
                "pass": False,
                "missing": True,
            }
        else:
            observed = _finite_number(raw.get("value"), label=f"{name}.value")
            margin = _finite_number(
                raw.get("signed_margin"), label=f"{name}.signed_margin"
            )
            violation = _finite_number(
                raw.get("normalized_violation"),
                label=f"{name}.normalized_violation",
            )
            expected_margin = (
                threshold - observed
                if constraint_type == "max"
                else observed - threshold
            )
            expected_violation = max(0.0, -expected_margin) / scale
            expected_pass = expected_margin >= 0.0
            if (
                not math.isclose(margin, expected_margin, abs_tol=1e-9)
                or not math.isclose(
                    violation, expected_violation, abs_tol=1e-9
                )
                or passed is not expected_pass
            ):
                raise NearFeasibleRepairProtocolError(
                    f"constraint assessment {name} arithmetic is inconsistent"
                )
            row = {
                "name": name,
                "value": observed,
                "threshold": threshold,
                "type": constraint_type,
                "direction": expected_direction,
                "scale": scale,
                "signed_margin": margin,
                "normalized_violation": violation,
                "pass": passed,
                "missing": False,
            }
        normalized.append(row)

    if expected is not None:
        if [row["name"] for row in normalized] != expected:
            raise NearFeasibleRepairProtocolError(
                "constraint assessments do not exactly match the active set"
            )
        if set(expected).issubset(CANONICAL_FULL_ADMET_CONSTRAINT_SPECS):
            for row in normalized:
                spec = CANONICAL_FULL_ADMET_CONSTRAINT_SPECS[row["name"]]
                if (
                    row["type"] != spec["type"]
                    or not math.isclose(
                        float(row["threshold"]),
                        float(spec["threshold"]),
                        abs_tol=1e-12,
                    )
                    or not math.isclose(
                        float(row["scale"]),
                        float(spec["scale"]),
                        abs_tol=1e-12,
                    )
                ):
                    raise NearFeasibleRepairProtocolError(
                        f"constraint assessment {row['name']} does not match "
                        "the frozen formal specification"
                    )
    return normalized


def total_normalized_violation(assessments: Sequence[Mapping]) -> float:
    """Return the finite sum for complete, non-missing assessments."""
    total = 0.0
    for row in assessments:
        if row.get("missing") is True:
            raise NearFeasibleRepairProtocolError(
                "cannot aggregate a missing constraint assessment"
            )
        total += _finite_number(
            row.get("normalized_violation"),
            label=f"{row.get('name', '?')}.normalized_violation",
        )
    return total


def format_near_feasible_context(
    protected_incumbent: Mapping[str, Any],
    anchors: Sequence[Mapping[str, Any]],
) -> str:
    """Render structured facts without promoting an anchor to edit parent."""
    lines = [
        "",
        "Near-feasible Pareto repair context (factual context only):",
        "The protected incumbent below remains the sole edit source. Do not "
        "replace it with an anchor; use anchors only to infer repair ideas.",
        (
            "Protected incumbent: "
            f"SMILES={protected_incumbent.get('smiles', 'N/A')}; "
            f"target={protected_incumbent.get('target_score', 'N/A')}; "
            f"ADMET={protected_incumbent.get('admet_score', 'N/A')}."
        ),
        "Protected-incumbent full-constraint assessments:",
    ]

    def append_assessments(rows: object, *, indent: str) -> None:
        if not isinstance(rows, list) or not rows:
            lines.append(f"{indent}(no complete assessment available)")
            return
        for row in rows:
            if not isinstance(row, Mapping):
                continue
            status = "PASS" if row.get("pass") is True else "FAIL"
            lines.append(
                f"{indent}{row.get('name', '?')}: {status}; "
                f"value={row.get('value')}; required "
                f"{row.get('direction')} {row.get('threshold')}; "
                f"margin={row.get('signed_margin')}; "
                f"normalized_violation={row.get('normalized_violation')}."
            )

    append_assessments(
        protected_incumbent.get("constraint_assessments"), indent="  - "
    )
    if not anchors:
        lines.append("No eligible near-feasible anchor has been observed yet.")
    for index, anchor in enumerate(anchors, start=1):
        lines.append(
            f"Context anchor {index}: roles={anchor.get('roles', [])}; "
            f"SMILES={anchor.get('smiles')}; "
            f"target={anchor.get('target_score')}; "
            f"ADMET={anchor.get('admet_score')}; "
            "total_normalized_violation="
            f"{anchor.get('total_normalized_violation')}."
        )
        append_assessments(
            anchor.get("constraint_assessments"), indent="    - "
        )
    return "\n".join(lines)


def near_feasible_dominates(left: Mapping, right: Mapping) -> bool:
    """Return Pareto dominance under target-maximize/violation-minimize."""
    left_target = float(left["target_score"])
    right_target = float(right["target_score"])
    left_violation = float(left["total_normalized_violation"])
    right_violation = float(right["total_normalized_violation"])
    return (
        left_target >= right_target
        and left_violation <= right_violation
        and (
            left_target > right_target
            or left_violation < right_violation
        )
    )


def select_near_feasible_anchors(
    candidates: Sequence[Mapping[str, Any]],
) -> tuple[list[dict[str, Any]], int, int]:
    """Pareto-filter candidates and retain two deterministic extrema.

    Returns ``(anchors, pareto_front_size, dominated_count)``.  Exact
    objective ties use canonical SMILES as a stable tie-break.
    """
    by_smiles: dict[str, dict[str, Any]] = {}
    for raw in candidates:
        record = deepcopy(dict(raw))
        record.pop("roles", None)
        smiles = record.get("smiles")
        if not isinstance(smiles, str) or not smiles:
            raise NearFeasibleRepairProtocolError(
                "near-feasible candidate SMILES must be non-empty"
            )
        previous = by_smiles.get(smiles)
        if previous is None or (
            -float(record["target_score"]),
            float(record["total_normalized_violation"]),
            smiles,
        ) < (
            -float(previous["target_score"]),
            float(previous["total_normalized_violation"]),
            smiles,
        ):
            by_smiles[smiles] = record
    pool = list(by_smiles.values())
    front = [
        candidate
        for candidate in pool
        if not any(
            other is not candidate
            and near_feasible_dominates(other, candidate)
            for other in pool
        )
    ]
    dominated_count = len(pool) - len(front)
    if not front:
        return [], 0, dominated_count

    activity = min(
        front,
        key=lambda row: (
            -float(row["target_score"]),
            float(row["total_normalized_violation"]),
            row["smiles"],
        ),
    )
    repairability = min(
        front,
        key=lambda row: (
            float(row["total_normalized_violation"]),
            -float(row["target_score"]),
            row["smiles"],
        ),
    )
    selected: list[dict[str, Any]] = []
    for role, record in zip(
        NEAR_FEASIBLE_ANCHOR_ROLES,
        (activity, repairability),
        strict=True,
    ):
        existing = next(
            (row for row in selected if row["smiles"] == record["smiles"]),
            None,
        )
        if existing is None:
            existing = deepcopy(record)
            existing["roles"] = []
            selected.append(existing)
        existing["roles"].append(role)
    return selected, len(front), dominated_count


def _valid_record(value: object, *, anchor: bool) -> bool:
    if not isinstance(value, Mapping):
        return False
    expected_fields = _ANCHOR_FIELDS if anchor else _BEST_FEASIBLE_FIELDS
    if set(value) != expected_fields:
        return False
    if not isinstance(value.get("smiles"), str) or not value["smiles"]:
        return False
    round_index = value.get("round")
    if (
        isinstance(round_index, bool)
        or not isinstance(round_index, int)
        or round_index < 0
    ):
        return False
    try:
        target_score = _finite_number(
            value.get("target_score"), label="target_score"
        )
        admet_score = _finite_number(
            value.get("admet_score"), label="admet_score"
        )
        if not (0.0 <= target_score <= 1.0 and 0.0 <= admet_score <= 1.0):
            return False
        assessments = normalize_constraint_assessments(
            value.get("constraint_assessments"),
            expected_names=CANONICAL_FULL_ADMET_CONSTRAINTS,
            reject_missing=True,
        )
    except NearFeasibleRepairProtocolError:
        return False
    all_pass = all(row["pass"] for row in assessments)
    if anchor:
        try:
            total = _finite_number(
                value.get("total_normalized_violation"),
                label="total_normalized_violation",
            )
            expected_total = total_normalized_violation(assessments)
        except NearFeasibleRepairProtocolError:
            return False
        roles = value.get("roles")
        if (
            total <= 0.0
            or not math.isclose(total, expected_total, abs_tol=1e-9)
            or all_pass
            or not isinstance(roles, list)
            or not roles
            or roles
            != [role for role in NEAR_FEASIBLE_ANCHOR_ROLES if role in roles]
            or len(set(roles)) != len(roles)
        ):
            return False
    elif not all_pass:
        return False
    return True


def _valid_evidence_record(value: object) -> bool:
    """Validate a scored incumbent/candidate used to replay an archive step."""
    if not isinstance(value, Mapping) or set(value) != _EVIDENCE_FIELDS:
        return False
    if not isinstance(value.get("pass_all"), bool):
        return False
    call_index = value.get("oracle_call_index")
    record_sha = value.get("oracle_record_sha256")
    if (call_index is None) != (record_sha is None):
        return False
    if call_index is not None and (
        isinstance(call_index, bool)
        or not isinstance(call_index, int)
        or call_index < 1
        or not isinstance(record_sha, str)
        or len(record_sha) != 64
        or any(character not in "0123456789abcdef" for character in record_sha)
    ):
        return False
    base = {
        key: deepcopy(item)
        for key, item in value.items()
        if key != "pass_all"
    }
    # ``_valid_record`` accepts only feasible records, so validate the shared
    # identity/score/assessment schema directly for either outcome.
    if not isinstance(base.get("smiles"), str) or not base["smiles"]:
        return False
    round_index = base.get("round")
    if (
        isinstance(round_index, bool)
        or not isinstance(round_index, int)
        or round_index < 0
    ):
        return False
    try:
        target_score = _finite_number(
            base.get("target_score"), label="target_score"
        )
        admet_score = _finite_number(
            base.get("admet_score"), label="admet_score"
        )
        assessments = normalize_constraint_assessments(
            base.get("constraint_assessments"),
            expected_names=CANONICAL_FULL_ADMET_CONSTRAINTS,
            reject_missing=True,
        )
    except NearFeasibleRepairProtocolError:
        return False
    if not (0.0 <= target_score <= 1.0 and 0.0 <= admet_score <= 1.0):
        return False
    return value["pass_all"] is all(row["pass"] for row in assessments)


def _canonical_record_sha256(value: Mapping[str, Any]) -> str:
    payload = json.dumps(
        dict(value),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _safe_canonical_record_sha256(value: Mapping[str, Any]) -> str | None:
    """Return a digest for a JSON-safe oracle row, otherwise fail closed."""
    try:
        return _canonical_record_sha256(value)
    except (TypeError, ValueError, OverflowError):
        return None


def advance_near_feasible_archive(
    *,
    full_active_set: bool,
    best_feasible: dict | None,
    anchors: list[dict],
    current_record: dict | None,
    candidate_records: list[dict],
) -> tuple[dict | None, list[dict], dict[str, int]]:
    """Deterministically replay one context-only archive transition.

    This pure function is shared by the optimizer and the result validator so
    persisted ``before``/``after`` claims are never trusted without replaying
    the exact incumbent and scored-candidate evidence.
    """
    best_after = deepcopy(best_feasible)
    anchors_before = deepcopy(anchors)
    stats = {
        "candidate_count": 0,
        "feasible_candidate_count": 0,
        "eligible_candidate_count": 0,
        "dominated_candidate_count": 0,
        "invalid_assessment_count": 0,
        "pareto_front_size": 0,
    }
    if not full_active_set:
        return best_after, anchors_before, stats

    stats["candidate_count"] = len(candidate_records)
    feasible_records = []
    if current_record is not None and current_record.get("pass_all") is True:
        feasible_records.append({
            key: deepcopy(current_record[key])
            for key in _BEST_FEASIBLE_FIELDS
        })
    for record in candidate_records:
        assessments = record.get("constraint_assessments")
        if assessments is None:
            stats["invalid_assessment_count"] += 1
            continue
        if record.get("pass_all") is True:
            stats["feasible_candidate_count"] += 1
            feasible_records.append({
                key: deepcopy(record[key])
                for key in _BEST_FEASIBLE_FIELDS
            })

    for record in sorted(
        feasible_records,
        key=lambda row: (-float(row["target_score"]), row["smiles"]),
    ):
        if best_after is None or (
            -float(record["target_score"]),
            record["smiles"],
        ) < (
            -float(best_after["target_score"]),
            best_after["smiles"],
        ):
            best_after = deepcopy(record)

    target_floor = (
        float("-inf")
        if best_after is None
        else float(best_after["target_score"])
    )
    retained = [
        {
            key: deepcopy(item)
            for key, item in anchor.items()
            if key != "roles"
        }
        for anchor in anchors_before
        if float(anchor["target_score"]) > target_floor
    ]
    eligible = []
    for record in candidate_records:
        assessments = record.get("constraint_assessments")
        if (
            assessments is None
            or record.get("pass_all") is True
            or float(record["target_score"]) <= target_floor
        ):
            continue
        total_violation = total_normalized_violation(assessments)
        if total_violation <= 0.0:
            stats["invalid_assessment_count"] += 1
            continue
        eligible.append({
            key: deepcopy(record[key])
            for key in _BEST_FEASIBLE_FIELDS
        } | {"total_normalized_violation": total_violation})
    stats["eligible_candidate_count"] = len(eligible)
    selected, front_size, _ = select_near_feasible_anchors(
        retained + eligible
    )
    stats["pareto_front_size"] = front_size
    pool = retained + eligible
    stats["dominated_candidate_count"] = sum(
        any(
            other is not candidate
            and near_feasible_dominates(other, candidate)
            for other in pool
        )
        for candidate in eligible
    )
    return best_after, selected, stats


def validate_near_feasible_state(
    best_feasible: object,
    anchors: object,
) -> bool:
    """Validate one persisted best-feasible/archive state pair."""
    if best_feasible is not None and not _valid_record(
        best_feasible, anchor=False
    ):
        return False
    if not isinstance(anchors, list) or len(anchors) > 2:
        return False
    if any(not _valid_record(row, anchor=True) for row in anchors):
        return False
    smiles = [row["smiles"] for row in anchors]
    if len(smiles) != len(set(smiles)):
        return False
    if best_feasible is not None and any(
        float(row["target_score"])
        <= float(best_feasible["target_score"])
        for row in anchors
    ):
        return False
    try:
        selected, _, _ = select_near_feasible_anchors(anchors)
    except NearFeasibleRepairProtocolError:
        return False
    return selected == anchors


def validate_near_feasible_repair_result(
    value: object,
    *,
    require_evaluation_history_binding: bool = False,
) -> bool:
    """Validate protocol, state transitions, and every trajectory audit."""
    if not isinstance(value, Mapping):
        return False
    if value.get("near_feasible_repair_protocol") != (
        CANONICAL_NEAR_FEASIBLE_REPAIR_PROTOCOL
    ):
        return False
    trajectory = value.get("trajectory")
    if not isinstance(trajectory, list):
        return False
    final_best = value.get("best_feasible")
    final_anchors = value.get("near_feasible_anchors")
    if not validate_near_feasible_state(final_best, final_anchors):
        return False

    previous_best = None
    previous_anchors: list[dict[str, Any]] = []
    history_by_smiles: dict[str, Mapping[str, Any]] = {}
    history_by_call_index: dict[int, Mapping[str, Any]] = {}
    if require_evaluation_history_binding:
        history = value.get("evaluation_history")
        if not isinstance(history, list):
            return False
        for row in history:
            if (
                not isinstance(row, Mapping)
                or not isinstance(row.get("smiles"), str)
                or row["smiles"] in history_by_smiles
            ):
                return False
            call_index = row.get("call_index")
            if (
                isinstance(call_index, bool)
                or not isinstance(call_index, int)
                or call_index != len(history_by_call_index) + 1
            ):
                return False
            context = row.get("oracle_context")
            if not isinstance(context, Mapping):
                return False
            if call_index <= min(26, len(history)):
                if dict(context) != {
                    "scope": "seed_pool",
                    "seed_pool_index": call_index - 1,
                }:
                    return False
            else:
                context_round = context.get("round")
                candidate_index = context.get("candidate_index")
                if (
                    set(context) != {"scope", "round", "candidate_index"}
                    or context.get("scope") != "optimization_round"
                    or isinstance(context_round, bool)
                    or not isinstance(context_round, int)
                    or context_round < 0
                    or isinstance(candidate_index, bool)
                    or not isinstance(candidate_index, int)
                    or candidate_index < 0
                ):
                    return False
            history_by_smiles[row["smiles"]] = row
            history_by_call_index[call_index] = row

    previous_accepted_smiles: str | None = None
    previous_trajectory_round = -1
    previous_trajectory_oracle_calls = 0

    def outer_identity_matches_history(
        trajectory_row: Mapping[str, Any],
    ) -> bool:
        """Bind the controller source/accepted chain to real oracle rows."""
        nonlocal previous_accepted_smiles
        if not require_evaluation_history_binding:
            return True
        source_smiles = trajectory_row.get("source_smiles")
        accepted_smiles = trajectory_row.get("accepted_smiles")
        if (
            not isinstance(source_smiles, str)
            or not source_smiles
            or not isinstance(accepted_smiles, str)
            or not accepted_smiles
        ):
            return False
        source_row = history_by_smiles.get(source_smiles)
        accepted_row = history_by_smiles.get(accepted_smiles)
        if source_row is None or accepted_row is None:
            return False

        if previous_accepted_smiles is None:
            seed_pool_size = min(26, len(history_by_call_index))
            seed_rows = [
                history_by_call_index[index]
                for index in range(1, seed_pool_size + 1)
            ]
            try:
                initial_source = max(
                    seed_rows,
                    key=lambda row: (
                        float(row["raw_target_score"]),
                        -int(row["call_index"]),
                    ),
                )["smiles"]
            except (KeyError, TypeError, ValueError, OverflowError):
                return False
            if source_smiles != initial_source:
                return False
        elif source_smiles != previous_accepted_smiles:
            return False

        source_index = source_row.get("call_index")
        accepted_index = accepted_row.get("call_index")
        if (
            isinstance(source_index, bool)
            or not isinstance(source_index, int)
            or isinstance(accepted_index, bool)
            or not isinstance(accepted_index, int)
            or trajectory_row.get("source_oracle_call_index") != source_index
            or trajectory_row.get("accepted_oracle_call_index")
            != accepted_index
            or trajectory_row.get("source_oracle_record_sha256")
            != _safe_canonical_record_sha256(source_row)
            or trajectory_row.get("accepted_oracle_record_sha256")
            != _safe_canonical_record_sha256(accepted_row)
        ):
            return False
        oracle_calls = trajectory_row.get("oracle_calls")
        n_candidates = trajectory_row.get("n_candidates")
        improves = trajectory_row.get("candidate_improves")
        if (
            isinstance(oracle_calls, bool)
            or not isinstance(oracle_calls, int)
            or isinstance(n_candidates, bool)
            or not isinstance(n_candidates, int)
            or n_candidates < 0
            or n_candidates > oracle_calls
            or oracle_calls > len(history_by_call_index)
            or not isinstance(improves, bool)
        ):
            return False
        candidate_start = oracle_calls - n_candidates + 1
        novelty_audit = trajectory_row.get("novelty_audit")
        globally_novel_count = (
            novelty_audit.get("globally_novel_count")
            if isinstance(novelty_audit, Mapping)
            else None
        )
        if (
            isinstance(globally_novel_count, bool)
            or not isinstance(globally_novel_count, int)
            or globally_novel_count < n_candidates
        ):
            return False
        candidate_context_indices = []
        for index in range(candidate_start, oracle_calls + 1):
            context = history_by_call_index[index].get("oracle_context")
            if (
                not isinstance(context, Mapping)
                or context.get("scope") != "optimization_round"
                or context.get("round") != trajectory_row.get("round")
            ):
                return False
            candidate_context_indices.append(context.get("candidate_index"))
        if any(
            isinstance(index, bool) or not isinstance(index, int)
            for index in candidate_context_indices
        ) or any(
            index < 0 or index >= globally_novel_count
            for index in candidate_context_indices
        ) or any(
            previous >= current
            for previous, current in zip(
                candidate_context_indices,
                candidate_context_indices[1:],
                strict=False,
            )
        ):
            return False
        if improves:
            if not (
                n_candidates > 0
                and candidate_start <= int(accepted_index) <= oracle_calls
                and accepted_smiles != source_smiles
            ):
                return False
        elif accepted_smiles != source_smiles or accepted_index != source_index:
            return False

        active_constraints = trajectory_row.get("active_constraints")
        if active_constraints == []:
            try:
                source_score = float(source_row["raw_target_score"])
                candidate_rows = [
                    history_by_call_index[index]
                    for index in range(candidate_start, oracle_calls + 1)
                ]
                winner = None
                winner_score = float("-inf")
                for candidate_row in candidate_rows:
                    score = float(candidate_row["raw_target_score"])
                    if score > winner_score:
                        winner = candidate_row
                        winner_score = score
                expected_improves = bool(
                    winner is not None and winner_score > source_score
                )
                expected_accepted = (
                    winner["smiles"] if expected_improves else source_smiles
                )
                expected_score = (
                    winner_score if expected_improves else source_score
                )
                numeric_fields_match = (
                    math.isclose(
                        float(trajectory_row.get("source_combined_score")),
                        source_score,
                        abs_tol=1e-12,
                    )
                    and math.isclose(
                        float(trajectory_row.get("best_combined")),
                        expected_score,
                        abs_tol=1e-12,
                    )
                    and math.isclose(
                        float(trajectory_row.get("best_score")),
                        float(
                            history_by_smiles[expected_accepted][
                                "raw_target_score"
                            ]
                        ),
                        abs_tol=1e-12,
                    )
                )
            except (KeyError, TypeError, ValueError, OverflowError):
                return False
            if (
                improves is not expected_improves
                or accepted_smiles != expected_accepted
                or not numeric_fields_match
            ):
                return False
        previous_accepted_smiles = accepted_smiles
        return True

    def evidence_matches_history(
        evidence: Mapping[str, Any], *, maximum_call_index: int
    ) -> bool:
        if not require_evaluation_history_binding:
            return True
        history_row = history_by_smiles.get(evidence["smiles"])
        if history_row is None:
            return False
        call_index = history_row.get("call_index")
        if (
            isinstance(call_index, bool)
            or not isinstance(call_index, int)
            or call_index < 1
            or call_index > maximum_call_index
        ):
            return False
        try:
            target_matches = math.isclose(
                float(history_row.get("raw_target_score")),
                float(evidence["target_score"]),
                abs_tol=1e-12,
            )
            admet_matches = math.isclose(
                float(history_row.get("admet_score")),
                float(evidence["admet_score"]),
                abs_tol=1e-12,
            )
        except (TypeError, ValueError, OverflowError):
            return False
        return (
            target_matches
            and admet_matches
            and history_row.get("pass_all") is evidence["pass_all"]
            and history_row.get("constraint_assessments")
            == evidence["constraint_assessments"]
            and evidence.get("oracle_call_index") == call_index
            and evidence.get("oracle_record_sha256")
            == _safe_canonical_record_sha256(history_row)
        )

    threshold = int(
        CANONICAL_NEAR_FEASIBLE_REPAIR_PROTOCOL[
            "activation_stagnation_count"
        ]
    )
    for trajectory_row in trajectory:
        if not isinstance(trajectory_row, Mapping):
            return False
        round_index = trajectory_row.get("round")
        active_constraints = trajectory_row.get("active_constraints")
        oracle_calls = trajectory_row.get("oracle_calls")
        if (
            isinstance(round_index, bool)
            or not isinstance(round_index, int)
            or round_index <= previous_trajectory_round
            or not isinstance(active_constraints, list)
            or tuple(active_constraints)
            not in {
                (),
                CANONICAL_EASY_ADMET_CONSTRAINTS,
                CANONICAL_FULL_ADMET_CONSTRAINTS,
            }
            or isinstance(oracle_calls, bool)
            or not isinstance(oracle_calls, int)
            or oracle_calls < previous_trajectory_oracle_calls
            or (
                require_evaluation_history_binding
                and oracle_calls > len(history_by_call_index)
            )
        ):
            return False
        previous_trajectory_round = round_index
        previous_trajectory_oracle_calls = oracle_calls
        if not outer_identity_matches_history(trajectory_row):
            return False
        audit = trajectory_row.get("near_feasible_audit")
        if not isinstance(audit, Mapping) or set(audit) != _AUDIT_FIELDS:
            return False
        if audit.get("schema_version") != NEAR_FEASIBLE_AUDIT_SCHEMA_VERSION:
            return False
        if audit.get("best_feasible_before") != previous_best:
            return False
        if audit.get("anchors_before") != previous_anchors:
            return False
        best_after = audit.get("best_feasible_after")
        anchors_after = audit.get("anchors_after")
        if not validate_near_feasible_state(best_after, anchors_after):
            return False

        full_active = audit.get("full_active_set")
        injection = audit.get("injection_triggered")
        stagnation = audit.get("phase_stagnation_count")
        if (
            not isinstance(full_active, bool)
            or not isinstance(injection, bool)
            or isinstance(stagnation, bool)
            or not isinstance(stagnation, int)
            or stagnation < 0
            or injection != (full_active and stagnation >= threshold)
        ):
            return False
        if full_active is not (
            tuple(active_constraints) == CANONICAL_FULL_ADMET_CONSTRAINTS
        ):
            return False
        current = audit.get("current_constraint_assessments")
        current_record = audit.get("current_record")
        candidate_records = audit.get("candidate_records")
        injected = audit.get("anchors_injected")
        if not isinstance(injected, list) or not isinstance(
            candidate_records, list
        ):
            return False
        try:
            if full_active:
                normalized_current = normalize_constraint_assessments(
                    current,
                    expected_names=CANONICAL_FULL_ADMET_CONSTRAINTS,
                    reject_missing=True,
                )
                if (
                    not _valid_evidence_record(current_record)
                    or current_record["round"] != trajectory_row.get("round")
                    or current_record["constraint_assessments"]
                    != normalized_current
                    or (
                        require_evaluation_history_binding
                        and (
                            current_record["smiles"]
                            != trajectory_row.get("source_smiles")
                            or current_record["oracle_call_index"]
                            != trajectory_row.get(
                                "source_oracle_call_index"
                            )
                            or current_record["oracle_record_sha256"]
                            != trajectory_row.get(
                                "source_oracle_record_sha256"
                            )
                        )
                    )
                    or any(
                        not _valid_evidence_record(record)
                        or record["round"] != trajectory_row.get("round")
                        for record in candidate_records
                    )
                    or len({record["smiles"] for record in candidate_records})
                    != len(candidate_records)
                ):
                    return False
            elif (
                current != []
                or current_record is not None
                or candidate_records != []
            ):
                return False
        except NearFeasibleRepairProtocolError:
            return False
        if injected != (previous_anchors if injection else []):
            return False

        integer_fields = (
            "candidate_count",
            "feasible_candidate_count",
            "eligible_candidate_count",
            "dominated_candidate_count",
            "invalid_assessment_count",
            "pareto_front_size",
        )
        if any(
            isinstance(audit.get(field), bool)
            or not isinstance(audit.get(field), int)
            or audit[field] < 0
            for field in integer_fields
        ):
            return False
        if (
            audit["feasible_candidate_count"] > audit["candidate_count"]
            or audit["eligible_candidate_count"] > audit["candidate_count"]
            or audit["invalid_assessment_count"] > audit["candidate_count"]
            or (
                audit["feasible_candidate_count"]
                + audit["eligible_candidate_count"]
                + audit["invalid_assessment_count"]
                > audit["candidate_count"]
            )
            or audit["dominated_candidate_count"]
            > audit["eligible_candidate_count"]
            or audit["candidate_count"] != len(candidate_records)
            or audit.get("best_feasible_updated")
            is not (previous_best != best_after)
            or audit.get("archive_changed")
            is not (previous_anchors != anchors_after)
        ):
            return False
        replay_best, replay_anchors, replay_stats = (
            advance_near_feasible_archive(
                full_active_set=full_active,
                best_feasible=deepcopy(previous_best),
                anchors=deepcopy(previous_anchors),
                current_record=deepcopy(current_record),
                candidate_records=deepcopy(candidate_records),
            )
        )
        if (
            replay_best != best_after
            or replay_anchors != anchors_after
            or any(audit[field] != replay_stats[field] for field in replay_stats)
        ):
            return False
        if full_active and require_evaluation_history_binding:
            round_oracle_calls = trajectory_row.get("oracle_calls")
            if (
                isinstance(round_oracle_calls, bool)
                or not isinstance(round_oracle_calls, int)
                or round_oracle_calls < len(candidate_records)
                or trajectory_row.get("n_candidates")
                != len(candidate_records)
                or not evidence_matches_history(
                    current_record,
                    maximum_call_index=(
                        round_oracle_calls - len(candidate_records)
                    ),
                )
            ):
                return False
            candidate_call_indices = []
            for record in candidate_records:
                if not evidence_matches_history(
                    record, maximum_call_index=round_oracle_calls
                ):
                    return False
                candidate_call_indices.append(
                    int(history_by_smiles[record["smiles"]]["call_index"])
                )
            if candidate_call_indices != list(range(
                round_oracle_calls - len(candidate_records) + 1,
                round_oracle_calls + 1,
            )):
                return False
        if not full_active and (
            any(audit[field] for field in integer_fields)
            or best_after != previous_best
            or anchors_after != previous_anchors
        ):
            return False
        previous_best = deepcopy(best_after)
        previous_anchors = deepcopy(anchors_after)

    return previous_best == final_best and previous_anchors == final_anchors


__all__ = [
    "CANONICAL_NEAR_FEASIBLE_REPAIR_PROTOCOL",
    "CANONICAL_EASY_ADMET_CONSTRAINTS",
    "CANONICAL_FULL_ADMET_CONSTRAINTS",
    "CANONICAL_FULL_ADMET_CONSTRAINT_SPECS",
    "NEAR_FEASIBLE_ANCHOR_ROLES",
    "NEAR_FEASIBLE_AUDIT_SCHEMA_VERSION",
    "NearFeasibleRepairProtocolError",
    "advance_near_feasible_archive",
    "canonical_near_feasible_repair_protocol",
    "format_near_feasible_context",
    "normalize_constraint_assessments",
    "near_feasible_dominates",
    "select_near_feasible_anchors",
    "total_normalized_violation",
    "validate_near_feasible_repair_result",
    "validate_near_feasible_state",
]
