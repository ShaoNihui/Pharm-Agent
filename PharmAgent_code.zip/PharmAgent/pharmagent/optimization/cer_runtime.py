"""Runtime wiring for seed-isolated, cross-task Chemical-CER databases."""

from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
from typing import Any, Sequence

from pharmagent.optimization.experience_replay import ExperienceDB
from pharmagent.optimization.near_feasible_archive import (
    CANONICAL_FULL_ADMET_CONSTRAINTS,
)
from pharmagent.optimization.run_state_protocol import (
    PublicRunStateError,
    replay_native_loop_state,
)


def _canonical_sha256(value: dict[str, Any]) -> str:
    payload = json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def configure_seed_cer(
    base_config: dict,
    *,
    cer_root: str | Path | None,
    seed: int,
    phase: str,
    tasks: Sequence[str],
) -> dict:
    """Return an isolated per-seed config sharing CER across ordered tasks.

    With no ``cer_root`` the copied config is forced into in-memory CER mode.
    Persistent runtime fields are never inherited silently from a YAML file.
    """
    config = copy.deepcopy(base_config)
    cer = config.setdefault("cer", {})
    for key in ("path", "seed", "identity"):
        cer.pop(key, None)
    if cer_root is None or not cer.get("enabled", False):
        return config

    if isinstance(seed, bool) or not isinstance(seed, int) or seed < 0:
        raise ValueError("CER seed must be a non-negative integer")
    ordered_tasks = tuple(tasks)
    if not ordered_tasks or len(ordered_tasks) != len(set(ordered_tasks)):
        raise ValueError("CER task order must be non-empty and duplicate-free")

    # Hash the complete scientific config before injecting runtime file fields.
    # The task order is explicit because CER transfer is order-dependent.
    config_sha256 = _canonical_sha256(config)
    root = Path(cer_root).expanduser().resolve()
    cer.update(
        path=str(root / f"seed_{seed}.sqlite3"),
        seed=seed,
        identity={
            "kind": "pharmagent-chemical-cer",
            "identity_version": 2,
            "phase": phase,
            "seed": seed,
            "task_order": list(ordered_tasks),
            "config_sha256": config_sha256,
        },
    )
    return config


def clear_incomplete_task(config: dict, task: str) -> int:
    """Clear partial rows for an incomplete task without touching prior tasks."""
    cer = config.get("cer", {})
    if not cer.get("enabled", False) or not cer.get("path"):
        return 0
    with ExperienceDB(cer) as database:
        return database.delete_task(task)


def result_sha256(result: dict) -> str:
    """Digest the stable scientific result across exact terminal replay.

    A crash may occur after the CER completion marker commits but before the
    result JSON is replaced.  Exact native terminal replay then regenerates
    wall-clock elapsed time and increments the journal's persistence revision;
    neither value changes the scientific run.  Exclude those runtime-only
    fields, together with the live prompt memory that is already physically
    replayed and independently bound by the native state protocol.
    """
    serializable = {
        key: copy.deepcopy(value)
        for key, value in result.items()
        if key not in {"elapsed_time", "memory"}
    }
    native_snapshot = serializable.get("native_run_journal")
    if isinstance(native_snapshot, dict):
        native_snapshot.pop("optimizer_state_revision", None)
    payload = json.dumps(
        {
            "schema_version": 1,
            "scientific_result": serializable,
        },
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
        default=str,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _expected_result_cer_entry_hashes(
    database: ExperienceDB,
    result: dict,
) -> list[str]:
    """Rebuild a task's sealed CER lineage from public physical evidence."""
    history = result.get("evaluation_history")
    trajectory = result.get("trajectory")
    failures = result.get("round_failure_history")
    if (
        not isinstance(history, list)
        or len(history) < 26
        or not isinstance(trajectory, list)
        or not isinstance(failures, list)
    ):
        raise ValueError("completed result lacks replayable CER evidence")
    attempted = [
        int(row["round"])
        for row in [*trajectory, *failures]
        if isinstance(row, dict) and "round" in row
    ]
    if not attempted:
        raise ValueError("completed result has no optimization round outcome")
    max_rounds = max(attempted) + 1
    selected_seed = max(
        enumerate(history[:26]),
        key=lambda pair: (
            float(pair[1]["raw_target_score"]), -pair[0]
        ),
    )[1]["smiles"]
    identity = database.identity or {}
    phase = identity.get("phase")
    constrained = phase != "standard"
    try:
        replayed = replay_native_loop_state(
            trajectory=trajectory,
            round_failure_history=failures,
            evaluation_history=history,
            seed_smiles=selected_seed,
            target_property=result.get("task"),
            stage="terminal",
            next_round=max_rounds,
            max_rounds=max_rounds,
            allowed_active_constraint_names=(
                CANONICAL_FULL_ADMET_CONSTRAINTS if constrained else ()
            ),
            curriculum_transition_history=result.get(
                "curriculum_transition_history"
            ),
            oracle_complete_count=len(history),
            lagrangian_enabled=isinstance(
                result.get("lagrangian_trajectory"), list
            ),
            reviewer_enabled=True,
            require_reviewer_feedback=False,
            memory_capacity=0,
            initial_admet_score=0.0 if constrained else 1.0,
        )
    except (KeyError, TypeError, ValueError, PublicRunStateError) as error:
        raise ValueError(
            "completed result CER lineage is not physically replayable"
        ) from error
    return [
        database.entry_hash_for(entry)
        for entry in replayed["cer_experience_entries"]
    ]


def mark_task_complete(
    config: dict,
    *,
    task: str,
    task_index: int,
    result: dict,
) -> None:
    """Commit the CER completion marker before the JSON checkpoint is saved."""
    cer = config.get("cer", {})
    if not cer.get("enabled", False) or not cer.get("path"):
        return
    with ExperienceDB(cer) as database:
        database.mark_task_complete(
            task,
            task_index,
            result_sha256(result),
            expected_entry_hashes=_expected_result_cer_entry_hashes(
                database, result
            ),
        )


def require_task_complete(
    config: dict,
    *,
    task: str,
    task_index: int,
    result: dict,
    require_experience_presence: bool = False,
) -> None:
    """Reconcile a validated result checkpoint with the seed's CER audit trail."""
    cer = config.get("cer", {})
    if not cer.get("enabled", False) or not cer.get("path"):
        return
    with ExperienceDB(cer) as database:
        database.require_task_complete(
            task,
            task_index,
            result_sha256(result),
            require_experience_presence=require_experience_presence,
            expected_entry_hashes=_expected_result_cer_entry_hashes(
                database, result
            ),
        )


def persistent_seed_paths(
    base_config: dict,
    *,
    cer_root: str | Path | None,
    seeds: int,
) -> tuple[Path, ...]:
    """Return seed DB targets when persistence applies to this config."""
    if cer_root is None or not base_config.get("cer", {}).get("enabled", False):
        return ()
    root = Path(cer_root).expanduser().resolve()
    return tuple(root / f"seed_{seed}.sqlite3" for seed in range(seeds))
