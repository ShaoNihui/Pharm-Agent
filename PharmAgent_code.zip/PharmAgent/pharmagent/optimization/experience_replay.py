"""
Chemical-aware Contextual Experience Replay (Chemical-CER).

The default database is process-local and in memory. Formal benchmark runners
can opt into a SQLite-backed database by supplying ``cer.path``, ``cer.seed``,
and ``cer.identity``. A persistent database is deliberately strict: it is
bound to one seed and one complete protocol identity, validates its SQL schema
on every open, and writes each experience in an atomic transaction.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from datetime import datetime, timezone
import hashlib
import json
import logging
import math
from pathlib import Path
import sqlite3
from typing import Any

import numpy as np

from pharmagent.optimization.formal_prompt_protocol import (
    canonicalize_formal_modifications,
)
from pharmagent.tools.rdkit_tools import compute_morgan_fp, validate_smiles

logger = logging.getLogger(__name__)


SCHEMA_VERSION = 3


class ExperienceDBError(RuntimeError):
    """Raised when a persistent CER database is unsafe to use."""


def _canonical_json(value: Any) -> str:
    try:
        return json.dumps(
            value,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        )
    except (TypeError, ValueError) as error:
        raise ExperienceDBError(
            f"CER identity/value is not canonical JSON: {error}"
        ) from error


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class ExperienceDB:
    """Chemical-aware experience replay with optional SQLite persistence.

    In-memory mode is the default. Persistent mode requires these additional
    config keys:

    ``path``
        SQLite file path. It must not be ``:memory:``.
    ``seed``
        Non-negative run index. Runners allocate one file per seed.
    ``identity``
        A JSON-serializable mapping describing the scientific protocol. An
        existing file is rejected if any identity or CER hyperparameter differs.
    """

    _EXPECTED_EXPERIENCE_COLUMNS = (
        ("id", "INTEGER", 0, 1),
        ("entry_hash", "TEXT", 1, 0),
        ("source_smiles", "TEXT", 1, 0),
        ("target_smiles", "TEXT", 1, 0),
        ("modifications_json", "TEXT", 1, 0),
        ("delta_target", "REAL", 1, 0),
        ("delta_admet", "REAL", 1, 0),
        ("delta_combined", "REAL", 1, 0),
        ("task_name", "TEXT", 1, 0),
        ("round", "INTEGER", 1, 0),
        ("fingerprint", "BLOB", 1, 0),
        ("created_at", "TEXT", 1, 0),
    )
    _EXPECTED_METADATA_COLUMNS = (
        ("key", "TEXT", 0, 1),
        ("value", "TEXT", 1, 0),
    )
    _EXPECTED_COMPLETION_COLUMNS = (
        ("task_name", "TEXT", 0, 1),
        ("task_index", "INTEGER", 1, 0),
        ("result_sha256", "TEXT", 1, 0),
        ("experience_count", "INTEGER", 1, 0),
        ("experience_hashes_json", "TEXT", 1, 0),
        ("experience_digest", "TEXT", 1, 0),
        ("completed_at", "TEXT", 1, 0),
    )

    def __init__(self, config: dict | None = None):
        config = config or {}
        self.max_size = self._positive_int(
            config.get("max_size", 1000), "max_size"
        )
        self.top_k = self._positive_int(config.get("top_k", 5), "top_k")
        self.fp_radius = self._positive_int(
            config.get("fp_radius", 2), "fp_radius"
        )
        self.fp_nbits = self._positive_int(
            config.get("fp_nbits", 2048), "fp_nbits"
        )

        self.entries: list[dict] = []
        self._fingerprints: list[np.ndarray] = []
        self._entry_hashes: set[str] = set()
        self._visible_entry_hashes: set[str] | None = None
        self._connection: sqlite3.Connection | None = None
        self.path: Path | None = None
        self.seed: int | None = None
        self.identity: dict[str, Any] | None = None

        raw_path = config.get("path")
        if raw_path in (None, ""):
            return
        if not isinstance(raw_path, (str, Path)) or str(raw_path) == ":memory:":
            raise ExperienceDBError("cer.path must be a filesystem SQLite path")

        seed = config.get("seed")
        if isinstance(seed, bool) or not isinstance(seed, int) or seed < 0:
            raise ExperienceDBError(
                "persistent Chemical-CER requires a non-negative integer cer.seed"
            )
        identity = config.get("identity")
        if not isinstance(identity, Mapping) or not identity:
            raise ExperienceDBError(
                "persistent Chemical-CER requires a non-empty mapping cer.identity"
            )

        self.path = Path(raw_path).expanduser().resolve()
        self.seed = seed
        self.identity = dict(identity)
        self._open_persistent()

    @staticmethod
    def _positive_int(value: Any, label: str) -> int:
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            raise ValueError(f"cer.{label} must be a positive integer")
        return value

    @property
    def persistent(self) -> bool:
        return self._connection is not None

    @property
    def size(self) -> int:
        return len(self.entries)

    def _database_identity(self) -> dict[str, Any]:
        return {
            "schema_version": SCHEMA_VERSION,
            "seed": self.seed,
            "protocol": self.identity,
            "cer": {
                "max_size": self.max_size,
                "top_k": self.top_k,
                "fp_radius": self.fp_radius,
                "fp_nbits": self.fp_nbits,
            },
        }

    def _open_persistent(self) -> None:
        assert self.path is not None
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            connection = sqlite3.connect(str(self.path), timeout=30.0)
            connection.execute("PRAGMA busy_timeout = 30000")
            connection.execute("PRAGMA foreign_keys = ON")
            journal_mode = connection.execute("PRAGMA journal_mode = WAL").fetchone()[0]
            connection.execute("PRAGMA synchronous = FULL")
        except sqlite3.Error as error:
            raise ExperienceDBError(
                f"cannot open persistent CER database {self.path}: {error}"
            ) from error

        self._connection = connection
        try:
            with connection:
                connection.execute(
                    """
                    CREATE TABLE IF NOT EXISTS metadata (
                        key TEXT PRIMARY KEY,
                        value TEXT NOT NULL
                    )
                    """
                )
                connection.execute(
                    """
                    CREATE TABLE IF NOT EXISTS experiences (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        entry_hash TEXT NOT NULL UNIQUE,
                        source_smiles TEXT NOT NULL,
                        target_smiles TEXT NOT NULL,
                        modifications_json TEXT NOT NULL,
                        delta_target REAL NOT NULL,
                        delta_admet REAL NOT NULL,
                        delta_combined REAL NOT NULL,
                        task_name TEXT NOT NULL,
                        round INTEGER NOT NULL CHECK(round >= 0),
                        fingerprint BLOB NOT NULL,
                        created_at TEXT NOT NULL
                    )
                    """
                )
                connection.execute(
                    "CREATE INDEX IF NOT EXISTS idx_experiences_task "
                    "ON experiences(task_name)"
                )
                connection.execute(
                    """
                    CREATE TABLE IF NOT EXISTS task_completions (
                        task_name TEXT PRIMARY KEY,
                        task_index INTEGER NOT NULL CHECK(task_index >= 0),
                        result_sha256 TEXT NOT NULL CHECK(length(result_sha256) = 64),
                        experience_count INTEGER NOT NULL CHECK(experience_count >= 0),
                        experience_hashes_json TEXT NOT NULL,
                        experience_digest TEXT NOT NULL CHECK(length(experience_digest) = 64),
                        completed_at TEXT NOT NULL
                    )
                    """
                )
            self._verify_sql_schema()
            expected_identity = _canonical_json(self._database_identity())
            rows = dict(connection.execute("SELECT key, value FROM metadata"))
            if rows:
                if set(rows) != {"config_identity", "created_at", "journal_mode"}:
                    raise ExperienceDBError(
                        f"CER metadata schema mismatch in {self.path}"
                    )
                if rows["config_identity"] != expected_identity:
                    raise ExperienceDBError(
                        "CER database protocol identity mismatch: refusing to mix "
                        f"seeds/configurations in {self.path}"
                    )
            else:
                with connection:
                    connection.executemany(
                        "INSERT INTO metadata(key, value) VALUES (?, ?)",
                        (
                            ("config_identity", expected_identity),
                            ("created_at", _utc_now()),
                            ("journal_mode", str(journal_mode).lower()),
                        ),
                    )
            self._reload_from_sqlite()
            self._validate_completion_markers()
        except (sqlite3.Error, ExperienceDBError) as error:
            connection.close()
            self._connection = None
            if isinstance(error, ExperienceDBError):
                raise
            raise ExperienceDBError(
                f"invalid persistent CER database {self.path}: {error}"
            ) from error

    def _verify_sql_schema(self) -> None:
        assert self._connection is not None

        def columns(table: str) -> tuple[tuple[str, str, int, int], ...]:
            rows = self._connection.execute(f"PRAGMA table_info({table})").fetchall()
            return tuple((row[1], row[2].upper(), row[3], row[5]) for row in rows)

        if columns("metadata") != self._EXPECTED_METADATA_COLUMNS:
            raise ExperienceDBError(f"CER metadata table schema mismatch in {self.path}")
        if columns("experiences") != self._EXPECTED_EXPERIENCE_COLUMNS:
            raise ExperienceDBError(
                f"CER experiences table schema mismatch in {self.path}"
            )
        if columns("task_completions") != self._EXPECTED_COMPLETION_COLUMNS:
            raise ExperienceDBError(
                f"CER task_completions table schema mismatch in {self.path}"
            )

        unique_hash = False
        for index_row in self._connection.execute(
            "PRAGMA index_list(experiences)"
        ).fetchall():
            if not index_row[2]:
                continue
            index_name = str(index_row[1]).replace('"', '""')
            indexed = self._connection.execute(
                f'PRAGMA index_info("{index_name}")'
            ).fetchall()
            if [row[2] for row in indexed] == ["entry_hash"]:
                unique_hash = True
                break
        if not unique_hash:
            raise ExperienceDBError(
                f"CER experiences.entry_hash is not uniquely indexed in {self.path}"
            )

    @staticmethod
    def _normalize_entry(entry: dict) -> dict:
        if not isinstance(entry, dict):
            raise ValueError("CER experience must be a mapping")
        required = {
            "source_smiles",
            "target_smiles",
            "modifications",
            "delta_target",
            "delta_admet",
            "delta_combined",
            "task_name",
            "round",
        }
        missing = sorted(required.difference(entry))
        if missing:
            raise ValueError("CER experience missing field(s): " + ", ".join(missing))

        source = validate_smiles(entry["source_smiles"])
        target = validate_smiles(entry["target_smiles"])
        if source is None or target is None:
            raise ValueError("CER source_smiles and target_smiles must be valid SMILES")
        modifications = entry["modifications"]
        if not isinstance(modifications, list):
            raise ValueError("CER modifications must be a list")
        modifications_json = _canonical_json(modifications)
        modifications = json.loads(modifications_json)

        deltas: dict[str, float] = {}
        for field in ("delta_target", "delta_admet", "delta_combined"):
            value = entry[field]
            if isinstance(value, bool):
                raise ValueError(f"CER {field} must be a finite number")
            try:
                value = float(value)
            except (TypeError, ValueError) as error:
                raise ValueError(f"CER {field} must be a finite number") from error
            if not math.isfinite(value):
                raise ValueError(f"CER {field} must be a finite number")
            deltas[field] = value

        task_name = entry["task_name"]
        if not isinstance(task_name, str) or not task_name.strip():
            raise ValueError("CER task_name must be a non-empty string")
        round_index = entry["round"]
        if (
            isinstance(round_index, bool)
            or not isinstance(round_index, int)
            or round_index < 0
        ):
            raise ValueError("CER round must be a non-negative integer")

        return {
            "source_smiles": source,
            "target_smiles": target,
            "modifications": modifications,
            **deltas,
            "task_name": task_name.strip(),
            "round": round_index,
        }

    @staticmethod
    def _entry_hash(entry: dict) -> str:
        return hashlib.sha256(_canonical_json(entry).encode("utf-8")).hexdigest()

    @staticmethod
    def _ordered_hash_digest(hashes: Sequence[str]) -> str:
        normalized = list(hashes)
        if any(
            not isinstance(value, str)
            or len(value) != 64
            or any(character not in "0123456789abcdef" for character in value)
            for value in normalized
        ):
            raise ExperienceDBError(
                "CER ordered entry-hash lineage contains an invalid digest"
            )
        return hashlib.sha256(
            _canonical_json({
                "schema_version": 1,
                "entry_hashes": normalized,
            }).encode("utf-8")
        ).hexdigest()

    def entry_hash_for(self, entry: dict) -> str:
        """Return the exact durable hash for one normalized CER transition."""
        return self._entry_hash(self._normalize_entry(entry))

    def _task_order(self) -> tuple[str, ...]:
        if not isinstance(self.identity, Mapping):
            return ()
        value = self.identity.get("task_order")
        if value is None:
            return ()
        if (
            not isinstance(value, list)
            or not value
            or any(not isinstance(task, str) or not task for task in value)
            or len(value) != len(set(value))
        ):
            raise ExperienceDBError(
                "CER protocol identity has an invalid task_order"
            )
        return tuple(value)

    def _validate_task_coordinate(self, task_name: str, task_index: int) -> None:
        order = self._task_order()
        if order and (
            task_name not in order or order.index(task_name) != task_index
        ):
            raise ExperienceDBError(
                "CER task name/index is outside the identity task_order"
            )

    def _ordered_task_hashes(self, task_name: str) -> list[str]:
        if self._connection is None:
            return [
                self._entry_hash(self._normalize_entry(entry))
                for entry in self.entries
                if entry.get("task_name") == task_name
            ]
        return [
            str(row[0])
            for row in self._connection.execute(
                "SELECT entry_hash FROM experiences "
                "WHERE task_name = ? ORDER BY id ASC",
                (task_name,),
            ).fetchall()
        ]

    def _completion_lineages(self) -> dict[str, dict[str, Any]]:
        if self._connection is None:
            return {}
        rows = self._connection.execute(
            """
            SELECT task_name, task_index, result_sha256, experience_count,
                   experience_hashes_json, experience_digest
            FROM task_completions ORDER BY task_index ASC
            """
        ).fetchall()
        lineages: dict[str, dict[str, Any]] = {}
        for row in rows:
            task_name = str(row[0])
            task_index = int(row[1])
            self._validate_task_coordinate(task_name, task_index)
            try:
                hashes = json.loads(row[4])
            except (TypeError, json.JSONDecodeError) as error:
                raise ExperienceDBError(
                    f"CER completion hash lineage is invalid for {task_name!r}"
                ) from error
            if (
                not isinstance(hashes, list)
                or int(row[3]) != len(hashes)
                or self._ordered_hash_digest(hashes) != row[5]
            ):
                raise ExperienceDBError(
                    f"CER completion digest mismatch for task {task_name!r}"
                )
            physical = self._ordered_task_hashes(task_name)
            physical_positions = {value: index for index, value in enumerate(physical)}
            if (
                any(value not in physical_positions for value in hashes)
                or [physical_positions[value] for value in hashes]
                != sorted(physical_positions[value] for value in hashes)
            ):
                raise ExperienceDBError(
                    f"CER completion rows are missing or reordered for task "
                    f"{task_name!r}"
                )
            lineages[task_name] = {
                "task_index": task_index,
                "result_sha256": str(row[2]),
                "experience_count": len(hashes),
                "experience_hashes": hashes,
                "experience_digest": str(row[5]),
            }
        return lineages

    def _validate_completion_markers(self) -> None:
        self._completion_lineages()

    def add_experience(self, entry: dict) -> bool:
        """Validate and atomically store one experience.

        Returns ``True`` only when a new unique row is inserted. Exact replay
        during ``--resume`` is a no-op, preventing duplicate experience from
        biasing later tasks.
        """
        normalized = self._normalize_entry(entry)
        task_order = self._task_order()
        if task_order and normalized["task_name"] not in task_order:
            raise ExperienceDBError(
                "CER experience task_name is outside identity task_order"
            )
        fingerprint = compute_morgan_fp(
            normalized["source_smiles"],
            radius=self.fp_radius,
            n_bits=self.fp_nbits,
        )
        if fingerprint is None:
            raise ValueError("CER source_smiles fingerprint generation failed")
        entry_hash = self._entry_hash(normalized)

        if self._connection is None:
            if entry_hash in self._entry_hashes:
                return False
            self.entries.append(normalized)
            self._fingerprints.append(fingerprint)
            self._entry_hashes.add(entry_hash)
            while len(self.entries) > self.max_size:
                removed = self.entries.pop(0)
                self._fingerprints.pop(0)
                self._entry_hashes.discard(self._entry_hash(removed))
            return True

        fingerprint_blob = np.asarray(fingerprint, dtype="<f4").tobytes()
        modifications_json = _canonical_json(normalized["modifications"])
        created_at = _utc_now()
        try:
            with self._connection:
                cursor = self._connection.execute(
                    """
                    INSERT OR IGNORE INTO experiences(
                        entry_hash, source_smiles, target_smiles,
                        modifications_json, delta_target, delta_admet,
                        delta_combined, task_name, round, fingerprint, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        entry_hash,
                        normalized["source_smiles"],
                        normalized["target_smiles"],
                        modifications_json,
                        normalized["delta_target"],
                        normalized["delta_admet"],
                        normalized["delta_combined"],
                        normalized["task_name"],
                        normalized["round"],
                        fingerprint_blob,
                        created_at,
                    ),
                )
                inserted = cursor.rowcount == 1
            if inserted:
                audit_entry = {
                    **normalized,
                    "experience_id": int(cursor.lastrowid),
                    "entry_hash": entry_hash,
                    "created_at": created_at,
                }
                self.entries.append(audit_entry)
                self._fingerprints.append(fingerprint)
                self._entry_hashes.add(entry_hash)
        except sqlite3.Error as error:
            raise ExperienceDBError(
                f"failed to persist CER experience in {self.path}: {error}"
            ) from error
        return inserted

    def contains_experience(self, entry: dict) -> bool:
        """Return whether the exact normalized transition is already durable."""
        normalized = self._normalize_entry(entry)
        return self._entry_hash(normalized) in self._entry_hashes

    def _reload_from_sqlite(self) -> None:
        assert self._connection is not None
        rows = self._connection.execute(
            """
            SELECT id, entry_hash, source_smiles, target_smiles,
                   modifications_json, delta_target, delta_admet,
                   delta_combined, task_name, round, fingerprint, created_at
            FROM experiences ORDER BY id ASC
            """
        ).fetchall()
        entries: list[dict] = []
        fingerprints: list[np.ndarray] = []
        hashes: set[str] = set()
        expected_bytes = self.fp_nbits * np.dtype("<f4").itemsize
        for row in rows:
            blob = bytes(row[10])
            if len(blob) != expected_bytes:
                raise ExperienceDBError(
                    f"CER fingerprint width mismatch for row {row[0]} in {self.path}"
                )
            try:
                modifications = json.loads(row[4])
            except json.JSONDecodeError as error:
                raise ExperienceDBError(
                    f"invalid CER modifications JSON for row {row[0]} in {self.path}"
                ) from error
            entry = {
                "source_smiles": row[2],
                "target_smiles": row[3],
                "modifications": modifications,
                "delta_target": float(row[5]),
                "delta_admet": float(row[6]),
                "delta_combined": float(row[7]),
                "task_name": row[8],
                "round": int(row[9]),
                "experience_id": int(row[0]),
                "entry_hash": row[1],
                "created_at": row[11],
            }
            normalized = self._normalize_entry(entry)
            normalized.update(
                experience_id=entry["experience_id"],
                entry_hash=entry["entry_hash"],
                created_at=entry["created_at"],
            )
            if self._entry_hash(self._normalize_entry(normalized)) != row[1]:
                raise ExperienceDBError(
                    f"CER row hash mismatch for row {row[0]} in {self.path}"
                )
            expected_fingerprint = compute_morgan_fp(
                normalized["source_smiles"],
                radius=self.fp_radius,
                n_bits=self.fp_nbits,
            )
            if expected_fingerprint is None or np.asarray(
                expected_fingerprint, dtype="<f4"
            ).tobytes() != blob:
                raise ExperienceDBError(
                    "CER fingerprint does not match source molecule for row "
                    f"{row[0]} in {self.path}"
                )
            entries.append(normalized)
            fingerprints.append(np.frombuffer(blob, dtype="<f4").copy())
            hashes.add(row[1])
        # Persistent rows are an append-only audit lineage.  Visibility is a
        # logical committed-row filter, so invisible crash orphans must not
        # evict visible rows from the bounded retrieval window.
        self.entries = entries
        self._fingerprints = fingerprints
        self._entry_hashes = hashes

    def delete_task(self, task_name: str) -> int:
        """Remove unfinished experiences for one task before a clean resume.

        Benchmark runners call this only for a seed whose result checkpoint is
        not complete. Experiences from earlier completed tasks remain available
        for cross-task transfer.
        """
        if not isinstance(task_name, str) or not task_name.strip():
            raise ValueError("CER task_name must be a non-empty string")
        task_name = task_name.strip()
        if self._connection is None:
            keep = [
                (entry, fingerprint)
                for entry, fingerprint in zip(self.entries, self._fingerprints)
                if entry.get("task_name") != task_name
            ]
            removed = len(self.entries) - len(keep)
            self.entries = [entry for entry, _ in keep]
            self._fingerprints = [fingerprint for _, fingerprint in keep]
            self._entry_hashes = {
                self._entry_hash(self._normalize_entry(entry))
                for entry in self.entries
            }
            return removed
        try:
            with self._connection:
                cursor = self._connection.execute(
                    "DELETE FROM experiences WHERE task_name = ?", (task_name,)
                )
                self._connection.execute(
                    "DELETE FROM task_completions WHERE task_name = ?",
                    (task_name,),
                )
            self._reload_from_sqlite()
            return max(cursor.rowcount, 0)
        except sqlite3.Error as error:
            raise ExperienceDBError(
                f"failed to clear unfinished CER task in {self.path}: {error}"
            ) from error

    def mark_task_complete(
        self,
        task_name: str,
        task_index: int,
        result_sha256: str,
        *,
        expected_entry_hashes: Sequence[str] | None = None,
    ) -> None:
        """Atomically bind a completed task to its validated result digest."""
        if self._connection is None:
            return
        if not isinstance(task_name, str) or not task_name.strip():
            raise ValueError("CER task_name must be a non-empty string")
        if (
            isinstance(task_index, bool)
            or not isinstance(task_index, int)
            or task_index < 0
        ):
            raise ValueError("CER task_index must be a non-negative integer")
        if (
            not isinstance(result_sha256, str)
            or len(result_sha256) != 64
            or any(character not in "0123456789abcdef" for character in result_sha256)
        ):
            raise ValueError("CER result_sha256 must be a lowercase SHA-256 digest")
        task_name = task_name.strip()
        self._validate_task_coordinate(task_name, task_index)
        physical_hashes = self._ordered_task_hashes(task_name)
        hashes = (
            physical_hashes
            if expected_entry_hashes is None
            else list(expected_entry_hashes)
        )
        physical_positions = {
            value: index for index, value in enumerate(physical_hashes)
        }
        digest = self._ordered_hash_digest(hashes)
        if (
            any(value not in physical_positions for value in hashes)
            or [physical_positions[value] for value in hashes]
            != sorted(physical_positions[value] for value in hashes)
        ):
            raise ExperienceDBError(
                f"CER completion rows are absent or reordered for task "
                f"{task_name!r}"
            )
        count = len(hashes)
        hashes_json = _canonical_json(hashes)
        existing = self._connection.execute(
            """
            SELECT task_index, result_sha256, experience_count,
                   experience_hashes_json, experience_digest
            FROM task_completions WHERE task_name = ?
            """,
            (task_name,),
        ).fetchone()
        expected = (
            task_index,
            result_sha256,
            count,
            hashes_json,
            digest,
        )
        if existing is not None and tuple(existing) != expected:
            raise ExperienceDBError(
                f"CER completion marker mismatch for task {task_name!r} in {self.path}"
            )
        if existing is None:
            try:
                with self._connection:
                    self._connection.execute(
                        """
                        INSERT INTO task_completions(
                            task_name, task_index, result_sha256,
                            experience_count, experience_hashes_json,
                            experience_digest, completed_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            task_name,
                            task_index,
                            result_sha256,
                            count,
                            hashes_json,
                            digest,
                            _utc_now(),
                        ),
                    )
            except sqlite3.Error as error:
                raise ExperienceDBError(
                    f"failed to mark CER task complete in {self.path}: {error}"
                ) from error

    def require_task_complete(
        self,
        task_name: str,
        task_index: int,
        result_sha256: str,
        *,
        require_experience_presence: bool = False,
        expected_entry_hashes: Sequence[str] | None = None,
    ) -> None:
        """Fail closed unless DB history matches the validated result checkpoint."""
        if self._connection is None:
            return
        row = self._connection.execute(
            """
            SELECT task_index, result_sha256, experience_count,
                   experience_hashes_json, experience_digest
            FROM task_completions WHERE task_name = ?
            """,
            (task_name,),
        ).fetchone()
        self._validate_task_coordinate(task_name, task_index)
        if (
            row is None
            or int(row[0]) != task_index
            or row[1] != result_sha256
        ):
            raise ExperienceDBError(
                "CER/checkpoint reconciliation failed for completed task "
                f"{task_name!r} in {self.path}; refusing to lose or mix "
                "cross-task experience"
            )
        try:
            hashes = json.loads(row[3])
        except (TypeError, json.JSONDecodeError) as error:
            raise ExperienceDBError(
                f"CER completion hash lineage is invalid for {task_name!r}"
            ) from error
        physical = self._ordered_task_hashes(task_name)
        positions = {value: index for index, value in enumerate(physical)}
        if (
            not isinstance(hashes, list)
            or len(hashes) != int(row[2])
            or self._ordered_hash_digest(hashes) != row[4]
            or (
                expected_entry_hashes is not None
                and hashes != list(expected_entry_hashes)
            )
            or any(value not in positions for value in hashes)
            or [positions[value] for value in hashes]
            != sorted(positions[value] for value in hashes)
            or (require_experience_presence and not hashes)
        ):
            raise ExperienceDBError(
                f"CER rows for completed task {task_name!r} are incomplete "
                f"or reordered in {self.path}; refusing a lossy resume"
            )

    def bind_formal_visible_prefix(
        self,
        *,
        current_task: str,
        current_entries: Sequence[Mapping[str, Any]],
        expected_binding: object = None,
    ) -> dict[str, Any]:
        """Bind retrieval to completed tasks plus replayed current outers.

        Durable rows written after a ``round_pending`` checkpoint remain in
        the append-only audit table, but are invisible until the corresponding
        outer trajectory row is committed.  This also keeps rows from caught
        failed rounds permanently out of online prompts.
        """
        if self._connection is None:
            raise ExperienceDBError(
                "formal CER visibility binding requires persistent storage"
            )
        order = self._task_order()
        if current_task not in order:
            raise ExperienceDBError(
                "formal CER current task is outside identity task_order"
            )
        task_index = order.index(current_task)
        lineages = self._completion_lineages()
        expected_prior = order[:task_index]
        if set(lineages) != set(expected_prior):
            raise ExperienceDBError(
                "formal CER completion markers are not the exact prior-task "
                "prefix"
            )
        prior_markers = [
            {
                "task_index": int(lineages[task]["task_index"]),
                "experience_count": int(
                    lineages[task]["experience_count"]
                ),
                "experience_digest": str(
                    lineages[task]["experience_digest"]
                ),
            }
            for task in expected_prior
        ]
        prior_hashes = [
            value
            for task in expected_prior
            for value in lineages[task]["experience_hashes"]
        ]
        current_hashes = [
            self.entry_hash_for(dict(entry)) for entry in current_entries
        ]
        if len(current_hashes) != len(set(current_hashes)):
            raise ExperienceDBError(
                "formal CER current-task replay contains duplicate rows"
            )
        physical_current = self._ordered_task_hashes(current_task)
        current_positions = {
            value: index for index, value in enumerate(physical_current)
        }
        if (
            any(value not in current_positions for value in current_hashes)
            or [current_positions[value] for value in current_hashes]
            != sorted(current_positions[value] for value in current_hashes)
        ):
            raise ExperienceDBError(
                "formal CER committed outer rows are absent or reordered in "
                "durable storage"
            )
        visible_hashes = [*prior_hashes, *current_hashes]
        binding = {
            "schema_version": 1,
            "task_index": task_index,
            "prior_task_completions": prior_markers,
            "current_entry_count": len(current_hashes),
            "current_entry_digest": self._ordered_hash_digest(
                current_hashes
            ),
            "visible_entry_count": len(visible_hashes),
            "visible_entry_digest": self._ordered_hash_digest(
                visible_hashes
            ),
        }
        if expected_binding is not None and expected_binding != binding:
            raise ExperienceDBError(
                "formal CER visibility binding differs from physical replay"
            )
        self._visible_entry_hashes = set(visible_hashes)
        return binding

    def retrieve(
        self,
        query_smiles: str,
        top_k: int | None = None,
        only_successful: bool = True,
        mode: str = "combined",
        max_origin_round: int | None = None,
    ) -> list[dict]:
        """Return structurally closest experiences, optionally successes only."""
        if mode not in {"combined", "target_only"}:
            raise ValueError("CER retrieval mode must be 'combined' or 'target_only'")
        if max_origin_round is not None and (
            isinstance(max_origin_round, bool)
            or not isinstance(max_origin_round, int)
            or max_origin_round <= 0
        ):
            raise ValueError("CER max_origin_round must be a positive integer")
        if not self.entries:
            return []
        k = self.top_k if top_k is None else self._positive_int(top_k, "top_k")
        query_fp = compute_morgan_fp(
            query_smiles, radius=self.fp_radius, n_bits=self.fp_nbits
        )
        if query_fp is None:
            return []

        # Persistent storage is an append-only physical audit lineage.  Build
        # the logical FIFO window from committed-visible rows *before* applying
        # query filters: neither crash-orphan rows nor failed/out-of-phase rows
        # may consume capacity or resurrect an older experience.
        visible_candidates = [
            (index, entry)
            for index, entry in enumerate(self.entries)
            if (
                self._visible_entry_hashes is None
                or entry.get("entry_hash") in self._visible_entry_hashes
            )
        ]
        if self._connection is not None and len(visible_candidates) > self.max_size:
            visible_candidates = visible_candidates[-self.max_size:]

        success_field = (
            "delta_target" if mode == "target_only" else "delta_combined"
        )
        candidates = [
            (index, entry)
            for index, entry in visible_candidates
            if (not only_successful or entry[success_field] > 0)
            and (
                max_origin_round is None
                or int(entry["round"]) < max_origin_round
            )
        ]
        if not candidates:
            return []

        indices = [index for index, _ in candidates]
        matrix = np.stack([self._fingerprints[index] for index in indices])
        distances = np.linalg.norm(matrix - query_fp.reshape(1, -1), axis=1)
        order = np.argsort(distances, kind="stable")[:k]
        return [candidates[index][1] for index in order]

    def format_experiences(
        self,
        experiences: list[dict],
        mode: str = "combined",
        *,
        structured_modifications_only: bool = False,
    ) -> str:
        """Format retrieved experiences for Generator prompt injection."""
        if mode not in {"combined", "target_only"}:
            raise ValueError("CER formatting mode must be 'combined' or 'target_only'")
        if not experiences:
            return "No similar optimization experiences available yet."

        lines = [
            "Similar successful modifications from past optimization "
            f"({len(experiences)} cases):"
        ]
        for index, experience in enumerate(experiences):
            source = experience.get("source_smiles", "?")
            target = experience.get("target_smiles", "?")
            delta_target = experience.get("delta_target", 0.0)
            delta_admet = experience.get("delta_admet", 0.0)
            task = experience.get("task_name", "unknown")
            case_label = (
                f"Case {index + 1}:"
                if structured_modifications_only
                else f"Case {index + 1} (task={task}):"
            )
            if mode == "target_only":
                # Free-form modification rationales from constrained phases
                # can name inactive endpoints.  Omitting that text keeps the
                # curriculum prompt focused on the target while retaining
                # the exact molecular transform.
                lines.append(
                    f"  {case_label} {source} -> {target}\n"
                    f"    Effect: target {delta_target:+.3f}"
                )
            else:
                modifications = experience.get("modifications") or []
                if structured_modifications_only:
                    modifications = canonicalize_formal_modifications(
                        modifications
                    )
                    description = ", ".join(
                        modification["type"]
                        for modification in modifications
                    ) or "none"
                    modification_label = "Modification types"
                else:
                    description = "; ".join(
                        modification.get("description", str(modification))
                        if isinstance(modification, dict)
                        else str(modification)
                        for modification in modifications
                    ) if modifications else "N/A"
                    modification_label = "Modification"
                lines.append(
                    f"  {case_label} {source} -> {target}\n"
                    f"    {modification_label}: {description}\n"
                    f"    Effect: target {delta_target:+.3f}, "
                    f"admet {delta_admet:+.3f}"
                )
        return "\n".join(lines)

    def retrieve_and_format(
        self,
        query_smiles: str,
        top_k: int | None = None,
        mode: str = "combined",
        *,
        structured_modifications_only: bool = False,
        max_origin_round: int | None = None,
    ) -> str:
        return self.format_experiences(
            self.retrieve(
                query_smiles,
                top_k,
                mode=mode,
                max_origin_round=max_origin_round,
            ),
            mode=mode,
            structured_modifications_only=structured_modifications_only,
        )

    def get_stats(self) -> dict:
        if not self.entries:
            stats: dict[str, Any] = {
                "size": 0,
                "n_successful": 0,
                "n_tasks": 0,
            }
        else:
            tasks = sorted({entry["task_name"] for entry in self.entries})
            stats = {
                "size": len(self.entries),
                "n_successful": sum(
                    entry["delta_combined"] > 0 for entry in self.entries
                ),
                "n_tasks": len(tasks),
                "tasks": tasks,
            }
        stats.update(
            persistent=self.persistent,
            path=str(self.path) if self.path is not None else None,
            seed=self.seed,
            schema_version=SCHEMA_VERSION,
        )
        return stats

    def close(self) -> None:
        if self._connection is not None:
            self._connection.close()
            self._connection = None

    def __enter__(self) -> "ExperienceDB":
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()

    def __del__(self) -> None:
        try:
            self.close()
        except Exception:
            pass
