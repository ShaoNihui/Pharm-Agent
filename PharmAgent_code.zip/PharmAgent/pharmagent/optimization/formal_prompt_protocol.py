"""Fail-closed structured reuse for formal online LLM prompts.

The paid protocol retains native raw LLM responses for audit, but raw prose is
never a cross-agent or cross-round prompt operand.  Only the validated enums in
this module may survive those boundaries.
"""

from __future__ import annotations

import math
from typing import Any, Mapping


FORMAL_PROMPT_REUSE_SCHEMA_VERSION = "pharmagent.formal-prompt-reuse"
FORMAL_ALLOWED_MODIFICATION_TYPES = (
    "substitution",
    "addition",
    "deletion",
    "ring_modification",
    "linker_change",
)
FORMAL_REUSABLE_MODIFICATION_FIELDS = ("type",)
FORMAL_REVIEWER_REUSABLE_FIELDS = (
    "priority_focus",
    "recommended_modification_types",
)
FORMAL_REVIEWER_INPUT_PRIORITY_FOCUS = ("activity", "admet", "balance")
FORMAL_CONSTRAINED_NORMALIZED_PRIORITY_FOCUS = (
    "target_activity",
    "active_constraints",
    "target_activity_and_active_constraints",
)
FORMAL_TARGET_ONLY_NORMALIZED_PRIORITY_FOCUS = ("target_activity",)
_FORMAL_PRIORITY_NORMALIZATION = {
    "activity": "target_activity",
    "admet": "active_constraints",
    "balance": "target_activity_and_active_constraints",
}
FORMAL_REVIEWER_DISABLED_FEEDBACK = "Continue optimization."
FORMAL_ROUND_ERROR_FEEDBACK = (
    "Previous round failed due to an error. "
    "Try simpler, more conservative modifications."
)
_FORMAL_MEMORY_FIELDS = {
    "smiles",
    "previous_smiles",
    "target_score",
    "admet_score",
    "combined_score",
    "modifications",
    "round",
    "delta_target",
    "delta_admet",
    "delta_combined",
    "delta_score",
    "active_constraints",
    "task_name",
}


class FormalPromptProtocolError(ValueError):
    """Raised when a declared formal prompt-reuse protocol is not exact."""


def canonical_formal_prompt_reuse_protocol() -> dict[str, Any]:
    """Return the immutable-by-copy structured-reuse protocol descriptor."""
    return {
        "schema_version": FORMAL_PROMPT_REUSE_SCHEMA_VERSION,
        "mode": "structured_only",
        "generator_candidate_cross_agent_fields": [
            "canonical_smiles",
            "validated_modification_types",
        ],
        "reviewer_candidate_prompt_fields": [
            "canonical_smiles",
            "target_score",
            "active_constraint_assessments",
            "validated_modification_types",
        ],
        "memory_cross_round_fields": [
            "canonical_smiles",
            "target_score",
            "admet_score",
            "combined_score",
            "numeric_deltas",
            "active_constraint_names",
        ],
        "memory_cross_round_modifications": "none_physical_replay_only",
        "active_endpoint_context_fields": [
            "active_constraint_specs",
            "active_constraint_assessments",
            "active_only_profile",
        ],
        "rag_context": {
            "mode": "structured_target_numeric_only",
            "fields": [
                "canonical_source_smiles",
                "canonical_target_smiles",
                "finite_target_score_delta",
            ],
            "asset_free_text_reused": False,
        },
        "cer_context": {
            "fields": [
                "canonical_source_smiles",
                "canonical_target_smiles",
                "finite_numeric_deltas",
            ],
            "task_text_reused": False,
            "modification_text_reused": False,
            "phase_origin_round_filter": {
                "phase1_max_exclusive": 20,
                "phase2_max_exclusive": 60,
                "phase3_max_exclusive": None,
            },
            "phase1_and_phase2_mode": "target_only",
            "phase3_mode": "combined_active_seven",
            "persistent_lineage_schema": 3,
            "visible_rows": (
                "sealed_prior_task_ordered_hashes_plus_current_committed_"
                "outer_hashes"
            ),
            "completion_binding": (
                "task_order_index_plus_exact_ordered_entry_hash_digest"
            ),
            "completion_result_digest": {
                "schema_version": 1,
                "projection": "stable_scientific_result",
                "excluded_runtime_fields": [
                    "memory",
                    "elapsed_time",
                    "native_run_journal.optimizer_state_revision",
                ],
            },
            "same_round_trace_ahead_reused": False,
            "failed_round_orphan_reused": False,
        },
        "near_feasible_context": "phase3_active_seven_only",
        "novelty_repair_context": {
            "fields": ["protocol_reason_enum", "candidate_ordinal"],
            "raw_candidate_text_reused": False,
            "raw_verifier_error_reused": False,
        },
        "modification_reusable_fields": list(
            FORMAL_REUSABLE_MODIFICATION_FIELDS
        ),
        "allowed_modification_types": list(
            FORMAL_ALLOWED_MODIFICATION_TYPES
        ),
        "reviewer_reusable_fields": list(FORMAL_REVIEWER_REUSABLE_FIELDS),
        "reviewer_input_priority_focus": list(
            FORMAL_REVIEWER_INPUT_PRIORITY_FOCUS
        ),
        "constrained_normalized_priority_focus": list(
            FORMAL_CONSTRAINED_NORMALIZED_PRIORITY_FOCUS
        ),
        "target_only_normalized_priority_focus": list(
            FORMAL_TARGET_ONLY_NORMALIZED_PRIORITY_FOCUS
        ),
        "canonical_smiles_required_after_verifier": True,
        "raw_llm_text_reused": False,
    }


def validate_formal_prompt_reuse_protocol(value: object) -> dict[str, Any]:
    """Validate an exact public descriptor and return a detached copy."""
    expected = canonical_formal_prompt_reuse_protocol()
    if not isinstance(value, Mapping) or dict(value) != expected:
        raise FormalPromptProtocolError(
            "formal prompt reuse must match the exact structured-only protocol"
        )
    return canonical_formal_prompt_reuse_protocol()


def canonicalize_formal_modifications(value: object) -> list[dict[str, str]]:
    """Keep only validated modification ``type`` enum values.

    Descriptions, rationales, expected effects, and arbitrary extra keys are
    intentionally discarded.  Invalid entries are not converted into prose or
    fallback labels.
    """
    if not isinstance(value, list):
        return []
    return [
        {"type": modification_type}
        for modification in value
        if isinstance(modification, Mapping)
        and isinstance(
            modification_type := modification.get("type"), str
        )
        and modification_type in FORMAL_ALLOWED_MODIFICATION_TYPES
    ]


def canonicalize_formal_candidates(value: object) -> list[dict[str, Any]]:
    """Project parsed Generator candidates onto formal reusable fields."""
    if not isinstance(value, list):
        return []
    candidates = []
    for candidate in value:
        if not isinstance(candidate, Mapping):
            continue
        smiles = candidate.get("new_smiles")
        if not isinstance(smiles, str):
            continue
        candidates.append({
            "new_smiles": smiles,
            "modifications": canonicalize_formal_modifications(
                candidate.get("modifications")
            ),
        })
    return candidates


def canonical_formal_reviewer_fields(
    value: object, *, target_only: bool
) -> dict[str, Any]:
    """Validate the only Reviewer fields allowed to cross a round boundary."""
    parsed = value if isinstance(value, Mapping) else {}
    if target_only:
        focus = "target_activity"
    else:
        focus = _FORMAL_PRIORITY_NORMALIZATION.get(
            parsed.get("priority_focus"),
            "target_activity_and_active_constraints",
        )
    return {
        "priority_focus": focus,
        "recommended_modification_types": [
            modification["type"]
            for modification in canonicalize_formal_modifications([
                {"type": item}
                for item in parsed.get("recommended_modification_types", [])
            ])
        ]
        if isinstance(parsed.get("recommended_modification_types"), list)
        else [],
    }


def format_formal_reviewer_feedback(
    value: object, *, target_only: bool
) -> str:
    """Render deterministic feedback without carrying Reviewer-authored prose."""
    fields = canonical_formal_reviewer_fields(
        value, target_only=target_only
    )
    types = fields["recommended_modification_types"]
    type_text = ", ".join(types) if types else "none"
    return (
        f"Protocol focus: {fields['priority_focus']}.\n"
        f"Recommended modification types: {type_text}."
    )


def format_formal_zero_candidate_feedback(failure_count: int) -> str:
    """Return the one protocol-owned feedback template with a counter."""
    if (
        isinstance(failure_count, bool)
        or not isinstance(failure_count, int)
        or failure_count <= 0
    ):
        raise FormalPromptProtocolError(
            "formal zero-candidate failure_count must be positive"
        )
    return (
        "All candidates failed verification or scoring "
        f"({failure_count} consecutive failures). "
        "Try simpler modifications: single-atom substitutions, "
        "small functional group changes."
    )


def _is_finite_number(value: object) -> bool:
    return (
        not isinstance(value, bool)
        and isinstance(value, (int, float))
        and math.isfinite(float(value))
    )


def validate_formal_prompt_reuse_memory(
    value: object,
    *,
    evaluation_history: object,
    target_property: str,
    allowed_active_constraint_names: tuple[str, ...],
) -> list[dict[str, Any]]:
    """Validate that formal FIFO/CER-facing state contains no authored text."""
    if not isinstance(value, list) or not isinstance(evaluation_history, list):
        raise FormalPromptProtocolError(
            "formal prompt reuse memory/history must be lists"
        )
    if not isinstance(target_property, str) or not target_property:
        raise FormalPromptProtocolError(
            "formal prompt reuse target property is malformed"
        )
    allowed_names = set(allowed_active_constraint_names)
    if len(allowed_names) != len(allowed_active_constraint_names):
        raise FormalPromptProtocolError(
            "formal active constraint allowlist is malformed"
        )

    from pharmagent.tools.rdkit_tools import validate_smiles

    history_by_smiles = {
        row.get("smiles"): row
        for row in evaluation_history
        if isinstance(row, Mapping) and isinstance(row.get("smiles"), str)
    }
    validated = []
    for entry in value:
        if not isinstance(entry, Mapping) or set(entry) != _FORMAL_MEMORY_FIELDS:
            raise FormalPromptProtocolError(
                "formal memory entry fields are not exact"
            )
        smiles = entry.get("smiles")
        previous_smiles = entry.get("previous_smiles")
        if (
            not isinstance(smiles, str)
            or validate_smiles(smiles) != smiles
            or not isinstance(previous_smiles, str)
            or validate_smiles(previous_smiles) != previous_smiles
            or smiles not in history_by_smiles
            or previous_smiles not in history_by_smiles
        ):
            raise FormalPromptProtocolError(
                "formal memory SMILES are not canonical history identities"
            )
        if entry.get("task_name") != target_property:
            raise FormalPromptProtocolError(
                "formal memory task name does not match the run"
            )
        round_index = entry.get("round")
        if (
            isinstance(round_index, bool)
            or not isinstance(round_index, int)
            or round_index < 0
        ):
            raise FormalPromptProtocolError(
                "formal memory round is malformed"
            )
        numeric_fields = (
            "target_score",
            "admet_score",
            "combined_score",
            "delta_target",
            "delta_admet",
            "delta_combined",
            "delta_score",
        )
        if not all(_is_finite_number(entry.get(field)) for field in numeric_fields):
            raise FormalPromptProtocolError(
                "formal memory contains a non-finite numeric field"
            )
        history_target = history_by_smiles[smiles].get("raw_target_score")
        if (
            not _is_finite_number(history_target)
            or float(entry["target_score"]) != float(history_target)
            or float(entry["delta_score"]) != float(entry["delta_combined"])
        ):
            raise FormalPromptProtocolError(
                "formal memory scores are not bound to oracle history"
            )
        active = entry.get("active_constraints")
        if (
            not isinstance(active, list)
            or any(not isinstance(name, str) for name in active)
            or len(active) != len(set(active))
            or not set(active).issubset(allowed_names)
        ):
            raise FormalPromptProtocolError(
                "formal memory active constraint names are invalid"
            )
        modifications = entry.get("modifications")
        if modifications != []:
            raise FormalPromptProtocolError(
                "formal cross-round memory must not reuse modifications"
            )
        validated.append(dict(entry))
    return validated


def validate_formal_reviewer_feedback(
    value: object,
    *,
    target_only: bool,
    failure_count: int,
) -> None:
    """Accept only deterministic feedback strings owned by this protocol."""
    if value is None or value in {
        FORMAL_REVIEWER_DISABLED_FEEDBACK,
        FORMAL_ROUND_ERROR_FEEDBACK,
    }:
        return
    if (
        isinstance(failure_count, int)
        and not isinstance(failure_count, bool)
        and failure_count > 0
        and value == format_formal_zero_candidate_feedback(failure_count)
    ):
        return
    if not isinstance(value, str):
        raise FormalPromptProtocolError(
            "formal reviewer feedback is not a protocol string"
        )
    lines = value.splitlines()
    if len(lines) != 2:
        raise FormalPromptProtocolError(
            "formal reviewer feedback is not structured-only"
        )
    focus_prefix = "Protocol focus: "
    types_prefix = "Recommended modification types: "
    if (
        not lines[0].startswith(focus_prefix)
        or not lines[0].endswith(".")
        or not lines[1].startswith(types_prefix)
        or not lines[1].endswith(".")
    ):
        raise FormalPromptProtocolError(
            "formal reviewer feedback is not structured-only"
        )
    focus = lines[0][len(focus_prefix):-1]
    allowed_focus = (
        FORMAL_TARGET_ONLY_NORMALIZED_PRIORITY_FOCUS
        if target_only
        else FORMAL_CONSTRAINED_NORMALIZED_PRIORITY_FOCUS
    )
    type_text = lines[1][len(types_prefix):-1]
    types = [] if type_text == "none" else type_text.split(", ")
    canonical = format_formal_reviewer_feedback(
        {
            "priority_focus": (
                "activity"
                if focus == "target_activity"
                else "admet"
                if focus == "active_constraints"
                else "balance"
            ),
            "recommended_modification_types": types,
        },
        target_only=target_only,
    )
    if (
        focus not in allowed_focus
        or any(item not in FORMAL_ALLOWED_MODIFICATION_TYPES for item in types)
        or value != canonical
    ):
        raise FormalPromptProtocolError(
            "formal reviewer feedback contains an unregistered enum"
        )


def validate_formal_prompt_reuse_state(
    value: object,
    *,
    evaluation_history: object,
    target_property: str,
    allowed_active_constraint_names: tuple[str, ...],
    target_only: bool,
) -> None:
    """Validate prompt-reusable fields before formal save or restoration."""
    if not isinstance(value, Mapping):
        raise FormalPromptProtocolError(
            "formal optimizer state must be a mapping"
        )
    failure_count = value.get("failure_count")
    if (
        isinstance(failure_count, bool)
        or not isinstance(failure_count, int)
        or failure_count < 0
    ):
        raise FormalPromptProtocolError(
            "formal state failure_count is malformed"
        )
    validate_formal_prompt_reuse_memory(
        value.get("memory_buffer"),
        evaluation_history=evaluation_history,
        target_property=target_property,
        allowed_active_constraint_names=allowed_active_constraint_names,
    )
    validate_formal_reviewer_feedback(
        value.get("reviewer_feedback"),
        target_only=target_only,
        failure_count=failure_count,
    )
