"""Deterministic replay of public terminal optimizer counters."""

from __future__ import annotations

from collections.abc import Mapping
from copy import deepcopy
import math
from typing import Any

from pharmagent.optimization.lagrangian import (
    compute_canonical_lagrangian_score,
)


class PublicRunStateError(ValueError):
    """Raised when terminal counters cannot be replayed from public rows."""


FORMAL_MEMORY_CAPACITY = 100


def _finite(value: object) -> bool:
    return (
        not isinstance(value, bool)
        and isinstance(value, (int, float))
        and math.isfinite(float(value))
    )


def _close(left: object, right: object) -> bool:
    return _finite(left) and _finite(right) and math.isclose(
        float(left), float(right), rel_tol=0.0, abs_tol=1e-12
    )


def _formal_assessment_scores(
    record: Mapping[str, Any], active_names: tuple[str, ...]
) -> tuple[float, dict[str, float]]:
    """Recompute active-only ADMET score/violations from physical rows."""
    if not active_names:
        return 1.0, {}
    assessments = record.get("constraint_assessments")
    if not isinstance(assessments, list):
        raise PublicRunStateError(
            "constrained history row has no constraint assessments"
        )
    by_name: dict[str, Mapping[str, Any]] = {}
    for assessment in assessments:
        if not isinstance(assessment, Mapping):
            raise PublicRunStateError("constraint assessment is malformed")
        name = assessment.get("name")
        if not isinstance(name, str) or name in by_name:
            raise PublicRunStateError(
                "constraint assessment names are malformed"
            )
        by_name[name] = assessment
    scores: list[float] = []
    violations: dict[str, float] = {}
    for name in active_names:
        row = by_name.get(name)
        if row is None or row.get("missing") is not False:
            raise PublicRunStateError(
                "active constraint assessment is missing"
            )
        value = row.get("value")
        threshold = row.get("threshold")
        scale = row.get("scale")
        ctype = row.get("type")
        if (
            not _finite(value)
            or not _finite(threshold)
            or not _finite(scale)
            or float(scale) <= 0.0
            or ctype not in {"max", "min"}
        ):
            raise PublicRunStateError(
                "active constraint assessment is not finite"
            )
        margin = (
            float(threshold) - float(value)
            if ctype == "max"
            else float(value) - float(threshold)
        )
        violation = max(0.0, -margin) / float(scale)
        if (
            not _close(row.get("signed_margin"), margin)
            or not _close(row.get("normalized_violation"), violation)
            or row.get("pass") is not (margin >= 0.0)
        ):
            raise PublicRunStateError(
                "active constraint assessment is internally inconsistent"
            )
        z = max(-500.0, min(500.0, 5.0 * margin / float(scale)))
        scores.append(1.0 / (1.0 + math.exp(-z)))
        violations[name] = violation
    return sum(scores) / len(scores), violations


def _formal_reviewer_feedback(
    response_text: object, *, target_only: bool
) -> str:
    if not isinstance(response_text, str) or not response_text.strip():
        raise PublicRunStateError(
            "completed Reviewer round has no durable response"
        )
    from pharmagent.llm.output_parser import parse_reviewer_output
    from pharmagent.optimization.formal_prompt_protocol import (
        format_formal_reviewer_feedback,
    )

    return format_formal_reviewer_feedback(
        parse_reviewer_output(response_text), target_only=target_only
    )


def replay_native_loop_state(
    *,
    trajectory: object,
    round_failure_history: object,
    evaluation_history: object,
    seed_smiles: str,
    target_property: str,
    stage: str,
    next_round: int,
    max_rounds: int,
    allowed_active_constraint_names: tuple[str, ...],
    curriculum_transition_history: object = None,
    oracle_complete_count: int | None = None,
    lagrangian_enabled: bool = False,
    reviewer_enabled: bool = True,
    reviewer_responses: Mapping[str, str] | None = None,
    require_reviewer_feedback: bool = False,
    memory_capacity: int = FORMAL_MEMORY_CAPACITY,
    alpha: float = 0.7,
    initial_admet_score: float = 1.0,
    restart_threshold: int = 5,
    restart_strategies: tuple[str, ...] = (
        "scaffold-hop",
        "ring-linker",
        "bioisostere",
    ),
) -> dict[str, Any]:
    """Replay formal mutable loop state from committed physical evidence.

    ``round_pending`` and ``ready`` both represent the committed outcome
    prefix ``0..next_round-1``.  A ``round_pending`` journal may contain
    trace-ahead calls for ``next_round``; ``oracle_complete_count`` cuts those
    calls away before replay.  ``terminal`` keeps the same committed prefix,
    while its persisted ``next_round`` is normalized to ``max_rounds``.
    """
    if (
        not isinstance(trajectory, list)
        or not isinstance(round_failure_history, list)
        or not isinstance(evaluation_history, list)
        or not isinstance(seed_smiles, str)
        or not seed_smiles
        or not isinstance(target_property, str)
        or not target_property
        or stage not in {"round_pending", "ready", "terminal"}
        or isinstance(next_round, bool)
        or not isinstance(next_round, int)
        or next_round < 0
        or isinstance(max_rounds, bool)
        or not isinstance(max_rounds, int)
        or max_rounds <= 0
        or isinstance(memory_capacity, bool)
        or not isinstance(memory_capacity, int)
        or memory_capacity < 0
        or not _finite(alpha)
        or not _finite(initial_admet_score)
    ):
        raise PublicRunStateError("native loop replay inputs are malformed")
    if stage == "terminal":
        if next_round != max_rounds:
            raise PublicRunStateError(
                "terminal native state must normalize next_round to max_rounds"
            )
    elif next_round > max_rounds:
        raise PublicRunStateError("native next_round exceeds max_rounds")

    complete_count = (
        len(evaluation_history)
        if oracle_complete_count is None
        else oracle_complete_count
    )
    if (
        isinstance(complete_count, bool)
        or not isinstance(complete_count, int)
        or complete_count < 0
        or complete_count > len(evaluation_history)
    ):
        raise PublicRunStateError("oracle-complete prefix is malformed")
    history = evaluation_history[:complete_count]
    if len(history) < 26:
        raise PublicRunStateError("formal replay has no complete seed pool")
    by_smiles: dict[str, Mapping[str, Any]] = {}
    by_round: dict[int, list[Mapping[str, Any]]] = {}
    for expected_index, record in enumerate(history, start=1):
        context = record.get("oracle_context") if isinstance(record, Mapping) else None
        smiles = record.get("smiles") if isinstance(record, Mapping) else None
        if (
            not isinstance(record, Mapping)
            or record.get("call_index") != expected_index
            or not isinstance(smiles, str)
            or not smiles
            or smiles in by_smiles
            or not _finite(record.get("raw_target_score"))
            or not isinstance(context, Mapping)
        ):
            raise PublicRunStateError("physical oracle history is malformed")
        if expected_index <= 26:
            if dict(context) != {
                "scope": "seed_pool",
                "seed_pool_index": expected_index - 1,
            }:
                raise PublicRunStateError("seed-pool history is malformed")
        else:
            round_index = context.get("round")
            candidate_index = context.get("candidate_index")
            if (
                set(context) != {"scope", "round", "candidate_index"}
                or context.get("scope") != "optimization_round"
                or isinstance(round_index, bool)
                or not isinstance(round_index, int)
                or round_index < 0
                or isinstance(candidate_index, bool)
                or not isinstance(candidate_index, int)
                or candidate_index < 0
            ):
                raise PublicRunStateError(
                    "optimization oracle context is malformed"
                )
            by_round.setdefault(round_index, []).append(record)
        by_smiles[smiles] = record
    selected_seed = max(
        enumerate(history[:26]),
        key=lambda pair: (float(pair[1]["raw_target_score"]), -pair[0]),
    )[1]["smiles"]
    if selected_seed != seed_smiles:
        raise PublicRunStateError(
            "persisted seed differs from deterministic seed-pool selection"
        )

    outer_by_round: dict[int, Mapping[str, Any]] = {}
    for row in trajectory:
        round_index = row.get("round") if isinstance(row, Mapping) else None
        if (
            not isinstance(row, Mapping)
            or isinstance(round_index, bool)
            or not isinstance(round_index, int)
            or round_index < 0
            or round_index in outer_by_round
        ):
            raise PublicRunStateError("trajectory rounds are malformed")
        outer_by_round[round_index] = row
    failures_by_round: dict[int, Mapping[str, Any]] = {}
    for event in round_failure_history:
        round_index = event.get("round") if isinstance(event, Mapping) else None
        if (
            not isinstance(event, Mapping)
            or isinstance(round_index, bool)
            or not isinstance(round_index, int)
            or round_index < 0
            or round_index in failures_by_round
            or round_index in outer_by_round
        ):
            raise PublicRunStateError("round failure history is malformed")
        failures_by_round[round_index] = event
    attempted = sorted(set(outer_by_round) | set(failures_by_round))
    if attempted and attempted != list(range(attempted[-1] + 1)):
        raise PublicRunStateError("round outcomes are not an exact prefix")
    if stage in {"round_pending", "ready"}:
        if attempted != list(range(next_round)):
            raise PublicRunStateError(
                "committed outcomes do not match resumable next_round"
            )
    elif attempted and attempted[-1] >= max_rounds:
        raise PublicRunStateError("terminal outcomes exceed max_rounds")

    allowed_names = tuple(allowed_active_constraint_names)
    if len(allowed_names) != len(set(allowed_names)):
        raise PublicRunStateError("active constraint allowlist is malformed")
    allowed_set = set(allowed_names)
    transition_rounds: set[int] = set()
    if curriculum_transition_history is not None:
        if not isinstance(curriculum_transition_history, list):
            raise PublicRunStateError(
                "curriculum transition history is malformed"
            )
        for event in curriculum_transition_history:
            transition_round = (
                event.get("round") if isinstance(event, Mapping) else None
            )
            if (
                not isinstance(event, Mapping)
                or isinstance(transition_round, bool)
                or not isinstance(transition_round, int)
                or transition_round < 0
                or transition_round in transition_rounds
            ):
                raise PublicRunStateError(
                    "curriculum transition history is malformed"
                )
            transition_rounds.add(transition_round)
    current_smiles = seed_smiles
    best_target = float(by_smiles[seed_smiles]["raw_target_score"])
    best_admet = float(initial_admet_score)
    best_combined = best_target
    memory: list[dict[str, Any]] = []
    cer_experience_entries: list[dict[str, Any]] = []
    lambdas = {name: 0.0 for name in allowed_names}
    rho = 1.0
    lagrangian_active: tuple[str, ...] = ()
    expected_dual_rows: list[dict[str, Any]] = []
    stagnation_count = 0
    consecutive_round_errors = 0
    successful_scored_rounds = 0
    cer_experiences_committed = 0
    failure_count = 0
    zero_novel_rounds = 0
    generation_restart_cursor = 0
    pending_generation_restart: str | None = None
    reviewer_feedback: str | None = None
    cursor = 26

    for round_index in attempted:
        if round_index in transition_rounds:
            stagnation_count = 0
        failure = failures_by_round.get(round_index)
        if failure is not None:
            before = failure.get("oracle_calls_before")
            after = failure.get("oracle_calls_after")
            if (
                before != cursor
                or isinstance(after, bool)
                or not isinstance(after, int)
                or after < cursor
                or after > complete_count
            ):
                raise PublicRunStateError(
                    "failed-round oracle prefix is not replayable"
                )
            records = by_round.get(round_index, [])
            if [row["call_index"] for row in records] != list(
                range(cursor + 1, after + 1)
            ):
                raise PublicRunStateError(
                    "failed-round records are not one physical prefix"
                )
            cursor = after
            consecutive_round_errors += 1
            if consecutive_round_errors < 3:
                from pharmagent.optimization.formal_prompt_protocol import (
                    FORMAL_ROUND_ERROR_FEEDBACK,
                )

                reviewer_feedback = FORMAL_ROUND_ERROR_FEEDBACK
            continue

        outer = outer_by_round[round_index]
        consecutive_round_errors = 0
        n_candidates = outer.get("n_candidates")
        outer_calls = outer.get("oracle_calls")
        active_value = outer.get("active_constraints")
        if (
            isinstance(n_candidates, bool)
            or not isinstance(n_candidates, int)
            or n_candidates < 0
            or isinstance(outer_calls, bool)
            or not isinstance(outer_calls, int)
            or outer_calls != cursor + n_candidates
            or outer_calls > complete_count
            or not isinstance(active_value, list)
            or any(not isinstance(name, str) for name in active_value)
            or len(active_value) != len(set(active_value))
            or not set(active_value).issubset(allowed_set)
        ):
            raise PublicRunStateError("completed round counters are malformed")
        active = tuple(active_value)
        candidates = sorted(
            by_round.get(round_index, []),
            key=lambda row: int(row["oracle_context"]["candidate_index"]),
        )
        if (
            len(candidates) != n_candidates
            or [row["oracle_context"]["candidate_index"] for row in candidates]
            != list(range(n_candidates))
            or [row["call_index"] for row in candidates]
            != list(range(cursor + 1, outer_calls + 1))
        ):
            raise PublicRunStateError(
                "completed round candidates are not one ordered physical slice"
            )
        cursor = outer_calls
        if outer.get("source_smiles") != current_smiles:
            raise PublicRunStateError(
                "trajectory source differs from replayed current molecule"
            )
        source_record = by_smiles.get(current_smiles)
        if source_record is None:
            raise PublicRunStateError("trajectory source has no oracle record")
        source_target = float(source_record["raw_target_score"])
        if not _close(source_target, best_target):
            raise PublicRunStateError(
                "trajectory source target differs from replayed incumbent"
            )
        source_admet, source_violations = _formal_assessment_scores(
            source_record, active
        )
        if active and lagrangian_enabled:
            if active != lagrangian_active:
                if not set(lagrangian_active) < set(active):
                    raise PublicRunStateError(
                        "formal Lagrangian active set is not expanding"
                    )
                rho = 1.0
                lagrangian_active = active
            source_combined = compute_canonical_lagrangian_score(
                source_target,
                source_violations,
                lambdas,
                rho,
                active,
            )
        elif active:
            source_combined = float(alpha) * source_target + (
                1.0 - float(alpha)
            ) * source_admet
        else:
            source_combined = source_target
        if not _close(outer.get("source_combined_score"), source_combined):
            raise PublicRunStateError(
                "trajectory source combined score is not physically replayable"
            )

        scored: list[dict[str, Any]] = []
        for candidate in candidates:
            target_score = float(candidate["raw_target_score"])
            admet_score, violations = _formal_assessment_scores(
                candidate, active
            )
            if active and lagrangian_enabled:
                combined = compute_canonical_lagrangian_score(
                    target_score,
                    violations,
                    lambdas,
                    rho,
                    active,
                )
            elif active:
                combined = float(alpha) * target_score + (
                    1.0 - float(alpha)
                ) * admet_score
            else:
                combined = target_score
            entry = {
                "smiles": candidate["smiles"],
                "previous_smiles": current_smiles,
                "target_score": target_score,
                "admet_score": admet_score,
                "combined_score": combined,
                # Generator-authored modification metadata is deliberately
                # not a cross-round operand: it has no physical oracle row.
                "modifications": [],
                "round": round_index,
                "delta_target": target_score - source_target,
                "delta_admet": (
                    0.0 if not active else admet_score - source_admet
                ),
                "delta_combined": combined - source_combined,
                "delta_score": combined - source_combined,
                "active_constraints": list(active),
                "task_name": target_property,
            }
            scored.append(entry)
            if memory_capacity:
                memory.append(deepcopy(entry))
                if len(memory) > memory_capacity:
                    memory.pop(0)

        candidate_improves = False
        accepted_smiles = current_smiles
        accepted_admet = source_admet
        accepted_violations = source_violations
        if scored:
            successful_scored_rounds += 1
            failure_count = 0
            round_best = max(
                enumerate(scored),
                key=lambda pair: (float(pair[1]["combined_score"]), -pair[0]),
            )[1]
            candidate_improves = (
                float(round_best["combined_score"]) > source_combined
            )
            if candidate_improves:
                accepted_smiles = str(round_best["smiles"])
                best_target = float(round_best["target_score"])
                accepted_admet = float(round_best["admet_score"])
                accepted_violations = _formal_assessment_scores(
                    by_smiles[accepted_smiles], active
                )[1]
                best_combined = float(round_best["combined_score"])
                current_smiles = accepted_smiles
                stagnation_count = 0
            else:
                best_admet = source_admet
                best_combined = source_combined
                stagnation_count += 1
        else:
            failure_count += 1
            best_admet = source_admet
            best_combined = source_combined
            stagnation_count += 1
            from pharmagent.optimization.formal_prompt_protocol import (
                format_formal_zero_candidate_feedback,
            )

            reviewer_feedback = format_formal_zero_candidate_feedback(
                failure_count
            )
        if candidate_improves:
            best_admet = accepted_admet
        if (
            outer.get("candidate_improves") is not candidate_improves
            or outer.get("accepted_smiles") != accepted_smiles
            or not _close(outer.get("best_score"), best_target)
            or not _close(outer.get("best_combined"), best_combined)
        ):
            raise PublicRunStateError(
                "trajectory accepted iterate is not physically replayable"
            )

        if active and lagrangian_enabled and scored:
            rho_used = rho
            for name in active:
                lambdas[name] = max(
                    0.0,
                    lambdas[name] + rho_used * accepted_violations[name],
                )
            total_violation = sum(accepted_violations.values())
            rho = (
                min(rho_used * 1.5, 100.0)
                if total_violation > 0.0
                else rho_used
            )
            expected_dual_rows.append({
                "round": round_index,
                "active_constraints": list(active),
                "violations": deepcopy(accepted_violations),
                "lambdas": deepcopy(lambdas),
                "rho_used": rho_used,
                "rho": rho,
                "accepted_smiles": accepted_smiles,
            })

        cer_committed = outer.get("cer_experience_committed")
        if not isinstance(cer_committed, bool):
            raise PublicRunStateError(
                "completed round CER commitment flag is malformed"
            )
        if cer_committed and not scored:
            raise PublicRunStateError(
                "zero-candidate round cannot commit a CER experience"
            )
        if cer_committed:
            cer_experiences_committed += 1
            cer_experience_entries.append({
                "source_smiles": round_best["previous_smiles"],
                "target_smiles": round_best["smiles"],
                "modifications": [],
                "delta_target": round_best["delta_target"],
                "delta_admet": round_best["delta_admet"],
                "delta_combined": round_best["delta_combined"],
                "task_name": target_property,
                "round": round_index,
            })
        audit = outer.get("novelty_audit")
        if not isinstance(audit, Mapping):
            raise PublicRunStateError("completed round has no novelty audit")
        if audit.get("restart_applied") != pending_generation_restart:
            raise PublicRunStateError("novelty restart is not replayable")
        pending_generation_restart = None
        novel_count = audit.get("globally_novel_count")
        if (
            isinstance(novel_count, bool)
            or not isinstance(novel_count, int)
            or novel_count < 0
        ):
            raise PublicRunStateError("novelty count is malformed")
        zero_novel_rounds = (
            0 if novel_count > 0 else zero_novel_rounds + 1
        )
        if audit.get("zero_novel_round_streak") != zero_novel_rounds:
            raise PublicRunStateError("zero-novel streak is not replayable")
        if zero_novel_rounds == restart_threshold:
            restart = restart_strategies[
                generation_restart_cursor % len(restart_strategies)
            ]
            if audit.get("restart_scheduled") != restart:
                raise PublicRunStateError("novelty restart schedule is invalid")
            pending_generation_restart = restart
            generation_restart_cursor += 1
            zero_novel_rounds = 0
        elif audit.get("restart_scheduled") is not None:
            raise PublicRunStateError("novelty restart was scheduled early")

        if scored:
            if reviewer_enabled:
                if require_reviewer_feedback:
                    response = (
                        reviewer_responses or {}
                    ).get(f"round:{round_index}:reviewer")
                    reviewer_feedback = _formal_reviewer_feedback(
                        response, target_only=not active
                    )
            else:
                from pharmagent.optimization.formal_prompt_protocol import (
                    FORMAL_REVIEWER_DISABLED_FEEDBACK,
                )

                reviewer_feedback = FORMAL_REVIEWER_DISABLED_FEEDBACK

    if cursor != complete_count:
        raise PublicRunStateError(
            "committed outcomes do not consume the checkpoint oracle prefix"
        )
    return {
        "current_smiles": current_smiles,
        "best_smiles": current_smiles,
        "best_target_score": best_target,
        "best_admet_score": best_admet,
        "best_combined": best_combined,
        "memory_buffer": memory,
        "reviewer_feedback": reviewer_feedback,
        "stagnation_count": stagnation_count,
        "round_error_count": len(failures_by_round),
        "consecutive_round_errors": consecutive_round_errors,
        "successful_scored_rounds": successful_scored_rounds,
        "cer_experiences_committed": cer_experiences_committed,
        "cer_experience_entries": cer_experience_entries,
        "failure_count": failure_count,
        "zero_novel_rounds": zero_novel_rounds,
        "generation_restart_cursor": generation_restart_cursor,
        "pending_generation_restart": pending_generation_restart,
        "selected_seed_smiles": selected_seed,
        "oracle_complete_count": complete_count,
        "committed_oracle_count": cursor,
        "expected_lagrangian_trajectory": expected_dual_rows,
    }


def validate_native_loop_state_against_replay(
    value: object, replayed: Mapping[str, Any]
) -> None:
    """Validate every mutable online operand covered by physical replay."""
    if not isinstance(value, Mapping):
        raise PublicRunStateError("native optimizer state is not a mapping")
    exact_fields = (
        "current_smiles",
        "best_smiles",
        "memory_buffer",
        "reviewer_feedback",
        "stagnation_count",
        "round_error_count",
        "consecutive_round_errors",
        "successful_scored_rounds",
        "cer_experiences_committed",
        "failure_count",
        "zero_novel_rounds",
        "generation_restart_cursor",
        "pending_generation_restart",
    )
    if any(value.get(field) != replayed.get(field) for field in exact_fields):
        raise PublicRunStateError(
            "native optimizer state differs from physical replay"
        )
    for field in (
        "best_target_score",
        "best_admet_score",
        "best_combined",
    ):
        if not _close(value.get(field), replayed.get(field)):
            raise PublicRunStateError(
                "native optimizer scores differ from physical replay"
            )


def replay_public_terminal_state(
    *,
    trajectory: object,
    round_failure_history: object,
    evaluation_history: object,
    restart_threshold: int = 5,
    restart_strategies: tuple[str, ...] = (
        "scaffold-hop",
        "ring-linker",
        "bioisostere",
    ),
    expected_max_rounds: int | None = None,
) -> dict[str, Any]:
    """Return counters and molecule identities implied by public evidence."""
    if (
        not isinstance(trajectory, list)
        or not isinstance(round_failure_history, list)
        or not isinstance(evaluation_history, list)
        or not evaluation_history
    ):
        raise PublicRunStateError("public terminal evidence is incomplete")
    outer: dict[int, Mapping[str, Any]] = {}
    for row in trajectory:
        if (
            not isinstance(row, Mapping)
            or isinstance(row.get("round"), bool)
            or not isinstance(row.get("round"), int)
            or row["round"] in outer
        ):
            raise PublicRunStateError("trajectory rounds are invalid")
        outer[int(row["round"])] = row
    failures: dict[int, Mapping[str, Any]] = {}
    for event in round_failure_history:
        if (
            not isinstance(event, Mapping)
            or isinstance(event.get("round"), bool)
            or not isinstance(event.get("round"), int)
            or event["round"] in failures
            or event["round"] in outer
        ):
            raise PublicRunStateError("failure rounds are invalid")
        failures[int(event["round"])] = event
    attempted = sorted(set(outer) | set(failures))
    if attempted and attempted != list(range(attempted[-1] + 1)):
        raise PublicRunStateError("round outcomes are not an exact prefix")
    if (
        expected_max_rounds is not None
        and (
            isinstance(expected_max_rounds, bool)
            or not isinstance(expected_max_rounds, int)
            or expected_max_rounds <= 0
            or any(round_index >= expected_max_rounds for round_index in attempted)
        )
    ):
        raise PublicRunStateError("round outcomes exceed max_rounds")

    seed_rows = evaluation_history[: min(26, len(evaluation_history))]
    if any(
        not isinstance(row, Mapping)
        or not isinstance(row.get("smiles"), str)
        or isinstance(row.get("raw_target_score"), bool)
        or not isinstance(row.get("raw_target_score"), (int, float))
        for row in seed_rows
    ):
        raise PublicRunStateError("seed-pool records are invalid")
    selected_seed = max(
        enumerate(seed_rows),
        key=lambda pair: (float(pair[1]["raw_target_score"]), -pair[0]),
    )[1]["smiles"]
    current_smiles = selected_seed

    consecutive_round_errors = 0
    successful_scored_rounds = 0
    cer_experiences_committed = 0
    failure_count = 0
    zero_novel_rounds = 0
    generation_restart_cursor = 0
    pending_generation_restart: str | None = None
    for round_index in attempted:
        if round_index in failures:
            consecutive_round_errors += 1
            if consecutive_round_errors >= 3:
                raise PublicRunStateError(
                    "formal runtime stops at three consecutive round errors"
                )
            continue
        consecutive_round_errors = 0
        row = outer[round_index]
        n_candidates = row.get("n_candidates")
        if (
            isinstance(n_candidates, bool)
            or not isinstance(n_candidates, int)
            or n_candidates < 0
            or not isinstance(row.get("cer_experience_committed"), bool)
        ):
            raise PublicRunStateError("outer counters are malformed")
        if n_candidates > 0:
            successful_scored_rounds += 1
            failure_count = 0
        else:
            failure_count += 1
        if row["cer_experience_committed"]:
            cer_experiences_committed += 1
        if row.get("candidate_improves") is True:
            accepted = row.get("accepted_smiles")
            if not isinstance(accepted, str):
                raise PublicRunStateError("improving outer has no accepted molecule")
            current_smiles = accepted

        audit = row.get("novelty_audit")
        if not isinstance(audit, Mapping):
            raise PublicRunStateError("outer novelty audit is missing")
        if audit.get("restart_applied") != pending_generation_restart:
            raise PublicRunStateError("restart application is not replayable")
        pending_generation_restart = None
        novel_count = audit.get("globally_novel_count")
        if (
            isinstance(novel_count, bool)
            or not isinstance(novel_count, int)
            or novel_count < 0
        ):
            raise PublicRunStateError("novelty counter is invalid")
        zero_novel_rounds = (
            0 if novel_count > 0 else zero_novel_rounds + 1
        )
        if audit.get("zero_novel_round_streak") != zero_novel_rounds:
            raise PublicRunStateError("zero-novel streak is not replayable")
        if zero_novel_rounds == restart_threshold:
            expected_restart = restart_strategies[
                generation_restart_cursor % len(restart_strategies)
            ]
            if audit.get("restart_scheduled") != expected_restart:
                raise PublicRunStateError("scheduled restart is not replayable")
            pending_generation_restart = expected_restart
            generation_restart_cursor += 1
            zero_novel_rounds = 0
        elif audit.get("restart_scheduled") is not None:
            raise PublicRunStateError("restart was scheduled before threshold")

    if successful_scored_rounds == 0:
        raise PublicRunStateError(
            "a complete terminal run needs a successful scored round"
        )
    terminal_records = [
        row
        for row in evaluation_history
        if isinstance(row, Mapping) and row.get("smiles") == current_smiles
    ]
    if len(terminal_records) != 1:
        raise PublicRunStateError(
            "terminal accepted molecule does not identify one oracle record"
        )
    terminal_record = terminal_records[0]
    raw_target_score = terminal_record.get("raw_target_score")
    if (
        isinstance(raw_target_score, bool)
        or not isinstance(raw_target_score, (int, float))
        or not math.isfinite(float(raw_target_score))
    ):
        raise PublicRunStateError(
            "terminal accepted record has no finite target score"
        )
    record_admet_score = terminal_record.get("admet_score")
    if record_admet_score is not None and (
        isinstance(record_admet_score, bool)
        or not isinstance(record_admet_score, (int, float))
        or not math.isfinite(float(record_admet_score))
    ):
        raise PublicRunStateError(
            "terminal accepted record has a non-finite ADMET score"
        )
    final_outer = outer[max(outer)]
    best_combined_score = final_outer.get("best_combined")
    if (
        isinstance(best_combined_score, bool)
        or not isinstance(best_combined_score, (int, float))
        or not math.isfinite(float(best_combined_score))
    ):
        raise PublicRunStateError(
            "terminal trajectory has no finite combined score"
        )
    return {
        "round_error_count": len(failures),
        "consecutive_round_errors": consecutive_round_errors,
        "successful_scored_rounds": successful_scored_rounds,
        "cer_experiences_committed": cer_experiences_committed,
        "zero_novel_rounds": zero_novel_rounds,
        "failure_count": failure_count,
        "generation_restart_cursor": generation_restart_cursor,
        "pending_generation_restart": pending_generation_restart,
        "selected_seed_smiles": selected_seed,
        "current_smiles": current_smiles,
        "best_smiles": current_smiles,
        "best_target_score": float(raw_target_score),
        "best_admet_score": (
            None
            if record_admet_score is None
            else float(record_admet_score)
        ),
        "best_combined_score": float(best_combined_score),
    }


__all__ = [
    "FORMAL_MEMORY_CAPACITY",
    "PublicRunStateError",
    "replay_native_loop_state",
    "replay_public_terminal_state",
    "validate_native_loop_state_against_replay",
]
