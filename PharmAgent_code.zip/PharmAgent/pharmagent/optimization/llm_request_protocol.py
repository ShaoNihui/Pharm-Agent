"""Public logical-LLM-request audit for formal optimization rounds."""

from __future__ import annotations

from collections import Counter
from collections.abc import Mapping
import re
from typing import Any


_REQUEST_ID = re.compile(
    r"^round:(?P<round>[0-9]+):(?:(?P<generator>generator):"
    r"(?P<stage>primary|repair):attempt_1|(?P<reviewer>reviewer))$"
)
_FIELDS = {
    "request_id",
    "client_role",
    "status",
    "known_failed_attempts",
    "last_accounted_attempt",
}


def _validate_public_llm_request_audit(
    *,
    trajectory: object,
    round_failure_history: object,
    request_audit: object,
    request_counts: object,
) -> bool:
    """Bind every published logical request to one attempted formal round."""
    if (
        not isinstance(trajectory, list)
        or not isinstance(round_failure_history, list)
        or not isinstance(request_audit, list)
        or not isinstance(request_counts, Mapping)
    ):
        return False
    outer: dict[int, Mapping[str, Any]] = {}
    failures: dict[int, Mapping[str, Any]] = {}
    try:
        for row in trajectory:
            if (
                not isinstance(row, Mapping)
                or isinstance(row.get("round"), bool)
                or not isinstance(row.get("round"), int)
                or row["round"] in outer
            ):
                return False
            outer[int(row["round"])] = row
        for event in round_failure_history:
            if (
                not isinstance(event, Mapping)
                or isinstance(event.get("round"), bool)
                or not isinstance(event.get("round"), int)
                or event["round"] in failures
                or event["round"] in outer
            ):
                return False
            failures[int(event["round"])] = event
    except (KeyError, TypeError, ValueError):
        return False

    by_round: dict[int, list[tuple[str, str, str]]] = {}
    observed_counts: Counter[str] = Counter()
    seen_ids: set[str] = set()
    previous_round = -1
    previous_last_attempt = 0
    for event in request_audit:
        if not isinstance(event, Mapping) or set(event) != _FIELDS:
            return False
        request_id = event.get("request_id")
        match = _REQUEST_ID.fullmatch(request_id or "")
        status = event.get("status")
        role = event.get("client_role")
        failed_attempts = event.get("known_failed_attempts")
        last_attempt = event.get("last_accounted_attempt")
        if (
            match is None
            or request_id in seen_ids
            or status not in {
                "prepared",
                "http_started",
                "complete",
                "failed_known",
            }
            or isinstance(failed_attempts, bool)
            or not isinstance(failed_attempts, int)
            or failed_attempts < 0
            or isinstance(last_attempt, bool)
            or not isinstance(last_attempt, int)
            or last_attempt < failed_attempts
            or (status == "complete" and last_attempt <= 0)
            or (
                status == "failed_known"
                and (failed_attempts <= 0 or last_attempt <= 0)
            )
        ):
            return False
        round_index = int(match.group("round"))
        kind = (
            match.group("stage")
            if match.group("generator")
            else "reviewer"
        )
        expected_role = "generator" if kind != "reviewer" else "reviewer"
        expected_last_attempt = (
            previous_last_attempt + failed_attempts + 1
            if status == "complete"
            else previous_last_attempt + failed_attempts
            if status == "failed_known"
            else last_attempt
        )
        if (
            role != expected_role
            or round_index not in set(outer) | set(failures)
            or round_index < previous_round
            or (
                status in {"complete", "failed_known"}
                and last_attempt != expected_last_attempt
            )
        ):
            return False
        by_round.setdefault(round_index, []).append((kind, status, request_id))
        observed_counts[str(status)] += 1
        seen_ids.add(str(request_id))
        previous_round = round_index
        previous_last_attempt = last_attempt

    if dict(observed_counts) != dict(request_counts):
        return False
    if any(status in observed_counts for status in ("prepared", "http_started")):
        return False

    for round_index, row in outer.items():
        audit = row.get("novelty_audit")
        if not isinstance(audit, Mapping):
            return False
        expected = [("primary", "complete")]
        if audit.get("repair_used") is True:
            expected.append(("repair", "complete"))
        elif audit.get("repair_used") is not False:
            return False
        reviewer_calls = audit.get("reviewer_calls")
        if reviewer_calls == 1:
            expected.append(("reviewer", "complete"))
        elif reviewer_calls != 0:
            return False
        observed = [
            (kind, status) for kind, status, _request_id
            in by_round.get(round_index, [])
        ]
        if observed != expected:
            return False

    allowed_failure_sequences = {
        (),
        ("primary",),
        ("primary", "repair"),
        ("primary", "reviewer"),
        ("primary", "repair", "reviewer"),
    }
    for round_index, failure in failures.items():
        events = by_round.get(round_index, [])
        kinds = tuple(kind for kind, _status, _request_id in events)
        statuses = [status for _kind, status, _request_id in events]
        before = failure.get("oracle_calls_before")
        after = failure.get("oracle_calls_after")
        if (
            isinstance(before, bool)
            or not isinstance(before, int)
            or isinstance(after, bool)
            or not isinstance(after, int)
            or after < before
        ):
            return False
        calls_advanced = after > before
        if (
            kinds not in allowed_failure_sequences
            or any(status not in {"complete", "failed_known"} for status in statuses)
            or any(
                status == "failed_known"
                for status in statuses[:-1]
            )
            or (
                calls_advanced
                and (
                    not events
                    or any(
                        kind != "reviewer" and status != "complete"
                        for kind, status, _request_id in events
                    )
                )
            )
            or ("reviewer" in kinds and not calls_advanced)
        ):
            return False
    return True


def validate_public_llm_request_audit(
    *,
    trajectory: object,
    round_failure_history: object,
    request_audit: object,
    request_counts: object,
) -> bool:
    """Fail closed for malformed public JSON without masking interrupts."""
    try:
        return _validate_public_llm_request_audit(
            trajectory=trajectory,
            round_failure_history=round_failure_history,
            request_audit=request_audit,
            request_counts=request_counts,
        )
    except (KeyError, TypeError, ValueError, OverflowError):
        return False


__all__ = ["validate_public_llm_request_audit"]
