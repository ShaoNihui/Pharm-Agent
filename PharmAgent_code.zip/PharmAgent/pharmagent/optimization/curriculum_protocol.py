"""Pure validation of the formal curriculum/Lagrangian mechanism trace.

The optimizer, result normalizer, and completion checks all need to answer the
same scientific question: did the two preregistered curriculum transitions
occur for the recorded reasons, and was each transition consumed by the
Lagrangian controller at the first successful round?  Keeping that replay in
this dependency-light module prevents the runtime and publication validators
from gradually accepting different histories.
"""

from __future__ import annotations

from collections.abc import Mapping
import math
from typing import Any


FORMAL_EASY_ADMET_CONSTRAINTS = (
    "lipinski_mw",
    "lipinski_logp",
    "qed",
    "sa_score",
)
FORMAL_FULL_ADMET_CONSTRAINTS = FORMAL_EASY_ADMET_CONSTRAINTS + (
    "cyp2d6_inh",
    "herg",
    "caco2",
)
FORMAL_CURRICULUM_TRANSITIONS = ((1, 2, 20), (2, 3, 60))
FORMAL_CURRICULUM_TRANSITION_POLICY = "round_boundary_only"


class CurriculumMechanismError(ValueError):
    """Raised when public mechanism evidence cannot be replayed exactly."""


def _integer(value: object, *, minimum: int = 0) -> bool:
    return (
        not isinstance(value, bool)
        and isinstance(value, int)
        and value >= minimum
    )


def _finite_nonnegative(value: object) -> bool:
    return (
        not isinstance(value, bool)
        and isinstance(value, (int, float))
        and math.isfinite(float(value))
        and float(value) >= 0.0
    )


def _failure_rounds(value: object) -> dict[int, Mapping[str, Any]]:
    if not isinstance(value, list):
        raise CurriculumMechanismError(
            "round_failure_history must be a list"
        )
    output: dict[int, Mapping[str, Any]] = {}
    previous_round = -1
    previous_after: int | None = None
    required = {
        "round",
        "failure_class",
        "error_type",
        "oracle_calls_before",
        "oracle_calls_after",
        "oracle_record_sha256",
    }
    for event in value:
        if not isinstance(event, Mapping) or set(event) != required:
            raise CurriculumMechanismError(
                "round failure event has an invalid schema"
            )
        round_index = event.get("round")
        before = event.get("oracle_calls_before")
        after = event.get("oracle_calls_after")
        hashes = event.get("oracle_record_sha256")
        error_type = event.get("error_type")
        if (
            not _integer(round_index)
            or int(round_index) <= previous_round
            or event.get("failure_class") != "recoverable_round_error"
            or not isinstance(error_type, str)
            or not error_type.isidentifier()
            or not _integer(before)
            or not _integer(after)
            or int(after) < int(before)
            or not isinstance(hashes, list)
            or len(hashes) != int(after) - int(before)
            or any(
                not isinstance(digest, str)
                or len(digest) != 64
                or any(character not in "0123456789abcdef" for character in digest)
                for digest in hashes
            )
            or (
                previous_after is not None
                and int(before) < previous_after
            )
        ):
            raise CurriculumMechanismError(
                "round failure event is not an ordered durable outcome"
            )
        output[int(round_index)] = event
        previous_round = int(round_index)
        previous_after = int(after)
    return output


def _outer_rounds(value: object) -> dict[int, Mapping[str, Any]]:
    if not isinstance(value, list):
        raise CurriculumMechanismError("trajectory must be a list")
    output: dict[int, Mapping[str, Any]] = {}
    previous_round = -1
    previous_calls = 0
    allowed_active = {
        (),
        FORMAL_EASY_ADMET_CONSTRAINTS,
        FORMAL_FULL_ADMET_CONSTRAINTS,
    }
    for row in value:
        if not isinstance(row, Mapping):
            raise CurriculumMechanismError("trajectory row must be a mapping")
        round_index = row.get("round")
        oracle_calls = row.get("oracle_calls")
        candidate_count = row.get("n_candidates")
        candidate_improves = row.get("candidate_improves")
        active = row.get("active_constraints")
        if (
            not _integer(round_index)
            or int(round_index) <= previous_round
            or not _integer(oracle_calls)
            or int(oracle_calls) < previous_calls
            or not _integer(candidate_count)
            or not isinstance(candidate_improves, bool)
            or (int(candidate_count) == 0 and candidate_improves)
            or not isinstance(active, list)
            or tuple(active) not in allowed_active
        ):
            raise CurriculumMechanismError(
                "trajectory row is not an ordered formal round outcome"
            )
        output[int(round_index)] = row
        previous_round = int(round_index)
        previous_calls = int(oracle_calls)
    return output


def _curriculum_events(value: object) -> list[Mapping[str, Any]]:
    if not isinstance(value, list) or len(value) > 2:
        raise CurriculumMechanismError(
            "curriculum transition history must contain at most two events"
        )
    output: list[Mapping[str, Any]] = []
    previous_round = -1
    required = {
        "event",
        "round",
        "from_phase",
        "to_phase",
        "reasons",
        "incoming_stagnation_count",
    }
    for index, event in enumerate(value):
        from_phase, to_phase, boundary = FORMAL_CURRICULUM_TRANSITIONS[index]
        if not isinstance(event, Mapping) or set(event) != required:
            raise CurriculumMechanismError(
                "curriculum transition event has an invalid schema"
            )
        round_index = event.get("round")
        incoming = event.get("incoming_stagnation_count")
        reasons = event.get("reasons")
        if (
            event.get("event") != "curriculum_phase_transition"
            or event.get("from_phase") != from_phase
            or event.get("to_phase") != to_phase
            or not _integer(round_index)
            or int(round_index) != boundary
            or int(round_index) <= previous_round
            or not _integer(incoming)
            or reasons != ["round_boundary"]
        ):
            raise CurriculumMechanismError(
                "curriculum transition event is not the formal phase sequence"
            )
        output.append(event)
        previous_round = int(round_index)
    return output


def _lagrangian_events(value: object) -> list[Mapping[str, Any]]:
    if not isinstance(value, list) or len(value) > 2:
        raise CurriculumMechanismError(
            "Lagrangian transition events must contain at most two events"
        )
    output: list[Mapping[str, Any]] = []
    for index, event in enumerate(value):
        previous = () if index == 0 else FORMAL_EASY_ADMET_CONSTRAINTS
        active = (
            FORMAL_EASY_ADMET_CONSTRAINTS
            if index == 0
            else FORMAL_FULL_ADMET_CONSTRAINTS
        )
        round_index = event.get("round") if isinstance(event, Mapping) else None
        if (
            not isinstance(event, Mapping)
            or event.get("event") != "active_set_expansion"
            or not _integer(round_index)
            or event.get("previous_active_constraints") != list(previous)
            or event.get("active_constraints") != list(active)
            or event.get("added_constraints")
            != [name for name in active if name not in previous]
            or event.get("removed_constraints") != []
            or event.get("rho_reset") is not True
            or not _finite_nonnegative(event.get("rho_before_transition"))
            or event.get("rho_after_transition") != 1.0
            or not isinstance(event.get("lambdas_retained"), Mapping)
            or set(event["lambdas_retained"])
            != set(FORMAL_FULL_ADMET_CONSTRAINTS)
            or any(
                not _finite_nonnegative(number)
                for number in event["lambdas_retained"].values()
            )
        ):
            raise CurriculumMechanismError(
                "Lagrangian expansion is not the formal ordered active set"
            )
        output.append(event)
    return output


def validate_curriculum_lagrangian_evidence(
    *,
    trajectory: object,
    round_failure_history: object,
    curriculum_transition_history: object,
    final_stagnation_count: object,
    lagrangian_transition_events: object,
    require_terminal: bool,
    expected_next_round: int | None = None,
) -> bool:
    """Replay curriculum decisions and bind catch-up to exact failed rounds.

    For a curriculum event at round ``c`` and its ordered Lagrangian expansion
    at round ``l``, ``l`` must be the first successful outer outcome at or
    after ``c``.  Consequently every attempted round in ``[c, l)`` is present
    in ``round_failure_history``.  No successful round using pre-transition
    constraints can occur before catch-up.
    """
    try:
        outer = _outer_rounds(trajectory)
        failures = _failure_rounds(round_failure_history)
        curriculum = _curriculum_events(curriculum_transition_history)
        lagrangian = _lagrangian_events(lagrangian_transition_events)
        if not _integer(final_stagnation_count):
            raise CurriculumMechanismError(
                "final_stagnation_count must be a non-negative integer"
            )
        if set(outer).intersection(failures):
            raise CurriculumMechanismError(
                "a round cannot be both successful and failed"
            )
        attempted = sorted(set(outer) | set(failures))
        if expected_next_round is not None:
            if not _integer(expected_next_round):
                raise CurriculumMechanismError("next_round is invalid")
            expected_attempted = list(range(expected_next_round))
        elif attempted:
            expected_attempted = list(range(attempted[-1] + 1))
        else:
            expected_attempted = []
        if attempted != expected_attempted:
            raise CurriculumMechanismError(
                "round outcomes are not an exact attempted-round prefix"
            )
        if require_terminal:
            if len(curriculum) != 2 or len(lagrangian) != 2:
                raise CurriculumMechanismError(
                    "terminal ADMET evidence must consume both transitions"
                )
        elif len(lagrangian) > len(curriculum):
            raise CurriculumMechanismError(
                "Lagrangian expansions are not a curriculum-history prefix"
            )
        expected_curriculum_count = sum(
            boundary in attempted
            for _from_phase, _to_phase, boundary
            in FORMAL_CURRICULUM_TRANSITIONS
        )
        if len(curriculum) != expected_curriculum_count:
            raise CurriculumMechanismError(
                "curriculum history is not the exact boundary prefix"
            )

        curriculum_by_round = {
            int(event["round"]): event for event in curriculum
        }
        for round_index, row in outer.items():
            expected_transition = curriculum_by_round.get(round_index)
            if row.get("curriculum_transition") != expected_transition:
                raise CurriculumMechanismError(
                    "outer curriculum marker differs from append-only history"
                )

        replayed_stagnation = 0
        for round_index in attempted:
            transition = curriculum_by_round.get(round_index)
            if transition is not None:
                if transition["incoming_stagnation_count"] != replayed_stagnation:
                    raise CurriculumMechanismError(
                        "curriculum incoming stagnation is not replayable"
                    )
                boundary = FORMAL_CURRICULUM_TRANSITIONS[
                    int(transition["from_phase"]) - 1
                ][2]
                if (
                    round_index != boundary
                    or transition["reasons"] != ["round_boundary"]
                ):
                    raise CurriculumMechanismError(
                        "curriculum reasons do not match deterministic replay"
                    )
                replayed_stagnation = 0
            row = outer.get(round_index)
            if row is None:
                continue
            near_audit = row.get("near_feasible_audit")
            if (
                not isinstance(near_audit, Mapping)
                or near_audit.get("phase_stagnation_count")
                != replayed_stagnation
            ):
                raise CurriculumMechanismError(
                    "outer phase stagnation audit does not match replay"
                )
            replayed_stagnation = (
                0 if row["candidate_improves"] else replayed_stagnation + 1
            )
        if replayed_stagnation != final_stagnation_count:
            raise CurriculumMechanismError(
                "terminal stagnation count does not match replay"
            )

        successful_rounds = sorted(outer)
        replayed_active: tuple[str, ...] = ()
        lagrangian_by_round: dict[int, list[Mapping[str, Any]]] = {}
        for index, event in enumerate(lagrangian):
            curriculum_event = curriculum[index]
            curriculum_round = int(curriculum_event["round"])
            lagrangian_round = int(event["round"])
            first_success = next(
                (round_index for round_index in successful_rounds
                 if round_index >= curriculum_round),
                None,
            )
            if (
                lagrangian_round < curriculum_round
                or first_success != lagrangian_round
                or any(
                    round_index not in failures
                    for round_index in range(curriculum_round, lagrangian_round)
                )
            ):
                raise CurriculumMechanismError(
                    "Lagrangian catch-up is not at the first post-transition outer round"
                )
            lagrangian_by_round.setdefault(lagrangian_round, []).append(event)

        lagrangian_cursor = 0
        for round_index in successful_rounds:
            for event in lagrangian_by_round.get(round_index, []):
                expected_previous = (
                    () if lagrangian_cursor == 0
                    else FORMAL_EASY_ADMET_CONSTRAINTS
                )
                expected_active = (
                    FORMAL_EASY_ADMET_CONSTRAINTS
                    if lagrangian_cursor == 0
                    else FORMAL_FULL_ADMET_CONSTRAINTS
                )
                if (
                    tuple(event["previous_active_constraints"])
                    != expected_previous
                    or tuple(event["active_constraints"])
                    != expected_active
                ):
                    raise CurriculumMechanismError(
                        "Lagrangian expansion order is not replayable"
                    )
                replayed_active = expected_active
                lagrangian_cursor += 1
            if tuple(outer[round_index]["active_constraints"]) != replayed_active:
                raise CurriculumMechanismError(
                    "outer active constraints differ from Lagrangian replay"
                )
        if require_terminal and replayed_active != FORMAL_FULL_ADMET_CONSTRAINTS:
            raise CurriculumMechanismError(
                "terminal Lagrangian active set is not complete"
            )
        return True
    except (CurriculumMechanismError, KeyError, TypeError, ValueError):
        return False


__all__ = [
    "CurriculumMechanismError",
    "FORMAL_CURRICULUM_TRANSITION_POLICY",
    "FORMAL_CURRICULUM_TRANSITIONS",
    "FORMAL_EASY_ADMET_CONSTRAINTS",
    "FORMAL_FULL_ADMET_CONSTRAINTS",
    "validate_curriculum_lagrangian_evidence",
]
