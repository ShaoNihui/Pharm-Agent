"""
PharmAgent: ADMET-Aware Multi-Agent LLM Framework for Practical Molecular Optimization
"""
