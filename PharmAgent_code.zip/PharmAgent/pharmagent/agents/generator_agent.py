"""
Generator Agent — proposes molecular modifications via LLM.
"""

from pharmagent.agents.base_agent import BaseAgent
from pharmagent.llm.api_client import LLMClient
from pharmagent.llm.prompt_templates import (
    GENERATOR_SYSTEM_PROMPT,
    GENERATOR_TARGET_ONLY_SYSTEM_PROMPT,
    GENERATOR_TARGET_ONLY_USER_PROMPT,
    GENERATOR_USER_PROMPT,
    format_admet_constraints,
    format_generation_context_restart,
    format_novelty_repair,
)
from pharmagent.llm.output_parser import parse_molecule_candidates
from pharmagent.optimization.near_feasible_archive import (
    format_near_feasible_context,
)


class GeneratorAgent(BaseAgent):
    """Uses an LLM to generate candidate molecular modifications."""

    def __init__(self, config: dict):
        super().__init__(config)
        self.llm = LLMClient(config["llm"], client_role="generator")
        self.n_candidates = config.get("n_candidates", 5)
        if (
            isinstance(self.n_candidates, bool)
            or not isinstance(self.n_candidates, int)
            or self.n_candidates <= 0
        ):
            raise ValueError("generator.n_candidates must be a positive integer")

    def run(self, inputs: dict) -> dict:
        """Generate candidate molecules.

        Inputs:
            current_smiles: str
            target_property: str
            admet_constraints: dict
            current_target_score: float (optional)
            current_admet_summary: str (optional)
            rag_context: str (optional)
            reviewer_feedback: str (optional)
            successful_patterns: str (optional)
            failed_patterns: str (optional)
            optimization_history: str (optional)

        Returns:
            {"candidates": list[dict], "raw_response": str}
        """
        target_only_phase = bool(inputs.get("target_only_phase", False))
        common_prompt_values = {
            "current_smiles": inputs["current_smiles"],
            "target_property": inputs.get("target_property", "target activity"),
            "current_target_score": inputs.get("current_target_score", 0.0),
            "rag_context": inputs.get(
                "rag_context", "No reference cases available."
            ),
            "reviewer_feedback": inputs.get(
                "reviewer_feedback", "First round, no feedback yet."
            ),
            "successful_patterns": inputs.get(
                "successful_patterns", "No patterns recorded yet."
            ),
            "failed_patterns": inputs.get(
                "failed_patterns", "No patterns recorded yet."
            ),
            "cer_experience": inputs.get(
                "cer_experience", "No similar experiences available yet."
            ),
            "n_candidates": self.n_candidates,
        }
        if target_only_phase:
            prompt = GENERATOR_TARGET_ONLY_USER_PROMPT.format(
                **common_prompt_values
            )
            system_prompt = GENERATOR_TARGET_ONLY_SYSTEM_PROMPT
        else:
            constraints_text = format_admet_constraints(
                inputs.get("admet_constraints", {})
            )
            prompt = GENERATOR_USER_PROMPT.format(
                **common_prompt_values,
                current_admet_summary=inputs.get(
                    "current_admet_summary", "N/A"
                ),
                admet_constraints_formatted=constraints_text,
                constraint_priorities=inputs.get("constraint_priorities", ""),
            )
            system_prompt = GENERATOR_SYSTEM_PROMPT
        prompt += format_generation_context_restart(
            inputs.get("generation_restart_strategy")
        )
        if "near_feasible_anchors" in inputs:
            prompt += format_near_feasible_context(
                {
                    "smiles": inputs["current_smiles"],
                    "target_score": inputs.get("current_target_score"),
                    "admet_score": inputs.get("current_admet_score"),
                    "constraint_assessments": inputs.get(
                        "current_constraint_assessments", []
                    ),
                },
                list(inputs.get("near_feasible_anchors", [])),
            )
        if inputs.get("novelty_repair", False):
            prompt += format_novelty_repair(
                reasons=list(inputs.get("repair_reasons", [])),
                taboo_smiles=list(inputs.get("taboo_smiles", [])),
                taboo_requested_count=int(
                    inputs.get("taboo_requested_count", 20)
                ),
                n_candidates=self.n_candidates,
            )
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt},
        ]

        # First attempt
        request_prefix = inputs.get("native_request_id")
        raw_response = self.llm.generate(
            messages,
            json_mode=True,
            request_id=(
                f"{request_prefix}:attempt_1" if request_prefix else None
            ),
        )
        candidates = parse_molecule_candidates(raw_response)

        # Direct callers may enable one parse retry.
        # Formal orchestration owns its bounded primary/repair control flow and
        # disables this additional LLM request.
        llm_call_count = 1
        if (
            not candidates
            and raw_response
            and not inputs.get("orchestrator_managed_novelty_repair", False)
        ):
            self.log("No valid candidates on first attempt, retrying with temp=0.9")
            raw_response = self.llm.generate(
                messages,
                temperature=0.9,
                json_mode=True,
                request_id=(
                    f"{request_prefix}:attempt_2" if request_prefix else None
                ),
            )
            llm_call_count += 1
            candidates = parse_molecule_candidates(raw_response)

        proposed_count = len(candidates)
        candidates = candidates[:self.n_candidates]
        truncated_count = proposed_count - len(candidates)

        if not candidates:
            self.log("Generator produced 0 valid candidates", level="WARNING")

        return {
            "candidates": candidates,
            "raw_response": raw_response,
            "proposed_count": proposed_count,
            "truncated_count": truncated_count,
            "llm_call_count": llm_call_count,
        }
