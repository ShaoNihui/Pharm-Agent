"""
Constraint Verifier Agent — validates chemical legality and drug-likeness.

This agent does NOT use an LLM. Pure RDKit computations.
"""

from pharmagent.agents.base_agent import BaseAgent
from pharmagent.tools.rdkit_tools import (
    validate_smiles,
    check_lipinski,
    check_veber,
    check_pains,
    check_brenk,
    compute_qed,
)
from pharmagent.tools.sa_scorer import compute_sa_score


class VerifierAgent(BaseAgent):
    """Validates candidate molecules for chemical legality and drug-likeness."""

    def __init__(self, config: dict):
        super().__init__(config)
        self.check_lipinski_flag = config.get("check_lipinski", True)
        self.check_veber_flag = config.get("check_veber", True)
        self.check_pains_flag = config.get("check_pains", True)
        self.check_brenk_flag = config.get("check_brenk", True)
        self.check_sa_flag = config.get("check_sa", True)
        self.check_qed_flag = config.get("check_qed", True)
        self.max_sa_score = config.get("max_sa_score", 6.0)
        self.min_qed = config.get("min_qed", 0.3)

    def run(self, inputs: dict) -> dict:
        """Verify a single molecule.

        Inputs:
            smiles: str

        Returns:
            dict with valid_smiles, lipinski, veber, pains, sa_score, qed, pass
        """
        smiles = inputs["smiles"]
        canonical = validate_smiles(smiles)

        result = {
            "smiles": smiles,
            "canonical_smiles": canonical,
            "valid_smiles": canonical is not None,
        }

        if canonical is None:
            result["pass"] = False
            return result

        # Lipinski
        if self.check_lipinski_flag:
            lip = check_lipinski(canonical)
            result["lipinski"] = lip
            result["lipinski_pass"] = lip.get("pass", False)
        else:
            result["lipinski_pass"] = True

        # Veber
        if self.check_veber_flag:
            veb = check_veber(canonical)
            result["veber"] = veb
            result["veber_pass"] = veb.get("pass", False)
        else:
            result["veber_pass"] = True

        # PAINS
        if self.check_pains_flag:
            pains = check_pains(canonical)
            result["pains"] = pains
            result["pains_pass"] = not pains.get("has_pains", False)
        else:
            result["pains_pass"] = True

        # Brenk structural alerts
        if self.check_brenk_flag:
            brenk = check_brenk(canonical)
            result["brenk"] = brenk
            result["brenk_pass"] = not brenk.get("has_alerts", False)
        else:
            result["brenk_pass"] = True

        # SA Score
        if self.check_sa_flag:
            sa = compute_sa_score(canonical)
            result["sa_score"] = sa
            result["sa_pass"] = sa <= self.max_sa_score
        else:
            result["sa_pass"] = True

        # QED
        if self.check_qed_flag:
            qed = compute_qed(canonical)
            result["qed"] = qed
            result["qed_pass"] = qed >= self.min_qed
        else:
            result["qed_pass"] = True

        # Overall pass
        result["pass"] = (
            result["valid_smiles"]
            and result["lipinski_pass"]
            and result["veber_pass"]
            and result["pains_pass"]
            and result["brenk_pass"]
            and result["sa_pass"]
            and result["qed_pass"]
        )

        return result
