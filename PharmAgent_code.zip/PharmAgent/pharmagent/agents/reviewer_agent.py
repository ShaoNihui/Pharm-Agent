"""
Reviewer Agent — analyzes optimization results and provides strategic guidance.
"""

from pharmagent.agents.base_agent import BaseAgent
from pharmagent.llm.api_client import LLMClient
from pharmagent.llm.prompt_templates import (
    REVIEWER_SYSTEM_PROMPT,
    REVIEWER_TARGET_ONLY_SYSTEM_PROMPT,
    REVIEWER_TARGET_ONLY_USER_PROMPT,
    REVIEWER_USER_PROMPT,
    format_admet_constraints,
    format_admet_profile,
    format_candidates_with_scores,
    format_optimization_history,
)
from pharmagent.llm.output_parser import parse_reviewer_output
from pharmagent.optimization.near_feasible_archive import (
    format_near_feasible_context,
)
from pharmagent.optimization.formal_prompt_protocol import (
    format_formal_reviewer_feedback,
)


class ReviewerAgent(BaseAgent):
    """Uses an LLM to analyze results and provide optimization guidance."""

    def __init__(self, config: dict):
        super().__init__(config)
        self.llm = LLMClient(config["llm"], client_role="reviewer")
        self.max_stagnation_rounds = config.get("max_stagnation_rounds", 5)
        self.allow_early_termination = config.get(
            "allow_early_termination", True
        )

    def run(self, inputs: dict) -> dict:
        """Review optimization round results.

        Inputs:
            candidates: list[dict] — this round's candidates
            admet_results: list[dict] — ADMET evaluation results
            target_scores: list[float] — oracle scores
            optimization_history: list[dict] — recent memory entries
            round_number: int
            best_smiles: str
            best_target_score: float
            best_admet_score: float (constrained phases only)
            admet_profile: dict (constrained phases only)
            admet_profile_mode: "active_only" | "full" (defaults fail-closed
                to active_only for online prompts)
            target_only_phase: bool
            oracle_calls_used: int
            oracle_budget: int
            stagnation_count: int

        Returns:
            {"feedback": str, "should_continue": bool, "parsed": dict}
        """
        target_only_phase = inputs.get("target_only_phase", False)

        # Format data for prompt.  The target-only branch deliberately omits
        # all ADMET fields rather than rendering placeholders or inactive
        # values that could still bias the Reviewer.
        candidates_text = format_candidates_with_scores(
            inputs.get("candidates", []),
            inputs.get("target_scores", []),
            inputs.get("admet_results", []),
            include_admet=not target_only_phase,
            admet_constraints=inputs.get("admet_constraints", {}),
            structured_modifications_only=bool(
                inputs.get("formal_structured_reuse", False)
            ),
        )
        trajectory_text = format_optimization_history(
            inputs.get("optimization_history", []),
            include_admet=not target_only_phase,
        )

        stagnation_count = inputs.get("stagnation_count", 0)
        common_prompt_fields = {
            "round_number": inputs.get("round_number", 0),
            "best_smiles": inputs.get("best_smiles", "N/A"),
            "best_target_score": inputs.get("best_target_score", 0.0),
            "candidates_with_scores": candidates_text,
            "recent_trajectory": trajectory_text,
            "rounds_completed": inputs.get("round_number", 0),
            "oracle_calls_used": inputs.get("oracle_calls_used", 0),
            "oracle_budget": inputs.get("oracle_budget", 1000),
            "stagnation_count": stagnation_count,
            "early_termination_allowed": self.allow_early_termination,
        }
        if target_only_phase:
            prompt = REVIEWER_TARGET_ONLY_USER_PROMPT.format(
                **common_prompt_fields
            )
            system_prompt = REVIEWER_TARGET_ONLY_SYSTEM_PROMPT
        else:
            constraints_text = format_admet_constraints(
                inputs.get("admet_constraints", {})
            )
            profile_text = format_admet_profile(
                inputs.get("admet_profile", {}),
                mode=inputs.get("admet_profile_mode", "active_only"),
            )
            prompt = REVIEWER_USER_PROMPT.format(
                **common_prompt_fields,
                best_admet_score=inputs.get("best_admet_score", 0.0),
                admet_profile_formatted=profile_text,
                admet_constraints_formatted=constraints_text,
                constraint_priorities=inputs.get("constraint_priorities", ""),
            )
            if "near_feasible_anchors_injected" in inputs:
                prompt += format_near_feasible_context(
                    inputs.get("protected_incumbent", {}),
                    list(inputs.get("near_feasible_anchors_injected", [])),
                )
            system_prompt = REVIEWER_SYSTEM_PROMPT
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt},
        ]

        raw_response = self.llm.generate(
            messages,
            temperature=0.3,
            json_mode=True,
            request_id=inputs.get("native_request_id"),
        )
        parsed = parse_reviewer_output(raw_response)

        # Override should_continue based on stagnation detection
        if (
            self.allow_early_termination
            and stagnation_count >= self.max_stagnation_rounds
        ):
            parsed["should_continue"] = False
            parsed["termination_reason"] = (
                f"Stagnation detected: {stagnation_count} rounds without improvement."
            )
            self.log(
                f"Recommending termination due to stagnation "
                f"({stagnation_count} rounds)"
            )
        elif not self.allow_early_termination:
            parsed["should_continue"] = True
            parsed["termination_reason"] = None

        # Formal cross-round reuse is enum-only.  Native raw responses and the
        # complete parsed object remain available for audit, but no authored
        # analysis/suggestion prose becomes a later Generator prompt operand.
        if inputs.get("formal_structured_reuse", False):
            feedback = format_formal_reviewer_feedback(
                parsed, target_only=target_only_phase
            )
        else:
            suggestions = parsed.get("suggestions_for_next_round", [])
            feedback_parts = []
            if parsed.get("analysis"):
                feedback_parts.append(f"Analysis: {parsed['analysis']}")
            if suggestions:
                feedback_parts.append(
                    "Suggestions:\n"
                    + "\n".join(f"- {s}" for s in suggestions[:5])
                )
            if parsed.get("priority_focus"):
                feedback_parts.append(
                    f"Focus priority: {parsed['priority_focus']}"
                )
            feedback = (
                "\n".join(feedback_parts)
                if feedback_parts
                else "Continue optimization."
            )

        return {
            "feedback": feedback,
            "should_continue": parsed.get("should_continue", True),
            "parsed": parsed,
        }
