"""
ADMET Analyst Agent — evaluates ADMET properties using computational tools.

This agent does NOT use an LLM. It is purely tool-based for speed and cost.
The evaluation is organized into 5 ADMET categories:
  Absorption, Distribution, Metabolism, Excretion, Toxicity.
"""

import logging
import math

from pharmagent.agents.base_agent import BaseAgent
from pharmagent.tools.admet_predictor import ADMETPredictor
from pharmagent.tools.sa_scorer import compute_sa_score

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Mapping from prediction keys to ADMET categories
# ---------------------------------------------------------------------------
_ADMET_CATEGORY_MAP: dict[str, str] = {
    # Absorption
    "Caco2": "absorption", "Caco2_approx": "absorption",
    "HIA": "absorption", "HIA_approx": "absorption",
    "Pgp_substrate": "absorption", "Pgp_inhibition": "absorption",
    "bioavailability": "absorption", "solubility": "absorption",
    "caco2": "absorption",
    # Distribution
    "PPB": "distribution", "BBB": "distribution",
    "BBB_approx": "distribution", "VDss": "distribution",
    # Metabolism
    "CYP1A2_inh": "metabolism", "CYP2C9_inh": "metabolism",
    "CYP2C19_inh": "metabolism", "CYP2D6_inh": "metabolism",
    "CYP3A4_inh": "metabolism",
    "CYP2C9_substrate": "metabolism", "CYP2D6_substrate": "metabolism",
    "CYP3A4_substrate": "metabolism",
    "CYP2D6_inh_approx": "metabolism",
    # Excretion
    "clearance": "excretion", "clearance_microsome": "excretion",
    "half_life": "excretion",
    # Toxicity
    "hERG": "toxicity", "hERG_approx": "toxicity",
    "AMES": "toxicity", "hepatotox": "toxicity",
    "clinical_toxicity": "toxicity", "LD50": "toxicity",
    "PAINS": "toxicity",
    # Physicochemical / druglikeness (mapped to absorption)
    "MW": "absorption", "logP": "absorption",
    "HBD": "absorption", "HBA": "absorption",
    "TPSA": "absorption", "RotBonds": "absorption",
    "QED": "absorption", "SA_score": "absorption",
    "lipinski_mw": "absorption", "lipinski_logp": "absorption",
    "qed": "absorption", "sa_score": "absorption",
}

_ADMET_CATEGORIES = (
    "absorption",
    "distribution",
    "metabolism",
    "excretion",
    "toxicity",
)


# Approximate natural ranges for common drug properties, used to normalize
# sigmoid transition zones so that each constraint contributes comparably.
# Values represent rough standard deviations across drug-like chemical space.
_DEFAULT_PROPERTY_SCALES: dict[str, float] = {
    "lipinski_mw": 150.0,       # MW std ~150 in drug-like space
    "lipinski_logp": 2.0,       # logP std ~2
    "qed": 0.2,                 # QED std ~0.2
    "sa_score": 2.0,            # SA score std ~2
    "cyp2d6_inh": 0.3,          # probability scale
    "herg": 0.3,                # ADMET-AI blocker probability scale
    "caco2": 1.0,               # log scale
}


class ADMETAnalystAgent(BaseAgent):
    """Evaluates candidate molecules for ADMET compliance.

    Produces structured output organized by the five ADMET categories,
    with a sigmoid-weighted ADMET score for continuous optimization.
    """

    def __init__(self, config: dict):
        super().__init__(config)
        backend = config.get("backend", "rdkit_only")
        self.admet = ADMETPredictor(backend=backend, config=config)
        self.constraints = config.get("admet_constraints", {})
        self.missing_prediction_policy = config.get(
            "missing_prediction_policy", "neutral"
        )
        self.allow_approximate_endpoint_fallback = config.get(
            "allow_approximate_endpoint_fallback", True
        )
        if self.missing_prediction_policy not in {"neutral", "fail"}:
            raise ValueError(
                "admet.missing_prediction_policy must be 'neutral' or 'fail'"
            )

    def run(self, inputs: dict) -> dict:
        """Evaluate ADMET properties for a batch of SMILES.

        Inputs:
            smiles_list: list[str]

        Returns:
            {"admet_results": list[dict]}
            Each result has: smiles, descriptors, admet_predictions,
            admet_profile (structured by A/D/M/E/T categories),
            violations, admet_score, pass_all
        """
        smiles_list = inputs["smiles_list"]
        admet_preds = self.admet.predict_batch(smiles_list)
        results = []

        for smi, pred in zip(smiles_list, admet_preds):
            if pred.get("error"):
                results.append({
                    "smiles": smi,
                    "descriptors": {},
                    "admet_predictions": pred,
                    "admet_profile": {},
                    "constraint_assessments": self._assess_constraints(pred),
                    "violations": [{"name": "invalid_smiles", "value": None, "threshold": None}],
                    "admet_score": 0.0,
                    "pass_all": False,
                })
                continue

            # Get SA score
            sa = compute_sa_score(smi)

            # Merge SA score into predictions
            pred["SA_score"] = sa

            # Check constraints
            constraint_assessments = self._assess_constraints(pred)
            violations = self._check_constraints(pred)
            admet_score = self._compute_admet_score(pred)

            # Build structured ADMET profile by category
            admet_profile = self._build_admet_profile(pred, violations)

            results.append({
                "smiles": smi,
                "descriptors": {
                    k: pred.get(k) for k in
                    ["MW", "logP", "HBD", "HBA", "TPSA", "RotBonds", "QED"]
                    if pred.get(k) is not None
                },
                "admet_predictions": pred,
                "admet_profile": admet_profile,
                "constraint_assessments": constraint_assessments,
                "violations": violations,
                "admet_score": admet_score,
                "pass_all": len(violations) == 0,
            })

        return {"admet_results": results}

    def _assess_constraints(
        self,
        pred: dict,
        constraints: dict | None = None,
    ) -> list[dict]:
        """Return a factual assessment for every requested hard constraint.

        ``None`` selects the analyst's full configured constraint set; an
        explicit mapping selects the active curriculum set.  The signed margin
        is expressed in the endpoint's native units and is positive when the
        constraint is satisfied::

            max constraint: threshold - value
            min constraint: value - threshold

        For an observed endpoint, ``normalized_violation`` is exactly
        ``max(0, -signed_margin / scale)``.  Missing/non-finite predictions are
        fail-closed (``pass=False`` and ``missing=True``) without inventing a
        numeric margin or violation magnitude.
        """
        selected_constraints = self.constraints if constraints is None else constraints
        assessments = []

        for constraint_name, constraint_def in selected_constraints.items():
            threshold = constraint_def.get("threshold")
            if threshold is None:
                continue

            ctype = constraint_def.get("type", "max")
            if ctype not in {"max", "min"}:
                raise ValueError(
                    f"Constraint type must be 'max' or 'min': {constraint_name}"
                )
            direction = "<=" if ctype == "max" else ">="
            scale = self._constraint_scale(
                constraint_name,
                constraint_def,
                threshold,
            )
            value = self._get_prediction_value(pred, constraint_name)
            if isinstance(value, bool):
                value = 1.0 if value else 0.0

            missing = value is None
            if missing:
                signed_margin = None
                normalized_violation = None
                passed = False
            else:
                signed_margin = (
                    threshold - value
                    if ctype == "max"
                    else value - threshold
                )
                normalized_violation = max(0.0, -signed_margin) / scale
                passed = signed_margin >= 0.0

            assessments.append({
                "name": constraint_name,
                "value": value,
                "threshold": threshold,
                "type": ctype,
                "direction": direction,
                "scale": scale,
                "signed_margin": signed_margin,
                "normalized_violation": normalized_violation,
                "pass": passed,
                "missing": missing,
            })

        return assessments

    @staticmethod
    def _constraint_scale(
        constraint_name: str,
        constraint_def: dict,
        threshold,
    ) -> float:
        """Resolve and validate the normalization scale for one constraint."""
        scale = constraint_def.get("scale")
        if scale is None:
            scale = _DEFAULT_PROPERTY_SCALES.get(
                constraint_name,
                abs(threshold) if abs(threshold) > 1e-6 else 1.0,
            )
        try:
            numeric_scale = float(scale)
        except (TypeError, ValueError, OverflowError) as error:
            raise ValueError(
                f"Constraint scale must be a positive finite number: "
                f"{constraint_name}"
            ) from error
        if not math.isfinite(numeric_scale) or numeric_scale <= 0:
            raise ValueError(
                f"Constraint scale must be a positive finite number: "
                f"{constraint_name}"
            )
        return numeric_scale

    def _check_constraints(
        self,
        pred: dict,
        constraints: dict | None = None,
    ) -> list[dict]:
        """Check the requested ADMET constraints against predictions.

        ``None`` means the analyst's full configured set.  Passing ``{}`` is
        intentional and represents a curriculum phase with no active ADMET
        constraints.
        """
        violations = []
        selected_constraints = self.constraints if constraints is None else constraints

        for assessment in self._assess_constraints(pred, selected_constraints):
            if assessment["missing"]:
                if self.missing_prediction_policy == "fail":
                    violations.append({
                        "name": assessment["name"],
                        "value": None,
                        "threshold": assessment["threshold"],
                        "type": assessment["type"],
                        "reason": "missing_prediction",
                    })
                continue

            if not assessment["pass"]:
                violations.append({
                    "name": assessment["name"],
                    "value": assessment["value"],
                    "threshold": assessment["threshold"],
                    "type": assessment["type"],
                })

        return violations

    # Shared alias table: constraint config names → prediction dict keys.
    # Used by _get_prediction_value, _resolve_alias, and _build_admet_profile.
    _CONSTRAINT_ALIASES: dict[str, str] = {
        "lipinski_mw": "MW",
        "lipinski_logp": "logP",
        "qed": "QED",
        "sa_score": "SA_score",
        "cyp2d6_inh": "CYP2D6_inh",
        "cyp2d6_inh_approx": "CYP2D6_inh_approx",
        "herg": "hERG",
        "herg_approx": "hERG_approx",
        "caco2": "Caco2",
        "caco2_approx": "Caco2_approx",
        "pains": "PAINS",
    }

    def _get_prediction_value(self, pred: dict, constraint_name: str):
        """Map constraint name to the corresponding prediction value.

        Resolution order:
          1. Direct key match in pred
          2. Alias lookup → check aliased key in pred
          3. Aliased key + "_approx" suffix in pred  (e.g. hERG → hERG_approx)
          4. constraint_name + "_approx" → alias lookup  (e.g. caco2_approx → Caco2_approx)
        """
        # 1. Direct match
        if constraint_name in pred:
            return self._finite_constraint_value(pred[constraint_name])

        # 2. Alias lookup
        mapped = self._CONSTRAINT_ALIASES.get(constraint_name)
        if mapped and mapped in pred:
            return self._finite_constraint_value(pred[mapped])

        if not getattr(self, "allow_approximate_endpoint_fallback", True):
            return None

        # 3. Aliased key + "_approx" (e.g. "herg" → alias "hERG" → try "hERG_approx")
        if mapped:
            mapped_approx = f"{mapped}_approx"
            if mapped_approx in pred:
                return self._finite_constraint_value(pred[mapped_approx])

        # 4. Raw approx key → alias (e.g. "caco2_approx" → alias "Caco2_approx")
        approx_key = f"{constraint_name}_approx"
        if approx_key in pred:
            return self._finite_constraint_value(pred[approx_key])
        approx_mapped = self._CONSTRAINT_ALIASES.get(approx_key)
        if approx_mapped and approx_mapped in pred:
            return self._finite_constraint_value(pred[approx_mapped])

        return None

    @staticmethod
    def _finite_constraint_value(value):
        """Return a comparable finite value, otherwise mark it as missing."""
        if value is None or isinstance(value, bool):
            return value
        try:
            numeric = float(value)
        except (TypeError, ValueError, OverflowError):
            return None
        return numeric if math.isfinite(numeric) else None

    def _compute_admet_score(
        self,
        pred: dict,
        constraints: dict | None = None,
    ) -> float:
        """Compute sigmoid-weighted ADMET compliance score.

        Uses the formula from the research proposal:
            ADMET_score = (1/N) * sum_i [ w_i * sigmoid(threshold_i - predicted_i) ]
        where sigmoid is applied so that values well within the threshold
        score close to 1.0 and values far beyond score close to 0.0.

        For "min" type constraints the sign is flipped:
            sigmoid(predicted_i - threshold_i)

        Falls back to 1.0 when no constraints are configured.
        """
        selected_constraints = self.constraints if constraints is None else constraints
        if not selected_constraints:
            return 1.0

        total_weight = 0.0
        weighted_sum = 0.0

        for constraint_name, constraint_def in selected_constraints.items():
            ctype = constraint_def.get("type", "max")
            threshold = constraint_def.get("threshold")
            weight = constraint_def.get("weight", 1.0)
            if threshold is None:
                continue

            value = self._get_prediction_value(pred, constraint_name)
            if value is None:
                # Formal ADMET runs fail closed.  Non-formal configurations can
                # use the neutral score explicitly.
                logger.debug(
                    "No prediction for constraint '%s', policy=%s",
                    constraint_name,
                    self.missing_prediction_policy,
                )
                if self.missing_prediction_policy == "neutral":
                    weighted_sum += weight * 0.5
                total_weight += weight
                continue

            if isinstance(value, bool):
                value = 1.0 if value else 0.0

            # Steepness factor controls how sharply the sigmoid transitions.
            # Per-constraint steepness can be set in YAML; otherwise use default.
            steepness = constraint_def.get("steepness", 5.0)

            # Normalize by the property's natural range so that the sigmoid
            # transition zone is comparable across properties with very different
            # scales (e.g. MW~500 vs QED~0.3).  A per-constraint "scale" in YAML
            # overrides the automatic estimate.
            scale = self._constraint_scale(
                constraint_name,
                constraint_def,
                threshold,
            )

            if ctype == "max":
                # Good when value < threshold
                z = steepness * (threshold - value) / scale
            else:
                # "min": good when value > threshold
                z = steepness * (value - threshold) / scale

            # Clamp to avoid overflow in math.exp
            z = max(-500.0, min(500.0, z))
            score_i = 1.0 / (1.0 + math.exp(-z))
            weighted_sum += weight * score_i
            total_weight += weight

        if total_weight <= 0:
            return 1.0
        return weighted_sum / total_weight

    def _build_admet_profile(
        self,
        pred: dict,
        violations: list[dict],
        active_constraints: dict | None = None,
        *,
        mask_inactive: bool = False,
    ) -> dict:
        """Organize predictions into the 5 ADMET categories.

        A category with at least one active threshold is ``PASS``/``FAIL``.
        A category with configured thresholds that are not active in the
        current curriculum phase is ``INACTIVE``.  A category with no hard
        threshold is ``MONITORED`` and has ``pass=None``; monitoring must never
        be misreported as satisfying a constraint.

        ``active_constraints=None`` means the full configured set is active.
        When ``mask_inactive`` is true, prediction values are retained only for
        active constraint endpoints, preventing future curriculum constraints
        or monitored endpoints from leaking into agent prompts.
        """
        profile: dict[str, dict] = {name: {} for name in _ADMET_CATEGORIES}
        configured_constraints = {
            name: definition
            for name, definition in self.constraints.items()
            if definition.get("threshold") is not None
        }
        active = (
            configured_constraints
            if active_constraints is None
            else {
                name: configured_constraints[name]
                for name in active_constraints
                if name in configured_constraints
            }
        )

        allowed_prediction_keys: set[str] | None = None
        if mask_inactive:
            allowed_prediction_keys = set()
            for name in active:
                allowed_prediction_keys.add(name)
                alias = self._resolve_alias(name)
                allowed_prediction_keys.add(alias)
                if getattr(self, "allow_approximate_endpoint_fallback", True):
                    allowed_prediction_keys.add(f"{name}_approx")
                    allowed_prediction_keys.add(f"{alias}_approx")

        # Populate each category with available predictions
        for key, value in pred.items():
            if key in ("smiles", "error", "lipinski_violations"):
                continue
            if (
                allowed_prediction_keys is not None
                and key not in allowed_prediction_keys
            ):
                continue
            category = _ADMET_CATEGORY_MAP.get(key)
            if category:
                profile[category][key] = value

        # Determine truthful per-category status under the active curriculum.
        violation_names = {v["name"] for v in violations}
        for category in profile:
            configured_names = [
                name
                for name in configured_constraints
                if self._constraint_category(name) == category
            ]
            active_names = [name for name in configured_names if name in active]
            inactive_names = [
                name for name in configured_names if name not in active
            ]
            cat_violations = [
                name for name in active_names if name in violation_names
            ]

            if active_names:
                passed = not cat_violations
                status = "PASS" if passed else "FAIL"
            elif inactive_names:
                passed = None
                status = "INACTIVE"
            else:
                passed = None
                status = "MONITORED"

            profile[category].update({
                "status": status,
                "pass": passed,
                "active_constraints": active_names,
                "inactive_constraints": inactive_names,
            })

        return profile

    def _constraint_category(self, constraint_name: str) -> str | None:
        """Map a configured constraint to one of the five ADMET categories."""
        return _ADMET_CATEGORY_MAP.get(
            constraint_name,
            _ADMET_CATEGORY_MAP.get(self._resolve_alias(constraint_name)),
        )

    def _resolve_alias(self, constraint_name: str) -> str:
        """Resolve a constraint name through the shared alias table."""
        return self._CONSTRAINT_ALIASES.get(constraint_name, constraint_name)
