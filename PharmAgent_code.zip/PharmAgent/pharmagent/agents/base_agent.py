"""
Base class for all PharmAgent agents.
"""

import logging
from abc import ABC, abstractmethod
from typing import Any


class BaseAgent(ABC):
    """Abstract base agent with logging and config management."""

    def __init__(self, config: dict):
        self.config = config
        self.name = self.__class__.__name__
        self.logger = logging.getLogger(f"pharmagent.{self.name}")

    @abstractmethod
    def run(self, inputs: dict[str, Any]) -> dict[str, Any]:
        """Execute agent logic, returning structured output."""
        ...

    def log(self, message: str, level: str = "INFO"):
        """Log a message at the specified level."""
        getattr(self.logger, level.lower(), self.logger.info)(message)
