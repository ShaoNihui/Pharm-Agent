"""
PharmAgent Orchestrator — main optimization loop wiring all agents, RAG, and memory.
"""

import hashlib
import logging
import math
import random
import time
from copy import deepcopy
from typing import Any

import numpy as np

from pharmagent.agents.generator_agent import GeneratorAgent
from pharmagent.agents.admet_analyst import ADMETAnalystAgent
from pharmagent.agents.verifier_agent import VerifierAgent
from pharmagent.agents.reviewer_agent import ReviewerAgent
from pharmagent.llm.api_client import (
    LLMAttemptAccountingError,
    LLMTransportRecoveryExhaustedError,
)
from pharmagent.evaluation.native_run import NativeRunJournal
from pharmagent.rag.retriever import MMPRetriever
from pharmagent.optimization.memory_buffer import OptimizationMemory
from pharmagent.optimization.experience_replay import ExperienceDBError
from pharmagent.optimization.novelty_recovery import (
    NOVELTY_AUDIT_SCHEMA_VERSION,
    NoveltyRecoveryProtocolError,
    canonical_novelty_recovery_protocol,
    formal_repair_reason_lines,
    replay_novelty_recovery_lineage,
    validate_novelty_recovery_config,
)
from pharmagent.optimization.near_feasible_archive import (
    CANONICAL_FULL_ADMET_CONSTRAINTS,
    NEAR_FEASIBLE_AUDIT_SCHEMA_VERSION,
    NearFeasibleRepairProtocolError,
    advance_near_feasible_archive,
    canonical_near_feasible_repair_protocol,
    normalize_constraint_assessments,
    validate_near_feasible_repair_result,
    validate_near_feasible_state,
)
from pharmagent.optimization.curriculum_protocol import (
    validate_curriculum_lagrangian_evidence,
)
from pharmagent.optimization.scoring import compute_combined_score
from pharmagent.optimization.run_state_protocol import (
    PublicRunStateError,
    replay_native_loop_state,
    validate_native_loop_state_against_replay,
)
from pharmagent.optimization.formal_prompt_protocol import (
    FORMAL_REVIEWER_DISABLED_FEEDBACK,
    FORMAL_ROUND_ERROR_FEEDBACK,
    FormalPromptProtocolError,
    canonical_formal_prompt_reuse_protocol,
    canonicalize_formal_candidates,
    format_formal_zero_candidate_feedback,
    validate_formal_prompt_reuse_state,
)
from pharmagent.tools.rdkit_tools import compute_tanimoto, validate_smiles

logger = logging.getLogger(__name__)

NATIVE_OPTIMIZER_STATE_SCHEMA_VERSION = 6


class FormalRunFatalError(RuntimeError):
    """A formal protocol/infrastructure failure that cannot be retried by round."""


class PharmAgentOrchestrator:
    """Coordinates all agents in the ADMET-aware molecular optimization loop."""

    def __init__(self, config: dict, *, admet_predictor=None):
        # LLM config resolution is handled by load_config(); re-apply here
        # in case the orchestrator is constructed with a raw dict.
        llm_config = config.get("llm", {})
        for agent_key in ("generator", "reviewer"):
            if agent_key in config and "llm" not in config[agent_key]:
                config[agent_key]["llm"] = llm_config
        self.config = config
        self.native_run_journal: NativeRunJournal | None = None
        native_spec = config.get("native_run_journal")
        if native_spec is not None:
            if not isinstance(native_spec, dict):
                raise ValueError("native_run_journal must be a mapping")
            try:
                self.native_run_journal = NativeRunJournal(
                    native_spec["path"], identity=native_spec["identity"]
                )
            except KeyError as error:
                raise ValueError(
                    f"native_run_journal is missing {error.args[0]!r}"
                ) from None

        # Initialize agents
        self.generator = GeneratorAgent(config.get("generator", {"llm": config.get("llm", {})}))
        self.admet_analyst = ADMETAnalystAgent(config.get("admet", {}))
        if admet_predictor is not None:
            # The ADMET-PMO runner's recording oracle and this analyst must use
            # one model instance/cache so a scored candidate is not inferred
            # twice under subtly different runtime configuration.
            self.admet_analyst.admet = admet_predictor
        self.verifier = VerifierAgent(config.get("verifier", {}))
        self.reviewer = ReviewerAgent(config.get("reviewer", {"llm": config.get("llm", {})}))

        reviewer_config = config.get("reviewer", {})
        optimization_config = config.get("optimization", {})
        self.allow_reviewer_termination = reviewer_config.get(
            "allow_early_termination", True
        )
        self.require_full_budget = optimization_config.get(
            "require_full_budget", False
        )
        if self.require_full_budget and self.allow_reviewer_termination:
            raise ValueError(
                "optimization.require_full_budget=true requires "
                "reviewer.allow_early_termination=false"
            )
        self.novelty_recovery_protocol = validate_novelty_recovery_config(
            config.get("novelty_recovery"),
            require_canonical=self.require_full_budget,
            generator_candidate_cap=self.generator.n_candidates,
        )
        self.novelty_recovery_enabled = (
            self.novelty_recovery_protocol is not None
        )
        self._global_seen_canonical: set[str] = set()
        self._global_seen_initialized = False
        self._pending_same_round_trace: list[dict[str, Any]] = []
        self._pending_same_round_consumed = 0

        # RAG retriever (gracefully degrades if not configured)
        self.rag = MMPRetriever(config.get("rag", {}))

        # Lagrangian constraint optimizer
        lagrangian_config = dict(config.get("lagrangian", {}))
        admet_config = config.get("admet", {})
        lagrangian_config.setdefault(
            "allow_approximate_endpoint_fallback",
            admet_config.get("allow_approximate_endpoint_fallback", True),
        )
        lagrangian_config.setdefault(
            "missing_prediction_violation",
            1.0
            if admet_config.get("missing_prediction_policy") == "fail"
            else 0.5,
        )
        self.use_lagrangian = lagrangian_config.get("enabled", False)
        self.lagrangian = None
        if self.use_lagrangian:
            from pharmagent.optimization.lagrangian import LagrangianOptimizer
            self.lagrangian = LagrangianOptimizer(
                admet_config.get("admet_constraints", {}),
                lagrangian_config,
            )

        # Contextual Experience Replay
        cer_config = config.get("cer", {})
        self.experience_db = None
        if cer_config.get("enabled", False):
            from pharmagent.optimization.experience_replay import ExperienceDB
            self.experience_db = ExperienceDB(cer_config)

        # Curriculum constraint scheduler
        curriculum_config = config.get("curriculum", {})
        self.curriculum = None
        if curriculum_config.get("enabled", False):
            from pharmagent.optimization.curriculum import ConstraintScheduler
            self.curriculum = ConstraintScheduler(
                config.get("admet", {}).get("admet_constraints", {}),
                curriculum_config,
            )

        # Optimization memory (with optional CER backing)
        self.memory = OptimizationMemory(
            max_size=optimization_config.get("memory_size", 100),
            experience_db=self.experience_db,
            structured_modifications_only=self.require_full_budget,
        )

        # Scoring weights (fallback when Lagrangian is disabled)
        self.alpha = optimization_config.get("alpha", 0.7)
        self.objective = optimization_config.get(
            "objective", "admet_constrained"
        )
        if self.objective not in {"target_only", "admet_constrained"}:
            raise ValueError(
                "optimization.objective must be 'target_only' or "
                f"'admet_constrained', got {self.objective!r}"
            )

    def optimize(self, seed_smiles: str, oracle: Any,
                 target_property: str, max_rounds: int = 200,
                 oracle_budget: int = 1000) -> dict:
        """Run the full optimization loop.

        Args:
            seed_smiles: Starting molecule SMILES.
            oracle: Scoring function. Can be called as oracle(smiles) -> float
                    or oracle([smi1, smi2, ...]) -> list[float].
                    May have .finish attribute for budget checking.
            target_property: Name of the target property (e.g., "GSK3B").
            max_rounds: Maximum number of optimization rounds.
            oracle_budget: Maximum oracle calls budget.

        Returns:
            dict with: best_smiles, best_combined_score, total_oracle_calls,
                       trajectory, memory
        """
        if (
            getattr(self, "require_full_budget", False)
            and max_rounds < oracle_budget
        ):
            raise ValueError(
                "A full-budget run requires max_rounds >= oracle_budget so "
                "there is capacity for at least one new canonical molecule "
                "per round. Increase optimization.max_rounds."
            )

        current_smiles = seed_smiles
        best_smiles = seed_smiles
        best_target_score = 0.0
        best_admet_score = 0.0
        best_combined = 0.0
        reviewer_feedback = None
        stagnation_count = 0
        novelty_enabled = bool(
            getattr(self, "novelty_recovery_enabled", False)
        )
        zero_novel_rounds = 0
        pending_generation_restart: str | None = None
        generation_restart_cursor = 0
        failure_count = 0
        round_error_count = 0
        round_failure_history: list[dict[str, Any]] = []
        consecutive_round_errors = 0
        successful_scored_rounds = 0
        cer_experiences_committed = 0
        best_feasible = None
        near_feasible_anchors = []
        termination_reason = "max_rounds_reached"
        trajectory = []
        start_round = 0
        restored_stage = None

        # Align with oracle's own call count (seed selection may have used some budget)
        total_oracle_calls = getattr(oracle, "call_count", 0)

        native_journal = getattr(self, "native_run_journal", None)
        native_state = (
            native_journal.load_optimizer_state()
            if native_journal is not None
            else None
        )
        if native_state is None:
            # Score seed molecule.  It is normally already present from fixed
            # seed-pool selection, so this replay spends no new oracle call.
            self._set_oracle_context(
                oracle, {"scope": "selected_seed", "round": -1}
            )
            seed_score = self._call_oracle(oracle, seed_smiles)
            total_oracle_calls = self._oracle_call_count_after_call(
                oracle, total_oracle_calls
            )
            best_target_score = seed_score
            best_combined = seed_score
            if self.objective == "target_only":
                best_admet_score = 1.0

            # Seed the run-global molecular identity set from every canonical
            # PMO call already spent during seed selection.
            if novelty_enabled:
                self._initialize_global_seen_canonical(oracle, seed_smiles)
        else:
            restored = self._restore_native_optimizer_state(
                native_state,
                seed_smiles=seed_smiles,
                target_property=target_property,
                max_rounds=max_rounds,
                oracle_budget=oracle_budget,
            )
            current_smiles = restored["current_smiles"]
            best_smiles = restored["best_smiles"]
            best_target_score = restored["best_target_score"]
            best_admet_score = restored["best_admet_score"]
            best_combined = restored["best_combined"]
            reviewer_feedback = restored["reviewer_feedback"]
            stagnation_count = restored["stagnation_count"]
            zero_novel_rounds = restored["zero_novel_rounds"]
            pending_generation_restart = restored[
                "pending_generation_restart"
            ]
            generation_restart_cursor = restored[
                "generation_restart_cursor"
            ]
            failure_count = restored["failure_count"]
            round_error_count = restored["round_error_count"]
            round_failure_history = restored["round_failure_history"]
            consecutive_round_errors = restored[
                "consecutive_round_errors"
            ]
            successful_scored_rounds = restored[
                "successful_scored_rounds"
            ]
            cer_experiences_committed = restored[
                "cer_experiences_committed"
            ]
            best_feasible = restored["best_feasible"]
            near_feasible_anchors = restored["near_feasible_anchors"]
            termination_reason = restored["termination_reason"]
            trajectory = restored["trajectory"]
            start_round = restored["next_round"]
            restored_stage = restored["stage"]

        logger.info(
            "Starting optimization: seed=%s, target=%s, budget=%d",
            seed_smiles, target_property, oracle_budget
        )

        for round_idx in range(start_round, max_rounds):
            total_oracle_calls = self._current_oracle_call_count(
                oracle, total_oracle_calls
            )
            replaying_pending_round = bool(
                round_idx == start_round
                and restored_stage == "round_pending"
                and getattr(self, "_pending_same_round_trace", [])
            )
            # Budget check
            if (
                self._is_budget_exhausted(
                    oracle, total_oracle_calls, oracle_budget
                )
                and not replaying_pending_round
            ):
                logger.info("Oracle budget exhausted at round %d", round_idx)
                termination_reason = "oracle_budget_exhausted"
                break

            round_oracle_calls_before = total_oracle_calls
            round_start = time.time()
            if not replaying_pending_round:
                self._save_native_optimizer_state(
                    stage="round_pending",
                    next_round=round_idx,
                    seed_smiles=seed_smiles,
                    target_property=target_property,
                    max_rounds=max_rounds,
                    oracle_budget=oracle_budget,
                    loop_values=locals(),
                )
            round_state = self._snapshot_round_mutable_state()
            restart_applied_this_round = pending_generation_restart
            round_source_smiles = current_smiles
            try:
                round_result = self._run_round(
                    round_idx=round_idx,
                    current_smiles=current_smiles,
                    target_property=target_property,
                    oracle=oracle,
                    reviewer_feedback=reviewer_feedback,
                    best_target_score=best_target_score,
                    best_admet_score=best_admet_score,
                    oracle_budget=oracle_budget,
                    total_oracle_calls=total_oracle_calls,
                    stagnation_count=stagnation_count,
                    generation_restart_strategy=(
                        restart_applied_this_round
                    ),
                    best_feasible=best_feasible,
                    near_feasible_anchors=near_feasible_anchors,
                )
            except LLMAttemptAccountingError as e:
                self._restore_round_mutable_state(round_state)
                raise FormalRunFatalError(
                    "formal LLM HTTP-attempt accounting failed"
                ) from e
            except LLMTransportRecoveryExhaustedError as e:
                self._restore_round_mutable_state(round_state)
                raise FormalRunFatalError(
                    "formal LLM transport recovery exhausted before a "
                    "complete round; no scientific round was recorded"
                ) from e
            except FormalRunFatalError:
                self._restore_round_mutable_state(round_state)
                raise
            except Exception as e:
                # Oracle calls are external budget events and deliberately
                # remain recorded.  Internal optimization state is committed
                # only when the whole round, including Reviewer, succeeds.
                self._restore_round_mutable_state(round_state)
                if novelty_enabled:
                    # Oracle budget events are irreversible.  Retain exactly
                    # the canonical identities that reached a durable score;
                    # verified candidates that never reached the oracle were
                    # restored away with the round snapshot above.
                    self._reconcile_global_seen_from_oracle_trace(oracle)
                    self._clear_pending_same_round_trace()
                total_oracle_calls = self._current_oracle_call_count(
                    oracle, total_oracle_calls
                )
                round_failure_history.append(
                    self._build_round_failure_event(
                        round_idx=round_idx,
                        error=e,
                        oracle=oracle,
                        trajectory=trajectory,
                        round_failure_history=round_failure_history,
                        fallback_oracle_calls_before=(
                            round_oracle_calls_before
                        ),
                        fallback_oracle_calls_after=total_oracle_calls,
                    )
                )
                # A curriculum transition may have completed before a later
                # agent/API step failed.  Do not carry the previous phase's
                # stagnation evidence into the newly active objective.
                transition = (
                    getattr(self.curriculum, "last_transition", None)
                    if self.curriculum
                    else None
                )
                if transition and transition.get("round") == round_idx:
                    stagnation_count = 0
                round_error_count = len(round_failure_history)
                consecutive_round_errors += 1
                logger.error("Round %d failed with error: %s", round_idx, e)
                if consecutive_round_errors >= 3:
                    termination_reason = "round_error_limit"
                    logger.error(
                        "Stopping after %d consecutive round errors",
                        consecutive_round_errors,
                    )
                    self._save_native_optimizer_state(
                        stage="ready",
                        next_round=round_idx + 1,
                        seed_smiles=seed_smiles,
                        target_property=target_property,
                        max_rounds=max_rounds,
                        oracle_budget=oracle_budget,
                        loop_values=locals(),
                    )
                    break
                reviewer_feedback = FORMAL_ROUND_ERROR_FEEDBACK
                self._save_native_optimizer_state(
                    stage="ready",
                    next_round=round_idx + 1,
                    seed_smiles=seed_smiles,
                    target_property=target_property,
                    max_rounds=max_rounds,
                    oracle_budget=oracle_budget,
                    loop_values=locals(),
                )
                continue

            # Unpack round results
            consecutive_round_errors = 0
            if novelty_enabled:
                self._commit_pending_same_round_trace(round_idx)
                novelty_audit = round_result.get("novelty_audit")
                if not isinstance(novelty_audit, dict):
                    raise FormalRunFatalError(
                        "canonical novelty recovery produced no round audit"
                    )
                # A scheduled restart is consumed only after a completed
                # round. A failed round retries the same generation context.
                if restart_applied_this_round is not None:
                    pending_generation_restart = None
                if novelty_audit["globally_novel_count"] > 0:
                    zero_novel_rounds = 0
                else:
                    zero_novel_rounds += 1
                restart_threshold = int(
                    self.novelty_recovery_protocol[
                        "zero_novel_restart_threshold"
                    ]
                )
                restart_scheduled = None
                if zero_novel_rounds == restart_threshold:
                    strategies = self.novelty_recovery_protocol[
                        "restart_strategies"
                    ]
                    restart_scheduled = strategies[
                        generation_restart_cursor % len(strategies)
                    ]
                    generation_restart_cursor += 1
                    pending_generation_restart = restart_scheduled
                    # The restart begins a fresh recovery window; the audit
                    # retains the triggering streak of exactly five.
                    next_zero_novel_rounds = 0
                else:
                    next_zero_novel_rounds = zero_novel_rounds
                novelty_audit["restart_scheduled"] = restart_scheduled
                novelty_audit["zero_novel_round_streak"] = (
                    zero_novel_rounds
                )
                zero_novel_rounds = next_zero_novel_rounds
            total_oracle_calls = round_result["total_oracle_calls"]
            if "near_feasible_audit" in round_result:
                best_feasible = deepcopy(round_result["best_feasible"])
                near_feasible_anchors = deepcopy(
                    round_result["near_feasible_anchors"]
                )
            if round_result.get("cer_experience_committed", False):
                cer_experiences_committed += 1
            curriculum_transition = round_result.get(
                "curriculum_transition"
            )
            if curriculum_transition:
                # The current round was already scored under the new active
                # objective.  Its outcome below is the first phase-local
                # stagnation observation; older-phase evidence is discarded.
                stagnation_count = 0

            if not round_result["scored_candidates"]:
                # The objective changes with curriculum phase, lambdas, and
                # rho.  Always carry the incumbent's score under the current
                # round objective rather than a stale earlier-phase value.
                best_combined = round_result.get(
                    "source_combined_score", best_combined
                )
                best_admet_score = round_result.get(
                    "source_admet_score", best_admet_score
                )
                failure_count += 1
                reviewer_feedback = format_formal_zero_candidate_feedback(
                    failure_count
                )
                stagnation_count += 1
                trajectory.append({
                    "round": round_idx,
                    "best_score": best_target_score,
                    "best_combined": best_combined,
                    "oracle_calls": total_oracle_calls,
                    "n_candidates": 0,
                    "n_admet_pass": 0,
                    "source_combined_score": round_result.get(
                        "source_combined_score", best_combined
                    ),
                    "candidate_improves": False,
                    "source_smiles": round_result.get(
                        "source_smiles", round_source_smiles
                    ),
                    "source_oracle_call_index": round_result.get(
                        "source_oracle_call_index"
                    ),
                    "source_oracle_record_sha256": round_result.get(
                        "source_oracle_record_sha256"
                    ),
                    "accepted_smiles": round_result.get(
                        "accepted_smiles", round_source_smiles
                    ),
                    "accepted_oracle_call_index": round_result.get(
                        "accepted_oracle_call_index"
                    ),
                    "accepted_oracle_record_sha256": round_result.get(
                        "accepted_oracle_record_sha256"
                    ),
                    "generator_proposed_count": round_result.get(
                        "generator_proposed_count", 0
                    ),
                    "generator_truncated_count": round_result.get(
                        "generator_truncated_count", 0
                    ),
                    "cer_experience_committed": False,
                    "active_constraints": round_result.get(
                        "active_constraints", []
                    ),
                    "curriculum_transition": curriculum_transition,
                    **(
                        {"novelty_audit": round_result["novelty_audit"]}
                        if novelty_enabled else {}
                    ),
                    **(
                        {
                            "near_feasible_audit": round_result[
                                "near_feasible_audit"
                            ]
                        }
                        if "near_feasible_audit" in round_result else {}
                    ),
                    "time": time.time() - round_start,
                })
                self._save_native_optimizer_state(
                    stage="ready",
                    next_round=round_idx + 1,
                    seed_smiles=seed_smiles,
                    target_property=target_property,
                    max_rounds=max_rounds,
                    oracle_budget=oracle_budget,
                    loop_values=locals(),
                )
                continue

            # Update best
            round_best = round_result["round_best"]
            successful_scored_rounds += 1
            failure_count = 0  # reset on any successful scoring round
            source_combined = round_result["source_combined_score"]
            if round_best["combined_score"] > source_combined:
                best_combined = round_best["combined_score"]
                best_smiles = round_best["smiles"]
                best_target_score = round_best["target_score"]
                best_admet_score = round_best["admet_score"]
                current_smiles = round_best["smiles"]
                stagnation_count = 0
            else:
                best_combined = source_combined
                best_admet_score = round_result["source_admet_score"]
                stagnation_count += 1

            # Reviewer feedback
            reviewer_feedback = round_result.get("reviewer_feedback")
            should_continue = round_result.get("should_continue", True)

            trajectory.append({
                "round": round_idx,
                "best_score": best_target_score,
                "best_combined": best_combined,
                "oracle_calls": total_oracle_calls,
                "n_candidates": len(round_result["scored_candidates"]),
                "n_admet_pass": round_result["n_admet_pass"],
                "source_combined_score": source_combined,
                "candidate_improves": round_result.get(
                    "candidate_improves", False
                ),
                "source_smiles": round_result.get(
                    "source_smiles", round_source_smiles
                ),
                "source_oracle_call_index": round_result.get(
                    "source_oracle_call_index"
                ),
                "source_oracle_record_sha256": round_result.get(
                    "source_oracle_record_sha256"
                ),
                "accepted_smiles": round_result.get(
                    "accepted_smiles", current_smiles
                ),
                "accepted_oracle_call_index": round_result.get(
                    "accepted_oracle_call_index"
                ),
                "accepted_oracle_record_sha256": round_result.get(
                    "accepted_oracle_record_sha256"
                ),
                "generator_proposed_count": round_result.get(
                    "generator_proposed_count",
                    len(round_result["scored_candidates"]),
                ),
                "generator_truncated_count": round_result.get(
                    "generator_truncated_count", 0
                ),
                "cer_experience_committed": round_result.get(
                    "cer_experience_committed", False
                ),
                "active_constraints": round_result.get(
                    "active_constraints", []
                ),
                "curriculum_transition": curriculum_transition,
                **(
                    {"novelty_audit": round_result["novelty_audit"]}
                    if novelty_enabled else {}
                ),
                **(
                    {
                        "near_feasible_audit": round_result[
                            "near_feasible_audit"
                        ]
                    }
                    if "near_feasible_audit" in round_result else {}
                ),
                "time": time.time() - round_start,
            })

            logger.info(
                "Round %d: best_target=%.4f, best_admet=%.3f, "
                "best_combined=%.4f, oracle_calls=%d, stagnation=%d",
                round_idx, best_target_score, best_admet_score,
                best_combined, total_oracle_calls, stagnation_count
            )

            if not should_continue and getattr(
                self, "allow_reviewer_termination", True
            ):
                logger.info("Reviewer recommended termination at round %d", round_idx)
                termination_reason = "reviewer_terminated"
                self._save_native_optimizer_state(
                    stage="ready",
                    next_round=round_idx + 1,
                    seed_smiles=seed_smiles,
                    target_property=target_property,
                    max_rounds=max_rounds,
                    oracle_budget=oracle_budget,
                    loop_values=locals(),
                )
                break
            if not should_continue:
                logger.info(
                    "Reviewer recommended termination at round %d, but the "
                    "full-budget protocol requires continuation",
                    round_idx,
                )
            self._save_native_optimizer_state(
                stage="ready",
                next_round=round_idx + 1,
                seed_smiles=seed_smiles,
                target_property=target_property,
                max_rounds=max_rounds,
                oracle_budget=oracle_budget,
                loop_values=locals(),
            )

        total_oracle_calls = self._current_oracle_call_count(
            oracle, total_oracle_calls
        )
        budget_complete = total_oracle_calls >= oracle_budget
        if budget_complete:
            termination_reason = "oracle_budget_exhausted"
        elif (
            getattr(self, "require_full_budget", False)
            and termination_reason == "max_rounds_reached"
        ):
            termination_reason = "max_rounds_before_oracle_budget"
        status = (
            "complete"
            if successful_scored_rounds > 0
            and termination_reason != "round_error_limit"
            and (
                not getattr(self, "require_full_budget", False)
                or budget_complete
            )
            else "failed"
        )
        result = {
            "best_smiles": best_smiles,
            "best_target_score": best_target_score,
            "best_admet_score": best_admet_score,
            "best_combined_score": best_combined,
            "total_oracle_calls": total_oracle_calls,
            "trajectory": trajectory,
            "memory": self.memory.buffer,
            "status": status,
            "termination_reason": termination_reason,
            "round_error_count": round_error_count,
            "round_failure_history": deepcopy(round_failure_history),
            "consecutive_round_errors": consecutive_round_errors,
            "successful_scored_rounds": successful_scored_rounds,
            "cer_experiences_committed": cer_experiences_committed,
            "budget_complete": budget_complete,
            "near_feasible_repair_protocol": (
                canonical_near_feasible_repair_protocol()
            ),
            "best_feasible": deepcopy(best_feasible),
            "near_feasible_anchors": deepcopy(near_feasible_anchors),
        }
        if self.curriculum is not None:
            # Include the append-only curriculum transition history in the result.
            # ``last_transition`` is omitted because it is an ephemeral
            # scheduler field.
            result["curriculum_transition_history"] = deepcopy(
                self.curriculum.transition_history
            )
            result["final_stagnation_count"] = int(stagnation_count)
        if novelty_enabled:
            result["novelty_recovery_protocol"] = (
                canonical_novelty_recovery_protocol()
            )
        if self.require_full_budget:
            result["formal_prompt_reuse_protocol"] = (
                canonical_formal_prompt_reuse_protocol()
            )

        # Include Lagrangian convergence data for analysis
        if self.use_lagrangian and self.lagrangian:
            result["lagrangian_trajectory"] = self.lagrangian.trajectory
            result["lagrangian_summary"] = self.lagrangian.get_trajectory_summary()
            result["lagrangian_protocol"] = (
                self.lagrangian.get_protocol_metadata()
            )
            result["lagrangian_transition_events"] = (
                self.lagrangian.transition_events
            )

        self._save_native_optimizer_state(
            stage="terminal",
            next_round=max_rounds,
            seed_smiles=seed_smiles,
            target_property=target_property,
            max_rounds=max_rounds,
            oracle_budget=oracle_budget,
            loop_values=locals(),
        )
        if native_journal is not None:
            result["native_run_journal"] = native_journal.snapshot()

        return result

    def _is_full_active_constraint_set(
        self, active_constraints: dict
    ) -> bool:
        """Return whether every configured hard constraint is active."""
        configured = [
            name
            for name, definition in self.config.get("admet", {}).get(
                "admet_constraints", {}
            ).items()
            if definition.get("threshold") is not None
        ]
        active = [
            name
            for name, definition in active_constraints.items()
            if definition.get("threshold") is not None
        ]
        return (
            tuple(configured) == CANONICAL_FULL_ADMET_CONSTRAINTS
            and set(active) == set(configured)
        )

    def _validated_full_constraint_assessments(
        self,
        admet_result: dict,
        active_constraints: dict,
        *,
        context: str,
    ) -> list[dict] | None:
        """Validate complete Phase-3 facts, failing closed in formal runs."""
        expected_names = [
            name
            for name, definition in active_constraints.items()
            if definition.get("threshold") is not None
        ]
        try:
            assessments = normalize_constraint_assessments(
                admet_result.get("constraint_assessments"),
                expected_names=expected_names,
                reject_missing=True,
            )
            factual_pass = bool(assessments) and all(
                row["pass"] for row in assessments
            )
            if admet_result.get("pass_all") is not factual_pass:
                raise NearFeasibleRepairProtocolError(
                    "pass_all disagrees with constraint assessments"
                )
            return assessments
        except NearFeasibleRepairProtocolError as error:
            if getattr(self, "require_full_budget", False):
                raise FormalRunFatalError(
                    "formal Phase-3 constraint assessment failed closed for "
                    f"{context}: {error}"
                ) from error
            logger.warning(
                "Ignoring malformed near-feasible evidence for %s: %s",
                context,
                error,
            )
            return None

    @staticmethod
    def _near_feasible_record(
        *,
        smiles: str,
        target_score: float,
        admet_score: float,
        round_idx: int,
        assessments: list[dict],
    ) -> dict:
        return {
            "smiles": smiles,
            "target_score": float(target_score),
            "admet_score": float(admet_score),
            "round": int(round_idx),
            "constraint_assessments": deepcopy(assessments),
        }

    def _near_feasible_durable_binding(
        self, oracle: Any, smiles: str
    ) -> dict[str, Any]:
        """Bind archive evidence to one complete identity-bound oracle row."""
        native_journal = getattr(oracle, "native_journal", None)
        durable_call = (
            native_journal.oracle_call_for_smiles(smiles)
            if native_journal is not None
            else None
        )
        if (
            isinstance(durable_call, dict)
            and durable_call.get("stage") == "complete"
            and isinstance(durable_call.get("call_index"), int)
            and isinstance(durable_call.get("record_sha256"), str)
        ):
            return {
                "oracle_call_index": int(durable_call["call_index"]),
                "oracle_record_sha256": durable_call["record_sha256"],
            }
        if getattr(self, "require_full_budget", False):
            raise FormalRunFatalError(
                "formal near-feasible evidence is not bound to a complete "
                f"native oracle record: {smiles}"
            )
        return {
            "oracle_call_index": None,
            "oracle_record_sha256": None,
        }

    def _advance_near_feasible_archive(
        self,
        *,
        full_active_set: bool,
        best_feasible: dict | None,
        anchors: list[dict],
        current_record: dict | None,
        current_passes: bool,
        candidate_records: list[dict],
    ) -> tuple[dict | None, list[dict], dict]:
        """Advance the context-only archive without touching optimizer state."""
        if current_record is not None:
            current_record = {
                **deepcopy(current_record),
                "pass_all": bool(current_passes),
            }
        return advance_near_feasible_archive(
            full_active_set=full_active_set,
            best_feasible=deepcopy(best_feasible),
            anchors=deepcopy(anchors),
            current_record=current_record,
            candidate_records=deepcopy(candidate_records),
        )

    @staticmethod
    def _near_feasible_audit(
        *,
        full_active_set: bool,
        phase_stagnation_count: int,
        current_assessments: list[dict] | None,
        current_record: dict | None,
        best_feasible: dict | None,
        anchors: list[dict],
    ) -> dict:
        injection_triggered = (
            full_active_set and phase_stagnation_count >= 5
        )
        return {
            "schema_version": NEAR_FEASIBLE_AUDIT_SCHEMA_VERSION,
            "full_active_set": bool(full_active_set),
            "phase_stagnation_count": int(phase_stagnation_count),
            "injection_triggered": injection_triggered,
            "current_constraint_assessments": deepcopy(
                current_assessments or []
            ),
            "current_record": deepcopy(current_record),
            "candidate_records": [],
            "anchors_injected": (
                deepcopy(anchors) if injection_triggered else []
            ),
            "best_feasible_before": deepcopy(best_feasible),
            "best_feasible_after": deepcopy(best_feasible),
            "anchors_before": deepcopy(anchors),
            "anchors_after": deepcopy(anchors),
            "candidate_count": 0,
            "feasible_candidate_count": 0,
            "eligible_candidate_count": 0,
            "dominated_candidate_count": 0,
            "invalid_assessment_count": 0,
            "pareto_front_size": 0,
            "best_feasible_updated": False,
            "archive_changed": False,
        }

    def _finalize_near_feasible_audit(
        self,
        audit: dict,
        *,
        full_active_set: bool,
        best_feasible: dict | None,
        anchors: list[dict],
        current_record: dict | None,
        current_passes: bool,
        candidate_records: list[dict],
    ) -> tuple[dict | None, list[dict], dict]:
        best_after, anchors_after, stats = (
            self._advance_near_feasible_archive(
                full_active_set=full_active_set,
                best_feasible=best_feasible,
                anchors=anchors,
                current_record=current_record,
                current_passes=current_passes,
                candidate_records=candidate_records,
            )
        )
        audit.update(stats)
        audit["current_record"] = (
            {
                **deepcopy(current_record),
                "pass_all": bool(current_passes),
            }
            if full_active_set and current_record is not None
            else None
        )
        audit["candidate_records"] = (
            deepcopy(candidate_records) if full_active_set else []
        )
        audit["best_feasible_after"] = deepcopy(best_after)
        audit["anchors_after"] = deepcopy(anchors_after)
        audit["best_feasible_updated"] = (
            audit["best_feasible_before"] != best_after
        )
        audit["archive_changed"] = audit["anchors_before"] != anchors_after
        return best_after, anchors_after, audit

    def _run_round(self, round_idx: int, current_smiles: str,
                    target_property: str, oracle: Any,
                    reviewer_feedback: str | None,
                    best_target_score: float, best_admet_score: float,
                    oracle_budget: int, total_oracle_calls: int,
                    stagnation_count: int,
                    generation_restart_strategy: str | None = None,
                    best_feasible: dict | None = None,
                    near_feasible_anchors: list[dict] | None = None) -> dict:
        """Execute a single optimization round."""

        archive_before = deepcopy(near_feasible_anchors or [])
        best_feasible_before = deepcopy(best_feasible)
        if not validate_near_feasible_state(
            best_feasible_before, archive_before
        ):
            raise FormalRunFatalError(
                "near-feasible repair state is malformed"
            )
        # Step 1: RAG retrieval
        try:
            rag_context = self.rag.retrieve(current_smiles, target_property)
        except Exception as error:
            if self.require_full_budget:
                raise FormalRunFatalError(
                    "formal RAG retrieval failed: "
                    f"{type(error).__name__}"
                ) from error
            raise

        # Step 2: Determine active constraints before producing any ADMET
        # context.  This ordering prevents full-constraint information from
        # leaking into target-only or easy-constraint curriculum phases.
        curriculum_transition = None
        if self.objective == "target_only":
            active_constraints = {}
        elif self.curriculum:
            active_constraints = self.curriculum.get_active_constraints(
                round_idx, best_target_score, stagnation_count
            )
            curriculum_transition = self.curriculum.last_transition
        else:
            active_constraints = self.config.get("admet", {}).get("admet_constraints", {})

        phase_stagnation_count = (
            0 if curriculum_transition else stagnation_count
        )
        full_active_set = self._is_full_active_constraint_set(
            active_constraints
        )

        # A curriculum expansion changes the constrained problem.  Prepare the
        # Lagrangian state before rescoring the incumbent or any candidate so a
        # Phase-2 rho cannot be applied to newly activated Phase-3 constraints.
        if self.use_lagrangian and self.lagrangian:
            self.lagrangian.prepare_active_constraints(
                active_constraints,
                round_idx=round_idx,
            )

        target_only_phase = not active_constraints
        # Step 2b: Build only the ADMET context active in this phase.
        if target_only_phase:
            current_admet_summary = (
                "ADMET constraints are inactive in this target-only phase."
            )
        else:
            current_admet_result = self._evaluate_admet_batch(
                [current_smiles], active_constraints
            )[0]
            try:
                current_admet_summary = self._format_admet_summary(
                    current_admet_result,
                    active_constraints=active_constraints,
                )
            except Exception as error:
                if self.require_full_budget:
                    raise FormalRunFatalError(
                        "formal ADMET source formatting failed: "
                        f"{type(error).__name__}"
                    ) from error
                raise

        if target_only_phase:
            current_admet_result = {
                "admet_score": 1.0,
                "pass_all": True,
                "violations": [],
                "constraints_inactive": True,
            }
            source_combined_score = best_target_score
        elif self.use_lagrangian and self.lagrangian:
            source_violations = self.lagrangian.compute_violation_vector(
                current_admet_result, active_constraints
            )
            source_combined_score = self.lagrangian.compute_lagrangian_score(
                best_target_score, source_violations, active_constraints
            )
        else:
            source_combined_score = compute_combined_score(
                best_target_score,
                current_admet_result.get("admet_score", 0.0),
                self.alpha,
            )
        source_admet_score = current_admet_result.get("admet_score", 1.0)

        current_constraint_assessments = None
        if full_active_set:
            current_constraint_assessments = (
                self._validated_full_constraint_assessments(
                    current_admet_result,
                    active_constraints,
                    context=f"round {round_idx} protected incumbent",
                )
            )
        current_record = None
        current_passes = False
        if current_constraint_assessments is not None:
            current_record = self._near_feasible_record(
                smiles=current_smiles,
                target_score=best_target_score,
                admet_score=source_admet_score,
                round_idx=round_idx,
                assessments=current_constraint_assessments,
            )
            current_record.update(
                self._near_feasible_durable_binding(oracle, current_smiles)
            )
            current_passes = bool(current_admet_result.get("pass_all", False))
        near_feasible_audit = self._near_feasible_audit(
            full_active_set=full_active_set,
            phase_stagnation_count=phase_stagnation_count,
            current_assessments=current_constraint_assessments,
            current_record=current_record,
            best_feasible=best_feasible_before,
            anchors=archive_before,
        )

        # Step 2c: Retrieve CER experience + constraint priorities
        try:
            cer_mode = "target_only" if target_only_phase else "combined"
            cer_max_origin_round = None
            if self.require_full_budget and self.curriculum is not None:
                if self.curriculum.current_phase == 1:
                    cer_mode = "target_only"
                    cer_max_origin_round = 20
                elif self.curriculum.current_phase == 2:
                    # Easy-four rounds must not reuse Phase-3 aggregate ADMET
                    # outcomes from prior tasks.
                    cer_mode = "target_only"
                    cer_max_origin_round = 60
            cer_experience = self.memory.get_relevant_experiences(
                current_smiles,
                mode=cer_mode,
                max_origin_round=cer_max_origin_round,
            )
        except Exception as error:
            if self.require_full_budget:
                raise FormalRunFatalError(
                    "formal Chemical-CER retrieval failed: "
                    f"{type(error).__name__}"
                ) from error
            raise
        generator_constraint_priorities = ""
        if self.curriculum:
            generator_constraint_priorities = (
                self.curriculum.get_phase_description()
            )
        if self.lagrangian and active_constraints:
            lagrangian_priorities = self.lagrangian.get_constraint_priorities(
                active_constraints,
                current_admet_result.get("constraint_assessments"),
            )
            generator_constraint_priorities = "\n".join(
                value
                for value in (
                    generator_constraint_priorities,
                    lagrangian_priorities,
                )
                if value
            )

        # Step 3: Generate candidates.  Canonical formal novelty recovery owns
        # the only possible second Generator call; GeneratorAgent's optional
        # parse retry is explicitly disabled for this path.
        generation_inputs = {
            "current_smiles": current_smiles,
            "target_property": target_property,
            "admet_constraints": active_constraints,
            "current_target_score": best_target_score,
            "current_admet_score": source_admet_score,
            "current_admet_summary": current_admet_summary,
            "rag_context": rag_context,
            "reviewer_feedback": reviewer_feedback or "First round, no feedback yet.",
            "successful_patterns": self.memory.get_successful_patterns(),
            "failed_patterns": self.memory.get_failed_patterns(),
            "cer_experience": cer_experience,
            "constraint_priorities": generator_constraint_priorities,
            "target_only_phase": target_only_phase,
            "generation_restart_strategy": generation_restart_strategy,
            "current_constraint_assessments": deepcopy(
                current_constraint_assessments or []
            ),
            **(
                {
                    "native_request_id": (
                        f"round:{round_idx}:generator:primary"
                    )
                }
                if getattr(self, "native_run_journal", None) is not None
                else {}
            ),
        }
        if near_feasible_audit["injection_triggered"]:
            generation_inputs["near_feasible_anchors"] = deepcopy(
                near_feasible_audit["anchors_injected"]
            )
        novelty_enabled = bool(
            getattr(self, "novelty_recovery_enabled", False)
        )
        if novelty_enabled:
            generation_inputs["orchestrator_managed_novelty_repair"] = True
            self._ensure_global_seen_canonical(oracle, current_smiles)
        global_seen_before = len(
            self._effective_global_seen_canonical()
            if novelty_enabled
            else getattr(self, "_global_seen_canonical", set())
        )

        primary_output = self.generator.run(generation_inputs)
        if self.require_full_budget:
            primary_output["candidates"] = canonicalize_formal_candidates(
                primary_output.get("candidates")
            )
        primary_candidates = primary_output["candidates"]
        if (
            novelty_enabled
            and int(primary_output.get("llm_call_count", 1)) != 1
        ):
            raise FormalRunFatalError(
                "canonical novelty recovery exceeded one primary Generator call"
            )

        if novelty_enabled:
            verified, primary_audit = self._verify_globally_novel_candidates(
                primary_candidates,
                stage="primary",
                round_idx=round_idx,
            )
        else:
            verified, primary_audit = self._verify_round_candidates_local(
                primary_candidates
            )

        repair_used = False
        repair_output: dict[str, Any] = {
            "candidates": [],
            "proposed_count": 0,
            "truncated_count": 0,
            "llm_call_count": 0,
        }
        repair_audit = self._empty_generation_stage_audit()
        repair_reasons: list[str] = []
        taboo_smiles: list[str] = []
        if novelty_enabled and not verified:
            repair_used = True
            repair_reasons = self._repair_reason_lines(
                primary_audit,
                formal_safe=self.require_full_budget,
            )
            taboo_count = int(
                self.novelty_recovery_protocol["nearest_taboo_count"]
            )
            taboo_smiles = self._nearest_global_taboo(
                current_smiles, taboo_count
            )
            repair_inputs = {
                **generation_inputs,
                "novelty_repair": True,
                "repair_reasons": repair_reasons,
                "taboo_smiles": taboo_smiles,
                "taboo_requested_count": taboo_count,
                "native_request_id": (
                    f"round:{round_idx}:generator:repair"
                ),
            }
            repair_output = self.generator.run(repair_inputs)
            if self.require_full_budget:
                repair_output["candidates"] = canonicalize_formal_candidates(
                    repair_output.get("candidates")
                )
            if int(repair_output.get("llm_call_count", 1)) != 1:
                raise FormalRunFatalError(
                    "canonical novelty repair exceeded one Generator call"
                )
            verified, repair_audit = (
                self._verify_globally_novel_candidates(
                    repair_output["candidates"],
                    stage="repair",
                    round_idx=round_idx,
                )
            )

        if novelty_enabled:
            self._require_pending_same_round_trace_consumed(round_idx)

        generator_proposed_count = sum(
            int(output.get("proposed_count", len(output["candidates"])))
            for output in (primary_output, repair_output)
        )
        generator_truncated_count = sum(
            int(output.get("truncated_count", 0))
            for output in (primary_output, repair_output)
        )
        novelty_audit = None
        if novelty_enabled:
            # Publish globally novel canonical identities before any candidate
            # ADMET inference.  Deterministic Verifier failures remain explicit
            # repair evidence but never become accepted global identities.
            self._global_seen_canonical.update(
                candidate["new_smiles"] for candidate in verified
            )
            novelty_audit = self._build_novelty_audit(
                primary=primary_audit,
                repair=repair_audit,
                globally_novel_smiles=[
                    candidate["new_smiles"] for candidate in verified
                ],
                repair_used=repair_used,
                repair_reasons=repair_reasons,
                taboo_smiles=taboo_smiles,
                restart_applied=generation_restart_strategy,
                global_seen_count_before=global_seen_before,
            )

        if not verified:
            source_durable_binding = self._near_feasible_durable_binding(
                oracle, current_smiles
            )
            (
                best_feasible_after,
                near_feasible_anchors_after,
                near_feasible_audit,
            ) = self._finalize_near_feasible_audit(
                near_feasible_audit,
                full_active_set=full_active_set,
                best_feasible=best_feasible_before,
                anchors=archive_before,
                current_record=current_record,
                current_passes=current_passes,
                candidate_records=[],
            )
            return {
                "scored_candidates": [],
                "round_best": None,
                "reviewer_feedback": None,
                "should_continue": True,
                "n_admet_pass": 0,
                "total_oracle_calls": total_oracle_calls,
                "source_combined_score": source_combined_score,
                "source_admet_score": source_admet_score,
                "generator_proposed_count": generator_proposed_count,
                "generator_truncated_count": generator_truncated_count,
                "cer_experience_committed": False,
                "active_constraints": list(active_constraints),
                "curriculum_transition": curriculum_transition,
                "best_feasible": best_feasible_after,
                "near_feasible_anchors": near_feasible_anchors_after,
                "near_feasible_audit": near_feasible_audit,
                "source_smiles": current_smiles,
                "source_oracle_call_index": source_durable_binding[
                    "oracle_call_index"
                ],
                "source_oracle_record_sha256": source_durable_binding[
                    "oracle_record_sha256"
                ],
                "accepted_smiles": current_smiles,
                "accepted_oracle_call_index": source_durable_binding[
                    "oracle_call_index"
                ],
                "accepted_oracle_record_sha256": source_durable_binding[
                    "oracle_record_sha256"
                ],
                **(
                    {"novelty_audit": novelty_audit}
                    if novelty_enabled else {}
                ),
            }

        # Step 5: ADMET evaluation
        smiles_list = [c["new_smiles"] for c in verified]
        if target_only_phase:
            admet_results = [
                {
                    "admet_score": 1.0,
                    "pass_all": True,
                    "violations": [],
                    "constraints_inactive": True,
                }
                for _ in smiles_list
            ]
        else:
            admet_results = self._evaluate_admet_batch(
                smiles_list, active_constraints
            )

        candidate_constraint_assessments: list[list[dict] | None] = [
            None for _ in admet_results
        ]
        if full_active_set:
            candidate_constraint_assessments = [
                self._validated_full_constraint_assessments(
                    admet_result,
                    active_constraints,
                    context=(
                        f"round {round_idx} candidate "
                        f"{verified[index]['new_smiles']}"
                    ),
                )
                for index, admet_result in enumerate(admet_results)
            ]

        # Step 6: Oracle scoring
        scores = []
        evaluated_candidates = []
        evaluated_admet_results = []
        evaluated_constraint_assessments = []
        oracle_buffer = getattr(oracle, "mol_buffer", None)
        tracked_oracle = hasattr(oracle, "call_count")
        for candidate_index, (
            candidate,
            admet_result,
            constraint_assessments,
        ) in enumerate(
            zip(
                verified,
                admet_results,
                candidate_constraint_assessments,
                strict=True,
            )
        ):
            smi = candidate["new_smiles"]
            total_oracle_calls = self._current_oracle_call_count(
                oracle, total_oracle_calls
            )
            native_journal = getattr(self, "native_run_journal", None)
            durable_call = (
                native_journal.oracle_call_for_smiles(smi)
                if native_journal is not None
                else None
            )
            replay_same_round = bool(
                durable_call is not None
                and durable_call.get("stage") in {"raw_scored", "complete"}
                and durable_call.get("context", {}).get("scope")
                == "optimization_round"
                and durable_call.get("context", {}).get("round") == round_idx
                and durable_call.get("context", {}).get("candidate_index")
                == candidate_index
            )
            if (
                durable_call is not None
                and durable_call.get("stage") in {"raw_scored", "complete"}
                and durable_call.get("context", {}).get("scope")
                == "optimization_round"
                and durable_call.get("context", {}).get("round") == round_idx
                and durable_call.get("context", {}).get("candidate_index")
                != candidate_index
            ):
                raise FormalRunFatalError(
                    "durable same-round oracle candidate index mismatch"
                )
            if replay_same_round:
                # A crash after this round's oracle scoring replays the durable
                # score into FIFO/duals/Reviewer without another PyTDC call.
                if durable_call["stage"] == "raw_scored":
                    score = self._call_oracle(oracle, smi)
                else:
                    score = float(durable_call["raw_target_score"])
                scores.append(score)
                evaluated_candidates.append(candidate)
                evaluated_admet_results.append(admet_result)
                evaluated_constraint_assessments.append(
                    constraint_assessments
                )
                continue
            if self._is_budget_exhausted(oracle, total_oracle_calls, oracle_budget):
                break
            # A cached molecule is not a new PMO evaluation.  It must not be
            # reintroduced as a round outcome or influence memory/duals.
            if isinstance(oracle_buffer, dict) and smi in oracle_buffer:
                continue
            calls_before = total_oracle_calls
            self._set_oracle_context(
                oracle,
                {
                    "scope": "optimization_round",
                    "round": round_idx,
                    "candidate_index": candidate_index,
                },
            )
            score = self._call_oracle(oracle, smi)
            total_oracle_calls = self._oracle_call_count_after_call(
                oracle, total_oracle_calls
            )
            if tracked_oracle and total_oracle_calls == calls_before:
                if self.require_full_budget:
                    raise FormalRunFatalError(
                        "Tracked oracle returned without recording a new "
                        f"canonical molecule: {smi}"
                    )
                continue
            if (
                tracked_oracle
                and total_oracle_calls != calls_before + 1
            ):
                raise FormalRunFatalError(
                    "Tracked oracle call count changed by an invalid amount: "
                    f"{calls_before} -> {total_oracle_calls}"
                )
            scores.append(score)
            evaluated_candidates.append(candidate)
            evaluated_admet_results.append(admet_result)
            evaluated_constraint_assessments.append(constraint_assessments)

        if not scores:
            source_durable_binding = self._near_feasible_durable_binding(
                oracle, current_smiles
            )
            (
                best_feasible_after,
                near_feasible_anchors_after,
                near_feasible_audit,
            ) = self._finalize_near_feasible_audit(
                near_feasible_audit,
                full_active_set=full_active_set,
                best_feasible=best_feasible_before,
                anchors=archive_before,
                current_record=current_record,
                current_passes=current_passes,
                candidate_records=[],
            )
            return {
                "scored_candidates": [],
                "round_best": None,
                "reviewer_feedback": None,
                "should_continue": True,
                "n_admet_pass": 0,
                "total_oracle_calls": total_oracle_calls,
                "source_combined_score": source_combined_score,
                "source_admet_score": source_admet_score,
                "generator_proposed_count": generator_proposed_count,
                "generator_truncated_count": generator_truncated_count,
                "cer_experience_committed": False,
                "active_constraints": list(active_constraints),
                "curriculum_transition": curriculum_transition,
                "best_feasible": best_feasible_after,
                "near_feasible_anchors": near_feasible_anchors_after,
                "near_feasible_audit": near_feasible_audit,
                "source_smiles": current_smiles,
                "source_oracle_call_index": source_durable_binding[
                    "oracle_call_index"
                ],
                "source_oracle_record_sha256": source_durable_binding[
                    "oracle_record_sha256"
                ],
                "accepted_smiles": current_smiles,
                "accepted_oracle_call_index": source_durable_binding[
                    "oracle_call_index"
                ],
                "accepted_oracle_record_sha256": source_durable_binding[
                    "oracle_record_sha256"
                ],
                **(
                    {"novelty_audit": novelty_audit}
                    if novelty_enabled else {}
                ),
            }

        # Step 7: Compute combined scores without mutating round state.  FIFO,
        # duals, and CER are committed only after Reviewer succeeds.
        scored_candidates = []
        n_admet_pass = 0
        # Augmented-Lagrangian scores are unbounded below; -1 is not a safe
        # sentinel once a configured constraint scale makes penalties strong.
        round_best = {
            "combined_score": float("-inf"),
            "smiles": "",
            "target_score": 0,
            "admet_score": 0,
        }

        best_round_admet = None  # track for Lagrangian dual update
        round_best_entry = None
        near_feasible_candidate_records = []
        for i in range(len(scores)):
            cand = evaluated_candidates[i]
            target_score = scores[i]
            admet_r = evaluated_admet_results[i]
            admet_score = admet_r.get("admet_score", 0)

            if target_only_phase:
                combined = target_score
            elif self.use_lagrangian and self.lagrangian:
                violations = self.lagrangian.compute_violation_vector(
                    admet_r, active_constraints
                )
                combined = self.lagrangian.compute_lagrangian_score(
                    target_score, violations, active_constraints
                )
            else:
                combined = compute_combined_score(
                    target_score, admet_score, self.alpha
                )

            if admet_r.get("pass_all", False):
                n_admet_pass += 1

            delta_target = target_score - best_target_score
            delta_admet = (
                0.0
                if target_only_phase
                else admet_score - source_admet_score
            )
            delta_combined = combined - source_combined_score

            entry = {
                "smiles": cand["new_smiles"],
                "previous_smiles": current_smiles,
                "target_score": target_score,
                "admet_score": admet_score,
                "combined_score": combined,
                "modifications": cand.get("modifications", []),
                "round": round_idx,
                # Explicit CER deltas.  Target/ADMET are relative to the source
                # (the current best molecule passed into this round) under the
                # same active set, lambdas, and rho as the candidate.
                "delta_target": delta_target,
                "delta_admet": delta_admet,
                "delta_combined": delta_combined,
                "delta_score": delta_combined,
                "active_constraints": list(active_constraints),
                "task_name": target_property,
            }
            scored_candidates.append(entry)
            near_feasible_candidate_records.append({
                **self._near_feasible_record(
                    smiles=cand["new_smiles"],
                    target_score=target_score,
                    admet_score=admet_score,
                    round_idx=round_idx,
                    assessments=(
                        evaluated_constraint_assessments[i] or []
                    ),
                ),
                "constraint_assessments": deepcopy(
                    evaluated_constraint_assessments[i]
                ),
                "pass_all": bool(admet_r.get("pass_all", False)),
                **self._near_feasible_durable_binding(
                    oracle, cand["new_smiles"]
                ),
            })

            if combined > round_best["combined_score"]:
                round_best = {
                    "smiles": cand["new_smiles"],
                    "target_score": target_score,
                    "admet_score": admet_score,
                    "combined_score": combined,
                }
                best_round_admet = admet_r
                round_best_entry = entry

        candidate_improves = (
            bool(scored_candidates)
            and round_best["combined_score"] > source_combined_score
        )
        selected_admet = (
            best_round_admet if candidate_improves else current_admet_result
        )
        selected_smiles = round_best["smiles"] if candidate_improves else current_smiles
        selected_target_score = (
            round_best["target_score"] if candidate_improves else best_target_score
        )
        selected_admet_score = (
            round_best["admet_score"] if candidate_improves else source_admet_score
        )
        selected_constraint_assessments: list[dict] = []
        if active_constraints:
            selected_constraint_assessments = (
                self._validated_full_constraint_assessments(
                    selected_admet,
                    active_constraints,
                    context=f"round {round_idx} accepted iterate",
                )
                or []
            )
        reviewer_constraint_priorities = ""
        if self.curriculum:
            reviewer_constraint_priorities = (
                self.curriculum.get_phase_description()
            )
        if self.lagrangian and active_constraints:
            reviewer_lagrangian_priorities = (
                self.lagrangian.get_constraint_priorities(
                    active_constraints,
                    selected_constraint_assessments,
                )
            )
            reviewer_constraint_priorities = "\n".join(
                value
                for value in (
                    reviewer_constraint_priorities,
                    reviewer_lagrangian_priorities,
                )
                if value
            )

        # Step 8: Reviewer feedback (skip if disabled for ablation)
        if self.config.get("reviewer", {}).get("disabled", False):
            reviewer_output = {
                "feedback": FORMAL_REVIEWER_DISABLED_FEEDBACK,
                "should_continue": True,
            }
        else:
            preview_recent = getattr(self.memory, "preview_recent", None)
            if callable(preview_recent):
                reviewer_history = preview_recent(scored_candidates, 10)
            else:
                # Compatibility for minimal external/test memory adapters.
                reviewer_history = (
                    list(self.memory.get_recent(10)) + scored_candidates
                )[-10:]
            reviewer_inputs = {
                "candidates": evaluated_candidates,
                "target_scores": scores,
                "optimization_history": reviewer_history,
                "round_number": round_idx,
                "best_smiles": selected_smiles,
                "best_target_score": selected_target_score,
                "oracle_calls_used": total_oracle_calls,
                "oracle_budget": oracle_budget,
                "stagnation_count": phase_stagnation_count,
                "target_only_phase": target_only_phase,
                "formal_structured_reuse": self.require_full_budget,
                **(
                    {
                        "native_request_id": (
                            f"round:{round_idx}:reviewer"
                        )
                    }
                    if getattr(self, "native_run_journal", None) is not None
                    else {}
                ),
            }
            if not target_only_phase:
                all_constraints = self.config.get("admet", {}).get(
                    "admet_constraints", {}
                )
                configured_hard_constraints = {
                    name
                    for name, definition in all_constraints.items()
                    if definition.get("threshold") is not None
                }
                active_hard_constraints = {
                    name
                    for name, definition in active_constraints.items()
                    if definition.get("threshold") is not None
                }
                full_active_set_for_repair = (
                    active_hard_constraints == configured_hard_constraints
                )
                reviewer_inputs.update({
                    "admet_results": evaluated_admet_results,
                    "best_admet_score": selected_admet_score,
                    "admet_constraints": active_constraints,
                    "constraint_priorities": reviewer_constraint_priorities,
                    "admet_profile": selected_admet.get("admet_profile", {}),
                    # Online prompts expose only explicitly active endpoints,
                    # including in Phase 3.  Unregistered/monitoring-only
                    # predictions are never LLM context.
                    "admet_profile_mode": "active_only",
                })
                if (
                    full_active_set_for_repair
                    and near_feasible_audit["injection_triggered"]
                ):
                    reviewer_inputs.update({
                        "protected_incumbent": {
                            "smiles": selected_smiles,
                            "target_score": float(selected_target_score),
                            "admet_score": float(selected_admet_score),
                            "constraint_assessments": deepcopy(
                                selected_constraint_assessments
                            ),
                        },
                        "near_feasible_anchors_injected": deepcopy(
                            near_feasible_audit["anchors_injected"]
                        ),
                    })
            reviewer_output = self.reviewer.run(reviewer_inputs)
            if novelty_enabled:
                novelty_audit["reviewer_calls"] = 1

        # The Reviewer completed successfully: atomically publish the
        # accepted round's task-local FIFO view, then update dual state from
        # the accepted iterate.  The outer loop restores both if a later
        # commit step raises.
        source_durable_binding = self._near_feasible_durable_binding(
            oracle, current_smiles
        )
        accepted_durable_binding = self._near_feasible_durable_binding(
            oracle, selected_smiles
        )
        for entry in scored_candidates:
            self.memory.add(entry)

        if (
            self.objective != "target_only"
            and self.use_lagrangian
            and self.lagrangian
            and selected_admet
            and active_constraints
        ):
            best_violations = self.lagrangian.compute_violation_vector(
                selected_admet, active_constraints
            )
            self.lagrangian.update_duals(
                best_violations,
                active_constraints,
                round_idx=round_idx,
                accepted_smiles=selected_smiles,
                accepted_constraint_assessments=(
                    selected_constraint_assessments
                ),
                accepted_oracle_call_index=accepted_durable_binding[
                    "oracle_call_index"
                ],
                accepted_oracle_record_sha256=accepted_durable_binding[
                    "oracle_record_sha256"
                ],
            )

        # Chemical-CER represents completed round-level transitions, not every
        # proposal.  The FIFO above intentionally retains all scored
        # candidates for the Reviewer; only the best scored outcome is
        # committed after the full round succeeds.
        cer_experience_committed = False
        if round_best_entry is not None:
            commit_experience = getattr(
                self.memory, "commit_experience", None
            )
            if commit_experience is not None:
                try:
                    cer_experience_committed = bool(
                        commit_experience(round_best_entry)
                    )
                    if (
                        not cer_experience_committed
                        and getattr(self, "native_run_journal", None) is not None
                    ):
                        # Crash window: CER may have committed immediately
                        # before the round snapshot.  Exact duplicate presence
                        # is the same logical commit, not a missing experience.
                        present = getattr(
                            self.memory,
                            "has_committed_experience",
                            None,
                        )
                        cer_experience_committed = bool(
                            callable(present) and present(round_best_entry)
                        )
                except Exception as error:
                    if self.require_full_budget:
                        raise FormalRunFatalError(
                            "formal Chemical-CER commit failed: "
                            f"{type(error).__name__}"
                        ) from error
                    raise

        (
            best_feasible_after,
            near_feasible_anchors_after,
            near_feasible_audit,
        ) = self._finalize_near_feasible_audit(
            near_feasible_audit,
            full_active_set=full_active_set,
            best_feasible=best_feasible_before,
            anchors=archive_before,
            current_record=current_record,
            current_passes=current_passes,
            candidate_records=near_feasible_candidate_records,
        )

        return {
            "scored_candidates": scored_candidates,
            "round_best": round_best,
            "reviewer_feedback": reviewer_output["feedback"],
            "should_continue": reviewer_output["should_continue"],
            "n_admet_pass": n_admet_pass,
            "total_oracle_calls": total_oracle_calls,
            "active_constraints": list(active_constraints),
            "source_combined_score": source_combined_score,
            "source_admet_score": source_admet_score,
            "candidate_improves": candidate_improves,
            "generator_proposed_count": generator_proposed_count,
            "generator_truncated_count": generator_truncated_count,
            "cer_experience_committed": cer_experience_committed,
            "curriculum_transition": curriculum_transition,
            "best_feasible": best_feasible_after,
            "near_feasible_anchors": near_feasible_anchors_after,
            "near_feasible_audit": near_feasible_audit,
            "source_smiles": current_smiles,
            "source_oracle_call_index": source_durable_binding[
                "oracle_call_index"
            ],
            "source_oracle_record_sha256": source_durable_binding[
                "oracle_record_sha256"
            ],
            "accepted_smiles": selected_smiles,
            "accepted_oracle_call_index": accepted_durable_binding[
                "oracle_call_index"
            ],
            "accepted_oracle_record_sha256": accepted_durable_binding[
                "oracle_record_sha256"
            ],
            **(
                {"novelty_audit": novelty_audit}
                if novelty_enabled else {}
            ),
        }

    @staticmethod
    def _empty_generation_stage_audit() -> dict:
        return {
            "parsed_count": 0,
            "verified_count": 0,
            "duplicate_count": 0,
            "globally_novel_count": 0,
            "rejections": [],
            "duplicates": [],
        }

    def _initialize_global_seen_canonical(
        self, oracle: Any, seed_smiles: str
    ) -> None:
        """Initialize run-global molecular identities from spent PMO calls."""
        seen: set[str] = set()
        oracle_buffer = getattr(oracle, "mol_buffer", None)
        candidates = (
            list(oracle_buffer)
            if isinstance(oracle_buffer, dict)
            else []
        )
        candidates.append(seed_smiles)
        for smiles in candidates:
            canonical = validate_smiles(smiles)
            if canonical is not None:
                seen.add(canonical)
        self._global_seen_canonical = seen
        self._global_seen_initialized = True

    def _ensure_global_seen_canonical(
        self, oracle: Any, current_smiles: str
    ) -> None:
        if not getattr(self, "_global_seen_initialized", False):
            self._initialize_global_seen_canonical(oracle, current_smiles)

    def _reconcile_global_seen_from_oracle_trace(self, oracle: Any) -> None:
        """Union only identities whose external oracle score is durable."""
        durable_smiles: list[str] = []
        native_journal = getattr(oracle, "native_journal", None)
        if native_journal is None:
            native_journal = getattr(self, "native_run_journal", None)
        if native_journal is not None:
            durable_smiles = [
                call["smiles"]
                for call in native_journal.oracle_calls()
                if call.get("stage") in {"raw_scored", "complete"}
            ]
        else:
            oracle_buffer = getattr(oracle, "mol_buffer", None)
            if isinstance(oracle_buffer, dict):
                durable_smiles = list(oracle_buffer)
        for smiles in durable_smiles:
            canonical = validate_smiles(smiles)
            if canonical is None or canonical != smiles:
                raise FormalRunFatalError(
                    "oracle trace contains a noncanonical global identity"
                )
            self._global_seen_canonical.add(canonical)
        self._global_seen_initialized = True

    def _derive_pending_same_round_trace(
        self,
        *,
        trajectory: object,
        round_failure_history: object,
        next_round: int,
        stage: str,
    ) -> None:
        """Derive one crash-ahead replay prefix only from the physical trace."""
        self._clear_pending_same_round_trace()
        if stage != "round_pending":
            return
        native_journal = getattr(self, "native_run_journal", None)
        if native_journal is None:
            return
        calls = [
            call
            for call in native_journal.oracle_calls()
            if call.get("stage") in {"raw_scored", "complete"}
        ]
        outcome_prefixes: list[tuple[int, object]] = []
        if isinstance(trajectory, list):
            outcome_prefixes.extend(
                (int(row["round"]), row.get("oracle_calls"))
                for row in trajectory
                if isinstance(row, dict) and "round" in row
            )
        if isinstance(round_failure_history, list):
            outcome_prefixes.extend(
                (int(event["round"]), event.get("oracle_calls_after"))
                for event in round_failure_history
                if isinstance(event, dict) and "round" in event
            )
        if outcome_prefixes:
            last_outcome_round, baseline = max(outcome_prefixes)
            if (
                last_outcome_round != next_round - 1
                or isinstance(baseline, bool)
                or not isinstance(baseline, int)
                or baseline < 0
            ):
                raise FormalRunFatalError(
                    "native novelty lineage has an invalid outcome-call baseline"
                )
        else:
            baseline = min(26, len(calls))

        pending: list[dict[str, Any]] = []
        pre_round_smiles: set[str] = set()
        seen_current_round = False
        for call in calls:
            if call["call_index"] <= baseline:
                pre_round_smiles.add(call["smiles"])
                continue
            context = call.get("context")
            context_round = (
                context.get("round") if isinstance(context, dict) else None
            )
            if (
                not isinstance(context, dict)
                or set(context) != {"scope", "round", "candidate_index"}
                or context.get("scope") != "optimization_round"
                or isinstance(context_round, bool)
                or not isinstance(context_round, int)
                or isinstance(context.get("candidate_index"), bool)
                or not isinstance(context.get("candidate_index"), int)
            ):
                raise FormalRunFatalError(
                    "native trace-ahead novelty context is invalid"
                )
            if context_round > next_round:
                raise FormalRunFatalError(
                    "native trace is ahead of the restored optimizer round"
                )
            if context_round < next_round:
                if seen_current_round:
                    raise FormalRunFatalError(
                        "native failed-gap trace follows current-round trace"
                    )
                pre_round_smiles.add(call["smiles"])
                continue
            seen_current_round = True
            canonical = validate_smiles(call.get("smiles"))
            if canonical is None or canonical != call.get("smiles"):
                raise FormalRunFatalError(
                    "native trace-ahead identity is not canonical"
                )
            pending.append({
                "call_index": int(call["call_index"]),
                "candidate_index": int(context["candidate_index"]),
                "smiles": canonical,
            })
        if [row["candidate_index"] for row in pending] != list(
            range(len(pending))
        ) or len({row["smiles"] for row in pending}) != len(pending) or len(
            pending
        ) > int(
            self.novelty_recovery_protocol[
                "candidate_cap_per_generator_call"
            ]
        ):
            raise FormalRunFatalError(
                "native trace-ahead candidates are not one exact ordered prefix"
            )
        if any(row["smiles"] in pre_round_smiles for row in pending):
            raise FormalRunFatalError(
                "native trace-ahead identity already existed before the round"
            )
        self._pending_same_round_trace = pending
        self._pending_same_round_consumed = 0

    def _effective_global_seen_canonical(self) -> set[str]:
        pending = {
            row["smiles"]
            for row in getattr(self, "_pending_same_round_trace", [])
        }
        global_seen = set(getattr(self, "_global_seen_canonical", set()))
        if not pending.issubset(global_seen):
            raise FormalRunFatalError(
                "pending trace-ahead identities are absent from global seen"
            )
        return global_seen - pending

    def _require_pending_same_round_trace_consumed(
        self, round_idx: int
    ) -> None:
        pending = getattr(self, "_pending_same_round_trace", [])
        consumed = int(
            getattr(self, "_pending_same_round_consumed", 0)
        )
        if consumed != len(pending):
            raise FormalRunFatalError(
                f"round {round_idx} did not replay every durable "
                "trace-ahead candidate"
            )

    def _commit_pending_same_round_trace(self, round_idx: int) -> None:
        self._require_pending_same_round_trace_consumed(round_idx)
        self._clear_pending_same_round_trace()

    def _clear_pending_same_round_trace(self) -> None:
        self._pending_same_round_trace = []
        self._pending_same_round_consumed = 0

    @staticmethod
    def _verifier_rejection_reason(result: dict) -> str:
        failed_checks = [
            key.removesuffix("_pass")
            for key, value in result.items()
            if key.endswith("_pass") and value is False
        ]
        if result.get("valid_smiles") is False:
            failed_checks.insert(0, "invalid_smiles")
        error = result.get("error")
        if isinstance(error, str) and error.strip():
            failed_checks.append(error.strip())
        return ", ".join(dict.fromkeys(failed_checks)) or "verifier_rejected"

    def _verify_globally_novel_candidates(
        self,
        candidates: list[dict],
        *,
        stage: str,
        round_idx: int,
    ) -> tuple[list[dict], dict]:
        """Apply the unchanged Verifier, then global canonical novelty."""
        audit = self._empty_generation_stage_audit()
        accepted: list[dict] = []
        stage_seen: set[str] = set()
        global_seen = self._effective_global_seen_canonical()
        pending = getattr(self, "_pending_same_round_trace", [])
        for candidate in candidates:
            audit["parsed_count"] += 1
            raw_smiles = candidate["new_smiles"]
            verifier_result = self.verifier.run({"smiles": raw_smiles})
            if not verifier_result.get("pass", False):
                audit["rejections"].append({
                    "stage": stage,
                    "smiles": raw_smiles,
                    "reason": self._verifier_rejection_reason(
                        verifier_result
                    ),
                })
                continue
            audit["verified_count"] += 1
            canonical = verifier_result.get("canonical_smiles")
            if not isinstance(canonical, str) or not canonical:
                raise FormalRunFatalError(
                    "Verifier passed a candidate without canonical SMILES"
                )
            pending_smiles = {row["smiles"] for row in pending}
            duplicate_scope = None
            if canonical in stage_seen:
                duplicate_scope = "within_generator_call"
            elif canonical in global_seen:
                duplicate_scope = "global_seen"
            if duplicate_scope is not None:
                audit["duplicate_count"] += 1
                audit["duplicates"].append({
                    "stage": stage,
                    "smiles": raw_smiles,
                    "canonical_smiles": canonical,
                    "reason": duplicate_scope,
                })
                stage_seen.add(canonical)
                continue
            pending_position = int(
                getattr(self, "_pending_same_round_consumed", 0)
            )
            if pending_position < len(pending):
                expected = pending[pending_position]
                if canonical != expected["smiles"]:
                    raise FormalRunFatalError(
                        f"round {round_idx} durable candidate replay is "
                        "missing or reordered"
                    )
                if canonical in stage_seen:
                    raise FormalRunFatalError(
                        "durable trace-ahead identity was replayed more than once"
                    )
                stage_seen.add(canonical)
                verified_candidate = dict(candidate)
                verified_candidate["new_smiles"] = canonical
                verified_candidate["verifier_result"] = verifier_result
                accepted.append(verified_candidate)
                audit["globally_novel_count"] += 1
                self._pending_same_round_consumed = pending_position + 1
                continue
            if canonical in pending_smiles:
                raise FormalRunFatalError(
                    "durable trace-ahead identity was replayed more than once"
                )
            stage_seen.add(canonical)
            verified_candidate = dict(candidate)
            verified_candidate["new_smiles"] = canonical
            verified_candidate["verifier_result"] = verifier_result
            accepted.append(verified_candidate)
            audit["globally_novel_count"] += 1
        return accepted, audit

    def _verify_round_candidates_local(
        self, candidates: list[dict]
    ) -> tuple[list[dict], dict]:
        """Deduplicate candidates within one round for non-formal configurations."""
        audit = self._empty_generation_stage_audit()
        verified: list[dict] = []
        seen_canonical: set[str] = set()
        for candidate in candidates:
            audit["parsed_count"] += 1
            result = self.verifier.run({"smiles": candidate["new_smiles"]})
            if not result.get("pass", False):
                audit["rejections"].append({
                    "stage": "primary",
                    "smiles": candidate["new_smiles"],
                    "reason": self._verifier_rejection_reason(result),
                })
                continue
            audit["verified_count"] += 1
            canonical = result["canonical_smiles"]
            if canonical in seen_canonical:
                audit["duplicate_count"] += 1
                audit["duplicates"].append({
                    "stage": "primary",
                    "smiles": candidate["new_smiles"],
                    "canonical_smiles": canonical,
                    "reason": "within_generator_call",
                })
                continue
            seen_canonical.add(canonical)
            accepted = dict(candidate)
            accepted["new_smiles"] = canonical
            accepted["verifier_result"] = result
            verified.append(accepted)
            audit["globally_novel_count"] += 1
        return verified, audit

    @staticmethod
    def _repair_reason_lines(
        primary_audit: dict, *, formal_safe: bool = False
    ) -> list[str]:
        if formal_safe:
            try:
                return formal_repair_reason_lines(primary_audit)
            except NoveltyRecoveryProtocolError as error:
                raise FormalRunFatalError(
                    "formal novelty repair evidence is malformed"
                ) from error
        reasons = [
            f"{row['smiles']!r}: Verifier rejected ({row['reason']})"
            for row in primary_audit["rejections"]
        ]
        reasons.extend(
            f"{row['smiles']!r} -> {row['canonical_smiles']}: "
            f"duplicate ({row['reason']})"
            for row in primary_audit["duplicates"]
        )
        if not reasons:
            reasons.append("No parseable candidate objects were returned.")
        return reasons

    def _nearest_global_taboo(
        self, current_smiles: str, count: int
    ) -> list[str]:
        """Return a deterministic nearest-first taboo list of fixed capacity."""
        ranked = sorted(
            self._effective_global_seen_canonical(),
            key=lambda smiles: (
                -compute_tanimoto(current_smiles, smiles),
                smiles,
            ),
        )
        return ranked[:count]

    def _build_novelty_audit(
        self,
        *,
        primary: dict,
        repair: dict,
        globally_novel_smiles: list[str],
        repair_used: bool,
        repair_reasons: list[str],
        taboo_smiles: list[str],
        restart_applied: str | None,
        global_seen_count_before: int,
    ) -> dict:
        count_fields = (
            "parsed_count",
            "verified_count",
            "duplicate_count",
            "globally_novel_count",
        )
        expected_novel_count = int(primary["globally_novel_count"]) + int(
            repair["globally_novel_count"]
        )
        if (
            len(globally_novel_smiles) != expected_novel_count
            or len(set(globally_novel_smiles))
            != len(globally_novel_smiles)
            or any(
                validate_smiles(smiles) != smiles
                for smiles in globally_novel_smiles
            )
        ):
            raise FormalRunFatalError(
                "novelty audit identities do not match verified candidates"
            )
        return {
            "schema_version": NOVELTY_AUDIT_SCHEMA_VERSION,
            **{
                field: int(primary[field]) + int(repair[field])
                for field in count_fields
            },
            "globally_novel_smiles": list(globally_novel_smiles),
            "generator_calls": 2 if repair_used else 1,
            "reviewer_calls": 0,
            "repair_used": repair_used,
            "repair_reasons": list(repair_reasons),
            "taboo_smiles": list(taboo_smiles),
            "restart_applied": restart_applied,
            "restart_scheduled": None,
            "zero_novel_round_streak": 0,
            "global_seen_count_before": global_seen_count_before,
            "global_seen_count_after": len(self._global_seen_canonical),
            "primary": primary,
            "repair": repair,
        }

    def _evaluate_admet_batch(
        self,
        smiles_list: list[str],
        active_constraints: dict,
    ) -> list[dict]:
        """Evaluate and mask one complete ADMET batch, failing closed formally."""
        try:
            output = self.admet_analyst.run({"smiles_list": smiles_list})
            results = output["admet_results"]
            if not isinstance(results, list) or len(results) != len(smiles_list):
                raise ValueError(
                    "ADMET analyst result cardinality does not match input"
                )
            return [
                self._mask_admet_result(result, active_constraints)
                for result in results
            ]
        except FormalRunFatalError:
            raise
        except Exception as error:
            if self.require_full_budget:
                raise FormalRunFatalError(
                    "formal ADMET evaluation failed: "
                    f"{type(error).__name__}"
                ) from error
            raise

    @staticmethod
    def _set_oracle_context(oracle: Any, context: dict) -> None:
        setter = getattr(oracle, "set_native_call_context", None)
        if callable(setter):
            setter(context)

    def _build_round_failure_event(
        self,
        *,
        round_idx: int,
        error: Exception,
        oracle: Any,
        trajectory: list[dict],
        round_failure_history: list[dict],
        fallback_oracle_calls_before: int,
        fallback_oracle_calls_after: int,
    ) -> dict:
        """Bind one recoverable failure to its exact durable oracle prefix."""
        outcome_by_round = {
            int(row["round"]): int(row["oracle_calls"])
            for row in trajectory
        }
        for event in round_failure_history:
            event_round = int(event["round"])
            if event_round in outcome_by_round:
                raise FormalRunFatalError(
                    "round failure history overlaps a successful round"
                )
            outcome_by_round[event_round] = int(
                event["oracle_calls_after"]
            )
        if sorted(outcome_by_round) != list(range(round_idx)):
            raise FormalRunFatalError(
                "round failure history is not an exact attempt prefix"
            )

        native_journal = getattr(self, "native_run_journal", None)
        if native_journal is not None:
            calls = native_journal.oracle_calls(complete_only=True)
            current_calls = [
                call
                for call in calls
                if call.get("context", {}).get("scope")
                == "optimization_round"
                and call.get("context", {}).get("round") == round_idx
            ]
            if round_idx > 0:
                before = outcome_by_round[round_idx - 1]
            else:
                before = max(
                    (
                        int(call["call_index"])
                        for call in calls
                        if call.get("context", {}).get("scope")
                        == "seed_pool"
                    ),
                    default=0,
                )
            expected_indices = list(
                range(before + 1, before + 1 + len(current_calls))
            )
            if (
                [int(call["call_index"]) for call in current_calls]
                != expected_indices
                or len(current_calls) > int(
                    (getattr(
                        self, "novelty_recovery_protocol", None
                    ) or canonical_novelty_recovery_protocol())[
                        "candidate_cap_per_generator_call"
                    ]
                )
                or any(
                    call.get("record_sha256") is None
                    for call in current_calls
                )
            ):
                raise FormalRunFatalError(
                    "failed round does not bind an exact durable oracle slice"
                )
            after = before + len(current_calls)
            record_hashes = [
                str(call["record_sha256"]) for call in current_calls
            ]
        else:
            before = (
                outcome_by_round[round_idx - 1]
                if round_idx > 0
                else int(fallback_oracle_calls_before)
            )
            after = int(fallback_oracle_calls_after)
            if after < before or after - before > 5:
                raise FormalRunFatalError(
                    "failed round has an invalid oracle-call delta"
                )
            # Non-native exploratory adapters cannot expose publication-row
            # digests.  Preserve cardinality with deterministic non-formal
            # sentinels; every formal validator recomputes physical digests.
            record_hashes = [
                hashlib.sha256(
                    f"non-native:{round_idx}:{call_index}".encode("utf-8")
                ).hexdigest()
                for call_index in range(before + 1, after + 1)
            ]

        error_type = type(error).__name__
        if not error_type.isidentifier():
            error_type = "Exception"
        return {
            "round": int(round_idx),
            "failure_class": "recoverable_round_error",
            "error_type": error_type,
            "oracle_calls_before": int(before),
            "oracle_calls_after": int(after),
            "oracle_record_sha256": record_hashes,
        }

    @staticmethod
    def _encode_numpy_rng_state() -> dict:
        name, keys, pos, has_gauss, cached_gaussian = np.random.get_state()
        return {
            "bit_generator": name,
            "keys": keys.tolist(),
            "position": int(pos),
            "has_gauss": int(has_gauss),
            "cached_gaussian": float(cached_gaussian),
        }

    @staticmethod
    def _restore_numpy_rng_state(state: dict) -> None:
        np.random.set_state((
            state["bit_generator"],
            np.asarray(state["keys"], dtype=np.uint32),
            int(state["position"]),
            int(state["has_gauss"]),
            float(state["cached_gaussian"]),
        ))

    @staticmethod
    def _tuple_tree(value: Any) -> Any:
        if isinstance(value, list):
            return tuple(
                PharmAgentOrchestrator._tuple_tree(item) for item in value
            )
        return value

    def _validate_replayed_native_loop_state(
        self,
        state: dict,
        *,
        evaluation_history: list[dict],
        oracle_complete_count: int,
    ) -> dict[str, Any]:
        """Fail closed unless mutable prompt/loop state is physical replay."""
        curriculum = state.get("curriculum")
        transition_history = (
            curriculum.get("transition_history")
            if isinstance(curriculum, dict)
            else None
        )
        journal = getattr(self, "native_run_journal", None)
        reviewer_responses = (
            journal.completed_llm_responses()
            if journal is not None
            else {}
        )
        try:
            replayed = replay_native_loop_state(
                trajectory=state.get("trajectory"),
                round_failure_history=state.get(
                    "round_failure_history"
                ),
                evaluation_history=evaluation_history,
                seed_smiles=state.get("seed_smiles"),
                target_property=state.get("target_property"),
                stage=state.get("stage"),
                next_round=state.get("next_round"),
                max_rounds=state.get("max_rounds"),
                allowed_active_constraint_names=tuple(
                    self.config.get("admet", {}).get(
                        "admet_constraints", {}
                    )
                ),
                curriculum_transition_history=transition_history,
                oracle_complete_count=oracle_complete_count,
                lagrangian_enabled=self.lagrangian is not None,
                reviewer_enabled=not bool(
                    self.config.get("reviewer", {}).get(
                        "disabled", False
                    )
                ),
                reviewer_responses=reviewer_responses,
                require_reviewer_feedback=True,
                memory_capacity=int(self.memory.max_size),
                alpha=float(self.alpha),
                initial_admet_score=(
                    1.0 if self.objective == "target_only" else 0.0
                ),
            )
        except (PublicRunStateError, ValueError) as error:
            raise FormalRunFatalError(
                "formal native loop state is not physically replayable"
            ) from error

        try:
            validate_native_loop_state_against_replay(state, replayed)
        except PublicRunStateError as error:
            raise FormalRunFatalError(
                "formal native loop state differs from physical replay"
            ) from error
        return replayed

    def _bind_formal_cer_visibility(
        self,
        replayed: dict[str, Any],
        *,
        target_property: str,
        expected_binding: object = None,
    ) -> dict[str, Any] | None:
        """Expose only CER rows proven by committed outer trajectory rows."""
        cer_config = self.config.get("cer", {})
        if not cer_config.get("enabled", False):
            if replayed.get("cer_experience_entries"):
                raise FormalRunFatalError(
                    "formal replay reports CER commits while CER is disabled"
                )
            if expected_binding is not None:
                raise FormalRunFatalError(
                    "formal checkpoint contains disabled CER runtime state"
                )
            return None
        database = getattr(self, "experience_db", None)
        if database is None or not database.persistent:
            raise FormalRunFatalError(
                "formal Chemical-CER requires persistent visibility binding"
            )
        try:
            return database.bind_formal_visible_prefix(
                current_task=target_property,
                current_entries=replayed["cer_experience_entries"],
                expected_binding=expected_binding,
            )
        except (ExperienceDBError, KeyError, TypeError, ValueError) as error:
            raise FormalRunFatalError(
                "formal Chemical-CER visibility is not physically replayable"
            ) from error

    def _save_native_optimizer_state(
        self,
        *,
        stage: str,
        next_round: int,
        seed_smiles: str,
        target_property: str,
        max_rounds: int,
        oracle_budget: int,
        loop_values: dict,
    ) -> None:
        """Persist every mutable optimizer input needed for exact continuation."""
        native_journal = getattr(self, "native_run_journal", None)
        if native_journal is None:
            return
        loop_keys = (
            "current_smiles",
            "best_smiles",
            "best_target_score",
            "best_admet_score",
            "best_combined",
            "reviewer_feedback",
            "stagnation_count",
            "zero_novel_rounds",
            "pending_generation_restart",
            "generation_restart_cursor",
            "failure_count",
            "round_error_count",
            "round_failure_history",
            "consecutive_round_errors",
            "successful_scored_rounds",
            "cer_experiences_committed",
            "best_feasible",
            "near_feasible_anchors",
            "termination_reason",
            "trajectory",
        )
        missing = [key for key in loop_keys if key not in loop_values]
        if missing:
            raise FormalRunFatalError(
                "native optimizer state is missing: " + ", ".join(missing)
            )
        state = {
            "state_schema_version": NATIVE_OPTIMIZER_STATE_SCHEMA_VERSION,
            "stage": stage,
            "seed_smiles": seed_smiles,
            "target_property": target_property,
            "max_rounds": int(max_rounds),
            "oracle_budget": int(oracle_budget),
            "next_round": int(next_round),
            **{key: deepcopy(loop_values[key]) for key in loop_keys},
            "memory_buffer": deepcopy(self.memory.buffer),
            "lagrangian": (
                None
                if self.lagrangian is None
                else self.lagrangian.snapshot_runtime_state()
            ),
            "curriculum": (
                None
                if self.curriculum is None
                else {
                    "current_phase": int(self.curriculum.current_phase),
                    "last_transition": deepcopy(
                        self.curriculum.last_transition
                    ),
                    "transition_history": deepcopy(
                        self.curriculum.transition_history
                    ),
                }
            ),
            "global_seen_canonical": sorted(self._global_seen_canonical),
            "global_seen_initialized": bool(
                self._global_seen_initialized
            ),
            "python_rng_state": random.getstate(),
            "numpy_rng_state": self._encode_numpy_rng_state(),
            "cer_runtime_binding": None,
        }
        if self.require_full_budget:
            evaluation_history = native_journal.evaluation_history()
            oracle_complete_count = native_journal.oracle_complete_count
            replayed = self._validate_replayed_native_loop_state(
                state,
                evaluation_history=evaluation_history,
                oracle_complete_count=oracle_complete_count,
            )
            state["cer_runtime_binding"] = self._bind_formal_cer_visibility(
                replayed,
                target_property=target_property,
            )
            target_only = self.objective == "target_only" or bool(
                self.curriculum is not None
                and self.curriculum.current_phase == 1
            )
            try:
                validate_formal_prompt_reuse_state(
                    state,
                    evaluation_history=evaluation_history[
                        :oracle_complete_count
                    ],
                    target_property=target_property,
                    allowed_active_constraint_names=tuple(
                        self.config.get("admet", {}).get(
                            "admet_constraints", {}
                        )
                    ),
                    target_only=target_only,
                )
            except FormalPromptProtocolError as error:
                raise FormalRunFatalError(
                    "formal optimizer prompt-reuse state is invalid"
                ) from error
        native_journal.save_optimizer_state(state)

    def _restore_native_optimizer_state(
        self,
        persisted: dict,
        *,
        seed_smiles: str,
        target_property: str,
        max_rounds: int,
        oracle_budget: int,
    ) -> dict:
        """Validate and hydrate one identity-bound native optimizer snapshot."""
        state = persisted.get("state")
        expected = {
            "state_schema_version": NATIVE_OPTIMIZER_STATE_SCHEMA_VERSION,
            "seed_smiles": seed_smiles,
            "target_property": target_property,
            "max_rounds": int(max_rounds),
            "oracle_budget": int(oracle_budget),
        }
        if not isinstance(state, dict) or any(
            state.get(key) != value for key, value in expected.items()
        ):
            raise FormalRunFatalError(
                "native optimizer checkpoint protocol/input mismatch"
            )
        stage = state.get("stage")
        if stage not in {"round_pending", "ready", "terminal"}:
            raise FormalRunFatalError(
                "native optimizer checkpoint has an invalid stage"
            )
        round_failure_history = state.get("round_failure_history")
        round_error_count = state.get("round_error_count")
        if (
            not isinstance(round_failure_history, list)
            or isinstance(round_error_count, bool)
            or not isinstance(round_error_count, int)
            or round_error_count != len(round_failure_history)
        ):
            raise FormalRunFatalError(
                "native checkpoint has invalid round failure history"
            )
        if stage in {"round_pending", "ready"}:
            outcome_rounds = sorted(
                {
                    int(row["round"])
                    for row in state.get("trajectory", [])
                    if isinstance(row, dict) and "round" in row
                }
                | {
                    int(event["round"])
                    for event in round_failure_history
                    if isinstance(event, dict) and "round" in event
                }
            )
            if outcome_rounds != list(range(int(state["next_round"]))):
                raise FormalRunFatalError(
                    "native checkpoint outcomes do not match next_round"
                )
        evaluation_history = self.native_run_journal.evaluation_history()
        saved_oracle_complete = int(persisted["oracle_complete_count"])
        saved_llm_complete = int(persisted["llm_complete_count"])
        if self.require_full_budget:
            replayed = self._validate_replayed_native_loop_state(
                state,
                evaluation_history=evaluation_history,
                oracle_complete_count=saved_oracle_complete,
            )
            persisted_cer_binding = state.get("cer_runtime_binding")
            if (
                self.config.get("cer", {}).get("enabled", False)
                and not isinstance(persisted_cer_binding, dict)
            ):
                raise FormalRunFatalError(
                    "formal checkpoint omitted exact CER runtime binding"
                )
            self._bind_formal_cer_visibility(
                replayed,
                target_property=target_property,
                expected_binding=persisted_cer_binding,
            )
            curriculum_state = state.get("curriculum")
            target_only = self.objective == "target_only" or bool(
                isinstance(curriculum_state, dict)
                and curriculum_state.get("current_phase") == 1
            )
            try:
                validate_formal_prompt_reuse_state(
                    state,
                    evaluation_history=evaluation_history[
                        :saved_oracle_complete
                    ],
                    target_property=target_property,
                    allowed_active_constraint_names=tuple(
                        self.config.get("admet", {}).get(
                            "admet_constraints", {}
                        )
                    ),
                    target_only=target_only,
                )
            except FormalPromptProtocolError as error:
                raise FormalRunFatalError(
                    "native checkpoint has invalid formal prompt-reuse state"
                ) from error
        near_feasible_result = {
            "near_feasible_repair_protocol": (
                canonical_near_feasible_repair_protocol()
            ),
            "trajectory": state.get("trajectory"),
            "best_feasible": state.get("best_feasible"),
            "near_feasible_anchors": state.get("near_feasible_anchors"),
            "evaluation_history": evaluation_history,
        }
        if not validate_near_feasible_repair_result(
            near_feasible_result,
            require_evaluation_history_binding=bool(
                self.require_full_budget
            ),
        ):
            raise FormalRunFatalError(
                "native checkpoint has invalid near-feasible repair state"
            )
        current_oracle_complete = self.native_run_journal.oracle_complete_count
        current_llm_complete = self.native_run_journal.llm_request_counts().get(
            "complete", 0
        )
        if (
            current_oracle_complete < saved_oracle_complete
            or current_llm_complete < saved_llm_complete
            or (
                stage != "round_pending"
                and (
                    current_oracle_complete != saved_oracle_complete
                    or current_llm_complete != saved_llm_complete
                )
            )
        ):
            raise FormalRunFatalError(
                "native event trace is incompatible with optimizer checkpoint"
            )

        if self.novelty_recovery_enabled:
            novelty_checkpoint = {
                "novelty_recovery_protocol": (
                    canonical_novelty_recovery_protocol()
                ),
                "trajectory": state.get("trajectory"),
                "round_error_count": state.get("round_error_count"),
                "round_failure_history": state.get(
                    "round_failure_history"
                ),
                "oracle_budget": int(state["oracle_budget"]),
                "evaluation_history": evaluation_history[
                    :saved_oracle_complete
                ],
            }
            try:
                expected_global_seen = replay_novelty_recovery_lineage(
                    novelty_checkpoint,
                    require_evaluation_history_binding=True,
                    expected_reviewer_enabled=not bool(
                        self.config.get("reviewer", {}).get(
                            "disabled", False
                        )
                    ),
                    allow_pending_round=(
                        int(state["next_round"])
                        if stage == "round_pending"
                        else None
                    ),
                    expected_next_round=(
                        int(state["next_round"])
                        if stage in {"round_pending", "ready"}
                        else None
                    ),
                )
            except NoveltyRecoveryProtocolError as error:
                raise FormalRunFatalError(
                    "native checkpoint has invalid novelty lineage"
                ) from error
            persisted_global_seen = state.get("global_seen_canonical")
            if (
                state.get("global_seen_initialized") is not True
                or not isinstance(persisted_global_seen, list)
                or persisted_global_seen != sorted(persisted_global_seen)
                or len(persisted_global_seen)
                != len(set(persisted_global_seen))
                or persisted_global_seen != expected_global_seen
            ):
                raise FormalRunFatalError(
                    "native checkpoint global-seen state does not match "
                    "the exact novelty lineage"
                )

        self.memory.buffer[:] = deepcopy(state["memory_buffer"])
        if self.lagrangian is not None:
            if state.get("lagrangian") is None:
                raise FormalRunFatalError(
                    "native checkpoint omitted enabled Lagrangian state"
                )
            if self.require_full_budget and not self._validate_native_lagrangian_state(
                state["lagrangian"],
                outer_trajectory=state["trajectory"],
                round_failure_history=state["round_failure_history"],
                evaluation_history=near_feasible_result[
                    "evaluation_history"
                ],
                next_round=state["next_round"],
                stage=stage,
                curriculum_state=state.get("curriculum"),
                stagnation_count=state.get("stagnation_count"),
            ):
                raise FormalRunFatalError(
                    "native checkpoint has invalid Lagrangian runtime state"
                )
            self.lagrangian.restore_runtime_state(state["lagrangian"])
        elif state.get("lagrangian") is not None:
            raise FormalRunFatalError(
                "native checkpoint contains disabled Lagrangian state"
            )
        if self.curriculum is not None:
            curriculum = state.get("curriculum")
            if not isinstance(curriculum, dict):
                raise FormalRunFatalError(
                    "native checkpoint omitted enabled curriculum state"
                )
            self.curriculum.current_phase = int(curriculum["current_phase"])
            self.curriculum.last_transition = deepcopy(
                curriculum.get("last_transition")
            )
            self.curriculum.transition_history = deepcopy(
                curriculum["transition_history"]
            )
        elif state.get("curriculum") is not None:
            raise FormalRunFatalError(
                "native checkpoint contains disabled curriculum state"
            )
        self._global_seen_canonical = set(state["global_seen_canonical"])
        self._global_seen_initialized = bool(
            state["global_seen_initialized"]
        )
        if self.novelty_recovery_enabled:
            # The durable event trace can be ahead of a pre-round optimizer
            # snapshot after a hard crash.  Reconcile it deterministically;
            # the next optimizer save will persist this exact expanded set.
            self._reconcile_global_seen_from_oracle_trace(
                self.native_run_journal
            )
            self._derive_pending_same_round_trace(
                trajectory=state.get("trajectory"),
                round_failure_history=state.get("round_failure_history"),
                next_round=int(state["next_round"]),
                stage=stage,
            )
        random.setstate(self._tuple_tree(state["python_rng_state"]))
        self._restore_numpy_rng_state(state["numpy_rng_state"])
        restored = deepcopy(state)
        if stage == "terminal":
            restored["next_round"] = max_rounds
        return restored

    @staticmethod
    def _validate_native_lagrangian_state(
        value: object,
        *,
        outer_trajectory: object,
        round_failure_history: object,
        evaluation_history: object,
        next_round: object,
        stage: object,
        curriculum_state: object,
        stagnation_count: object,
    ) -> bool:
        """Validate a formal runtime snapshot before mutating live state."""
        if not isinstance(value, dict) or set(value) != {
            "lambdas",
            "rho",
            "trajectory",
            "transition_events",
            "active_constraint_names",
            "pending_transition_events",
        }:
            return False
        if (
            isinstance(next_round, bool)
            or not isinstance(next_round, int)
            or next_round < 0
            or stage not in {"round_pending", "ready", "terminal"}
            or not isinstance(curriculum_state, dict)
            or isinstance(stagnation_count, bool)
            or not isinstance(stagnation_count, int)
            or stagnation_count < 0
            or set(curriculum_state) != {
                "current_phase",
                "last_transition",
                "transition_history",
            }
        ):
            return False
        full = CANONICAL_FULL_ADMET_CONSTRAINTS
        easy = full[:4]
        lambdas = value.get("lambdas")
        rho = value.get("rho")
        dual_trajectory = value.get("trajectory")
        transition_events = value.get("transition_events")
        pending_events = value.get("pending_transition_events")
        active_names = value.get("active_constraint_names")
        if (
            not isinstance(lambdas, dict)
            or set(lambdas) != set(full)
            or any(
                isinstance(item, bool)
                or not isinstance(item, (int, float))
                or not math.isfinite(float(item))
                or float(item) < 0.0
                for item in lambdas.values()
            )
            or isinstance(rho, bool)
            or not isinstance(rho, (int, float))
            or not math.isfinite(float(rho))
            or not 1.0 <= float(rho) <= 100.0
            or not isinstance(dual_trajectory, list)
            or not isinstance(transition_events, list)
            or not isinstance(pending_events, list)
            or not isinstance(active_names, (list, tuple))
            or tuple(active_names) not in {(), easy, full}
            or len(pending_events) > len(transition_events)
            or (
                pending_events
                and transition_events[-len(pending_events):]
                != pending_events
            )
            or (stage == "terminal" and bool(pending_events))
        ):
            return False

        if not validate_curriculum_lagrangian_evidence(
            trajectory=outer_trajectory,
            round_failure_history=round_failure_history,
            curriculum_transition_history=curriculum_state.get(
                "transition_history"
            ),
            final_stagnation_count=stagnation_count,
            lagrangian_transition_events=transition_events,
            require_terminal=stage == "terminal",
            expected_next_round=(
                int(next_round) if stage != "terminal" else None
            ),
        ):
            return False

        outer_by_round: dict[int, dict] = {}
        previous_outer_round = -1
        previous_outer_oracle_calls = 0
        if not isinstance(outer_trajectory, list):
            return False
        for outer in outer_trajectory:
            if not isinstance(outer, dict):
                return False
            outer_round = outer.get("round")
            outer_active = outer.get("active_constraints")
            n_candidates = outer.get("n_candidates")
            oracle_calls = outer.get("oracle_calls")
            candidate_improves = outer.get("candidate_improves")
            if (
                isinstance(outer_round, bool)
                or not isinstance(outer_round, int)
                or outer_round < 0
                or outer_round <= previous_outer_round
                or outer_round >= next_round
                or outer_round in outer_by_round
                or not isinstance(outer_active, list)
                or tuple(outer_active) not in {(), easy, full}
                or isinstance(n_candidates, bool)
                or not isinstance(n_candidates, int)
                or n_candidates < 0
                or isinstance(oracle_calls, bool)
                or not isinstance(oracle_calls, int)
                or oracle_calls < previous_outer_oracle_calls
                or oracle_calls > len(evaluation_history)
                or not isinstance(candidate_improves, bool)
                or (n_candidates == 0 and candidate_improves)
            ):
                return False
            outer_by_round[outer_round] = outer
            previous_outer_round = outer_round
            previous_outer_oracle_calls = oracle_calls

        phase = curriculum_state.get("current_phase")
        curriculum_history = curriculum_state.get("transition_history")
        last_transition = curriculum_state.get("last_transition")
        if (
            isinstance(phase, bool)
            or not isinstance(phase, int)
            or not isinstance(curriculum_history, list)
            or len(curriculum_history) > 2
            or phase != 1 + len(curriculum_history)
        ):
            return False
        expected_from_phase = 1
        previous_curriculum_round = -1
        curriculum_by_round: dict[int, dict] = {}
        for transition in curriculum_history:
            if not isinstance(transition, dict) or set(transition) != {
                "event",
                "round",
                "from_phase",
                "to_phase",
                "reasons",
                "incoming_stagnation_count",
            }:
                return False
            transition_round = transition.get("round")
            incoming_stagnation = transition.get(
                "incoming_stagnation_count"
            )
            reasons = transition.get("reasons")
            boundary = 20 if expected_from_phase == 1 else 60
            if (
                transition.get("event")
                != "curriculum_phase_transition"
                or transition.get("from_phase") != expected_from_phase
                or transition.get("to_phase") != expected_from_phase + 1
                or isinstance(transition_round, bool)
                or not isinstance(transition_round, int)
                or transition_round != boundary
                or transition_round <= previous_curriculum_round
                or transition_round >= next_round
                or isinstance(incoming_stagnation, bool)
                or not isinstance(incoming_stagnation, int)
                or incoming_stagnation < 0
                or reasons != ["round_boundary"]
            ):
                return False
            curriculum_by_round[transition_round] = transition
            previous_curriculum_round = transition_round
            expected_from_phase += 1
        if (
            (not curriculum_history and last_transition is not None)
            or (
                curriculum_history
                and last_transition is not None
                and last_transition != curriculum_history[-1]
            )
        ):
            return False
        seen_outer_curriculum_rounds: set[int] = set()
        for outer in outer_trajectory:
            outer_transition = outer.get("curriculum_transition")
            outer_round = int(outer["round"])
            if outer_transition is None:
                if outer_round in curriculum_by_round:
                    return False
                continue
            if (
                outer_round in seen_outer_curriculum_rounds
                or curriculum_by_round.get(outer_round)
                != outer_transition
            ):
                return False
            seen_outer_curriculum_rounds.add(outer_round)

        # Deterministically replay the phase-local stagnation input used by
        # the scheduler.  Failed rounds are absent from the outer trajectory
        # and leave this counter unchanged, except that a failed transition
        # still clears old-phase evidence exactly as optimize() does.
        replayed_stagnation = 0
        for round_idx in sorted(
            set(outer_by_round) | set(curriculum_by_round)
        ):
            transition = curriculum_by_round.get(round_idx)
            if transition is not None:
                if transition["incoming_stagnation_count"] != replayed_stagnation:
                    return False
                boundary = 20 if transition["from_phase"] == 1 else 60
                if (
                    round_idx != boundary
                    or transition["reasons"] != ["round_boundary"]
                ):
                    return False
                replayed_stagnation = 0
            outer = outer_by_round.get(round_idx)
            if outer is not None:
                near_audit = outer.get("near_feasible_audit")
                expected_phase_stagnation = (
                    0 if transition is not None else replayed_stagnation
                )
                if (
                    not isinstance(near_audit, dict)
                    or isinstance(
                        near_audit.get("phase_stagnation_count"), bool
                    )
                    or not isinstance(
                        near_audit.get("phase_stagnation_count"), int
                    )
                    or near_audit["phase_stagnation_count"]
                    != expected_phase_stagnation
                ):
                    return False
                replayed_stagnation = (
                    0
                    if outer["candidate_improves"]
                    else replayed_stagnation + 1
                )
        if replayed_stagnation != stagnation_count:
            return False

        # Lagrangian active-set expansions are an ordered prefix of durable
        # curriculum transitions.  Catch-up may happen in a later round, but
        # the curriculum can be ahead by at most one phase because the
        # scheduler advances at most one phase per call.
        if (
            len(transition_events) > len(curriculum_history)
            or len(curriculum_history) - len(transition_events) > 1
        ):
            return False
        for index, lagrangian_event in enumerate(transition_events):
            curriculum_event = curriculum_history[index]
            lagrangian_round = (
                lagrangian_event.get("round")
                if isinstance(lagrangian_event, dict)
                else None
            )
            if (
                isinstance(lagrangian_round, bool)
                or not isinstance(lagrangian_round, int)
                or lagrangian_round < curriculum_event["round"]
                or lagrangian_event.get("previous_active_constraints")
                != ([] if index == 0 else list(easy))
                or lagrangian_event.get("active_constraints")
                != (list(easy) if index == 0 else list(full))
            ):
                return False
        if len(curriculum_history) == len(transition_events) + 1:
            if stage == "terminal":
                return False
            missing_transition_round = curriculum_history[-1]["round"]
            if any(
                int(outer["round"]) >= missing_transition_round
                for outer in outer_trajectory
            ):
                return False

        committed_events = transition_events[
            :len(transition_events) - len(pending_events)
            if pending_events else len(transition_events)
        ]
        from pharmagent.evaluation.oracle_utils import (
            _has_formal_rho_trajectory,
        )

        committed_outer_trajectory = outer_trajectory
        if pending_events:
            first_pending_round = pending_events[0].get("round")
            if (
                isinstance(first_pending_round, bool)
                or not isinstance(first_pending_round, int)
            ):
                return False
            # Any scored constrained round consumes every pending active-set
            # event in update_duals().  Therefore a durable snapshot that
            # still carries pending events can contain only zero-candidate
            # completed rounds from the first pending expansion onward.
            if any(
                outer.get("n_candidates") != 0
                for outer in outer_trajectory
                if outer.get("round") >= first_pending_round
            ):
                return False
            committed_outer_trajectory = [
                outer
                for outer in outer_trajectory
                if outer.get("round") < first_pending_round
            ]
        if not _has_formal_rho_trajectory({
            "lagrangian_trajectory": dual_trajectory,
            "lagrangian_transition_events": committed_events,
            "trajectory": committed_outer_trajectory,
            "evaluation_history": evaluation_history,
        }):
            return False
        if dual_trajectory:
            last_dual = dual_trajectory[-1]
            expected_lambdas = last_dual["lambdas"]
            expected_rho = float(last_dual["rho"])
            expected_active = tuple(last_dual["active_constraints"])
        else:
            if committed_events:
                return False
            expected_lambdas = {name: 0.0 for name in full}
            expected_rho = 1.0
            expected_active = ()
        if any(
            not math.isclose(
                float(lambdas[name]),
                float(expected_lambdas[name]),
                abs_tol=1e-12,
            )
            for name in full
        ):
            return False

        previous_transition_round = (
            int(committed_events[-1]["round"])
            if committed_events else -1
        )
        pending_initial_active = expected_active
        for event in pending_events:
            if not isinstance(event, dict):
                return False
            next_active = event.get("active_constraints")
            event_round = event.get("round")
            retained = event.get("lambdas_retained")
            rho_before = event.get("rho_before_transition")
            bound_outer = (
                outer_by_round.get(event_round)
                if isinstance(event_round, int)
                and not isinstance(event_round, bool)
                else None
            )
            expected_curriculum_transition = (
                (1, 2) if tuple(expected_active) == () else (2, 3)
            )
            curriculum_transition = (
                bound_outer.get("curriculum_transition")
                if isinstance(bound_outer, dict)
                else None
            )
            same_round_curriculum_transition = bool(
                isinstance(curriculum_transition, dict)
                and curriculum_transition.get("round") == event_round
                and (
                    curriculum_transition.get("from_phase"),
                    curriculum_transition.get("to_phase"),
                )
                == expected_curriculum_transition
            )
            catch_up_after_failed_transition = bool(
                curriculum_transition is None
                and not isinstance(event_round, bool)
                and isinstance(event_round, int)
                and event_round > 0
                # A failed transition round advances the curriculum but is
                # deliberately absent from the committed outer trajectory.
                # The next successful zero-candidate round may therefore
                # persist Lagrangian catch-up without its own curriculum
                # transition marker.  Replay the pending active-set chain and
                # check the final phase below instead of comparing every
                # event with the final curriculum phase.
                and (event_round - 1) not in outer_by_round
            )
            if (
                not isinstance(next_active, list)
                or tuple(next_active) not in {easy, full}
                or not set(expected_active) < set(next_active)
                or event.get("event") != "active_set_expansion"
                or event.get("previous_active_constraints")
                != list(expected_active)
                or event.get("added_constraints")
                != [
                    name for name in next_active
                    if name not in expected_active
                ]
                or event.get("removed_constraints") != []
                or event.get("rho_reset") is not True
                or isinstance(rho_before, bool)
                or not isinstance(rho_before, (int, float))
                or not math.isfinite(float(rho_before))
                or not math.isclose(
                    float(rho_before),
                    expected_rho,
                    abs_tol=1e-12,
                )
                or event.get("rho_after_transition") != 1.0
                or isinstance(event_round, bool)
                or not isinstance(event_round, int)
                or event_round <= previous_transition_round
                or event_round >= next_round
                or not isinstance(retained, dict)
                or retained != lambdas
                or not isinstance(bound_outer, dict)
                or bound_outer.get("active_constraints") != next_active
                or bound_outer.get("n_candidates") != 0
                or not (
                    same_round_curriculum_transition
                    or catch_up_after_failed_transition
                )
            ):
                return False
            expected_active = tuple(next_active)
            expected_rho = 1.0
            previous_transition_round = event_round

        if pending_events:
            pending_active_by_round = {
                int(event["round"]): tuple(event["active_constraints"])
                for event in pending_events
            }
            replayed_active = pending_initial_active
            for outer in outer_trajectory:
                outer_round = int(outer["round"])
                if outer_round < int(pending_events[0]["round"]):
                    continue
                event_active = pending_active_by_round.get(outer_round)
                if event_active is not None:
                    replayed_active = event_active
                elif outer.get("curriculum_transition") is not None:
                    # A curriculum expansion without a matching pending
                    # Lagrangian expansion is not an exact resumable state.
                    return False
                if tuple(outer["active_constraints"]) != replayed_active:
                    return False
        if (
            tuple(active_names) != expected_active
            or not math.isclose(float(rho), expected_rho, abs_tol=1e-12)
        ):
            return False

        phase_active = {1: (), 2: easy, 3: full}.get(phase)
        if phase_active is None:
            return False
        if tuple(active_names) == phase_active:
            return len(curriculum_history) == len(transition_events)

        # A failed transition round is absent from the outer trajectory and
        # may leave the curriculum exactly one phase ahead of the round-atomic
        # Lagrangian state.  The append-only transition history above proves
        # when that advance occurred; ``last_transition`` is an ephemeral
        # scheduler field and is not used to validate replay.
        expected_next_active = (
            easy if tuple(active_names) == () else full
        )
        return (
            phase_active == expected_next_active
            and len(curriculum_history) == len(transition_events) + 1
        )

    def _snapshot_round_mutable_state(self) -> dict:
        """Snapshot internal state that must not survive a failed round."""
        lagrangian_state = None
        if self.lagrangian is not None:
            lagrangian_state = self.lagrangian.snapshot_runtime_state()
        return {
            "memory_buffer": list(self.memory.buffer),
            "lagrangian": lagrangian_state,
            "global_seen_canonical": set(
                getattr(self, "_global_seen_canonical", set())
            ),
            "global_seen_initialized": bool(
                getattr(self, "_global_seen_initialized", False)
            ),
            "pending_same_round_trace": deepcopy(
                getattr(self, "_pending_same_round_trace", [])
            ),
            "pending_same_round_consumed": int(
                getattr(self, "_pending_same_round_consumed", 0)
            ),
        }

    def _restore_round_mutable_state(self, state: dict) -> None:
        """Roll back internal state while retaining external oracle calls."""
        self.memory.buffer[:] = state["memory_buffer"]
        self._global_seen_canonical = set(state["global_seen_canonical"])
        self._global_seen_initialized = bool(
            state["global_seen_initialized"]
        )
        self._pending_same_round_trace = deepcopy(
            state["pending_same_round_trace"]
        )
        self._pending_same_round_consumed = int(
            state["pending_same_round_consumed"]
        )
        if self.lagrangian is not None and state["lagrangian"] is not None:
            self.lagrangian.restore_runtime_state(state["lagrangian"])

    def _call_oracle(self, oracle: Any, smiles: str) -> float:
        """Call the oracle to score a molecule. Handles different oracle interfaces."""
        try:
            result = oracle(smiles)
            if isinstance(result, (list, tuple)):
                result = result[0] if result else 0.0
            score = float(result)
            if not math.isfinite(score):
                raise ValueError("oracle returned a non-finite score")
            return score
        except Exception as e:
            if self.require_full_budget:
                raise FormalRunFatalError(
                    f"Formal oracle scoring failed for {smiles}: "
                    f"{type(e).__name__}"
                ) from e
            logger.warning("Oracle call failed for %s: %s", smiles, e)
            return 0.0

    def _is_budget_exhausted(self, oracle: Any, current_calls: int,
                              budget: int) -> bool:
        """Check if the oracle budget is exhausted."""
        current_calls = self._current_oracle_call_count(oracle, current_calls)
        # Check PMO oracle's built-in finish flag
        if hasattr(oracle, "finish") and oracle.finish:
            return True
        return current_calls >= budget

    @staticmethod
    def _current_oracle_call_count(oracle: Any, fallback: int) -> int:
        """Read a tracked oracle's authoritative unique-call count."""
        if not hasattr(oracle, "call_count"):
            return fallback
        value = getattr(oracle, "call_count")
        if isinstance(value, bool):
            return fallback
        try:
            count = int(value)
        except (TypeError, ValueError):
            return fallback
        return count if count >= 0 else fallback

    def _oracle_call_count_after_call(self, oracle: Any, previous: int) -> int:
        """Sync after a call, incrementing locally only for untracked oracles."""
        if hasattr(oracle, "call_count"):
            return self._current_oracle_call_count(oracle, previous)
        return previous + 1

    def _mask_admet_result(
        self,
        admet_result: dict,
        active_constraints: dict,
    ) -> dict:
        """Return an analyst result scored only against active constraints."""
        masked = dict(admet_result)
        predictions = {
            **admet_result.get("admet_predictions", {}),
            **admet_result.get("descriptors", {}),
        }
        violations = self.admet_analyst._check_constraints(
            predictions, active_constraints
        )
        assess_constraints = getattr(
            self.admet_analyst, "_assess_constraints", None
        )
        masked["constraint_assessments"] = (
            assess_constraints(predictions, active_constraints)
            if callable(assess_constraints)
            else deepcopy(admet_result.get("constraint_assessments", []))
        )
        masked["violations"] = violations
        masked["admet_score"] = self.admet_analyst._compute_admet_score(
            predictions, active_constraints
        )
        masked["pass_all"] = not violations
        masked["active_constraints"] = list(active_constraints)
        # Formal online contexts expose only explicitly active constraint
        # endpoints in every phase.  Phase 3 must not reintroduce unregistered
        # or monitoring-only predictions merely because all seven registered
        # constraints are now active.
        active_profile = self.admet_analyst._build_admet_profile(
            predictions,
            violations,
            active_constraints=active_constraints,
            mask_inactive=True,
        )
        masked["admet_profile"] = {
            category: details
            for category, details in active_profile.items()
            if details.get("active_constraints")
        }
        return masked

    def _format_admet_summary(
        self,
        admet_result: dict,
        active_constraints: dict | None = None,
    ) -> str:
        """Format only the active ADMET constraints for prompt injection."""
        if not admet_result or admet_result.get("error"):
            return "ADMET evaluation not available."

        constraints = (
            self.config.get("admet", {}).get("admet_constraints", {})
            if active_constraints is None
            else active_constraints
        )
        if not constraints:
            return "ADMET constraints are inactive in this target-only phase."

        masked = self._mask_admet_result(admet_result, constraints)
        predictions = {
            **admet_result.get("admet_predictions", {}),
            **admet_result.get("descriptors", {}),
        }
        parts = [f"Active-constraint ADMET score: {masked['admet_score']:.2f}"]
        for name in constraints:
            value = self.admet_analyst._get_prediction_value(predictions, name)
            parts.append(f"{name}={'unavailable' if value is None else value}")

        violations = masked["violations"]
        if violations:
            viol_names = [v.get("name", "?") for v in violations]
            parts.append(f"Violations: {', '.join(viol_names)}")
        else:
            parts.append("All active constraints passed")

        return "; ".join(parts)
